//+------------------------------------------------------------------+
//|                                       ExMachina_SuperTrend.mq5   |
//|                          Copyright 2026, ExMachina Trading Systems|
//|                   https://www.mql5.com/en/users/williammukam      |
//+------------------------------------------------------------------+
//|  ExMachina SuperTrend — Precision before profit                   |
//|  ATR-based trend-following indicator with dynamic coloring,       |
//|  directional arrows, dashboard panel, and multi-alert system.     |
//+------------------------------------------------------------------+
#property copyright   "ExMachina Trading Systems"
#property link        "https://www.mql5.com/en/users/williammukam"
#property version     "1.00"
#property description "ExMachina SuperTrend — ATR-based trend indicator"
#property description "Dynamic color line, signal arrows, on-chart dashboard"
#property description "Push, Email, Popup & Sound alerts on trend change"
#property description "Precision before profit."
#property indicator_chart_window
#property indicator_buffers 7
#property indicator_plots   3
#property strict

//--- Plot 0: SuperTrend line (bullish segments)
#property indicator_label1  "SuperTrend Bull"
#property indicator_type1   DRAW_LINE
#property indicator_color1  clrLime
#property indicator_style1  STYLE_SOLID
#property indicator_width1  2

//--- Plot 1: SuperTrend line (bearish segments)
#property indicator_label2  "SuperTrend Bear"
#property indicator_type2   DRAW_LINE
#property indicator_color2  clrRed
#property indicator_style2  STYLE_SOLID
#property indicator_width2  2

//--- Plot 2: Signal arrows
#property indicator_label3  "Signal"
#property indicator_type3   DRAW_COLOR_ARROW
#property indicator_color3  clrLime,clrRed
#property indicator_width3  3

//+------------------------------------------------------------------+
//| Enumerations                                                      |
//+------------------------------------------------------------------+
enum ENUM_ATR_MODE
  {
   ATR_STANDARD = 0,   // Standard ATR
   ATR_SMA      = 1,   // SMA-based ATR
   ATR_EMA      = 2    // EMA-based ATR
  };

//+------------------------------------------------------------------+
//| Input Parameters                                                  |
//+------------------------------------------------------------------+
input group           "══════ SuperTrend Settings ══════"
input int             InpPeriod        = 10;          // ATR Period
input double          InpMultiplier    = 3.0;         // ATR Multiplier
input ENUM_ATR_MODE   InpATRMode       = ATR_STANDARD;// ATR Calculation Mode

input group           "══════ Visual Settings ══════"
input color           InpBullColor     = C'0,185,140';  // Bullish Color
input color           InpBearColor     = C'220,50,80';  // Bearish Color
input int             InpLineWidth     = 2;             // Line Width
input bool            InpShowArrows    = true;          // Show Signal Arrows
input int             InpArrowSize     = 3;             // Arrow Size (1-5)
input bool            InpShowDashboard = true;          // Show Dashboard Panel

input group           "══════ Alert Settings ══════"
input bool            InpAlertPopup    = true;        // Popup Alert
input bool            InpAlertSound    = true;        // Sound Alert
input string          InpAlertSoundFile= "alert.wav"; // Sound File
input bool            InpAlertEmail    = false;       // Email Alert
input bool            InpAlertPush     = false;       // Push Notification

input group           "══════ Dashboard Settings ══════"
input int             InpDashX         = 20;          // Dashboard X Position
input int             InpDashY         = 40;          // Dashboard Y Position
input int             InpDashFontSize  = 9;           // Dashboard Font Size
input color           InpDashBgColor   = C'8,10,18';  // Dashboard Background
input color           InpDashTextColor = C'160,168,180';// Dashboard Text Color

//+------------------------------------------------------------------+
//| Global Variables                                                   |
//+------------------------------------------------------------------+
//--- Indicator buffers
double BuffBull[];       // Plot 0: bullish SuperTrend line
double BuffBear[];       // Plot 1: bearish SuperTrend line
double BuffArrow[];      // Plot 2: arrow values
double BuffArrowClr[];   // Plot 2: arrow color index
double BuffUpperBand[];  // Internal: upper band
double BuffLowerBand[];  // Internal: lower band
double BuffDirection[];  // Internal: 1=bull, -1=bear

//--- Alert management
datetime g_lastAlertTime = 0;
string   g_objPrefix     = "EXSS_ST_";

//+------------------------------------------------------------------+
//| Custom indicator initialization function                          |
//+------------------------------------------------------------------+
int OnInit()
  {
//--- Validate inputs
   if(InpPeriod < 1)
     {
      Print("ExMachina SuperTrend: ATR Period must be >= 1. Using 10.");
     }
   if(InpMultiplier <= 0)
     {
      Print("ExMachina SuperTrend: Multiplier must be > 0. Using 3.0.");
     }

//--- Set indicator buffers
   SetIndexBuffer(0, BuffBull,      INDICATOR_DATA);
   SetIndexBuffer(1, BuffBear,      INDICATOR_DATA);
   SetIndexBuffer(2, BuffArrow,     INDICATOR_DATA);
   SetIndexBuffer(3, BuffArrowClr,  INDICATOR_COLOR_INDEX);
   SetIndexBuffer(4, BuffUpperBand, INDICATOR_CALCULATIONS);
   SetIndexBuffer(5, BuffLowerBand, INDICATOR_CALCULATIONS);
   SetIndexBuffer(6, BuffDirection, INDICATOR_CALCULATIONS);

//--- Set empty values
   PlotIndexSetDouble(0, PLOT_EMPTY_VALUE, EMPTY_VALUE);
   PlotIndexSetDouble(1, PLOT_EMPTY_VALUE, EMPTY_VALUE);
   PlotIndexSetDouble(2, PLOT_EMPTY_VALUE, EMPTY_VALUE);

//--- Arrow codes
   PlotIndexSetInteger(2, PLOT_ARROW, 233);  // up arrow base, colored

//--- Plot visual settings
   PlotIndexSetInteger(0, PLOT_LINE_COLOR, InpBullColor);
   PlotIndexSetInteger(0, PLOT_LINE_WIDTH, InpLineWidth);
   PlotIndexSetInteger(1, PLOT_LINE_COLOR, InpBearColor);
   PlotIndexSetInteger(1, PLOT_LINE_WIDTH, InpLineWidth);
   PlotIndexSetInteger(2, PLOT_LINE_WIDTH, InpArrowSize);
   PlotIndexSetInteger(2, PLOT_COLOR_INDEXES, 2);
   PlotIndexSetInteger(2, PLOT_LINE_COLOR, 0, InpBullColor);
   PlotIndexSetInteger(2, PLOT_LINE_COLOR, 1, InpBearColor);

//--- Indicator name
   string shortName = "ExMachina SuperTrend(" + IntegerToString(MathMax(InpPeriod,1)) + ", " +
                      DoubleToString(MathMax(InpMultiplier,0.1), 1) + ")";
   IndicatorSetString(INDICATOR_SHORTNAME, shortName);
   IndicatorSetInteger(INDICATOR_DIGITS, _Digits);

//--- Dashboard
   if(InpShowDashboard)
      CreateDashboard();

   return(INIT_SUCCEEDED);
  }

//+------------------------------------------------------------------+
//| Custom indicator deinitialization function                        |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   ObjectsDeleteAll(0, g_objPrefix);
   ChartRedraw(0);
  }

//+------------------------------------------------------------------+
//| Custom indicator iteration function                               |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
   int period = MathMax(InpPeriod, 1);
   double multiplier = MathMax(InpMultiplier, 0.1);

   if(rates_total < period + 1)
      return(0);

//--- Determine start position
   int start;
   if(prev_calculated == 0)
     {
      start = period;
      //--- Initialize buffers
      for(int i = 0; i < period; i++)
        {
         BuffBull[i]      = EMPTY_VALUE;
         BuffBear[i]      = EMPTY_VALUE;
         BuffArrow[i]     = EMPTY_VALUE;
         BuffArrowClr[i]  = 0;
         BuffUpperBand[i] = 0;
         BuffLowerBand[i] = 0;
         BuffDirection[i] = 1;
        }
     }
   else
      start = prev_calculated - 1;

//--- Main calculation loop
   for(int i = start; i < rates_total; i++)
     {
      //--- Calculate ATR
      double atr = CalcATR(high, low, close, i, period, rates_total);

      //--- Calculate basic bands
      double median   = (high[i] + low[i]) / 2.0;
      double basicUp  = median + multiplier * atr;
      double basicDn  = median - multiplier * atr;

      //--- Final upper band: if basic < prev final OR prev close > prev final => use basic, else keep prev
      if(i == period)
        {
         BuffUpperBand[i] = basicUp;
         BuffLowerBand[i] = basicDn;
         BuffDirection[i] = (close[i] > basicUp) ? 1 : -1;
        }
      else
        {
         //--- Upper band logic
         if(basicUp < BuffUpperBand[i-1] || close[i-1] > BuffUpperBand[i-1])
            BuffUpperBand[i] = basicUp;
         else
            BuffUpperBand[i] = BuffUpperBand[i-1];

         //--- Lower band logic
         if(basicDn > BuffLowerBand[i-1] || close[i-1] < BuffLowerBand[i-1])
            BuffLowerBand[i] = basicDn;
         else
            BuffLowerBand[i] = BuffLowerBand[i-1];

         //--- Direction logic
         double prevDir = BuffDirection[i-1];
         if(prevDir == -1 && close[i] > BuffUpperBand[i])
            BuffDirection[i] = 1;   // flip to bullish
         else if(prevDir == 1 && close[i] < BuffLowerBand[i])
            BuffDirection[i] = -1;  // flip to bearish
         else
            BuffDirection[i] = prevDir;
        }

      //--- Assign plot values
      if(BuffDirection[i] == 1)
        {
         BuffBull[i] = BuffLowerBand[i];
         BuffBear[i] = EMPTY_VALUE;
        }
      else
        {
         BuffBear[i] = BuffUpperBand[i];
         BuffBull[i] = EMPTY_VALUE;
        }

      //--- Signal arrows on direction change
      BuffArrow[i]    = EMPTY_VALUE;
      BuffArrowClr[i] = 0;

      if(i > period && InpShowArrows)
        {
         if(BuffDirection[i] == 1 && BuffDirection[i-1] == -1)
           {
            //--- Bullish signal
            BuffArrow[i]    = BuffLowerBand[i] - atr * 0.5;
            BuffArrowClr[i] = 0;  // bull color
            PlotIndexSetInteger(2, PLOT_ARROW, 233); // up arrow
           }
         else if(BuffDirection[i] == -1 && BuffDirection[i-1] == 1)
           {
            //--- Bearish signal
            BuffArrow[i]    = BuffUpperBand[i] + atr * 0.5;
            BuffArrowClr[i] = 1;  // bear color
           }
        }

      //--- Alerts (only on last completed bar)
      if(i == rates_total - 2 && prev_calculated > 0)
        {
         if(time[i] > g_lastAlertTime)
           {
            if(BuffDirection[i] == 1 && BuffDirection[i-1] == -1)
              {
               FireAlert("BULLISH", close[i], time[i]);
               g_lastAlertTime = time[i];
              }
            else if(BuffDirection[i] == -1 && BuffDirection[i-1] == 1)
              {
               FireAlert("BEARISH", close[i], time[i]);
               g_lastAlertTime = time[i];
              }
           }
        }
     }

//--- Update dashboard
   if(InpShowDashboard && rates_total > period + 1)
      UpdateDashboard(BuffDirection[rates_total-1], close[rates_total-1],
                      BuffDirection[rates_total-1] == 1 ? BuffBull[rates_total-1] : BuffBear[rates_total-1],
                      time[rates_total-1]);

   return(rates_total);
  }

//+------------------------------------------------------------------+
//| Calculate ATR based on selected mode                              |
//+------------------------------------------------------------------+
double CalcATR(const double &high[], const double &low[], const double &close[],
               int idx, int period, int total)
  {
   if(idx < 1)
      return(high[idx] - low[idx]);

   double sum = 0;
   int count  = 0;

   for(int j = idx; j >= MathMax(idx - period + 1, 1); j--)
     {
      double tr = MathMax(high[j] - low[j],
                  MathMax(MathAbs(high[j] - close[j-1]),
                          MathAbs(low[j]  - close[j-1])));
      sum += tr;
      count++;
     }

   return(count > 0 ? sum / count : high[idx] - low[idx]);
  }

//+------------------------------------------------------------------+
//| Fire alert on trend change                                        |
//+------------------------------------------------------------------+
void FireAlert(string direction, double price, datetime time)
  {
   string symbol  = _Symbol;
   string tf      = PeriodToStr();
   string message = "ExMachina SuperTrend | " + symbol + " " + tf +
                    " | " + direction + " signal @ " + DoubleToString(price, _Digits);

   if(InpAlertPopup)
      Alert(message);

   if(InpAlertSound)
      PlaySound(InpAlertSoundFile);

   if(InpAlertEmail)
      SendMail("ExMachina SuperTrend — " + direction + " | " + symbol, message);

   if(InpAlertPush)
      SendNotification(message);

   Print(message);
  }

//+------------------------------------------------------------------+
//| Timeframe to string                                               |
//+------------------------------------------------------------------+
string PeriodToStr()
  {
   switch(_Period)
     {
      case PERIOD_M1:  return("M1");
      case PERIOD_M5:  return("M5");
      case PERIOD_M15: return("M15");
      case PERIOD_M30: return("M30");
      case PERIOD_H1:  return("H1");
      case PERIOD_H4:  return("H4");
      case PERIOD_D1:  return("D1");
      case PERIOD_W1:  return("W1");
      case PERIOD_MN1: return("MN");
      default:         return(IntegerToString(_Period));
     }
  }

//+------------------------------------------------------------------+
//| Create dashboard objects                                          |
//+------------------------------------------------------------------+
void CreateDashboard()
  {
   int w = 220, h = 105;
   string name;

//--- Background rectangle
   name = g_objPrefix + "BG";
   ObjectCreate(0, name, OBJ_RECTANGLE_LABEL, 0, 0, 0);
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE,  InpDashX);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE,  InpDashY);
   ObjectSetInteger(0, name, OBJPROP_XSIZE,       w);
   ObjectSetInteger(0, name, OBJPROP_YSIZE,       h);
   ObjectSetInteger(0, name, OBJPROP_BGCOLOR,     InpDashBgColor);
   ObjectSetInteger(0, name, OBJPROP_BORDER_COLOR,C'30,34,46');
   ObjectSetInteger(0, name, OBJPROP_BORDER_TYPE, BORDER_FLAT);
   ObjectSetInteger(0, name, OBJPROP_CORNER,      CORNER_LEFT_UPPER);
   ObjectSetInteger(0, name, OBJPROP_BACK,        false);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE,  false);

//--- Title label
   CreateLabel(g_objPrefix + "Title", InpDashX + 10, InpDashY + 8,
               "EXMACHINA SUPERTREND", C'90,180,220', InpDashFontSize + 1, "Consolas");

//--- Separator line
   CreateLabel(g_objPrefix + "Sep", InpDashX + 10, InpDashY + 26,
               "────────────────────", C'30,34,46', InpDashFontSize - 2, "Consolas");

//--- Trend label
   CreateLabel(g_objPrefix + "TrendLbl", InpDashX + 10, InpDashY + 38,
               "Trend:", InpDashTextColor, InpDashFontSize, "Consolas");
   CreateLabel(g_objPrefix + "TrendVal", InpDashX + 100, InpDashY + 38,
               "---", InpDashTextColor, InpDashFontSize, "Consolas");

//--- Level label
   CreateLabel(g_objPrefix + "LevelLbl", InpDashX + 10, InpDashY + 56,
               "Level:", InpDashTextColor, InpDashFontSize, "Consolas");
   CreateLabel(g_objPrefix + "LevelVal", InpDashX + 100, InpDashY + 56,
               "---", InpDashTextColor, InpDashFontSize, "Consolas");

//--- Settings label
   CreateLabel(g_objPrefix + "SetLbl", InpDashX + 10, InpDashY + 74,
               "ATR(" + IntegerToString(MathMax(InpPeriod,1)) + ") x" +
               DoubleToString(MathMax(InpMultiplier,0.1), 1),
               C'90,95,110', InpDashFontSize - 1, "Consolas");

//--- Branding
   CreateLabel(g_objPrefix + "Brand", InpDashX + 10, InpDashY + 90,
               "Precision before profit", C'55,60,75', InpDashFontSize - 2, "Consolas");

   ChartRedraw(0);
  }

//+------------------------------------------------------------------+
//| Create a text label                                               |
//+------------------------------------------------------------------+
void CreateLabel(string name, int x, int y, string text,
                 color clr, int fontSize, string font)
  {
   ObjectCreate(0, name, OBJ_LABEL, 0, 0, 0);
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE,  x);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE,  y);
   ObjectSetString(0,  name, OBJPROP_TEXT,        text);
   ObjectSetInteger(0, name, OBJPROP_COLOR,       clr);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE,    fontSize);
   ObjectSetString(0,  name, OBJPROP_FONT,        font);
   ObjectSetInteger(0, name, OBJPROP_CORNER,      CORNER_LEFT_UPPER);
   ObjectSetInteger(0, name, OBJPROP_ANCHOR,      ANCHOR_LEFT_UPPER);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE,  false);
   ObjectSetInteger(0, name, OBJPROP_BACK,        false);
  }

//+------------------------------------------------------------------+
//| Update dashboard values                                           |
//+------------------------------------------------------------------+
void UpdateDashboard(double direction, double price, double stLevel, datetime time)
  {
   string trendText;
   color  trendClr;

   if(direction == 1)
     {
      trendText = "▲ BULLISH";
      trendClr  = InpBullColor;
     }
   else
     {
      trendText = "▼ BEARISH";
      trendClr  = InpBearColor;
     }

   ObjectSetString(0,  g_objPrefix + "TrendVal", OBJPROP_TEXT, trendText);
   ObjectSetInteger(0, g_objPrefix + "TrendVal", OBJPROP_COLOR, trendClr);

   ObjectSetString(0,  g_objPrefix + "LevelVal", OBJPROP_TEXT,
                   DoubleToString(stLevel, _Digits));
   ObjectSetInteger(0, g_objPrefix + "LevelVal", OBJPROP_COLOR, InpDashTextColor);

   ChartRedraw(0);
  }
//+------------------------------------------------------------------+
