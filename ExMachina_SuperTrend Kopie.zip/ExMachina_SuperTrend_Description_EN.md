# ExMachina SuperTrend — MQL5 Code Base Description (English)

---

## Title
ExMachina SuperTrend

## Short Description
ATR-based trend-following indicator with dynamic color line, signal arrows, on-chart dashboard, and full alert system. Steel palette design. Free.

---

## Full Description

**ExMachina SuperTrend** is a clean, professional ATR-based trend indicator for MetaTrader 5. It plots a dynamic SuperTrend line that switches color in real time as the trend direction changes — green below price in uptrends, red above price in downtrends.

**Core Features:**

• Dynamic SuperTrend line with configurable ATR period and multiplier
• Color-coded trend direction: bullish (teal) / bearish (red)
• Signal arrows on every trend reversal — no repaint on closed bars
• On-chart dashboard panel showing current trend, SuperTrend level, and settings
• Full alert system: Popup, Sound, Email, and Push notifications on trend change
• Three ATR calculation modes: Standard, SMA-based, EMA-based

**Dashboard Panel:**
A compact, always-visible panel displays the current trend state (▲ BULLISH / ▼ BEARISH), the exact SuperTrend level, and your active settings — so you never lose context.

**Alert System:**
Get notified instantly when the trend flips. Supports all four MetaTrader 5 alert types:
— Popup dialog
— Custom sound file
— Email notification
— Mobile push notification

**Visual Design:**
Built with the ExMachina steel palette (dark background C'8,10,18'). All graphical objects use the EXSS_ prefix for clean chart management. Colors are fully customizable via input parameters.

**Default Settings:**
— ATR Period: 10
— Multiplier: 3.0
— Mode: Standard ATR

Works on all symbols and timeframes. Optimized for XAUUSD, EURUSD, GBPUSD, and indices.

**How to Use:**
1. Attach to any chart
2. Adjust ATR period and multiplier to match your trading style
3. Trade in the direction of the SuperTrend color
4. Use signal arrows as entry confirmations
5. Set alerts to catch reversals even when away from the screen

Developed by ExMachina Trading Systems — Precision before profit.

For professional trading tools, visit: https://www.mql5.com/en/users/williammukam

---

## Tags (comma-separated)
supertrend, trend, ATR, indicator, arrows, alerts, dashboard, trend following, free, scalping, swing, intraday, XAUUSD, gold, forex

---

## Category
Technical Indicators

## Subcategory
Trend Indicators
