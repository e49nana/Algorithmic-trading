"""
Djibril AI — WebSocket Manager

Manages WebSocket connections for real-time signal updates.
Features: multi-client broadcast, heartbeat, typed messages, auto-reconnect support.
"""

from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from typing import Set

from fastapi import WebSocket, WebSocketDisconnect

try:
    from ..utils.logger import get_logger
    from ..utils.models import WSMessage, WSMessageType
except ImportError:
    from utils.logger import get_logger
    from utils.models import WSMessage, WSMessageType

logger = get_logger(__name__)


class WebSocketManager:
    """Manages active WebSocket connections and broadcasts messages."""

    def __init__(self) -> None:
        self._connections: Set[WebSocket] = set()
        self._heartbeat_interval: int = 30  # seconds

    @property
    def connection_count(self) -> int:
        """Number of active connections."""
        return len(self._connections)

    async def connect(self, websocket: WebSocket) -> None:
        """Accept and register a new WebSocket connection.

        Args:
            websocket: The incoming WebSocket connection.
        """
        await websocket.accept()
        self._connections.add(websocket)
        logger.info("ws_client_connected", total=self.connection_count)

        # Send welcome message
        welcome = WSMessage(
            type=WSMessageType.HEARTBEAT,
            payload={"message": "Connected to Djibril AI", "clients": self.connection_count},
        )
        await self._send(websocket, welcome)

    def disconnect(self, websocket: WebSocket) -> None:
        """Remove a disconnected WebSocket.

        Args:
            websocket: The disconnected WebSocket.
        """
        self._connections.discard(websocket)
        logger.info("ws_client_disconnected", total=self.connection_count)

    async def broadcast(self, message: WSMessage) -> None:
        """Send a message to all connected clients.

        Silently removes clients that fail to receive.

        Args:
            message: The WSMessage to broadcast.
        """
        if not self._connections:
            return

        dead: list[WebSocket] = []
        for ws in self._connections:
            try:
                await self._send(ws, message)
            except Exception:
                dead.append(ws)

        for ws in dead:
            self._connections.discard(ws)

        if dead:
            logger.debug("ws_cleaned_dead_connections", count=len(dead))

    async def broadcast_signal(self, signal_dict: dict) -> None:
        """Broadcast a trade signal update.

        Args:
            signal_dict: Serialized TradeSignal data.
        """
        msg = WSMessage(type=WSMessageType.SIGNAL, payload=signal_dict)
        await self.broadcast(msg)

    async def broadcast_geo_score(self, score_dict: dict) -> None:
        """Broadcast a geo score update.

        Args:
            score_dict: Serialized GeoScore data.
        """
        msg = WSMessage(type=WSMessageType.GEO_SCORE, payload=score_dict)
        await self.broadcast(msg)

    async def broadcast_news(self, news_list: list[dict]) -> None:
        """Broadcast new headlines.

        Args:
            news_list: List of serialized NewsItem dicts.
        """
        msg = WSMessage(type=WSMessageType.NEWS, payload={"items": news_list})
        await self.broadcast(msg)

    async def run_heartbeat(self) -> None:
        """Run the heartbeat loop — sends a ping to all clients periodically."""
        while True:
            await asyncio.sleep(self._heartbeat_interval)
            msg = WSMessage(
                type=WSMessageType.HEARTBEAT,
                payload={
                    "clients": self.connection_count,
                    "server_time": datetime.now(timezone.utc).isoformat(),
                },
            )
            await self.broadcast(msg)

    async def run_queue_consumer(self, queue: asyncio.Queue[WSMessage]) -> None:
        """Consume messages from the publisher queue and broadcast them.

        Args:
            queue: The asyncio queue fed by SignalPublisher.
        """
        while True:
            try:
                message = await queue.get()
                await self.broadcast(message)
                queue.task_done()
            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.error("ws_queue_consumer_error", error=str(exc))

    @staticmethod
    async def _send(websocket: WebSocket, message: WSMessage) -> None:
        """Send a typed message to a single WebSocket.

        Args:
            websocket: Target connection.
            message: The message to send.
        """
        data = message.model_dump_json()
        await websocket.send_text(data)


# Singleton manager
ws_manager = WebSocketManager()
