"""
Djibril AI — Main Orchestrator

Runs the full pipeline on schedule:
- News scan every 2 minutes
- AI scoring every 5 minutes
- Signal check every 30 seconds
- SQLite cleanup weekly

Handles SIGTERM/SIGINT for graceful shutdown.
"""

from __future__ import annotations

import asyncio
import os
import signal as os_signal
import sys
from datetime import datetime, timezone
from typing import List, Optional

try:
    from apscheduler.schedulers.asyncio import AsyncIOScheduler
except ImportError:
    AsyncIOScheduler = None  # type: ignore

try:
    from utils.config import get_settings
    from utils.logger import get_logger, timed
    from utils.models import GeoSignal, NewsItem, TradeAction
    from collectors.rss_aggregator import RSSAggregator
    from collectors.worldmonitor_client import WorldMonitorClient
    from collectors.news_fetcher import NewsFetcher
    from scoring.claude_scorer import ClaudeScorer
    from scoring.sentiment_analyzer import SentimentAnalyzer
    from scoring.technical_analyzer import TechnicalAnalyzer
    from scoring.geo_risk_engine import GeoRiskEngine
    from signal.signal_composer import SignalComposer
    from signal.signal_publisher import SignalPublisher
    from signal.alerts import AlertManager
except ImportError:
    # Handle relative imports for package mode
    from .utils.config import get_settings  # type: ignore
    from .utils.logger import get_logger, timed  # type: ignore
    # ... (same pattern)

logger = get_logger(__name__)


class DjibrilOrchestrator:
    """Main orchestrator that ties together all system components.

    Schedules periodic tasks: news collection, scoring, signal
    generation, and cleanup. Supports graceful shutdown.
    """

    def __init__(self) -> None:
        self._settings = get_settings()
        self._shutdown_event = asyncio.Event()
        self._news_queue: asyncio.Queue[NewsItem] = asyncio.Queue(maxsize=1000)

        # Components
        self._rss = RSSAggregator()
        self._worldmonitor = WorldMonitorClient()
        self._newsapi = NewsFetcher(event_queue=self._news_queue)
        self._claude_scorer = ClaudeScorer()
        self._sentiment = SentimentAnalyzer()
        self._technical = TechnicalAnalyzer()
        self._risk_engine = GeoRiskEngine()
        self._composer = SignalComposer()
        self._publisher = SignalPublisher()
        self._alerts = AlertManager()

        # State
        self._latest_news: List[NewsItem] = []
        self._latest_signal: Optional[GeoSignal] = None
        self._running = False

    async def start(self) -> None:
        """Start the orchestrator with scheduled tasks."""
        logger.info("orchestrator_starting")
        self._running = True

        if AsyncIOScheduler is None:
            logger.error("apscheduler_not_installed")
            return

        scheduler = AsyncIOScheduler()
        cfg = self._settings.signal

        # Schedule tasks
        scheduler.add_job(
            self.scan_news,
            "interval",
            minutes=cfg.scan_interval_minutes,
            id="scan_news",
            max_instances=1,
        )
        scheduler.add_job(
            self.run_scoring,
            "interval",
            minutes=cfg.scoring_interval_minutes,
            id="run_scoring",
            max_instances=1,
        )
        scheduler.add_job(
            self.check_signal,
            "interval",
            seconds=cfg.signal_check_interval_seconds,
            id="check_signal",
            max_instances=1,
        )
        scheduler.add_job(
            self.cleanup,
            "cron",
            day_of_week="sun",
            hour=3,
            id="weekly_cleanup",
        )

        scheduler.start()
        logger.info(
            "orchestrator_scheduled",
            scan_interval=cfg.scan_interval_minutes,
            scoring_interval=cfg.scoring_interval_minutes,
            signal_check=cfg.signal_check_interval_seconds,
        )

        # Initial scan
        await self.scan_news()
        await self.run_scoring()

        # Wait for shutdown
        try:
            await self._shutdown_event.wait()
        finally:
            scheduler.shutdown(wait=False)
            await self._worldmonitor.close()
            self._running = False
            logger.info("orchestrator_stopped")

    @timed
    async def scan_news(self) -> None:
        """Collect news from all sources."""
        logger.info("scan_news_start")

        all_items: List[NewsItem] = []

        # RSS feeds
        try:
            rss_items = await self._rss.fetch_all_feeds()
            all_items.extend(rss_items)
        except Exception as exc:
            logger.error("scan_rss_failed", error=str(exc))

        # WorldMonitor
        try:
            wm_items = await self._worldmonitor.fetch_events()
            all_items.extend(wm_items)
        except Exception as exc:
            logger.error("scan_worldmonitor_failed", error=str(exc))

        # NewsAPI
        try:
            news_items = await self._newsapi.fetch_all()
            all_items.extend(news_items)
        except Exception as exc:
            logger.error("scan_newsapi_failed", error=str(exc))

        # Deduplicate across sources by title hash
        seen: set[str] = set()
        unique: List[NewsItem] = []
        for item in all_items:
            if item.title_hash not in seen:
                seen.add(item.title_hash)
                unique.append(item)

        self._latest_news = unique
        logger.info("scan_news_complete", total=len(unique))

    @timed
    async def run_scoring(self) -> None:
        """Score the latest news and produce a GeoSignal."""
        if not self._latest_news:
            logger.info("scoring_no_news")
            return

        logger.info("scoring_start", headlines=len(self._latest_news))

        # 1. Geo score via Claude
        geo_score = self._claude_scorer.score_headlines(self._latest_news)

        # 2. Technical analysis
        tech_score = self._technical.analyze()

        # 3. Sentiment analysis
        sentiment_score = await self._sentiment.analyze()

        # 4. Risk engine aggregation
        self._latest_signal = self._risk_engine.compute_signal(
            geo_score=geo_score,
            technical_score=tech_score,
            sentiment_score=sentiment_score,
        )

        logger.info(
            "scoring_complete",
            composite=self._latest_signal.composite_score,
            action=self._latest_signal.suggested_action.value,
            confidence=self._latest_signal.confidence,
        )

    @timed
    async def check_signal(self) -> None:
        """Check the latest signal and publish if actionable."""
        if self._latest_signal is None:
            return

        trade_signal = self._composer.compose(self._latest_signal)

        # Publish all signals (including FLAT for dashboard)
        await self._publisher.publish(trade_signal)

        # Send alert for actionable signals
        if trade_signal.action != TradeAction.FLAT:
            await self._alerts.send_signal_alert(trade_signal)

    async def force_scan(self) -> None:
        """Force an immediate full scan + score + signal cycle."""
        logger.info("force_scan_triggered")
        await self.scan_news()
        await self.run_scoring()
        await self.check_signal()

    def cleanup(self) -> None:
        """Weekly cleanup of old data."""
        logger.info("cleanup_start")
        try:
            self._rss.cleanup_old(keep_days=30)
        except Exception as exc:
            logger.error("cleanup_failed", error=str(exc))

    def shutdown(self) -> None:
        """Signal the orchestrator to shut down gracefully."""
        logger.info("shutdown_requested")
        self._shutdown_event.set()

    @property
    def is_running(self) -> bool:
        return self._running

    @property
    def latest_signal(self) -> Optional[GeoSignal]:
        return self._latest_signal

    @property
    def latest_news(self) -> List[NewsItem]:
        return self._latest_news


def _setup_signal_handlers(orchestrator: DjibrilOrchestrator) -> None:
    """Register OS signal handlers for graceful shutdown."""
    try:
        loop = asyncio.get_running_loop()
        for sig in (os_signal.SIGTERM, os_signal.SIGINT):
            loop.add_signal_handler(sig, orchestrator.shutdown)
    except (NotImplementedError, RuntimeError):
        # Windows or no running loop
        pass


async def main() -> None:
    """Entry point for the Djibril AI backend."""
    orchestrator = DjibrilOrchestrator()
    _setup_signal_handlers(orchestrator)
    await orchestrator.start()


if __name__ == "__main__":
    asyncio.run(main())
