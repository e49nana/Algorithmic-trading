"""Djibril AI — utils package."""
