// Djibril AI — Main Dashboard Application
// Industrial OSINT aesthetic with ExMachina steel palette.
// Real-time WebSocket updates, signal banner, geo score, news flux, risk panel.

import { useState, useCallback, useEffect, useRef } from "react";
import type {
  TradeSignal,
  TradeAction,
  Urgency,
  NewsItem,
  WSMessage,
  GeoScoreResponse,
  NewsCategory,
} from "./types";
import { useWebSocket } from "./hooks/useWebSocket";
import {
  useLatestSignal,
  useGeoScore,
  useSignalHistory,
  useNews,
} from "./hooks/useSignalHistory";

// ═══════════════════════════════════════════════════
// Design Tokens — ExMachina Steel Palette
// ═══════════════════════════════════════════════════
const T = {
  bg: "#080A12",
  bgCard: "#0D1017",
  bgCardHover: "#111620",
  border: "#1A1F2E",
  borderActive: "#2A3040",
  text: "#C8CDD8",
  textMuted: "#6B7280",
  textBright: "#E8ECF2",
  accent: "#3B82F6",
  green: "#10B981",
  red: "#EF4444",
  amber: "#F59E0B",
  critical: "#DC2626",
  cyan: "#06B6D4",
} as const;

const WS_URL = import.meta.env.VITE_WS_URL ?? "ws://localhost:8000/ws";

// ═══════════════════════════════════════════════════
// SignalBanner Component
// ═══════════════════════════════════════════════════
function SignalBanner({ signal }: { signal: TradeSignal | null }) {
  if (!signal) {
    return (
      <div style={{ ...styles.banner, borderColor: T.border }}>
        <div style={styles.bannerAction}>⏳ AWAITING SIGNAL</div>
        <div style={{ color: T.textMuted, fontSize: 13 }}>
          System initializing — waiting for first analysis cycle
        </div>
      </div>
    );
  }

  const actionColors: Record<TradeAction, string> = {
    BUY: T.green,
    SELL: T.red,
    FLAT: T.textMuted,
  };
  const actionEmoji: Record<TradeAction, string> = {
    BUY: "📈",
    SELL: "📉",
    FLAT: "⏸",
  };

  const color = actionColors[signal.action];
  const pnlDir = signal.action === "BUY" ? "LONG" : signal.action === "SELL" ? "SHORT" : "—";

  return (
    <div
      style={{
        ...styles.banner,
        borderColor: color,
        boxShadow: `0 0 20px ${color}15`,
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 16, flexWrap: "wrap" }}>
        <div
          style={{
            ...styles.bannerAction,
            color,
            fontSize: 28,
            fontFamily: "'JetBrains Mono', monospace",
          }}
        >
          {actionEmoji[signal.action]} {signal.action} {signal.symbol}
        </div>
        <div
          style={{
            background: `${color}18`,
            border: `1px solid ${color}40`,
            borderRadius: 6,
            padding: "4px 12px",
            color,
            fontSize: 13,
            fontWeight: 600,
          }}
        >
          {pnlDir} · {(signal.confidence * 100).toFixed(0)}% CONF
        </div>
      </div>

      {signal.action !== "FLAT" && (
        <div style={{ display: "flex", gap: 24, marginTop: 12, flexWrap: "wrap" }}>
          <Stat label="ENTRY" value={`$${signal.entry_price.toFixed(2)}`} />
          <Stat label="SL" value={`$${signal.stop_loss.toFixed(2)}`} color={T.red} />
          <Stat label="TP" value={`$${signal.take_profit.toFixed(2)}`} color={T.green} />
          <Stat label="R:R" value={signal.risk_reward_ratio.toFixed(2)} />
          <Stat label="LOTS" value={signal.lot_size.toFixed(2)} />
          <Stat label="GEO" value={`${signal.geo_score > 0 ? "+" : ""}${signal.geo_score}`} />
        </div>
      )}

      <div style={{ color: T.textMuted, fontSize: 12, marginTop: 8 }}>
        {signal.reasoning.slice(0, 250)}
      </div>
    </div>
  );
}

function Stat({
  label,
  value,
  color,
}: {
  label: string;
  value: string;
  color?: string;
}) {
  return (
    <div>
      <div style={{ fontSize: 10, color: T.textMuted, letterSpacing: 1 }}>{label}</div>
      <div
        style={{
          fontSize: 16,
          fontWeight: 700,
          color: color ?? T.textBright,
          fontFamily: "'JetBrains Mono', monospace",
        }}
      >
        {value}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// GeoScoreCard Component
// ═══════════════════════════════════════════════════
function GeoScoreCard({ score }: { score: GeoScoreResponse | null }) {
  const value = score?.score ?? 0;
  const urgency = score?.urgency ?? "low";
  const normalizedAngle = ((value + 10) / 20) * 360;

  const urgencyColors: Record<Urgency, string> = {
    low: T.green,
    medium: T.amber,
    high: "#F97316",
    critical: T.critical,
  };
  const ringColor = urgencyColors[urgency];

  const circumference = 2 * Math.PI * 54;
  const progress = ((value + 10) / 20) * circumference;

  return (
    <div style={styles.card}>
      <div style={styles.cardHeader}>GEO SCORE</div>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}>
        <svg width="140" height="140" viewBox="0 0 140 140">
          {/* Background ring */}
          <circle cx="70" cy="70" r="54" fill="none" stroke={T.border} strokeWidth="8" />
          {/* Progress ring */}
          <circle
            cx="70"
            cy="70"
            r="54"
            fill="none"
            stroke={ringColor}
            strokeWidth="8"
            strokeDasharray={`${progress} ${circumference}`}
            strokeLinecap="round"
            transform="rotate(-90 70 70)"
            style={{ transition: "stroke-dasharray 0.8s ease, stroke 0.5s ease" }}
          />
          {/* Score text */}
          <text
            x="70"
            y="65"
            textAnchor="middle"
            fill={ringColor}
            fontSize="32"
            fontWeight="800"
            fontFamily="'JetBrains Mono', monospace"
          >
            {value > 0 ? "+" : ""}
            {value}
          </text>
          <text x="70" y="85" textAnchor="middle" fill={T.textMuted} fontSize="11">
            {urgency.toUpperCase()}
          </text>
        </svg>
      </div>
      <div style={{ padding: "0 16px 16px", color: T.textMuted, fontSize: 12, lineHeight: 1.5 }}>
        {score?.reasoning ?? "Awaiting analysis..."}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// NewsFlux Component
// ═══════════════════════════════════════════════════
const CATEGORY_COLORS: Record<string, string> = {
  military: "#EF4444",
  conflict: "#F97316",
  sanctions: "#F59E0B",
  diplomatic: "#3B82F6",
  energy: "#10B981",
  infrastructure: "#8B5CF6",
  market: "#06B6D4",
  other: "#6B7280",
};

const DANGER_KEYWORDS = [
  "iran", "strike", "strait", "blockade", "missile", "attack",
  "nuclear", "escalat", "closure", "houthi", "war",
];

function NewsFlux({ items }: { items: NewsItem[] }) {
  const [filter, setFilter] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const filtered = filter ? items.filter((i) => i.category === filter) : items;
  const categories = [...new Set(items.map((i) => i.category))];

  return (
    <div style={{ ...styles.card, flex: 1, minHeight: 300 }}>
      <div style={styles.cardHeader}>NEWS FLUX</div>

      {/* Filter chips */}
      <div style={{ display: "flex", gap: 6, padding: "8px 16px", flexWrap: "wrap" }}>
        <FilterChip label="ALL" active={filter === null} onClick={() => setFilter(null)} />
        {categories.map((cat) => (
          <FilterChip
            key={cat}
            label={cat.toUpperCase()}
            active={filter === cat}
            color={CATEGORY_COLORS[cat]}
            onClick={() => setFilter(filter === cat ? null : cat)}
          />
        ))}
      </div>

      {/* News list */}
      <div ref={scrollRef} style={{ overflowY: "auto", maxHeight: 400, padding: "0 16px 16px" }}>
        {filtered.length === 0 ? (
          <div style={{ color: T.textMuted, padding: 20, textAlign: "center" }}>
            No news items yet
          </div>
        ) : (
          filtered.map((item, idx) => <NewsRow key={`${item.title_hash}-${idx}`} item={item} />)
        )}
      </div>
    </div>
  );
}

function FilterChip({
  label,
  active,
  color,
  onClick,
}: {
  label: string;
  active: boolean;
  color?: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      style={{
        background: active ? (color ?? T.accent) + "25" : "transparent",
        border: `1px solid ${active ? (color ?? T.accent) : T.border}`,
        borderRadius: 4,
        padding: "3px 10px",
        fontSize: 10,
        fontWeight: 600,
        letterSpacing: 0.8,
        color: active ? (color ?? T.accent) : T.textMuted,
        cursor: "pointer",
        transition: "all 0.2s",
      }}
    >
      {label}
    </button>
  );
}

function NewsRow({ item }: { item: NewsItem }) {
  const catColor = CATEGORY_COLORS[item.category] ?? T.textMuted;
  const titleLower = item.title.toLowerCase();
  const isDangerous = DANGER_KEYWORDS.some((kw) => titleLower.includes(kw));

  const timeStr = new Date(item.published_at).toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
  });

  return (
    <div
      style={{
        padding: "10px 0",
        borderBottom: `1px solid ${T.border}`,
        display: "flex",
        gap: 10,
        alignItems: "flex-start",
      }}
    >
      <div
        style={{
          background: catColor + "20",
          color: catColor,
          fontSize: 9,
          fontWeight: 700,
          padding: "2px 6px",
          borderRadius: 3,
          whiteSpace: "nowrap",
          marginTop: 2,
        }}
      >
        {item.category.toUpperCase()}
      </div>
      <div style={{ flex: 1 }}>
        <div
          style={{
            fontSize: 13,
            color: isDangerous ? T.amber : T.text,
            fontWeight: isDangerous ? 600 : 400,
            lineHeight: 1.4,
          }}
        >
          {isDangerous && "⚠️ "}
          {item.title}
        </div>
        <div style={{ fontSize: 11, color: T.textMuted, marginTop: 3 }}>
          {item.source_name} · {timeStr}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// ConfidenceMeter Component
// ═══════════════════════════════════════════════════
function ConfidenceMeter({ signal }: { signal: TradeSignal | null }) {
  const bars = [
    { label: "GEO", value: signal ? (signal.geo_score + 10) / 20 : 0, color: T.amber },
    { label: "TECH", value: signal ? (signal.technical_score_value + 1) / 2 : 0, color: T.cyan },
    { label: "SENT", value: signal ? (signal.sentiment_score_value + 1) / 2 : 0, color: T.accent },
    { label: "CONF", value: signal?.confidence ?? 0, color: T.green },
  ];

  return (
    <div style={styles.card}>
      <div style={styles.cardHeader}>CONFIDENCE METER</div>
      <div style={{ padding: 16, display: "flex", flexDirection: "column", gap: 12 }}>
        {bars.map((bar) => (
          <div key={bar.label}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
              <span style={{ fontSize: 10, color: T.textMuted, letterSpacing: 1 }}>{bar.label}</span>
              <span
                style={{
                  fontSize: 11,
                  color: bar.color,
                  fontFamily: "'JetBrains Mono', monospace",
                }}
              >
                {(bar.value * 100).toFixed(0)}%
              </span>
            </div>
            <div style={{ height: 6, background: T.border, borderRadius: 3, overflow: "hidden" }}>
              <div
                style={{
                  width: `${Math.max(0, Math.min(100, bar.value * 100))}%`,
                  height: "100%",
                  background: bar.color,
                  borderRadius: 3,
                  transition: "width 0.6s ease",
                }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// RiskPanel Component
// ═══════════════════════════════════════════════════
function RiskPanel({ signal }: { signal: TradeSignal | null }) {
  return (
    <div style={styles.card}>
      <div style={styles.cardHeader}>RISK PANEL</div>
      <div style={{ padding: 16, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        <RiskStat label="Lot Size" value={signal?.lot_size.toFixed(2) ?? "—"} />
        <RiskStat label="Kelly" value={signal?.kelly_fraction.toFixed(3) ?? "—"} />
        <RiskStat label="SL (pips)" value={signal?.sl_pips.toFixed(0) ?? "—"} color={T.red} />
        <RiskStat label="TP (pips)" value={signal?.tp_pips.toFixed(0) ?? "—"} color={T.green} />
        <RiskStat label="R:R" value={signal?.risk_reward_ratio.toFixed(2) ?? "—"} />
        <RiskStat label="Spread Max" value={String(signal?.max_spread_allowed ?? "—")} />
      </div>
      {signal && signal.risk_flags.length > 0 && (
        <div style={{ padding: "0 16px 16px" }}>
          <div style={{ fontSize: 10, color: T.amber, letterSpacing: 1, marginBottom: 6 }}>
            ⚠ RISK FLAGS
          </div>
          {signal.risk_flags.map((flag, i) => (
            <div key={i} style={{ fontSize: 11, color: T.textMuted, lineHeight: 1.6 }}>
              • {flag}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function RiskStat({ label, value, color }: { label: string; value: string; color?: string }) {
  return (
    <div>
      <div style={{ fontSize: 10, color: T.textMuted, letterSpacing: 0.8 }}>{label}</div>
      <div
        style={{
          fontSize: 15,
          fontWeight: 700,
          color: color ?? T.textBright,
          fontFamily: "'JetBrains Mono', monospace",
        }}
      >
        {value}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// Main App
// ═══════════════════════════════════════════════════
export default function App() {
  const { signal, setSignal } = useLatestSignal();
  const { score, setScore } = useGeoScore();
  const { items: newsItems } = useNews(undefined, 50);
  const { signals: signalHistory } = useSignalHistory(20);
  const [news, setNews] = useState<NewsItem[]>([]);

  useEffect(() => {
    if (newsItems.length > 0) setNews(newsItems);
  }, [newsItems]);

  const handleWsMessage = useCallback(
    (msg: WSMessage) => {
      if (msg.type === "signal") {
        setSignal(msg.payload as unknown as TradeSignal);
      } else if (msg.type === "geo_score") {
        setScore(msg.payload as unknown as GeoScoreResponse);
      } else if (msg.type === "news") {
        const payload = msg.payload as { items?: NewsItem[] };
        if (payload.items) {
          setNews((prev) => [...payload.items!, ...prev].slice(0, 100));
        }
      }
    },
    [setSignal, setScore]
  );

  const { isConnected, clientCount } = useWebSocket({
    url: WS_URL,
    onMessage: handleWsMessage,
  });

  return (
    <div style={{ minHeight: "100vh", background: T.bg, color: T.text }}>
      {/* Header */}
      <header
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "12px 24px",
          borderBottom: `1px solid ${T.border}`,
          background: T.bgCard,
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <span style={{ fontSize: 20, fontWeight: 800, letterSpacing: 1.5, color: T.textBright }}>
            🛢️ Djibril AI
          </span>
          <span style={{ fontSize: 11, color: T.textMuted, letterSpacing: 2 }}>
            GEOPOLITICAL OSINT · CRUDE OIL
          </span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div
            style={{
              width: 8,
              height: 8,
              borderRadius: "50%",
              background: isConnected ? T.green : T.red,
              boxShadow: isConnected ? `0 0 8px ${T.green}` : `0 0 8px ${T.red}`,
            }}
          />
          <span style={{ fontSize: 11, color: T.textMuted }}>
            {isConnected ? `LIVE · ${clientCount} clients` : "DISCONNECTED"}
          </span>
        </div>
      </header>

      {/* Main Content */}
      <main style={{ padding: 24, maxWidth: 1440, margin: "0 auto" }}>
        {/* Signal Banner */}
        <SignalBanner signal={signal} />

        {/* Dashboard Grid */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "280px 1fr 280px",
            gap: 20,
            marginTop: 20,
          }}
        >
          {/* Left Column */}
          <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
            <GeoScoreCard score={score} />
            <ConfidenceMeter signal={signal} />
          </div>

          {/* Center — News Flux */}
          <NewsFlux items={news} />

          {/* Right Column */}
          <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
            <RiskPanel signal={signal} />

            {/* Signal History Mini */}
            <div style={styles.card}>
              <div style={styles.cardHeader}>RECENT SIGNALS</div>
              <div style={{ padding: "8px 16px", maxHeight: 250, overflowY: "auto" }}>
                {signalHistory.slice(0, 10).map((sig, i) => (
                  <div
                    key={i}
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      padding: "6px 0",
                      borderBottom: `1px solid ${T.border}`,
                      fontSize: 12,
                    }}
                  >
                    <span
                      style={{
                        color:
                          sig.action === "BUY"
                            ? T.green
                            : sig.action === "SELL"
                              ? T.red
                              : T.textMuted,
                        fontWeight: 600,
                        fontFamily: "'JetBrains Mono', monospace",
                      }}
                    >
                      {sig.action}
                    </span>
                    <span style={{ color: T.textMuted }}>
                      {new Date(sig.created_at).toLocaleTimeString()}
                    </span>
                    <span style={{ color: T.textBright }}>
                      {(sig.confidence * 100).toFixed(0)}%
                    </span>
                  </div>
                ))}
                {signalHistory.length === 0 && (
                  <div style={{ color: T.textMuted, textAlign: "center", padding: 20, fontSize: 12 }}>
                    No signal history
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer
        style={{
          textAlign: "center",
          padding: 16,
          color: T.textMuted,
          fontSize: 11,
          borderTop: `1px solid ${T.border}`,
          marginTop: 40,
        }}
      >
        Djibril AI v1.0 · Precision before profit · Powered by Claude claude-opus-4-6
      </footer>

      {/* Google Font */}
      <link
        href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600;700;800&display=swap"
        rel="stylesheet"
      />
    </div>
  );
}

// ═══════════════════════════════════════════════════
// Shared Styles
// ═══════════════════════════════════════════════════
const styles: Record<string, React.CSSProperties> = {
  banner: {
    background: T.bgCard,
    border: `1px solid ${T.border}`,
    borderLeftWidth: 4,
    borderRadius: 8,
    padding: "16px 20px",
    transition: "all 0.3s ease",
  },
  bannerAction: {
    fontWeight: 800,
    fontSize: 24,
    letterSpacing: 1,
  },
  card: {
    background: T.bgCard,
    border: `1px solid ${T.border}`,
    borderRadius: 8,
    overflow: "hidden",
  },
  cardHeader: {
    fontSize: 11,
    fontWeight: 700,
    letterSpacing: 2,
    color: T.textMuted,
    padding: "12px 16px",
    borderBottom: `1px solid ${T.border}`,
    background: `${T.bg}80`,
  },
};
