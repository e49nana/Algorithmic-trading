# AlgoSphere Quant - Complete MT5 Products Package

![Version](https://img.shields.io/badge/Version-2.10-blue)
![Platform](https://img.shields.io/badge/Platform-MetaTrader%205-green)
![License](https://img.shields.io/badge/License-Commercial-orange)

## 🎨 AlgoSphere Quant Visual Theme

All products feature a unified professional trading theme, optimized for active MT5 trading:

| Element | Color | Hex Code |
|---------|-------|----------|
| **Background** | Anthracite/Dark Blue | `#0D1117` |
| **Bullish Candles** | Cool Desaturated Green | `#4A9E7D` |
| **Bearish Candles** | Deep Controlled Red | `#C04040` |
| **Primary Indicators** | Bright Cyan Blue | `#00B4D8` |
| **Secondary Indicators** | Amber Orange | `#E8973C` |
| **Key Zones** | Soft Violet | `#7B68A6` |
| **Text/Labels** | Off-White | `#E8E6E3` |
| **Alerts/Signals** | Golden Yellow | `#F4C542` |

**Design Philosophy:**
- Dark anthracite background reduces eye strain during extended trading
- Cool, desaturated green for bullish signals (stability, continuity)
- Deep, controlled red for bearish signals (without visual aggression)
- Cyan blue draws immediate attention to primary indicators
- Amber orange provides visual hierarchy for secondary information
- Golden yellow creates instant impact for alerts without breaking harmony

---

## 📦 Package Contents (14 Products)

### UTILITIES (Expert Advisors - Panels)
These are **EA-based utilities** with interactive panels. They don't trade but provide essential account management.

| Product | Lines | Description |
|---------|-------|-------------|
| **PropGuard.mq5** | ~1100 | Prop Firm Protection - FTMO, FundedNext, The5ers, MFF presets |
| **RiskManager_Pro.mq5** | ~850 | Portfolio Risk Manager - Lot calculator, daily/weekly limits |
| **SessionControl.mq5** | ~700 | Session & Kill Zone Monitor - London/NY/Tokyo sessions |
| **TradeManager.mq5** | ~900 | Position Manager - Auto BE, trailing stop, partial close |
| **AccountAnalytics.mq5** | ~450 | Account Statistics - Win rate, profit factor, drawdown |

### INDICATORS (Chart Indicators)
Pure indicators with buffers and chart objects.

| Product | Lines | Description |
|---------|-------|-------------|
| **SmartMoneyDashboard.mq5** | ~750 | SMC Analysis - BOS/CHoCH, Order Blocks, FVGs |
| **SupplyDemandZones.mq5** | ~500 | S/D Zone Detector - Auto zones, fresh/tested status ⭐ |
| **ICTSilverBullet.mq5** | ~500 | ICT Strategy - Silver Bullet windows, FVG detection |
| **VolumeProfilePro.mq5** | ~400 | Volume Profile - POC, VAH/VAL, session profiles |
| **CorrelationMatrix.mq5** | ~450 | Currency Correlation - 6-pair matrix, hedge detection ⭐ |
| **DivergenceScanner.mq5** | ~350 | RSI Divergence - Regular/Hidden divergences |
| **LiquidityHeatmap.mq5** | ~450 | Liquidity Analysis - EQH/EQL, sweep detection |
| **OrderFlowDelta.mq5** | ~400 | Order Flow - Buy/Sell delta, cumulative delta |
| **MultiSymbolScanner.mq5** | ~350 | Multi-Pair Scanner - 12 symbols, trend/RSI/ATR |

⭐ = Updated to v2.10 with unified theme architecture

---

## 📂 Installation

### Step 1: Copy Include Files (Required)
```
MQL5/
└── Include/
    └── Algosphere/
        ├── ASQ_Theme.mqh      ← Copy here
        └── ASQ_Common.mqh     ← Copy here
```

### Step 2: Copy Indicators
```
MQL5/
└── Indicators/
    └── Algosphere/           ← Create folder
        ├── SupplyDemandZones.mq5
        ├── CorrelationMatrix.mq5
        └── ... (all .mq5 files from Indicators/)
```

### Step 3: Copy Utilities (EAs)
```
MQL5/
└── Experts/
    └── Algosphere/           ← Create folder
        ├── PropGuard.mq5
        ├── TradeManager.mq5
        └── ... (all .mq5 files from Utilities/)
```

### Step 4: Compile & Activate
1. Restart MetaTrader 5 or Refresh Navigator (Ctrl+R)
2. Open MetaEditor (F4)
3. Compile each file (F7) or compile all (Ctrl+F7)
4. Attach indicators/utilities to your chart

---

## 🎨 Theme System Architecture

### Include Files

**ASQ_Theme.mqh** - Visual theme constants and chart application:
- All color definitions (background, candles, indicators, panels)
- `ASQ_ApplyChartTheme()` - Applies full theme to any chart
- `ASQ_ResetChartTheme()` - Resets to MT5 defaults
- Color utility functions (blend, gradient, alpha)

**ASQ_Common.mqh** - Shared UI components:
- Panel creation helpers
- Label and rectangle functions
- Progress bars, buttons, separators
- Chart object creation (lines, arrows, zones)
- Formatting utilities (numbers, percentages, time)

### Using the Theme in Your Code

```mql5
#include <Algosphere/ASQ_Theme.mqh>
#include <Algosphere/ASQ_Common.mqh>

int OnInit()
{
   // Apply the AlgoSphere Quant theme to chart
   ASQ_ApplyChartTheme();
   
   // Create a panel with header
   ASQ_CreatePanel("MyPanel", 20, 50, 200, 150, "MY INDICATOR", "v1.0");
   
   // Use theme colors
   ASQ_CreateLabel("Label1", 30, 80, "Status:", ASQ_TEXT_SECONDARY);
   ASQ_CreateLabel("Value1", 100, 80, "Active", ASQ_SUCCESS);
   
   return INIT_SUCCEEDED;
}
```

---

## ⚙️ Product Details

### Supply & Demand Zones Pro v2.10
**Purpose:** Auto-detect institutional supply and demand zones

**Features:**
- Automatic zone detection based on price action
- Fresh vs Tested zone tracking with visual indicators
- Zone strength calculation (Weak/Moderate/Strong)
- Configurable zone size and move multiplier
- Real-time zone status updates (broken, tested)
- Alert system for zone touches and breaks
- Interactive info panel with statistics

**Inputs:**
- Lookback Period (default: 150)
- Min/Max Zone Size (points)
- Move Multiplier for zone validation
- Display options (hide broken, show fresh only)
- Zone opacity control

---

### Correlation Matrix Pro v2.10
**Purpose:** Real-time currency pair correlation analysis

**Features:**
- Pearson correlation coefficient calculation
- 6-pair matrix with color-coded strength
- Hedging opportunity detection
- Configurable correlation thresholds
- Auto-refresh with timer
- Visual strength indicators

**Correlation Thresholds:**
- Strong: |r| ≥ 0.80 (Green/Red)
- Moderate: |r| ≥ 0.50 (Green/Orange)
- Weak: |r| ≥ 0.20 (Gray)
- None: |r| < 0.20 (Muted)

**Hedging Detection:**
Automatically identifies pairs with strong negative correlation (default: r ≤ -0.75) for potential hedging strategies.

---

### [Other Products - Documentation continues...]

*Each product includes full documentation. See individual files for complete feature lists.*

---

## 🔒 Market-Ready Compliance

All products follow these standards:

✅ **Self-contained** - Each file works independently  
✅ **Clean object management** - All objects deleted on deinit  
✅ **Error handling** - Input validation, graceful failures  
✅ **Safe mode** - Critical features can be disabled  
✅ **No trading in indicators** - Pure visualization  
✅ **Proper buffer management** - SetAsSeries, prev_calculated  

---

## 📝 Changelog

### v2.10 (February 2026)
- **NEW:** Unified theme architecture with include files
- **NEW:** ASQ_Theme.mqh - Centralized color definitions
- **NEW:** ASQ_Common.mqh - Shared UI components
- **UPDATED:** SupplyDemandZones.mq5 - Theme integration
- **UPDATED:** CorrelationMatrix.mq5 - Theme integration
- **IMPROVED:** Code maintainability and consistency

### v2.00 (January 2026)
- Initial release with embedded theme
- 5 Utilities + 9 Indicators
- AlgoSphere Quant branding
- Market-ready standalone products

---

## 📞 Support

**AlgoSphere Quant**  
Website: https://algosphere-quant.com  
GitHub: https://github.com/algosphere-quant

© 2026 AlgoSphere Quant. All rights reserved.
