#region Using declarations
using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using System.IO;
using System.Text;
using NinjaTrader.NinjaScript;
#endregion

//===============================================================================
// SOPHON AI MODULE v1.0
// Système d'Intelligence Artificielle Adaptative
//
// Ce module implémente:
//   - Détection de régime de marché (Trending, Ranging, Volatile, Quiet)
//   - Scoring dynamique des setups basé sur performance historique
//   - Optimisation adaptative des paramètres
//   - Filtrage intelligent par conditions de marché
//   - Apprentissage continu des patterns gagnants
//   - Analyse de corrélation setup/conditions
//
// Copyright (c) 2026 Algosphere Quant - Emmanuel
//===============================================================================

namespace NinjaTrader.NinjaScript.AddOns.Sophon
{
    /// <summary>
    /// Module d'IA adaptative - Apprentissage et optimisation continue
    /// </summary>
    public class SophonAI : ISophonModule
    {
        #region Properties
        public string ModuleName => "SophonAI";
        public bool IsInitialized { get; private set; }
        public bool IsEnabled { get; set; }
        
        public AISettings Settings { get; set; }
        
        // Détection de régime
        private Dictionary<string, MarketRegimeData> _regimeByInstrument;
        private Dictionary<string, CircularBuffer<RegimeSnapshot>> _regimeHistory;
        
        // Scoring des setups
        private Dictionary<SetupType, SetupScore> _setupScores;
        private Dictionary<string, Dictionary<SetupType, SetupScore>> _setupScoresByInstrument;
        
        // Apprentissage des patterns
        private List<PatternRecord> _patternHistory;
        private Dictionary<string, PatternCluster> _patternClusters;
        
        // Optimisation des paramètres
        private Dictionary<string, OptimizedParameters> _optimizedParams;
        private DateTime _lastOptimization;
        
        // Feature importance
        private Dictionary<string, double> _featureImportance;
        
        // Cache
        private CalculationCache<string, MarketRegime> _regimeCache;
        private CalculationCache<string, double> _scoreCache;
        
        // Events
        public event EventHandler<MarketRegimeChange> OnRegimeChanged;
        public event EventHandler<SetupScoreUpdate> OnScoreUpdated;
        public event EventHandler<OptimizationComplete> OnOptimizationComplete;
        
        private readonly object _lock = new object();
        #endregion

        #region Initialization
        public SophonAI()
        {
            Settings = new AISettings();
            _regimeByInstrument = new Dictionary<string, MarketRegimeData>();
            _regimeHistory = new Dictionary<string, CircularBuffer<RegimeSnapshot>>();
            _setupScores = new Dictionary<SetupType, SetupScore>();
            _setupScoresByInstrument = new Dictionary<string, Dictionary<SetupType, SetupScore>>();
            _patternHistory = new List<PatternRecord>();
            _patternClusters = new Dictionary<string, PatternCluster>();
            _optimizedParams = new Dictionary<string, OptimizedParameters>();
            _featureImportance = new Dictionary<string, double>();
            _regimeCache = new CalculationCache<string, MarketRegime>(TimeSpan.FromSeconds(30));
            _scoreCache = new CalculationCache<string, double>(TimeSpan.FromMinutes(5));
            IsEnabled = true;
            
            InitializeDefaultScores();
            InitializeFeatureImportance();
        }

        public void Initialize()
        {
            if (IsInitialized) return;
            
            _regimeByInstrument.Clear();
            _regimeHistory.Clear();
            _patternHistory.Clear();
            _regimeCache.Clear();
            _scoreCache.Clear();
            
            // Charger les données sauvegardées
            if (Settings.LoadStateOnStart)
                LoadState();
            
            IsInitialized = true;
        }

        public void Shutdown()
        {
            if (Settings.SaveStateOnShutdown)
                SaveState();
            
            _regimeByInstrument.Clear();
            _regimeHistory.Clear();
            IsInitialized = false;
        }

        public void Reset()
        {
            Shutdown();
            Initialize();
        }

        public void OnBarUpdate(int barsInProgress) { }

        private void InitializeDefaultScores()
        {
            foreach (SetupType setup in Enum.GetValues(typeof(SetupType)))
            {
                _setupScores[setup] = new SetupScore
                {
                    Setup = setup,
                    BaseScore = 50.0,
                    CurrentScore = 50.0,
                    WinRate = 0.5,
                    ProfitFactor = 1.0,
                    SampleSize = 0
                };
            }
        }

        private void InitializeFeatureImportance()
        {
            _featureImportance = new Dictionary<string, double>
            {
                ["MarketStructure"] = 0.20,
                ["OrderBlockQuality"] = 0.15,
                ["FVGPresent"] = 0.10,
                ["LiquiditySweep"] = 0.15,
                ["PricePosition"] = 0.10,
                ["SessionTiming"] = 0.08,
                ["ATRCondition"] = 0.07,
                ["TrendAlignment"] = 0.08,
                ["VolumeProfile"] = 0.05,
                ["NewsProximity"] = 0.02
            };
        }
        #endregion

        #region Market Regime Detection
        /// <summary>
        /// Met à jour les données de régime pour un instrument
        /// </summary>
        public void UpdateRegimeData(string instrument, double close, double high, double low, 
                                      double atr, double volume, DateTime time)
        {
            lock (_lock)
            {
                if (!_regimeByInstrument.ContainsKey(instrument))
                {
                    _regimeByInstrument[instrument] = new MarketRegimeData(instrument);
                    _regimeHistory[instrument] = new CircularBuffer<RegimeSnapshot>(500);
                }
                
                var data = _regimeByInstrument[instrument];
                
                // Ajouter les nouvelles données
                data.Closes.Add(close);
                data.Highs.Add(high);
                data.Lows.Add(low);
                data.ATRValues.Add(atr);
                data.Volumes.Add(volume);
                data.LastUpdate = time;
                
                // Recalculer le régime
                var previousRegime = data.CurrentRegime;
                data.CurrentRegime = CalculateRegime(data);
                data.RegimeStrength = CalculateRegimeStrength(data);
                data.TrendDirection = CalculateTrendDirection(data);
                data.Volatility = CalculateVolatilityLevel(data);
                
                // Sauvegarder le snapshot
                _regimeHistory[instrument].Add(new RegimeSnapshot
                {
                    Timestamp = time,
                    Regime = data.CurrentRegime,
                    Strength = data.RegimeStrength,
                    ATR = atr,
                    Close = close
                });
                
                // Notifier si changement de régime
                if (previousRegime != data.CurrentRegime && previousRegime != MarketRegime.Unknown)
                {
                    OnRegimeChanged?.Invoke(this, new MarketRegimeChange
                    {
                        Instrument = instrument,
                        PreviousRegime = previousRegime,
                        NewRegime = data.CurrentRegime,
                        Timestamp = time,
                        Strength = data.RegimeStrength
                    });
                }
            }
        }

        /// <summary>
        /// Calcule le régime de marché actuel
        /// </summary>
        private MarketRegime CalculateRegime(MarketRegimeData data)
        {
            if (data.Closes.Count < Settings.RegimeLookback)
                return MarketRegime.Unknown;
            
            var closes = data.Closes.ToArray().TakeLast(Settings.RegimeLookback).ToArray();
            var atrs = data.ATRValues.ToArray().TakeLast(Settings.RegimeLookback).ToArray();
            var highs = data.Highs.ToArray().TakeLast(Settings.RegimeLookback).ToArray();
            var lows = data.Lows.ToArray().TakeLast(Settings.RegimeLookback).ToArray();
            
            // Calculer les métriques
            double trendStrength = CalculateTrendStrength(closes);
            double rangeRatio = CalculateRangeRatio(highs, lows, closes);
            double volatilityRatio = CalculateVolatilityRatio(atrs);
            double adx = CalculateSimpleADX(highs, lows, closes);
            
            // Déterminer le régime basé sur les métriques
            // ADX > 25 = trending, ADX < 20 = ranging
            // Volatility ratio > 1.5 = volatile, < 0.7 = quiet
            
            if (volatilityRatio > Settings.VolatileThreshold)
            {
                return MarketRegime.Volatile;
            }
            else if (volatilityRatio < Settings.QuietThreshold)
            {
                return MarketRegime.Quiet;
            }
            else if (adx > Settings.TrendingADXThreshold && trendStrength > 0.6)
            {
                return MarketRegime.Trending;
            }
            else if (adx < Settings.RangingADXThreshold || rangeRatio > 0.7)
            {
                return MarketRegime.Ranging;
            }
            else if (trendStrength > 0.5)
            {
                return MarketRegime.Trending;
            }
            else
            {
                return MarketRegime.Ranging;
            }
        }

        private double CalculateTrendStrength(double[] closes)
        {
            if (closes.Length < 2) return 0;
            
            // Linear regression slope normalized
            int n = closes.Length;
            double sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
            
            for (int i = 0; i < n; i++)
            {
                sumX += i;
                sumY += closes[i];
                sumXY += i * closes[i];
                sumX2 += i * i;
            }
            
            double slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
            double avgPrice = sumY / n;
            double normalizedSlope = slope / avgPrice * 100;
            
            // Transformer en force de tendance (0-1)
            return Math.Min(1.0, Math.Abs(normalizedSlope) / 0.5);
        }

        private double CalculateRangeRatio(double[] highs, double[] lows, double[] closes)
        {
            if (highs.Length < 10) return 0.5;
            
            double periodHigh = highs.Max();
            double periodLow = lows.Min();
            double range = periodHigh - periodLow;
            
            if (range == 0) return 0;
            
            // Calculer combien de temps le prix reste dans le range central
            double midPoint = (periodHigh + periodLow) / 2;
            double rangeBuffer = range * 0.3;
            
            int inRange = closes.Count(c => c >= midPoint - rangeBuffer && c <= midPoint + rangeBuffer);
            return (double)inRange / closes.Length;
        }

        private double CalculateVolatilityRatio(double[] atrs)
        {
            if (atrs.Length < 20) return 1.0;
            
            double recentATR = atrs.TakeLast(5).Average();
            double historicalATR = atrs.Take(atrs.Length - 5).Average();
            
            return historicalATR > 0 ? recentATR / historicalATR : 1.0;
        }

        private double CalculateSimpleADX(double[] highs, double[] lows, double[] closes)
        {
            if (highs.Length < 14) return 25; // Default neutral
            
            int period = 14;
            double[] tr = new double[highs.Length - 1];
            double[] dmPlus = new double[highs.Length - 1];
            double[] dmMinus = new double[highs.Length - 1];
            
            for (int i = 1; i < highs.Length; i++)
            {
                double highDiff = highs[i] - highs[i - 1];
                double lowDiff = lows[i - 1] - lows[i];
                
                tr[i - 1] = Math.Max(highs[i] - lows[i], 
                            Math.Max(Math.Abs(highs[i] - closes[i - 1]), 
                                    Math.Abs(lows[i] - closes[i - 1])));
                
                dmPlus[i - 1] = highDiff > lowDiff && highDiff > 0 ? highDiff : 0;
                dmMinus[i - 1] = lowDiff > highDiff && lowDiff > 0 ? lowDiff : 0;
            }
            
            // Simplified ADX calculation
            double atr = tr.TakeLast(period).Average();
            double diPlus = atr > 0 ? (dmPlus.TakeLast(period).Average() / atr) * 100 : 0;
            double diMinus = atr > 0 ? (dmMinus.TakeLast(period).Average() / atr) * 100 : 0;
            
            double diSum = diPlus + diMinus;
            double dx = diSum > 0 ? Math.Abs(diPlus - diMinus) / diSum * 100 : 0;
            
            return dx;
        }

        private double CalculateRegimeStrength(MarketRegimeData data)
        {
            var closes = data.Closes.ToArray().TakeLast(Settings.RegimeLookback).ToArray();
            var atrs = data.ATRValues.ToArray().TakeLast(Settings.RegimeLookback).ToArray();
            
            double trendStrength = CalculateTrendStrength(closes);
            double volatilityRatio = CalculateVolatilityRatio(atrs);
            
            return data.CurrentRegime switch
            {
                MarketRegime.Trending => Math.Min(1.0, trendStrength * 1.2),
                MarketRegime.Ranging => Math.Min(1.0, (1 - trendStrength) * 1.2),
                MarketRegime.Volatile => Math.Min(1.0, (volatilityRatio - 1) / 0.5),
                MarketRegime.Quiet => Math.Min(1.0, (1 - volatilityRatio) * 2),
                _ => 0.5
            };
        }

        private TrendDirection CalculateTrendDirection(MarketRegimeData data)
        {
            if (data.Closes.Count < 20) return TrendDirection.Neutral;
            
            var closes = data.Closes.ToArray().TakeLast(20).ToArray();
            double sma10 = closes.TakeLast(10).Average();
            double sma20 = closes.Average();
            double currentPrice = closes.Last();
            
            if (currentPrice > sma10 && sma10 > sma20)
                return TrendDirection.Bullish;
            else if (currentPrice < sma10 && sma10 < sma20)
                return TrendDirection.Bearish;
            else
                return TrendDirection.Neutral;
        }

        private VolatilityLevel CalculateVolatilityLevel(MarketRegimeData data)
        {
            if (data.ATRValues.Count < 20) return VolatilityLevel.Normal;
            
            var atrs = data.ATRValues.ToArray();
            double ratio = CalculateVolatilityRatio(atrs);
            
            if (ratio > 1.5) return VolatilityLevel.Extreme;
            if (ratio > 1.2) return VolatilityLevel.High;
            if (ratio < 0.7) return VolatilityLevel.Low;
            if (ratio < 0.5) return VolatilityLevel.VeryLow;
            return VolatilityLevel.Normal;
        }

        /// <summary>
        /// Obtient le régime actuel pour un instrument
        /// </summary>
        public MarketRegime GetCurrentRegime(string instrument)
        {
            return _regimeCache.GetOrCompute($"regime_{instrument}", () =>
            {
                lock (_lock)
                {
                    return _regimeByInstrument.ContainsKey(instrument)
                        ? _regimeByInstrument[instrument].CurrentRegime
                        : MarketRegime.Unknown;
                }
            });
        }

        /// <summary>
        /// Obtient les données de régime complètes
        /// </summary>
        public MarketRegimeData GetRegimeData(string instrument)
        {
            lock (_lock)
            {
                return _regimeByInstrument.ContainsKey(instrument)
                    ? _regimeByInstrument[instrument]
                    : null;
            }
        }
        #endregion

        #region Setup Scoring
        /// <summary>
        /// Enregistre le résultat d'un trade pour l'apprentissage
        /// </summary>
        public void RecordTradeResult(TradeResult result, MarketContext context)
        {
            lock (_lock)
            {
                // Créer un pattern record
                var pattern = new PatternRecord
                {
                    TradeId = result.TradeId,
                    Setup = result.Setup,
                    Instrument = result.Instrument,
                    Direction = result.Direction,
                    EntryTime = result.EntryTime,
                    ExitTime = result.ExitTime,
                    RMultiple = result.RMultiple,
                    IsWinner = result.IsWinner,
                    
                    // Contexte au moment de l'entrée
                    MarketRegime = context?.Structure == MarketStructure.Bullish 
                        ? MarketRegime.Trending 
                        : MarketRegime.Ranging,
                    PricePosition = context?.CurrentPosition ?? PricePosition.Equilibrium,
                    ConfluenceCount = result.ConfluenceCount,
                    Session = result.Session,
                    DayOfWeek = result.EntryTime.DayOfWeek,
                    HourOfDay = result.EntryTime.Hour
                };
                
                _patternHistory.Add(pattern);
                
                // Limiter l'historique
                while (_patternHistory.Count > Settings.MaxPatternHistory)
                    _patternHistory.RemoveAt(0);
                
                // Mettre à jour les scores
                UpdateSetupScore(result.Setup, result);
                UpdateInstrumentScore(result.Instrument, result.Setup, result);
                
                // Recalculer les clusters si suffisamment de données
                if (_patternHistory.Count % 50 == 0)
                    UpdatePatternClusters();
            }
        }

        /// <summary>
        /// Met à jour le score d'un setup
        /// </summary>
        private void UpdateSetupScore(SetupType setup, TradeResult result)
        {
            if (!_setupScores.ContainsKey(setup))
            {
                _setupScores[setup] = new SetupScore { Setup = setup, BaseScore = 50.0, CurrentScore = 50.0 };
            }
            
            var score = _setupScores[setup];
            score.SampleSize++;
            
            // Calculer la nouvelle win rate avec decay
            double alpha = Math.Min(0.1, 1.0 / score.SampleSize); // Learning rate
            score.WinRate = score.WinRate * (1 - alpha) + (result.IsWinner ? 1.0 : 0.0) * alpha;
            
            // Mettre à jour l'expectancy
            score.AverageRMultiple = score.AverageRMultiple * (1 - alpha) + result.RMultiple * alpha;
            
            // Calculer le nouveau score (0-100)
            // Score = f(WinRate, ProfitFactor, Expectancy)
            score.CurrentScore = CalculateSetupScore(score);
            
            score.LastUpdate = DateTime.Now;
            
            OnScoreUpdated?.Invoke(this, new SetupScoreUpdate
            {
                Setup = setup,
                NewScore = score.CurrentScore,
                WinRate = score.WinRate,
                SampleSize = score.SampleSize
            });
        }

        private void UpdateInstrumentScore(string instrument, SetupType setup, TradeResult result)
        {
            if (!_setupScoresByInstrument.ContainsKey(instrument))
                _setupScoresByInstrument[instrument] = new Dictionary<SetupType, SetupScore>();
            
            if (!_setupScoresByInstrument[instrument].ContainsKey(setup))
            {
                _setupScoresByInstrument[instrument][setup] = new SetupScore 
                { 
                    Setup = setup, 
                    BaseScore = 50.0, 
                    CurrentScore = 50.0 
                };
            }
            
            var score = _setupScoresByInstrument[instrument][setup];
            score.SampleSize++;
            
            double alpha = Math.Min(0.15, 1.0 / score.SampleSize);
            score.WinRate = score.WinRate * (1 - alpha) + (result.IsWinner ? 1.0 : 0.0) * alpha;
            score.AverageRMultiple = score.AverageRMultiple * (1 - alpha) + result.RMultiple * alpha;
            score.CurrentScore = CalculateSetupScore(score);
            score.LastUpdate = DateTime.Now;
        }

        private double CalculateSetupScore(SetupScore score)
        {
            if (score.SampleSize < Settings.MinSamplesForScoring)
                return score.BaseScore;
            
            // Composantes du score
            double winRateComponent = score.WinRate * 40; // 0-40 points
            double expectancyComponent = Math.Min(30, Math.Max(-10, score.AverageRMultiple * 15)); // -10 to 30 points
            double consistencyBonus = score.SampleSize > 30 ? 10 : score.SampleSize / 3.0; // 0-10 points
            double profitFactorComponent = Math.Min(20, score.ProfitFactor * 10); // 0-20 points
            
            double rawScore = winRateComponent + expectancyComponent + consistencyBonus + profitFactorComponent;
            
            // Normaliser entre 0-100
            return Math.Max(0, Math.Min(100, rawScore));
        }

        /// <summary>
        /// Obtient le score ajusté d'un setup pour les conditions actuelles
        /// </summary>
        public double GetAdjustedSetupScore(SetupType setup, string instrument, MarketRegime regime, TradingSession session)
        {
            string cacheKey = $"{setup}_{instrument}_{regime}_{session}";
            
            return _scoreCache.GetOrCompute(cacheKey, () =>
            {
                lock (_lock)
                {
                    double baseScore = _setupScores.ContainsKey(setup) 
                        ? _setupScores[setup].CurrentScore 
                        : 50.0;
                    
                    // Ajuster par instrument
                    if (_setupScoresByInstrument.ContainsKey(instrument) &&
                        _setupScoresByInstrument[instrument].ContainsKey(setup))
                    {
                        var instScore = _setupScoresByInstrument[instrument][setup];
                        if (instScore.SampleSize >= 10)
                        {
                            baseScore = (baseScore + instScore.CurrentScore) / 2;
                        }
                    }
                    
                    // Ajuster par régime
                    double regimeMultiplier = GetRegimeMultiplier(setup, regime);
                    
                    // Ajuster par session
                    double sessionMultiplier = GetSessionMultiplier(setup, session);
                    
                    return baseScore * regimeMultiplier * sessionMultiplier;
                }
            });
        }

        private double GetRegimeMultiplier(SetupType setup, MarketRegime regime)
        {
            // Certains setups performent mieux dans certains régimes
            return (setup, regime) switch
            {
                // Setups de tendance meilleurs en trending
                (SetupType.G_BOS_Continuation, MarketRegime.Trending) => 1.2,
                (SetupType.G_BOS_Continuation, MarketRegime.Ranging) => 0.7,
                
                // Setups de reversal meilleurs en ranging
                (SetupType.H_ChoCH_Reversal, MarketRegime.Ranging) => 1.2,
                (SetupType.H_ChoCH_Reversal, MarketRegime.Trending) => 0.8,
                
                // Liquidity sweep fonctionne bien en volatile
                (SetupType.F_Liquidity_MSS, MarketRegime.Volatile) => 1.1,
                
                // Confluence OB+FVG polyvalent
                (SetupType.E_OB_FVG_Confluence, _) => 1.0,
                
                // Quiet = réduire tout
                (_, MarketRegime.Quiet) => 0.8,
                
                // Default
                _ => 1.0
            };
        }

        private double GetSessionMultiplier(SetupType setup, TradingSession session)
        {
            // Ajuster par session
            return session switch
            {
                TradingSession.LondonNYOverlap => 1.15, // Meilleure liquidité
                TradingSession.London => 1.05,
                TradingSession.NewYork => 1.05,
                TradingSession.Asian => 0.9, // Moins de volatilité
                _ => 1.0
            };
        }
        #endregion

        #region Pattern Clustering
        /// <summary>
        /// Met à jour les clusters de patterns
        /// </summary>
        private void UpdatePatternClusters()
        {
            if (_patternHistory.Count < 50) return;
            
            // Grouper par setup + régime + session
            var groups = _patternHistory
                .GroupBy(p => $"{p.Setup}_{p.MarketRegime}_{p.Session}")
                .Where(g => g.Count() >= 5);
            
            _patternClusters.Clear();
            
            foreach (var group in groups)
            {
                var patterns = group.ToList();
                
                var cluster = new PatternCluster
                {
                    ClusterId = group.Key,
                    Setup = patterns.First().Setup,
                    Regime = patterns.First().MarketRegime,
                    Session = patterns.First().Session,
                    SampleSize = patterns.Count,
                    WinRate = patterns.Count(p => p.IsWinner) / (double)patterns.Count,
                    AvgRMultiple = patterns.Average(p => p.RMultiple),
                    BestHour = patterns.GroupBy(p => p.HourOfDay)
                                       .OrderByDescending(g => g.Count(p => p.IsWinner) / (double)g.Count())
                                       .First().Key,
                    BestDay = patterns.GroupBy(p => p.DayOfWeek)
                                      .OrderByDescending(g => g.Count(p => p.IsWinner) / (double)g.Count())
                                      .First().Key
                };
                
                cluster.Score = CalculateClusterScore(cluster);
                _patternClusters[cluster.ClusterId] = cluster;
            }
        }

        private double CalculateClusterScore(PatternCluster cluster)
        {
            double winRateScore = cluster.WinRate * 50;
            double expectancyScore = Math.Min(30, cluster.AvgRMultiple * 15);
            double sampleBonus = Math.Min(20, cluster.SampleSize / 5.0);
            
            return Math.Max(0, Math.Min(100, winRateScore + expectancyScore + sampleBonus));
        }

        /// <summary>
        /// Obtient le meilleur cluster pour les conditions actuelles
        /// </summary>
        public PatternCluster GetBestCluster(SetupType setup, MarketRegime regime, TradingSession session)
        {
            string key = $"{setup}_{regime}_{session}";
            
            lock (_lock)
            {
                if (_patternClusters.ContainsKey(key))
                    return _patternClusters[key];
                
                // Chercher un cluster similaire
                return _patternClusters.Values
                    .Where(c => c.Setup == setup)
                    .OrderByDescending(c => c.Score)
                    .FirstOrDefault();
            }
        }
        #endregion

        #region Parameter Optimization
        /// <summary>
        /// Lance une optimisation des paramètres
        /// </summary>
        public void RunOptimization(string instrument = null)
        {
            if (_patternHistory.Count < Settings.MinSamplesForOptimization)
                return;
            
            lock (_lock)
            {
                var patterns = instrument == null 
                    ? _patternHistory 
                    : _patternHistory.Where(p => p.Instrument == instrument).ToList();
                
                if (patterns.Count < 30) return;
                
                var optimized = new OptimizedParameters
                {
                    Instrument = instrument ?? "Global",
                    OptimizedAt = DateTime.Now,
                    SampleSize = patterns.Count
                };
                
                // Optimiser les heures de trading
                var hourStats = patterns
                    .GroupBy(p => p.HourOfDay)
                    .Select(g => new { Hour = g.Key, WinRate = g.Count(p => p.IsWinner) / (double)g.Count(), Count = g.Count() })
                    .Where(h => h.Count >= 5)
                    .OrderByDescending(h => h.WinRate)
                    .ToList();
                
                optimized.BestHours = hourStats.Take(5).Select(h => h.Hour).ToList();
                optimized.WorstHours = hourStats.TakeLast(3).Select(h => h.Hour).ToList();
                
                // Optimiser les jours
                var dayStats = patterns
                    .GroupBy(p => p.DayOfWeek)
                    .Select(g => new { Day = g.Key, WinRate = g.Count(p => p.IsWinner) / (double)g.Count(), Count = g.Count() })
                    .Where(d => d.Count >= 5)
                    .OrderByDescending(d => d.WinRate)
                    .ToList();
                
                optimized.BestDays = dayStats.Take(3).Select(d => d.Day).ToList();
                
                // Optimiser les setups par régime
                foreach (MarketRegime regime in Enum.GetValues(typeof(MarketRegime)))
                {
                    var regimePatterns = patterns.Where(p => p.MarketRegime == regime).ToList();
                    if (regimePatterns.Count < 10) continue;
                    
                    var bestSetup = regimePatterns
                        .GroupBy(p => p.Setup)
                        .Select(g => new { Setup = g.Key, Score = g.Count(p => p.IsWinner) / (double)g.Count() * g.Average(p => p.RMultiple) })
                        .OrderByDescending(s => s.Score)
                        .FirstOrDefault();
                    
                    if (bestSetup != null)
                        optimized.BestSetupByRegime[regime] = bestSetup.Setup;
                }
                
                // Calculer l'amélioration potentielle
                double currentPerformance = patterns.Average(p => p.RMultiple);
                var filteredPatterns = patterns.Where(p => 
                    optimized.BestHours.Contains(p.HourOfDay) &&
                    optimized.BestDays.Contains(p.DayOfWeek)).ToList();
                
                double optimizedPerformance = filteredPatterns.Count > 0 
                    ? filteredPatterns.Average(p => p.RMultiple) 
                    : currentPerformance;
                
                optimized.ExpectedImprovement = (optimizedPerformance - currentPerformance) / Math.Abs(currentPerformance);
                
                _optimizedParams[optimized.Instrument] = optimized;
                _lastOptimization = DateTime.Now;
                
                OnOptimizationComplete?.Invoke(this, new OptimizationComplete
                {
                    Instrument = optimized.Instrument,
                    Parameters = optimized,
                    Improvement = optimized.ExpectedImprovement
                });
            }
        }

        /// <summary>
        /// Obtient les paramètres optimisés
        /// </summary>
        public OptimizedParameters GetOptimizedParameters(string instrument)
        {
            lock (_lock)
            {
                if (_optimizedParams.ContainsKey(instrument))
                    return _optimizedParams[instrument];
                
                if (_optimizedParams.ContainsKey("Global"))
                    return _optimizedParams["Global"];
                
                return null;
            }
        }
        #endregion

        #region Signal Filtering
        /// <summary>
        /// Filtre un signal basé sur l'IA
        /// </summary>
        public AIFilterResult FilterSignal(SMCSignal signal, MarketContext context)
        {
            var result = new AIFilterResult
            {
                SignalId = signal.Id,
                OriginalStrength = signal.Strength,
                Timestamp = DateTime.Now
            };
            
            // Obtenir le régime actuel
            var regime = GetCurrentRegime(signal.Instrument);
            var session = signal.Session;
            
            // Calculer le score ajusté
            double adjustedScore = GetAdjustedSetupScore(signal.Setup, signal.Instrument, regime, session);
            
            // Vérifier le seuil minimum
            if (adjustedScore < Settings.MinScoreThreshold)
            {
                result.ShouldTrade = false;
                result.Reason = $"Score {adjustedScore:F1} below threshold {Settings.MinScoreThreshold}";
                return result;
            }
            
            // Vérifier les paramètres optimisés
            var optParams = GetOptimizedParameters(signal.Instrument);
            if (optParams != null && Settings.UseOptimizedFilters)
            {
                int currentHour = DateTime.Now.Hour;
                DayOfWeek currentDay = DateTime.Now.DayOfWeek;
                
                if (optParams.WorstHours.Contains(currentHour))
                {
                    result.ShouldTrade = false;
                    result.Reason = $"Hour {currentHour} is historically poor";
                    return result;
                }
                
                if (!optParams.BestDays.Contains(currentDay) && optParams.BestDays.Count > 0)
                {
                    adjustedScore *= 0.85; // Réduire le score
                }
            }
            
            // Ajuster la force du signal
            result.AdjustedScore = adjustedScore;
            result.AdjustedStrength = ScoreToStrength(adjustedScore);
            result.RegimeAlignment = GetRegimeMultiplier(signal.Setup, regime);
            result.ShouldTrade = adjustedScore >= Settings.MinScoreThreshold;
            result.Reason = result.ShouldTrade 
                ? $"Score {adjustedScore:F1} approved" 
                : $"Score {adjustedScore:F1} rejected";
            
            // Recommandation de sizing
            result.SuggestedSizeMultiplier = adjustedScore > 70 ? 1.0 
                                           : adjustedScore > 60 ? 0.75 
                                           : 0.5;
            
            return result;
        }

        private SignalStrength ScoreToStrength(double score)
        {
            return score switch
            {
                >= 80 => SignalStrength.VeryStrong,
                >= 65 => SignalStrength.Strong,
                >= 50 => SignalStrength.Medium,
                >= 35 => SignalStrength.Weak,
                _ => SignalStrength.VeryWeak
            };
        }
        #endregion

        #region Persistence
        private string GetStateFilePath()
        {
            string dir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                "NinjaTrader 8", "Sophon", "AI"
            );
            if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
            return Path.Combine(dir, "SophonAI_State.csv");
        }

        private void SaveState()
        {
            try
            {
                var sb = new StringBuilder();
                
                // Sauvegarder les scores
                sb.AppendLine("# Setup Scores");
                foreach (var kvp in _setupScores)
                {
                    sb.AppendLine($"SCORE,{kvp.Key},{kvp.Value.CurrentScore:F2},{kvp.Value.WinRate:F4},{kvp.Value.SampleSize}");
                }
                
                // Sauvegarder les patterns récents
                sb.AppendLine("# Patterns");
                foreach (var p in _patternHistory.TakeLast(500))
                {
                    sb.AppendLine($"PATTERN,{p.Setup},{p.Instrument},{p.RMultiple:F4},{p.IsWinner},{p.MarketRegime},{p.Session},{p.HourOfDay}");
                }
                
                File.WriteAllText(GetStateFilePath(), sb.ToString());
            }
            catch { }
        }

        private void LoadState()
        {
            try
            {
                string path = GetStateFilePath();
                if (!File.Exists(path)) return;
                
                foreach (var line in File.ReadAllLines(path))
                {
                    if (line.StartsWith("#") || string.IsNullOrWhiteSpace(line)) continue;
                    
                    var parts = line.Split(',');
                    if (parts[0] == "SCORE" && parts.Length >= 5)
                    {
                        if (Enum.TryParse<SetupType>(parts[1], out var setup))
                        {
                            _setupScores[setup] = new SetupScore
                            {
                                Setup = setup,
                                CurrentScore = double.Parse(parts[2]),
                                WinRate = double.Parse(parts[3]),
                                SampleSize = int.Parse(parts[4])
                            };
                        }
                    }
                }
            }
            catch { }
        }
        #endregion

        #region Query Interface
        /// <summary>
        /// Obtient un résumé de l'état de l'IA
        /// </summary>
        public AIStatusSummary GetStatusSummary()
        {
            lock (_lock)
            {
                return new AIStatusSummary
                {
                    TotalPatterns = _patternHistory.Count,
                    TotalClusters = _patternClusters.Count,
                    LastOptimization = _lastOptimization,
                    TopSetups = _setupScores.Values
                        .OrderByDescending(s => s.CurrentScore)
                        .Take(3)
                        .Select(s => new SetupSummary { Setup = s.Setup, Score = s.CurrentScore, WinRate = s.WinRate })
                        .ToList(),
                    RegimeDistribution = _patternHistory
                        .GroupBy(p => p.MarketRegime)
                        .ToDictionary(g => g.Key, g => g.Count())
                };
            }
        }
        #endregion
    }

    #region Supporting Classes
    public class AISettings
    {
        public int RegimeLookback { get; set; } = 50;
        public double TrendingADXThreshold { get; set; } = 25;
        public double RangingADXThreshold { get; set; } = 20;
        public double VolatileThreshold { get; set; } = 1.5;
        public double QuietThreshold { get; set; } = 0.7;
        public int MinSamplesForScoring { get; set; } = 10;
        public int MinSamplesForOptimization { get; set; } = 50;
        public int MaxPatternHistory { get; set; } = 2000;
        public double MinScoreThreshold { get; set; } = 40;
        public bool UseOptimizedFilters { get; set; } = true;
        public bool LoadStateOnStart { get; set; } = true;
        public bool SaveStateOnShutdown { get; set; } = true;
    }

    public enum MarketRegime { Unknown, Trending, Ranging, Volatile, Quiet }
    public enum TrendDirection { Bullish, Bearish, Neutral }
    public enum VolatilityLevel { VeryLow, Low, Normal, High, Extreme }

    public class MarketRegimeData
    {
        public string Instrument { get; set; }
        public MarketRegime CurrentRegime { get; set; }
        public double RegimeStrength { get; set; }
        public TrendDirection TrendDirection { get; set; }
        public VolatilityLevel Volatility { get; set; }
        public DateTime LastUpdate { get; set; }
        public CircularBuffer<double> Closes { get; set; }
        public CircularBuffer<double> Highs { get; set; }
        public CircularBuffer<double> Lows { get; set; }
        public CircularBuffer<double> ATRValues { get; set; }
        public CircularBuffer<double> Volumes { get; set; }

        public MarketRegimeData(string instrument)
        {
            Instrument = instrument;
            CurrentRegime = MarketRegime.Unknown;
            Closes = new CircularBuffer<double>(200);
            Highs = new CircularBuffer<double>(200);
            Lows = new CircularBuffer<double>(200);
            ATRValues = new CircularBuffer<double>(200);
            Volumes = new CircularBuffer<double>(200);
        }
    }

    public class RegimeSnapshot
    {
        public DateTime Timestamp { get; set; }
        public MarketRegime Regime { get; set; }
        public double Strength { get; set; }
        public double ATR { get; set; }
        public double Close { get; set; }
    }

    public class SetupScore
    {
        public SetupType Setup { get; set; }
        public double BaseScore { get; set; }
        public double CurrentScore { get; set; }
        public double WinRate { get; set; }
        public double ProfitFactor { get; set; }
        public double AverageRMultiple { get; set; }
        public int SampleSize { get; set; }
        public DateTime LastUpdate { get; set; }
    }

    public class PatternRecord
    {
        public string TradeId { get; set; }
        public SetupType Setup { get; set; }
        public string Instrument { get; set; }
        public TradeDirection Direction { get; set; }
        public DateTime EntryTime { get; set; }
        public DateTime ExitTime { get; set; }
        public double RMultiple { get; set; }
        public bool IsWinner { get; set; }
        public MarketRegime MarketRegime { get; set; }
        public PricePosition PricePosition { get; set; }
        public int ConfluenceCount { get; set; }
        public TradingSession Session { get; set; }
        public DayOfWeek DayOfWeek { get; set; }
        public int HourOfDay { get; set; }
    }

    public class PatternCluster
    {
        public string ClusterId { get; set; }
        public SetupType Setup { get; set; }
        public MarketRegime Regime { get; set; }
        public TradingSession Session { get; set; }
        public int SampleSize { get; set; }
        public double WinRate { get; set; }
        public double AvgRMultiple { get; set; }
        public double Score { get; set; }
        public int BestHour { get; set; }
        public DayOfWeek BestDay { get; set; }
    }

    public class OptimizedParameters
    {
        public string Instrument { get; set; }
        public DateTime OptimizedAt { get; set; }
        public int SampleSize { get; set; }
        public List<int> BestHours { get; set; } = new List<int>();
        public List<int> WorstHours { get; set; } = new List<int>();
        public List<DayOfWeek> BestDays { get; set; } = new List<DayOfWeek>();
        public Dictionary<MarketRegime, SetupType> BestSetupByRegime { get; set; } = new Dictionary<MarketRegime, SetupType>();
        public double ExpectedImprovement { get; set; }
    }

    public class MarketRegimeChange
    {
        public string Instrument { get; set; }
        public MarketRegime PreviousRegime { get; set; }
        public MarketRegime NewRegime { get; set; }
        public DateTime Timestamp { get; set; }
        public double Strength { get; set; }
    }

    public class SetupScoreUpdate
    {
        public SetupType Setup { get; set; }
        public double NewScore { get; set; }
        public double WinRate { get; set; }
        public int SampleSize { get; set; }
    }

    public class OptimizationComplete
    {
        public string Instrument { get; set; }
        public OptimizedParameters Parameters { get; set; }
        public double Improvement { get; set; }
    }

    public class AIFilterResult
    {
        public string SignalId { get; set; }
        public bool ShouldTrade { get; set; }
        public string Reason { get; set; }
        public double AdjustedScore { get; set; }
        public SignalStrength OriginalStrength { get; set; }
        public SignalStrength AdjustedStrength { get; set; }
        public double RegimeAlignment { get; set; }
        public double SuggestedSizeMultiplier { get; set; }
        public DateTime Timestamp { get; set; }
    }

    public class AIStatusSummary
    {
        public int TotalPatterns { get; set; }
        public int TotalClusters { get; set; }
        public DateTime LastOptimization { get; set; }
        public List<SetupSummary> TopSetups { get; set; }
        public Dictionary<MarketRegime, int> RegimeDistribution { get; set; }
    }

    public class SetupSummary
    {
        public SetupType Setup { get; set; }
        public double Score { get; set; }
        public double WinRate { get; set; }
    }
    #endregion
}
