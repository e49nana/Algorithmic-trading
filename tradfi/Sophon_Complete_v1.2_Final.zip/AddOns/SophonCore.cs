#region Using declarations
using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
#endregion

//===============================================================================
// SOPHON CORE v1.0
// Fondations du Système de Trading Automatisé Avancé pour NinjaTrader
// 
// Ce fichier contient toutes les structures, énumérations, classes et interfaces
// partagées entre les différents modules du système Sophon.
//
// Architecture:
//   - Enums: Types fondamentaux (direction, setup, structure de marché)
//   - Structs: Données légères (prix, niveaux)
//   - Classes: Objets complexes (signaux, zones, ordres)
//   - Interfaces: Contrats entre modules
//   - Helpers: Fonctions utilitaires statiques
//
// Copyright (c) 2026 Algosphere Quant - Emmanuel
//===============================================================================

namespace NinjaTrader.NinjaScript.AddOns.Sophon
{
    #region ═══════════════════════════════════════════════════════════════════
    //                              ENUMERATIONS
    // ═══════════════════════════════════════════════════════════════════════
    #endregion

    /// <summary>
    /// Direction générale du marché basée sur la structure SMC
    /// </summary>
    public enum MarketStructure
    {
        /// <summary>Structure haussière - HH et HL successifs</summary>
        Bullish,
        
        /// <summary>Structure baissière - LH et LL successifs</summary>
        Bearish,
        
        /// <summary>Structure neutre/consolidation - pas de direction claire</summary>
        Ranging,
        
        /// <summary>Structure non déterminée (pas assez de données)</summary>
        Unknown
    }

    /// <summary>
    /// Type de changement de structure de marché (MSS)
    /// </summary>
    public enum MarketStructureShift
    {
        /// <summary>Pas de changement de structure</summary>
        None,
        
        /// <summary>Break of Structure - continuation de tendance</summary>
        BOS,
        
        /// <summary>Change of Character - renversement potentiel</summary>
        ChoCH,
        
        /// <summary>Market Structure Shift - confirmation de renversement</summary>
        MSS
    }

    /// <summary>
    /// Types de pivots significatifs
    /// </summary>
    public enum PivotType
    {
        /// <summary>Higher High - nouveau sommet plus haut</summary>
        HH,
        
        /// <summary>Higher Low - creux plus haut</summary>
        HL,
        
        /// <summary>Lower High - sommet plus bas</summary>
        LH,
        
        /// <summary>Lower Low - nouveau creux plus bas</summary>
        LL,
        
        /// <summary>Equal High - sommet égal (liquidité)</summary>
        EQH,
        
        /// <summary>Equal Low - creux égal (liquidité)</summary>
        EQL
    }

    /// <summary>
    /// Types de zones de liquidité ICT
    /// </summary>
    public enum LiquidityType
    {
        /// <summary>Liquidité côté achat (stops au-dessus des sommets)</summary>
        BuySide,
        
        /// <summary>Liquidité côté vente (stops en-dessous des creux)</summary>
        SellSide,
        
        /// <summary>Equal Highs - zone de liquidité achat majeure</summary>
        EqualHighs,
        
        /// <summary>Equal Lows - zone de liquidité vente majeure</summary>
        EqualLows,
        
        /// <summary>Previous Day High</summary>
        PDH,
        
        /// <summary>Previous Day Low</summary>
        PDL,
        
        /// <summary>Previous Week High</summary>
        PWH,
        
        /// <summary>Previous Week Low</summary>
        PWL,
        
        /// <summary>Asian Session High</summary>
        AsianHigh,
        
        /// <summary>Asian Session Low</summary>
        AsianLow
    }

    /// <summary>
    /// Types d'Order Blocks (blocs d'ordres institutionnels)
    /// </summary>
    public enum OrderBlockType
    {
        /// <summary>Order Block haussier - dernière bougie baissière avant montée</summary>
        Bullish,
        
        /// <summary>Order Block baissier - dernière bougie haussière avant descente</summary>
        Bearish,
        
        /// <summary>Breaker Block haussier - ancien OB baissier cassé</summary>
        BullishBreaker,
        
        /// <summary>Breaker Block baissier - ancien OB haussier cassé</summary>
        BearishBreaker,
        
        /// <summary>Mitigation Block - OB partiellement rempli</summary>
        Mitigation
    }

    /// <summary>
    /// État d'une zone (S/R, OB, FVG)
    /// </summary>
    public enum ZoneState
    {
        /// <summary>Zone fraîche, jamais testée</summary>
        Fresh,
        
        /// <summary>Zone testée une fois</summary>
        Tested,
        
        /// <summary>Zone testée plusieurs fois</summary>
        Weakened,
        
        /// <summary>Zone cassée/invalidée</summary>
        Broken,
        
        /// <summary>Zone en cours de test</summary>
        Testing,
        
        /// <summary>Zone remplie (mitigated)</summary>
        Mitigated
    }

    /// <summary>
    /// Types de Fair Value Gaps (FVG/Imbalance)
    /// </summary>
    public enum FVGType
    {
        /// <summary>FVG haussier - gap à combler par le bas</summary>
        Bullish,
        
        /// <summary>FVG baissier - gap à combler par le haut</summary>
        Bearish,
        
        /// <summary>Volume Imbalance haussière</summary>
        VolumeImbalanceBull,
        
        /// <summary>Volume Imbalance baissière</summary>
        VolumeImbalanceBear,
        
        /// <summary>Opening Gap</summary>
        OpeningGap
    }

    /// <summary>
    /// Position du prix dans un range
    /// </summary>
    public enum PricePosition
    {
        /// <summary>Zone Premium - prix cher (>0.5 du range, idéal pour vendre)</summary>
        Premium,
        
        /// <summary>Zone Discount - prix bon marché (<0.5 du range, idéal pour acheter)</summary>
        Discount,
        
        /// <summary>Zone Equilibrium - prix au milieu du range</summary>
        Equilibrium,
        
        /// <summary>Hors range</summary>
        OutOfRange
    }

    /// <summary>
    /// Types de setups de trading Sophon
    /// </summary>
    public enum SetupType
    {
        /// <summary>Setup A - Rebond SMA + Zone S/R (haute probabilité)</summary>
        A_SMA_SR,
        
        /// <summary>Setup B - Breakout de consolidation avec volume</summary>
        B_Breakout,
        
        /// <summary>Setup C - Rebond sur trendline</summary>
        C_Trendline,
        
        /// <summary>Setup D - Retest après cassure (pullback)</summary>
        D_Retest,
        
        /// <summary>Setup E - Order Block + FVG confluence</summary>
        E_OB_FVG,
        
        /// <summary>Setup F - Liquidity Sweep + MSS</summary>
        F_LiquiditySweep,
        
        /// <summary>Setup G - BOS continuation</summary>
        G_BOS_Continuation,
        
        /// <summary>Setup H - ChoCH reversal</summary>
        H_ChoCH_Reversal,
        
        /// <summary>Aucun setup détecté</summary>
        None
    }

    /// <summary>
    /// Direction d'un trade
    /// </summary>
    public enum TradeDirection
    {
        Long,
        Short,
        Flat
    }

    /// <summary>
    /// Qualité/Force d'un signal
    /// </summary>
    public enum SignalStrength
    {
        /// <summary>Signal très fort - haute confluence (>=4 facteurs)</summary>
        VeryStrong = 5,
        
        /// <summary>Signal fort (3 facteurs)</summary>
        Strong = 4,
        
        /// <summary>Signal moyen (2 facteurs)</summary>
        Medium = 3,
        
        /// <summary>Signal faible (1 facteur)</summary>
        Weak = 2,
        
        /// <summary>Signal très faible/douteux</summary>
        VeryWeak = 1
    }

    /// <summary>
    /// État d'un trade
    /// </summary>
    public enum TradeState
    {
        /// <summary>Signal détecté, en attente de validation</summary>
        Pending,
        
        /// <summary>Validé par le filtre risque, prêt à exécuter</summary>
        Validated,
        
        /// <summary>Ordre envoyé, en attente d'exécution</summary>
        Submitted,
        
        /// <summary>Position ouverte</summary>
        Open,
        
        /// <summary>Stop-loss déplacé au break-even</summary>
        BreakEven,
        
        /// <summary>Trailing stop actif</summary>
        Trailing,
        
        /// <summary>Position renforcée (pyramiding)</summary>
        Scaled,
        
        /// <summary>Sortie partielle effectuée</summary>
        PartialExit,
        
        /// <summary>Trade fermé</summary>
        Closed,
        
        /// <summary>Trade annulé/rejeté</summary>
        Cancelled,
        
        /// <summary>Erreur d'exécution</summary>
        Error
    }

    /// <summary>
    /// Raison de sortie d'un trade
    /// </summary>
    public enum ExitReason
    {
        StopLoss,
        TakeProfit1,
        TakeProfit2,
        TakeProfit3,
        TrailingStop,
        BreakEven,
        TimeExit,
        ReverseSignal,
        ManualClose,
        RiskLimit,
        NewsFilter,
        SessionEnd,
        MaxDrawdown,
        CorrelationLimit,
        SystemError
    }

    /// <summary>
    /// Sessions de trading
    /// </summary>
    public enum TradingSession
    {
        /// <summary>Session asiatique (Tokyo)</summary>
        Asian,
        
        /// <summary>Session Londres</summary>
        London,
        
        /// <summary>Session New York</summary>
        NewYork,
        
        /// <summary>Overlap London-NY (haute volatilité)</summary>
        LondonNYOverlap,
        
        /// <summary>Session fermée/off-hours</summary>
        Closed,
        
        /// <summary>Toutes sessions</summary>
        All
    }

    /// <summary>
    /// Profil de risque
    /// </summary>
    public enum RiskProfile
    {
        /// <summary>Ultra conservateur (0.25% risque/trade)</summary>
        UltraConservative,
        
        /// <summary>Conservateur (0.5% risque/trade)</summary>
        Conservative,
        
        /// <summary>Normal (1% risque/trade)</summary>
        Normal,
        
        /// <summary>Agressif (1.5% risque/trade)</summary>
        Aggressive,
        
        /// <summary>Très agressif (2% risque/trade)</summary>
        VeryAggressive,
        
        /// <summary>Personnalisé</summary>
        Custom
    }

    /// <summary>
    /// Mode de fonctionnement du système
    /// </summary>
    public enum OperationMode
    {
        /// <summary>Mode automatique - exécution sans intervention</summary>
        Automatic,
        
        /// <summary>Mode semi-auto - confirmation manuelle requise</summary>
        SemiAutomatic,
        
        /// <summary>Mode manuel - analyse seulement, pas d'exécution</summary>
        ManualOnly,
        
        /// <summary>Mode backtest</summary>
        Backtest,
        
        /// <summary>Système en pause</summary>
        Paused
    }

    /// <summary>
    /// Types de timeframes pour l'analyse multi-TF
    /// </summary>
    public enum TimeframeType
    {
        /// <summary>Timeframe d'exécution (M1-M5)</summary>
        Execution,
        
        /// <summary>Timeframe d'entrée (M3-M15)</summary>
        Entry,
        
        /// <summary>Timeframe de confirmation (M15-H1)</summary>
        Confirmation,
        
        /// <summary>Timeframe de tendance HTF (H4-D1)</summary>
        Trend,
        
        /// <summary>Timeframe de structure (D1-W1)</summary>
        Structure
    }

    /// <summary>
    /// Niveaux de log
    /// </summary>
    public enum LogLevel
    {
        Debug = 0,
        Info = 1,
        Warning = 2,
        Error = 3,
        Critical = 4,
        Trade = 5
    }

    #region ═══════════════════════════════════════════════════════════════════
    //                              STRUCTURES
    // ═══════════════════════════════════════════════════════════════════════
    #endregion

    /// <summary>
    /// Niveau de prix avec métadonnées
    /// </summary>
    public struct PriceLevel
    {
        public double Price;
        public DateTime Timestamp;
        public int BarIndex;
        public double Volume;
        public string Label;

        public PriceLevel(double price, DateTime timestamp, int barIndex, double volume = 0, string label = "")
        {
            Price = price;
            Timestamp = timestamp;
            BarIndex = barIndex;
            Volume = volume;
            Label = label;
        }

        public bool IsValid => Price > 0 && BarIndex >= 0;
        
        public override string ToString() => $"{Label}: {Price:F2} @ Bar {BarIndex}";
    }

    /// <summary>
    /// Point pivot avec type
    /// </summary>
    public struct PivotPoint
    {
        public double Price;
        public DateTime Timestamp;
        public int BarIndex;
        public PivotType Type;
        public bool IsSwing;
        public int Strength;

        public PivotPoint(double price, DateTime timestamp, int barIndex, PivotType type, bool isSwing = false, int strength = 1)
        {
            Price = price;
            Timestamp = timestamp;
            BarIndex = barIndex;
            Type = type;
            IsSwing = isSwing;
            Strength = strength;
        }

        public bool IsBullish => Type == PivotType.HH || Type == PivotType.HL;
        public bool IsBearish => Type == PivotType.LH || Type == PivotType.LL;
        
        public override string ToString() => $"{Type}: {Price:F2} @ {Timestamp:HH:mm}";
    }

    /// <summary>
    /// Range de prix (haut/bas)
    /// </summary>
    public struct PriceRange
    {
        public double High;
        public double Low;
        public DateTime StartTime;
        public DateTime EndTime;
        public int StartBar;
        public int EndBar;

        public PriceRange(double high, double low, DateTime startTime, DateTime endTime, int startBar, int endBar)
        {
            High = high;
            Low = low;
            StartTime = startTime;
            EndTime = endTime;
            StartBar = startBar;
            EndBar = endBar;
        }

        public double Range => High - Low;
        public double Mid => (High + Low) / 2;
        public double Equilibrium => Mid;
        public double PremiumLevel => Mid + (Range * 0.25); // 75% du range
        public double DiscountLevel => Mid - (Range * 0.25); // 25% du range
        
        public bool Contains(double price) => price >= Low && price <= High;
        
        public PricePosition GetPosition(double price)
        {
            if (!Contains(price)) return PricePosition.OutOfRange;
            double ratio = (price - Low) / Range;
            if (ratio > 0.618) return PricePosition.Premium;
            if (ratio < 0.382) return PricePosition.Discount;
            return PricePosition.Equilibrium;
        }
        
        public override string ToString() => $"Range: {Low:F2} - {High:F2} (Size: {Range:F2})";
    }

    /// <summary>
    /// Paramètres de risque pour un trade
    /// </summary>
    public struct RiskParameters
    {
        public double RiskPercent;
        public double RiskAmount;
        public int PositionSize;
        public double StopLossPrice;
        public double StopLossDistance;
        public double TakeProfit1Price;
        public double TakeProfit2Price;
        public double TakeProfit3Price;
        public double RiskRewardRatio;
        public double ATRValue;
        public double ATRMultiplier;

        public bool IsValid => PositionSize > 0 && StopLossDistance > 0 && RiskRewardRatio > 0;
        
        public override string ToString() => $"Risk: {RiskPercent:P1}, Size: {PositionSize}, SL: {StopLossDistance:F2}, R:R: {RiskRewardRatio:F1}";
    }

    /// <summary>
    /// Statistiques de corrélation
    /// </summary>
    public struct CorrelationData
    {
        public string Instrument1;
        public string Instrument2;
        public double Correlation;
        public int Period;
        public DateTime CalculatedAt;

        public CorrelationData(string inst1, string inst2, double corr, int period)
        {
            Instrument1 = inst1;
            Instrument2 = inst2;
            Correlation = corr;
            Period = period;
            CalculatedAt = DateTime.Now;
        }

        public bool IsHighlyCorrelated => Math.Abs(Correlation) >= 0.7;
        public bool IsInverselyCorrelated => Correlation <= -0.7;
        
        public override string ToString() => $"{Instrument1}/{Instrument2}: {Correlation:F2}";
    }

    #region ═══════════════════════════════════════════════════════════════════
    //                              CLASSES
    // ═══════════════════════════════════════════════════════════════════════
    #endregion

    /// <summary>
    /// Zone de Support/Résistance
    /// </summary>
    public class SRZone
    {
        public double UpperPrice { get; set; }
        public double LowerPrice { get; set; }
        public DateTime CreatedAt { get; set; }
        public int CreatedBar { get; set; }
        public int TouchCount { get; set; }
        public ZoneState State { get; set; }
        public bool IsSupport { get; set; }
        public double Strength { get; set; }
        public string Instrument { get; set; }
        public List<DateTime> TouchTimestamps { get; set; }

        public SRZone()
        {
            TouchTimestamps = new List<DateTime>();
            State = ZoneState.Fresh;
            TouchCount = 0;
            Strength = 1.0;
        }

        public SRZone(double upper, double lower, DateTime created, int bar, bool isSupport, string instrument = "")
            : this()
        {
            UpperPrice = upper;
            LowerPrice = lower;
            CreatedAt = created;
            CreatedBar = bar;
            IsSupport = isSupport;
            Instrument = instrument;
        }

        public double MidPrice => (UpperPrice + LowerPrice) / 2;
        public double ZoneSize => UpperPrice - LowerPrice;
        public bool IsActive => State != ZoneState.Broken && State != ZoneState.Mitigated;
        
        public bool Contains(double price) => price >= LowerPrice && price <= UpperPrice;
        
        public bool IsNear(double price, double tolerance)
        {
            return Math.Abs(price - MidPrice) <= (ZoneSize / 2 + tolerance);
        }

        public void RecordTouch(DateTime timestamp)
        {
            TouchCount++;
            TouchTimestamps.Add(timestamp);
            
            if (TouchCount == 1)
                State = ZoneState.Tested;
            else if (TouchCount >= 3)
                State = ZoneState.Weakened;
        }

        public void MarkBroken() => State = ZoneState.Broken;
        public void MarkMitigated() => State = ZoneState.Mitigated;

        public override string ToString() => 
            $"{(IsSupport ? "Support" : "Resistance")}: {LowerPrice:F2}-{UpperPrice:F2} [{State}] Touches: {TouchCount}";
    }

    /// <summary>
    /// Order Block (bloc d'ordres institutionnel)
    /// </summary>
    public class OrderBlock
    {
        public double HighPrice { get; set; }
        public double LowPrice { get; set; }
        public double OpenPrice { get; set; }
        public double ClosePrice { get; set; }
        public DateTime CreatedAt { get; set; }
        public int CreatedBar { get; set; }
        public OrderBlockType Type { get; set; }
        public ZoneState State { get; set; }
        public double Volume { get; set; }
        public int TouchCount { get; set; }
        public double ImpulseStrength { get; set; }
        public string Instrument { get; set; }
        public int ExpirationBars { get; set; }

        public OrderBlock()
        {
            State = ZoneState.Fresh;
            TouchCount = 0;
            ImpulseStrength = 1.0;
            ExpirationBars = 100;
        }

        public double MidPrice => (HighPrice + LowPrice) / 2;
        public double BlockSize => HighPrice - LowPrice;
        public bool IsBullish => Type == OrderBlockType.Bullish || Type == OrderBlockType.BullishBreaker;
        public bool IsBearish => Type == OrderBlockType.Bearish || Type == OrderBlockType.BearishBreaker;
        public bool IsActive => State != ZoneState.Broken && State != ZoneState.Mitigated;
        
        /// <summary>Zone d'entrée optimale (50-100% du OB)</summary>
        public double OptimalEntryHigh => IsBullish ? LowPrice + (BlockSize * 0.5) : HighPrice;
        public double OptimalEntryLow => IsBullish ? LowPrice : HighPrice - (BlockSize * 0.5);

        public bool Contains(double price) => price >= LowPrice && price <= HighPrice;
        
        public bool IsInOptimalEntry(double price)
        {
            return price >= OptimalEntryLow && price <= OptimalEntryHigh;
        }

        public void RecordTouch()
        {
            TouchCount++;
            if (TouchCount == 1)
                State = ZoneState.Tested;
            else if (TouchCount >= 2)
                State = ZoneState.Mitigated;
        }

        public override string ToString() => 
            $"OB {Type}: {LowPrice:F2}-{HighPrice:F2} [{State}] Strength: {ImpulseStrength:F1}";
    }

    /// <summary>
    /// Fair Value Gap (FVG/Imbalance)
    /// </summary>
    public class FairValueGap
    {
        public double HighPrice { get; set; }
        public double LowPrice { get; set; }
        public DateTime CreatedAt { get; set; }
        public int CreatedBar { get; set; }
        public FVGType Type { get; set; }
        public ZoneState State { get; set; }
        public double FillPercentage { get; set; }
        public string Instrument { get; set; }
        public int ExpirationBars { get; set; }

        public FairValueGap()
        {
            State = ZoneState.Fresh;
            FillPercentage = 0;
            ExpirationBars = 50;
        }

        public double GapSize => HighPrice - LowPrice;
        public double MidPrice => (HighPrice + LowPrice) / 2;
        public bool IsBullish => Type == FVGType.Bullish || Type == FVGType.VolumeImbalanceBull;
        public bool IsBearish => Type == FVGType.Bearish || Type == FVGType.VolumeImbalanceBear;
        public bool IsActive => State != ZoneState.Mitigated && FillPercentage < 100;
        
        /// <summary>Zone CE (Consequent Encroachment) - 50% du FVG</summary>
        public double CELevel => MidPrice;

        public bool Contains(double price) => price >= LowPrice && price <= HighPrice;

        public void UpdateFill(double price)
        {
            if (!Contains(price)) return;
            
            double fillDistance;
            if (IsBullish)
                fillDistance = HighPrice - price;
            else
                fillDistance = price - LowPrice;
                
            FillPercentage = Math.Max(FillPercentage, (fillDistance / GapSize) * 100);
            
            if (FillPercentage >= 50)
                State = ZoneState.Tested;
            if (FillPercentage >= 100)
                State = ZoneState.Mitigated;
        }

        public override string ToString() => 
            $"FVG {Type}: {LowPrice:F2}-{HighPrice:F2} [{State}] Fill: {FillPercentage:F0}%";
    }

    /// <summary>
    /// Zone de liquidité
    /// </summary>
    public class LiquidityZone
    {
        public double Price { get; set; }
        public DateTime CreatedAt { get; set; }
        public int CreatedBar { get; set; }
        public LiquidityType Type { get; set; }
        public ZoneState State { get; set; }
        public double EstimatedVolume { get; set; }
        public int TouchCount { get; set; }
        public bool WasTaken { get; set; }
        public DateTime TakenAt { get; set; }
        public string Instrument { get; set; }

        public LiquidityZone()
        {
            State = ZoneState.Fresh;
            TouchCount = 0;
            WasTaken = false;
        }

        public bool IsBuySide => Type == LiquidityType.BuySide || 
                                  Type == LiquidityType.EqualHighs || 
                                  Type == LiquidityType.PDH || 
                                  Type == LiquidityType.PWH ||
                                  Type == LiquidityType.AsianHigh;
                                  
        public bool IsSellSide => !IsBuySide;
        public bool IsActive => !WasTaken && State != ZoneState.Broken;

        public void MarkAsTaken(DateTime timestamp)
        {
            WasTaken = true;
            TakenAt = timestamp;
            State = ZoneState.Broken;
        }

        public override string ToString() => 
            $"Liquidity {Type}: {Price:F2} [{(WasTaken ? "TAKEN" : "Active")}]";
    }

    /// <summary>
    /// Signal de trading SMC
    /// </summary>
    public class SMCSignal
    {
        public string Id { get; set; }
        public string Instrument { get; set; }
        public DateTime Timestamp { get; set; }
        public int BarIndex { get; set; }
        public SetupType Setup { get; set; }
        public TradeDirection Direction { get; set; }
        public SignalStrength Strength { get; set; }
        public double EntryPrice { get; set; }
        public double StopLoss { get; set; }
        public double TakeProfit1 { get; set; }
        public double TakeProfit2 { get; set; }
        public double TakeProfit3 { get; set; }
        public double RiskRewardRatio { get; set; }
        public List<string> ConfluenceFactors { get; set; }
        public MarketStructure Structure { get; set; }
        public PricePosition PricePosition { get; set; }
        public TradingSession Session { get; set; }
        public OrderBlock RelatedOB { get; set; }
        public FairValueGap RelatedFVG { get; set; }
        public LiquidityZone RelatedLiquidity { get; set; }
        public string Notes { get; set; }
        public bool IsValid { get; set; }
        public DateTime ExpiresAt { get; set; }

        public SMCSignal()
        {
            Id = Guid.NewGuid().ToString("N").Substring(0, 8);
            ConfluenceFactors = new List<string>();
            IsValid = true;
            Timestamp = DateTime.Now;
            ExpiresAt = DateTime.Now.AddMinutes(30);
        }

        public int ConfluenceCount => ConfluenceFactors.Count;
        public bool IsLong => Direction == TradeDirection.Long;
        public bool IsShort => Direction == TradeDirection.Short;
        public bool IsExpired => DateTime.Now > ExpiresAt;
        
        public double RiskInPoints => Math.Abs(EntryPrice - StopLoss);
        public double Reward1InPoints => Math.Abs(TakeProfit1 - EntryPrice);

        public void AddConfluence(string factor)
        {
            if (!ConfluenceFactors.Contains(factor))
            {
                ConfluenceFactors.Add(factor);
                UpdateStrength();
            }
        }

        private void UpdateStrength()
        {
            int count = ConfluenceFactors.Count;
            if (count >= 5) Strength = SignalStrength.VeryStrong;
            else if (count >= 4) Strength = SignalStrength.Strong;
            else if (count >= 3) Strength = SignalStrength.Medium;
            else if (count >= 2) Strength = SignalStrength.Weak;
            else Strength = SignalStrength.VeryWeak;
        }

        public string GetSetupLabel()
        {
            string letter = Setup.ToString().Split('_')[0];
            string arrow = IsLong ? "↑" : "↓";
            return $"{letter}{arrow}";
        }

        public override string ToString() => 
            $"[{GetSetupLabel()}] {Instrument} @ {EntryPrice:F2} | SL: {StopLoss:F2} | TP1: {TakeProfit1:F2} | R:R: {RiskRewardRatio:F1} | {Strength}";
    }

    /// <summary>
    /// Configuration d'un trade à exécuter
    /// </summary>
    public class TradeSetup
    {
        public string Id { get; set; }
        public SMCSignal Signal { get; set; }
        public RiskParameters Risk { get; set; }
        public TradeState State { get; set; }
        public string AccountId { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? ExecutedAt { get; set; }
        public DateTime? ClosedAt { get; set; }
        public int OrderId { get; set; }
        public double ActualEntryPrice { get; set; }
        public double ActualExitPrice { get; set; }
        public int ActualPositionSize { get; set; }
        public double RealizedPnL { get; set; }
        public double MaxFavorableExcursion { get; set; }
        public double MaxAdverseExcursion { get; set; }
        public ExitReason? ExitReason { get; set; }
        public List<string> ExecutionLog { get; set; }
        public int PyramidLevel { get; set; }
        public List<TradeSetup> PyramidTrades { get; set; }

        public TradeSetup()
        {
            Id = Guid.NewGuid().ToString("N").Substring(0, 8);
            State = TradeState.Pending;
            CreatedAt = DateTime.Now;
            ExecutionLog = new List<string>();
            PyramidTrades = new List<TradeSetup>();
            PyramidLevel = 0;
        }

        public TradeSetup(SMCSignal signal) : this()
        {
            Signal = signal;
        }

        public bool IsOpen => State == TradeState.Open || 
                              State == TradeState.BreakEven || 
                              State == TradeState.Trailing || 
                              State == TradeState.Scaled;
                              
        public bool IsClosed => State == TradeState.Closed || State == TradeState.Cancelled;
        public TimeSpan Duration => (ClosedAt ?? DateTime.Now) - (ExecutedAt ?? CreatedAt);

        public void Log(string message)
        {
            ExecutionLog.Add($"[{DateTime.Now:HH:mm:ss}] {message}");
        }

        public void UpdateMFE(double currentPrice)
        {
            if (!IsOpen) return;
            
            double excursion = Signal.IsLong 
                ? currentPrice - ActualEntryPrice 
                : ActualEntryPrice - currentPrice;
                
            if (excursion > MaxFavorableExcursion)
                MaxFavorableExcursion = excursion;
        }

        public void UpdateMAE(double currentPrice)
        {
            if (!IsOpen) return;
            
            double excursion = Signal.IsLong 
                ? ActualEntryPrice - currentPrice 
                : currentPrice - ActualEntryPrice;
                
            if (excursion > MaxAdverseExcursion)
                MaxAdverseExcursion = excursion;
        }

        public override string ToString() => 
            $"Trade {Id}: {Signal?.Instrument} {Signal?.Direction} [{State}] P/L: {RealizedPnL:F2}";
    }

    /// <summary>
    /// Résultat d'un trade (pour journal et statistiques)
    /// </summary>
    public class TradeResult
    {
        public string TradeId { get; set; }
        public string Instrument { get; set; }
        public SetupType Setup { get; set; }
        public TradeDirection Direction { get; set; }
        public DateTime EntryTime { get; set; }
        public DateTime ExitTime { get; set; }
        public double EntryPrice { get; set; }
        public double ExitPrice { get; set; }
        public int PositionSize { get; set; }
        public double GrossPnL { get; set; }
        public double Commission { get; set; }
        public double NetPnL { get; set; }
        public double RMultiple { get; set; }
        public double MFE { get; set; }
        public double MAE { get; set; }
        public ExitReason ExitReason { get; set; }
        public SignalStrength SignalStrength { get; set; }
        public TradingSession Session { get; set; }
        public int ConfluenceCount { get; set; }
        public List<string> ConfluenceFactors { get; set; }
        public string Notes { get; set; }

        public TradeResult()
        {
            ConfluenceFactors = new List<string>();
        }

        public bool IsWinner => NetPnL > 0;
        public bool IsLoser => NetPnL < 0;
        public bool IsBreakEven => Math.Abs(NetPnL) < 0.01;
        public TimeSpan Duration => ExitTime - EntryTime;
        public double EfficiencyRatio => MFE > 0 ? NetPnL / MFE : 0;
        public double EdgeRatio => MAE > 0 ? MFE / MAE : 0;

        public static TradeResult FromTradeSetup(TradeSetup trade)
        {
            return new TradeResult
            {
                TradeId = trade.Id,
                Instrument = trade.Signal?.Instrument,
                Setup = trade.Signal?.Setup ?? SetupType.None,
                Direction = trade.Signal?.Direction ?? TradeDirection.Flat,
                EntryTime = trade.ExecutedAt ?? trade.CreatedAt,
                ExitTime = trade.ClosedAt ?? DateTime.Now,
                EntryPrice = trade.ActualEntryPrice,
                ExitPrice = trade.ActualExitPrice,
                PositionSize = trade.ActualPositionSize,
                NetPnL = trade.RealizedPnL,
                MFE = trade.MaxFavorableExcursion,
                MAE = trade.MaxAdverseExcursion,
                ExitReason = trade.ExitReason ?? Sophon.ExitReason.ManualClose,
                SignalStrength = trade.Signal?.Strength ?? SignalStrength.Medium,
                ConfluenceCount = trade.Signal?.ConfluenceCount ?? 0,
                ConfluenceFactors = trade.Signal?.ConfluenceFactors ?? new List<string>()
            };
        }

        public override string ToString() => 
            $"{Instrument} {Direction} {Setup}: {NetPnL:F2} ({RMultiple:F1}R) [{ExitReason}]";
    }

    /// <summary>
    /// Configuration d'un compte de trading
    /// </summary>
    public class AccountConfig
    {
        public string AccountId { get; set; }
        public string AccountName { get; set; }
        public string BrokerName { get; set; }
        public double InitialBalance { get; set; }
        public double CurrentBalance { get; set; }
        public RiskProfile RiskProfile { get; set; }
        public double MaxRiskPerTrade { get; set; }
        public double MaxDailyLoss { get; set; }
        public double MaxDrawdown { get; set; }
        public int MaxOpenTrades { get; set; }
        public int MaxTradesPerDay { get; set; }
        public List<string> AllowedInstruments { get; set; }
        public List<TradingSession> AllowedSessions { get; set; }
        public bool IsActive { get; set; }
        public bool IsMaster { get; set; }
        public double CopyRatio { get; set; }

        public AccountConfig()
        {
            AllowedInstruments = new List<string>();
            AllowedSessions = new List<TradingSession>();
            RiskProfile = RiskProfile.Normal;
            MaxRiskPerTrade = 0.01;
            MaxDailyLoss = 0.03;
            MaxDrawdown = 0.10;
            MaxOpenTrades = 5;
            MaxTradesPerDay = 10;
            IsActive = true;
            IsMaster = false;
            CopyRatio = 1.0;
        }

        public double DailyLossAmount => InitialBalance * MaxDailyLoss;
        public double MaxDrawdownAmount => InitialBalance * MaxDrawdown;
        public double RiskAmountPerTrade => CurrentBalance * MaxRiskPerTrade;

        public override string ToString() => 
            $"{AccountName} ({AccountId}): {CurrentBalance:C} | Risk: {MaxRiskPerTrade:P1}";
    }

    /// <summary>
    /// Données de marché agrégées pour un instrument
    /// </summary>
    public class MarketContext
    {
        public string Instrument { get; set; }
        public DateTime Timestamp { get; set; }
        public MarketStructure Structure { get; set; }
        public MarketStructure HTFStructure { get; set; }
        public PricePosition CurrentPosition { get; set; }
        public TradingSession CurrentSession { get; set; }
        public double ATR { get; set; }
        public double ATRPercent { get; set; }
        public double RSI { get; set; }
        public double VolatilityRatio { get; set; }
        public PriceRange DailyRange { get; set; }
        public PriceRange WeeklyRange { get; set; }
        public PriceRange CurrentSwingRange { get; set; }
        public List<PivotPoint> RecentPivots { get; set; }
        public List<OrderBlock> ActiveOrderBlocks { get; set; }
        public List<FairValueGap> ActiveFVGs { get; set; }
        public List<LiquidityZone> ActiveLiquidity { get; set; }
        public List<SRZone> ActiveSRZones { get; set; }
        public double? NextResistance { get; set; }
        public double? NextSupport { get; set; }
        public bool HasBullishBias { get; set; }
        public bool HasBearishBias { get; set; }
        public int ConfluenceScore { get; set; }

        public MarketContext()
        {
            RecentPivots = new List<PivotPoint>();
            ActiveOrderBlocks = new List<OrderBlock>();
            ActiveFVGs = new List<FairValueGap>();
            ActiveLiquidity = new List<LiquidityZone>();
            ActiveSRZones = new List<SRZone>();
            Timestamp = DateTime.Now;
        }

        public bool IsTrending => Structure == MarketStructure.Bullish || Structure == MarketStructure.Bearish;
        public bool IsRanging => Structure == MarketStructure.Ranging;
        public bool IsAlignedWithHTF => Structure == HTFStructure;
        
        public bool IsHighVolatility => VolatilityRatio > 1.5;
        public bool IsLowVolatility => VolatilityRatio < 0.5;

        public override string ToString() => 
            $"{Instrument}: {Structure} | Session: {CurrentSession} | ATR: {ATR:F2} | RSI: {RSI:F0}";
    }

    /// <summary>
    /// Événement économique (pour filtre news)
    /// </summary>
    public class EconomicEvent
    {
        public string Id { get; set; }
        public DateTime Timestamp { get; set; }
        public string Currency { get; set; }
        public string Title { get; set; }
        public int Impact { get; set; } // 1=Low, 2=Medium, 3=High
        public string Actual { get; set; }
        public string Forecast { get; set; }
        public string Previous { get; set; }
        public List<string> AffectedInstruments { get; set; }

        public EconomicEvent()
        {
            AffectedInstruments = new List<string>();
        }

        public bool IsHighImpact => Impact >= 3;
        public bool IsMediumImpact => Impact == 2;
        public bool IsUpcoming => Timestamp > DateTime.Now;
        public TimeSpan TimeUntil => Timestamp - DateTime.Now;

        public bool IsWithinWindow(int minutesBefore, int minutesAfter)
        {
            DateTime now = DateTime.Now;
            return now >= Timestamp.AddMinutes(-minutesBefore) && 
                   now <= Timestamp.AddMinutes(minutesAfter);
        }

        public override string ToString() => 
            $"[{Impact}★] {Currency} {Title} @ {Timestamp:HH:mm}";
    }

    /// <summary>
    /// Message de log du système
    /// </summary>
    public class LogEntry
    {
        public DateTime Timestamp { get; set; }
        public LogLevel Level { get; set; }
        public string Module { get; set; }
        public string Message { get; set; }
        public string TradeId { get; set; }
        public string Instrument { get; set; }
        public Dictionary<string, object> Data { get; set; }

        public LogEntry()
        {
            Timestamp = DateTime.Now;
            Data = new Dictionary<string, object>();
        }

        public LogEntry(LogLevel level, string module, string message) : this()
        {
            Level = level;
            Module = module;
            Message = message;
        }

        public override string ToString() => 
            $"[{Timestamp:HH:mm:ss}] [{Level}] [{Module}] {Message}";
    }

    #region ═══════════════════════════════════════════════════════════════════
    //                              INTERFACES
    // ═══════════════════════════════════════════════════════════════════════
    #endregion

    /// <summary>
    /// Interface de base pour tous les modules Sophon
    /// </summary>
    public interface ISophonModule
    {
        string ModuleName { get; }
        bool IsInitialized { get; }
        bool IsEnabled { get; set; }
        
        void Initialize();
        void Shutdown();
        void Reset();
        void OnBarUpdate(int barsInProgress);
    }

    /// <summary>
    /// Interface pour les providers de signaux
    /// </summary>
    public interface ISignalProvider
    {
        List<SMCSignal> GetActiveSignals();
        SMCSignal GetSignal(string instrument);
        void InvalidateSignal(string signalId);
        event EventHandler<SMCSignal> OnNewSignal;
        event EventHandler<SMCSignal> OnSignalInvalidated;
    }

    /// <summary>
    /// Interface pour la gestion du risque
    /// </summary>
    public interface IRiskManager
    {
        bool ValidateSignal(SMCSignal signal, AccountConfig account);
        RiskParameters CalculateRisk(SMCSignal signal, AccountConfig account, double atr);
        bool CanOpenTrade(AccountConfig account);
        double GetCurrentDrawdown(string accountId);
        double GetDailyPnL(string accountId);
        int GetOpenTradesCount(string accountId);
        bool IsCorrelationSafe(string instrument, List<TradeSetup> openTrades);
    }

    /// <summary>
    /// Interface pour l'exécution des ordres
    /// </summary>
    public interface IOrderExecutor
    {
        TradeSetup ExecuteTrade(TradeSetup setup);
        bool ModifyStopLoss(TradeSetup trade, double newStopLoss);
        bool ModifyTakeProfit(TradeSetup trade, double newTakeProfit);
        bool ClosePosition(TradeSetup trade, ExitReason reason);
        bool CloseAllPositions(string accountId, ExitReason reason);
        List<TradeSetup> GetOpenTrades(string accountId = null);
        event EventHandler<TradeSetup> OnTradeOpened;
        event EventHandler<TradeSetup> OnTradeClosed;
        event EventHandler<TradeSetup> OnTradeModified;
    }

    /// <summary>
    /// Interface pour le journal de trading
    /// </summary>
    public interface ITradeJournal
    {
        void LogTrade(TradeResult result);
        void LogEntry(LogEntry entry);
        List<TradeResult> GetTrades(DateTime? from = null, DateTime? to = null, string instrument = null);
        Dictionary<string, double> GetStatistics(DateTime? from = null, DateTime? to = null);
        void ExportToCsv(string filePath);
    }

    /// <summary>
    /// Interface pour le dashboard
    /// </summary>
    public interface IDashboard
    {
        void UpdateSignals(List<SMCSignal> signals);
        void UpdateTrades(List<TradeSetup> trades);
        void UpdateMarketContext(MarketContext context);
        void UpdateStatistics(Dictionary<string, double> stats);
        void ShowAlert(string message, LogLevel level);
    }

    #region ═══════════════════════════════════════════════════════════════════
    //                          HELPER CLASSES
    // ═══════════════════════════════════════════════════════════════════════
    #endregion

    /// <summary>
    /// Fonctions utilitaires statiques pour les calculs
    /// </summary>
    public static class SophonHelpers
    {
        #region Price Calculations
        
        /// <summary>
        /// Calcule le milieu d'un range
        /// </summary>
        public static double MidPrice(double high, double low) => (high + low) / 2;
        
        /// <summary>
        /// Calcule le niveau Fibonacci dans un range
        /// </summary>
        public static double FibLevel(double high, double low, double ratio, bool fromLow = true)
        {
            double range = high - low;
            return fromLow ? low + (range * ratio) : high - (range * ratio);
        }
        
        /// <summary>
        /// Calcule le ratio d'un prix dans un range (0 = low, 1 = high)
        /// </summary>
        public static double PriceRatio(double price, double high, double low)
        {
            if (high == low) return 0.5;
            return (price - low) / (high - low);
        }
        
        /// <summary>
        /// Vérifie si un prix est dans un range avec tolérance
        /// </summary>
        public static bool IsInRange(double price, double high, double low, double tolerance = 0)
        {
            return price >= (low - tolerance) && price <= (high + tolerance);
        }
        
        /// <summary>
        /// Distance en points entre deux prix
        /// </summary>
        public static double PointDistance(double price1, double price2) => Math.Abs(price1 - price2);
        
        /// <summary>
        /// Distance en pourcentage
        /// </summary>
        public static double PercentDistance(double price1, double price2)
        {
            if (price1 == 0) return 0;
            return Math.Abs(price2 - price1) / price1 * 100;
        }
        
        #endregion
        
        #region ATR Calculations
        
        /// <summary>
        /// Calcule le stop-loss basé sur l'ATR
        /// </summary>
        public static double CalculateATRStop(double entryPrice, double atr, double multiplier, bool isLong)
        {
            double stopDistance = atr * multiplier;
            return isLong ? entryPrice - stopDistance : entryPrice + stopDistance;
        }
        
        /// <summary>
        /// Calcule le take-profit basé sur le R:R et l'ATR
        /// </summary>
        public static double CalculateATRTarget(double entryPrice, double stopLoss, double rrRatio, bool isLong)
        {
            double risk = Math.Abs(entryPrice - stopLoss);
            double reward = risk * rrRatio;
            return isLong ? entryPrice + reward : entryPrice - reward;
        }
        
        /// <summary>
        /// Calcule la taille de position basée sur le risque et l'ATR
        /// </summary>
        public static int CalculatePositionSize(double accountBalance, double riskPercent, double stopDistance, double pointValue)
        {
            if (stopDistance <= 0 || pointValue <= 0) return 0;
            double riskAmount = accountBalance * riskPercent;
            double positionSize = riskAmount / (stopDistance * pointValue);
            return (int)Math.Floor(positionSize);
        }
        
        #endregion
        
        #region Time Helpers
        
        /// <summary>
        /// Détermine la session de trading actuelle
        /// </summary>
        public static TradingSession GetCurrentSession(DateTime time)
        {
            int hour = time.Hour;
            int minute = time.Minute;
            double timeDecimal = hour + (minute / 60.0);
            
            // Heures UTC
            // Asian: 00:00 - 09:00
            // London: 08:00 - 17:00
            // NY: 13:00 - 22:00
            // Overlap: 13:00 - 17:00
            
            if (timeDecimal >= 13 && timeDecimal < 17)
                return TradingSession.LondonNYOverlap;
            if (timeDecimal >= 8 && timeDecimal < 17)
                return TradingSession.London;
            if (timeDecimal >= 13 && timeDecimal < 22)
                return TradingSession.NewYork;
            if (timeDecimal >= 0 && timeDecimal < 9)
                return TradingSession.Asian;
                
            return TradingSession.Closed;
        }
        
        /// <summary>
        /// Vérifie si c'est une session de haute volatilité
        /// </summary>
        public static bool IsHighVolatilitySession(DateTime time)
        {
            var session = GetCurrentSession(time);
            return session == TradingSession.LondonNYOverlap || 
                   session == TradingSession.London;
        }
        
        /// <summary>
        /// Calcule les minutes jusqu'à la fin de session
        /// </summary>
        public static int MinutesToSessionEnd(DateTime time, TradingSession session)
        {
            int currentMinutes = time.Hour * 60 + time.Minute;
            int sessionEndMinutes = session switch
            {
                TradingSession.Asian => 9 * 60,
                TradingSession.London => 17 * 60,
                TradingSession.NewYork => 22 * 60,
                TradingSession.LondonNYOverlap => 17 * 60,
                _ => 24 * 60
            };
            
            int diff = sessionEndMinutes - currentMinutes;
            return diff > 0 ? diff : diff + 24 * 60;
        }
        
        #endregion
        
        #region Correlation Helpers
        
        /// <summary>
        /// Calcule la corrélation de Pearson entre deux séries
        /// </summary>
        public static double CalculateCorrelation(double[] series1, double[] series2)
        {
            if (series1.Length != series2.Length || series1.Length < 2)
                return 0;
                
            int n = series1.Length;
            double sum1 = series1.Sum();
            double sum2 = series2.Sum();
            double sum1Sq = series1.Sum(x => x * x);
            double sum2Sq = series2.Sum(x => x * x);
            double sumProd = series1.Zip(series2, (a, b) => a * b).Sum();
            
            double num = (n * sumProd) - (sum1 * sum2);
            double den = Math.Sqrt((n * sum1Sq - sum1 * sum1) * (n * sum2Sq - sum2 * sum2));
            
            return den == 0 ? 0 : num / den;
        }
        
        /// <summary>
        /// Vérifie si deux instruments sont corrélés selon un seuil
        /// </summary>
        public static bool AreCorrelated(double correlation, double threshold = 0.7)
        {
            return Math.Abs(correlation) >= threshold;
        }
        
        #endregion
        
        #region Signal Validation
        
        /// <summary>
        /// Valide un ratio R:R
        /// </summary>
        public static bool IsValidRiskReward(double rr, double minRR = 1.5)
        {
            return rr >= minRR;
        }
        
        /// <summary>
        /// Calcule le score de confluence
        /// </summary>
        public static int CalculateConfluenceScore(List<string> factors)
        {
            int score = factors.Count;
            
            // Bonus pour certains facteurs critiques
            if (factors.Contains("HTF_Aligned")) score += 2;
            if (factors.Contains("OrderBlock")) score += 1;
            if (factors.Contains("FVG")) score += 1;
            if (factors.Contains("LiquiditySweep")) score += 2;
            if (factors.Contains("PremiumDiscount")) score += 1;
            
            return score;
        }
        
        /// <summary>
        /// Convertit un score de confluence en force de signal
        /// </summary>
        public static SignalStrength ScoreToStrength(int score)
        {
            if (score >= 8) return SignalStrength.VeryStrong;
            if (score >= 6) return SignalStrength.Strong;
            if (score >= 4) return SignalStrength.Medium;
            if (score >= 2) return SignalStrength.Weak;
            return SignalStrength.VeryWeak;
        }
        
        #endregion
        
        #region Formatting
        
        /// <summary>
        /// Formate un prix selon l'instrument
        /// </summary>
        public static string FormatPrice(double price, int decimals = 2)
        {
            return price.ToString($"F{decimals}");
        }
        
        /// <summary>
        /// Formate une durée en texte lisible
        /// </summary>
        public static string FormatDuration(TimeSpan duration)
        {
            if (duration.TotalDays >= 1)
                return $"{duration.Days}d {duration.Hours}h";
            if (duration.TotalHours >= 1)
                return $"{duration.Hours}h {duration.Minutes}m";
            return $"{duration.Minutes}m {duration.Seconds}s";
        }
        
        /// <summary>
        /// Formate un P/L avec couleur
        /// </summary>
        public static string FormatPnL(double pnl)
        {
            string prefix = pnl >= 0 ? "+" : "";
            return $"{prefix}{pnl:F2}";
        }
        
        #endregion
    }

    /// <summary>
    /// Buffer circulaire thread-safe pour les données de marché
    /// </summary>
    public class CircularBuffer<T>
    {
        private readonly T[] _buffer;
        private int _head;
        private int _tail;
        private int _count;
        private readonly object _lock = new object();

        public CircularBuffer(int capacity)
        {
            _buffer = new T[capacity];
            _head = 0;
            _tail = 0;
            _count = 0;
        }

        public int Capacity => _buffer.Length;
        public int Count { get { lock (_lock) return _count; } }
        public bool IsFull => Count == Capacity;
        public bool IsEmpty => Count == 0;

        public void Add(T item)
        {
            lock (_lock)
            {
                _buffer[_head] = item;
                _head = (_head + 1) % Capacity;
                
                if (_count == Capacity)
                    _tail = (_tail + 1) % Capacity;
                else
                    _count++;
            }
        }

        public T[] ToArray()
        {
            lock (_lock)
            {
                T[] result = new T[_count];
                for (int i = 0; i < _count; i++)
                {
                    result[i] = _buffer[(_tail + i) % Capacity];
                }
                return result;
            }
        }

        public T this[int index]
        {
            get
            {
                lock (_lock)
                {
                    if (index < 0 || index >= _count)
                        throw new IndexOutOfRangeException();
                    return _buffer[(_tail + index) % Capacity];
                }
            }
        }

        public T Last()
        {
            lock (_lock)
            {
                if (_count == 0)
                    throw new InvalidOperationException("Buffer is empty");
                return _buffer[(_head - 1 + Capacity) % Capacity];
            }
        }

        public void Clear()
        {
            lock (_lock)
            {
                _head = 0;
                _tail = 0;
                _count = 0;
            }
        }
    }

    /// <summary>
    /// Cache thread-safe pour les calculs fréquents
    /// </summary>
    public class CalculationCache<TKey, TValue>
    {
        private readonly ConcurrentDictionary<TKey, CacheEntry> _cache;
        private readonly TimeSpan _expiration;

        private class CacheEntry
        {
            public TValue Value { get; set; }
            public DateTime ExpiresAt { get; set; }
        }

        public CalculationCache(TimeSpan expiration)
        {
            _cache = new ConcurrentDictionary<TKey, CacheEntry>();
            _expiration = expiration;
        }

        public bool TryGet(TKey key, out TValue value)
        {
            if (_cache.TryGetValue(key, out var entry) && entry.ExpiresAt > DateTime.Now)
            {
                value = entry.Value;
                return true;
            }
            value = default;
            return false;
        }

        public void Set(TKey key, TValue value)
        {
            _cache[key] = new CacheEntry
            {
                Value = value,
                ExpiresAt = DateTime.Now.Add(_expiration)
            };
        }

        public TValue GetOrCompute(TKey key, Func<TValue> compute)
        {
            if (TryGet(key, out var value))
                return value;
                
            value = compute();
            Set(key, value);
            return value;
        }

        public void Invalidate(TKey key)
        {
            _cache.TryRemove(key, out _);
        }

        public void Clear()
        {
            _cache.Clear();
        }

        public void CleanExpired()
        {
            var now = DateTime.Now;
            var expiredKeys = _cache.Where(kvp => kvp.Value.ExpiresAt <= now)
                                    .Select(kvp => kvp.Key)
                                    .ToList();
            foreach (var key in expiredKeys)
            {
                _cache.TryRemove(key, out _);
            }
        }
    }

    #region ═══════════════════════════════════════════════════════════════════
    //                          CONSTANTS
    // ═══════════════════════════════════════════════════════════════════════
    #endregion

    /// <summary>
    /// Constantes globales du système Sophon
    /// </summary>
    public static class SophonConstants
    {
        // Version
        public const string VERSION = "1.0.0";
        public const string BUILD_DATE = "2026-01-21";
        
        // Limites de zones
        public const int MAX_SR_ZONES = 6;
        public const int MAX_ORDER_BLOCKS = 10;
        public const int MAX_FVGS = 10;
        public const int MAX_LIQUIDITY_ZONES = 20;
        public const int MAX_PIVOTS = 50;
        public const int MAX_SIGNALS = 20;
        public const int MAX_OPEN_TRADES = 10;
        
        // Timeouts
        public const int SIGNAL_EXPIRY_MINUTES = 30;
        public const int ZONE_EXPIRY_BARS = 100;
        public const int FVG_EXPIRY_BARS = 50;
        public const int OB_EXPIRY_BARS = 100;
        
        // Fibonacci levels
        public const double FIB_236 = 0.236;
        public const double FIB_382 = 0.382;
        public const double FIB_500 = 0.500;
        public const double FIB_618 = 0.618;
        public const double FIB_786 = 0.786;
        
        // Premium/Discount
        public const double PREMIUM_LEVEL = 0.618;
        public const double DISCOUNT_LEVEL = 0.382;
        public const double EQUILIBRIUM_LOWER = 0.382;
        public const double EQUILIBRIUM_UPPER = 0.618;
        
        // Risk defaults
        public const double DEFAULT_RISK_PERCENT = 0.01;
        public const double DEFAULT_ATR_MULTIPLIER = 1.5;
        public const double DEFAULT_MIN_RR = 1.5;
        public const double DEFAULT_MAX_DAILY_LOSS = 0.03;
        public const double DEFAULT_MAX_DRAWDOWN = 0.10;
        public const double HIGH_CORRELATION_THRESHOLD = 0.70;
        
        // Session times (UTC)
        public const int ASIAN_START = 0;
        public const int ASIAN_END = 9;
        public const int LONDON_START = 8;
        public const int LONDON_END = 17;
        public const int NY_START = 13;
        public const int NY_END = 22;
        
        // Market-specific
        public static readonly string[] DEFAULT_FUTURES = { "MES", "MNQ", "MGC", "MCL", "M2K", "MYM" };
        public static readonly string[] DEFAULT_FOREX = { "EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD" };
    }
}
