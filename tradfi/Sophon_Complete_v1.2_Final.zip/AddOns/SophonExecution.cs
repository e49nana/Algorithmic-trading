#region Using declarations
using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
#endregion

//===============================================================================
// SOPHON EXECUTION MODULE v1.0
// Moteur d'Exécution Automatique des Ordres
// Copyright (c) 2026 Algosphere Quant - Emmanuel
//===============================================================================

namespace NinjaTrader.NinjaScript.AddOns.Sophon
{
    public class SophonExecution : ISophonModule, IOrderExecutor
    {
        #region Properties
        public string ModuleName => "SophonExecution";
        public bool IsInitialized { get; private set; }
        public bool IsEnabled { get; set; }
        public ExecutionSettings Settings { get; set; }
        
        private ConcurrentDictionary<string, TradeSetup> _activeTrades;
        private ConcurrentDictionary<string, PendingOrder> _pendingOrders;
        private ConcurrentQueue<ExecutionAction> _actionQueue;
        private List<ExecutionLog> _executionHistory;
        
        public Action<OrderRequest> OnOrderRequest { get; set; }
        public Action<ModifyRequest> OnModifyRequest { get; set; }
        public Action<CancelRequest> OnCancelRequest { get; set; }
        
        public event EventHandler<TradeSetup> OnTradeOpened;
        public event EventHandler<TradeSetup> OnTradeClosed;
        public event EventHandler<TradeSetup> OnTradeModified;
        public event EventHandler<TradeSetup> OnBreakEvenActivated;
        public event EventHandler<TradeSetup> OnTrailingActivated;
        public event EventHandler<TradeSetup> OnPyramidAdded;
        public event EventHandler<ExecutionError> OnExecutionError;
        
        private readonly object _tradeLock = new object();
        #endregion

        #region Initialization
        public SophonExecution()
        {
            Settings = new ExecutionSettings();
            _activeTrades = new ConcurrentDictionary<string, TradeSetup>();
            _pendingOrders = new ConcurrentDictionary<string, PendingOrder>();
            _actionQueue = new ConcurrentQueue<ExecutionAction>();
            _executionHistory = new List<ExecutionLog>();
            IsEnabled = true;
        }

        public void Initialize()
        {
            if (IsInitialized) return;
            _activeTrades.Clear();
            _pendingOrders.Clear();
            while (_actionQueue.TryDequeue(out _)) { }
            _executionHistory.Clear();
            IsInitialized = true;
        }

        public void Shutdown()
        {
            if (Settings.CloseAllOnShutdown) CloseAllPositions(null, ExitReason.SystemError);
            _activeTrades.Clear();
            _pendingOrders.Clear();
            IsInitialized = false;
        }

        public void Reset() { Shutdown(); Initialize(); }
        public void OnBarUpdate(int barsInProgress) { }
        #endregion

        #region Main Update Loop
        public void Update(double currentPrice, double currentATR, DateTime currentTime, int currentBar)
        {
            if (!IsEnabled || !IsInitialized) return;
            ProcessActionQueue();
            foreach (var kvp in _activeTrades)
            {
                var trade = kvp.Value;
                if (!trade.IsOpen) continue;
                UpdateTrade(trade, currentPrice, currentATR, currentTime, currentBar);
            }
            CleanupClosedTrades();
        }

        private void UpdateTrade(TradeSetup trade, double currentPrice, double currentATR, DateTime currentTime, int currentBar)
        {
            trade.UpdateMFE(currentPrice);
            trade.UpdateMAE(currentPrice);
            if (CheckTimeExit(trade, currentTime)) return;
            CheckBreakEven(trade, currentPrice, currentATR);
            CheckTrailingStop(trade, currentPrice, currentATR);
            CheckPartialTakeProfits(trade, currentPrice);
            if (Settings.EnablePyramiding) CheckPyramiding(trade, currentPrice, currentATR);
        }
        #endregion

        #region Order Execution
        public TradeSetup ExecuteTrade(TradeSetup setup)
        {
            if (!IsEnabled || !IsInitialized)
            {
                setup.State = TradeState.Error;
                setup.Log("Execution module not ready");
                return setup;
            }
            
            try
            {
                setup.State = TradeState.Submitted;
                setup.Log($"Submitting {setup.Signal.Direction} order @ {setup.Signal.EntryPrice:F2}");
                
                var entryOrder = new OrderRequest
                {
                    TradeId = setup.Id,
                    Instrument = setup.Signal.Instrument,
                    Direction = setup.Signal.Direction,
                    OrderType = Settings.DefaultEntryOrderType,
                    Price = setup.Signal.EntryPrice,
                    Quantity = setup.Risk.PositionSize,
                    StopLoss = setup.Risk.StopLossPrice,
                    TakeProfit = setup.Risk.TakeProfit1Price,
                    AccountId = setup.AccountId
                };
                
                OnOrderRequest?.Invoke(entryOrder);
                _activeTrades[setup.Id] = setup;
                
                LogExecution(new ExecutionLog
                {
                    TradeId = setup.Id,
                    Action = ExecutionActionType.EntryOrder,
                    Price = setup.Signal.EntryPrice,
                    Quantity = setup.Risk.PositionSize,
                    Timestamp = DateTime.Now,
                    Details = $"Entry {setup.Signal.Direction} @ {setup.Signal.EntryPrice:F2}"
                });
                
                return setup;
            }
            catch (Exception ex)
            {
                setup.State = TradeState.Error;
                setup.Log($"Execution error: {ex.Message}");
                OnExecutionError?.Invoke(this, new ExecutionError { TradeId = setup.Id, Message = ex.Message, Timestamp = DateTime.Now });
                return setup;
            }
        }

        public void ConfirmTradeOpened(string tradeId, double fillPrice, int fillQuantity, DateTime fillTime)
        {
            if (_activeTrades.TryGetValue(tradeId, out var trade))
            {
                trade.State = TradeState.Open;
                trade.ActualEntryPrice = fillPrice;
                trade.ActualPositionSize = fillQuantity;
                trade.ExecutedAt = fillTime;
                trade.Log($"Filled @ {fillPrice:F2} x {fillQuantity}");
                OnTradeOpened?.Invoke(this, trade);
            }
        }

        public bool ModifyStopLoss(TradeSetup trade, double newStopLoss)
        {
            if (!trade.IsOpen) return false;
            
            var modifyRequest = new ModifyRequest { TradeId = trade.Id, NewStopLoss = newStopLoss, Timestamp = DateTime.Now };
            OnModifyRequest?.Invoke(modifyRequest);
            
            trade.Risk = new RiskParameters
            {
                StopLossPrice = newStopLoss,
                StopLossDistance = Math.Abs(trade.ActualEntryPrice - newStopLoss),
                TakeProfit1Price = trade.Risk.TakeProfit1Price,
                TakeProfit2Price = trade.Risk.TakeProfit2Price,
                TakeProfit3Price = trade.Risk.TakeProfit3Price,
                PositionSize = trade.Risk.PositionSize,
                RiskPercent = trade.Risk.RiskPercent,
                RiskAmount = trade.Risk.RiskAmount
            };
            
            trade.Log($"SL modified to {newStopLoss:F2}");
            OnTradeModified?.Invoke(this, trade);
            LogExecution(new ExecutionLog { TradeId = trade.Id, Action = ExecutionActionType.ModifyStopLoss, Price = newStopLoss, Timestamp = DateTime.Now, Details = $"SL moved to {newStopLoss:F2}" });
            return true;
        }

        public bool ModifyTakeProfit(TradeSetup trade, double newTakeProfit)
        {
            if (!trade.IsOpen) return false;
            OnModifyRequest?.Invoke(new ModifyRequest { TradeId = trade.Id, NewTakeProfit = newTakeProfit, Timestamp = DateTime.Now });
            trade.Risk = new RiskParameters
            {
                StopLossPrice = trade.Risk.StopLossPrice,
                StopLossDistance = trade.Risk.StopLossDistance,
                TakeProfit1Price = newTakeProfit,
                TakeProfit2Price = trade.Risk.TakeProfit2Price,
                TakeProfit3Price = trade.Risk.TakeProfit3Price,
                PositionSize = trade.Risk.PositionSize,
                RiskPercent = trade.Risk.RiskPercent,
                RiskAmount = trade.Risk.RiskAmount
            };
            trade.Log($"TP modified to {newTakeProfit:F2}");
            OnTradeModified?.Invoke(this, trade);
            return true;
        }

        public bool ClosePosition(TradeSetup trade, ExitReason reason)
        {
            if (!trade.IsOpen) return false;
            trade.Log($"Closing position: {reason}");
            OnCancelRequest?.Invoke(new CancelRequest { TradeId = trade.Id, Reason = reason, Timestamp = DateTime.Now });
            trade.State = TradeState.Closed;
            trade.ClosedAt = DateTime.Now;
            trade.ExitReason = reason;
            OnTradeClosed?.Invoke(this, trade);
            LogExecution(new ExecutionLog { TradeId = trade.Id, Action = ExecutionActionType.ClosePosition, Timestamp = DateTime.Now, Details = $"Closed: {reason}" });
            return true;
        }

        public bool CloseAllPositions(string accountId, ExitReason reason)
        {
            var tradesToClose = accountId == null 
                ? _activeTrades.Values.Where(t => t.IsOpen).ToList()
                : _activeTrades.Values.Where(t => t.IsOpen && t.AccountId == accountId).ToList();
            foreach (var trade in tradesToClose) ClosePosition(trade, reason);
            return true;
        }

        public List<TradeSetup> GetOpenTrades(string accountId = null)
        {
            return accountId == null 
                ? _activeTrades.Values.Where(t => t.IsOpen).ToList()
                : _activeTrades.Values.Where(t => t.IsOpen && t.AccountId == accountId).ToList();
        }
        #endregion

        #region Break-Even
        private void CheckBreakEven(TradeSetup trade, double currentPrice, double currentATR)
        {
            if (!Settings.EnableBreakEven) return;
            if (trade.State == TradeState.BreakEven || trade.State == TradeState.Trailing) return;
            
            bool isLong = trade.Signal.IsLong;
            double entryPrice = trade.ActualEntryPrice;
            double riskDistance = trade.Risk.StopLossDistance;
            double beThreshold = riskDistance * Settings.BreakEvenTriggerRR;
            double unrealizedProfit = isLong ? currentPrice - entryPrice : entryPrice - currentPrice;
            
            if (unrealizedProfit >= beThreshold)
            {
                double beOffset = Settings.BreakEvenOffset * currentATR;
                double newStopLoss = isLong ? entryPrice + beOffset : entryPrice - beOffset;
                double currentSL = trade.Risk.StopLossPrice;
                bool isBetter = isLong ? newStopLoss > currentSL : newStopLoss < currentSL;
                
                if (isBetter)
                {
                    ModifyStopLoss(trade, newStopLoss);
                    trade.State = TradeState.BreakEven;
                    trade.Log($"Break-even activated @ {newStopLoss:F2}");
                    OnBreakEvenActivated?.Invoke(this, trade);
                }
            }
        }
        #endregion

        #region Trailing Stop
        private void CheckTrailingStop(TradeSetup trade, double currentPrice, double currentATR)
        {
            if (!Settings.EnableTrailingStop) return;
            if (trade.State != TradeState.BreakEven && trade.State != TradeState.Trailing) return;
            
            bool isLong = trade.Signal.IsLong;
            double entryPrice = trade.ActualEntryPrice;
            double currentSL = trade.Risk.StopLossPrice;
            double trailTrigger = trade.Risk.StopLossDistance * Settings.TrailingTriggerRR;
            double unrealizedProfit = isLong ? currentPrice - entryPrice : entryPrice - currentPrice;
            
            if (unrealizedProfit < trailTrigger) return;
            
            double trailDistance = currentATR * Settings.TrailingATRMultiplier;
            double newStopLoss = isLong ? currentPrice - trailDistance : currentPrice + trailDistance;
            bool isBetter = isLong ? newStopLoss > currentSL : newStopLoss < currentSL;
            
            if (isBetter)
            {
                ModifyStopLoss(trade, newStopLoss);
                if (trade.State != TradeState.Trailing)
                {
                    trade.State = TradeState.Trailing;
                    trade.Log($"Trailing stop activated @ {newStopLoss:F2}");
                    OnTrailingActivated?.Invoke(this, trade);
                }
            }
        }
        #endregion

        #region Partial Take-Profits
        private void CheckPartialTakeProfits(TradeSetup trade, double currentPrice)
        {
            if (!Settings.EnablePartialTakeProfits) return;
            bool isLong = trade.Signal.IsLong;
            
            if (trade.Risk.TakeProfit1Price > 0 && trade.State != TradeState.PartialExit)
            {
                bool tp1Hit = isLong ? currentPrice >= trade.Risk.TakeProfit1Price : currentPrice <= trade.Risk.TakeProfit1Price;
                if (tp1Hit) ExecutePartialExit(trade, Settings.TP1ExitPercent, trade.Risk.TakeProfit1Price, "TP1");
            }
            
            if (trade.Risk.TakeProfit2Price > 0 && trade.ActualPositionSize > 1)
            {
                bool tp2Hit = isLong ? currentPrice >= trade.Risk.TakeProfit2Price : currentPrice <= trade.Risk.TakeProfit2Price;
                if (tp2Hit) ExecutePartialExit(trade, Settings.TP2ExitPercent, trade.Risk.TakeProfit2Price, "TP2");
            }
        }

        private void ExecutePartialExit(TradeSetup trade, double exitPercent, double exitPrice, string label)
        {
            int exitQuantity = (int)Math.Floor(trade.ActualPositionSize * exitPercent);
            if (exitQuantity <= 0) return;
            
            trade.State = TradeState.PartialExit;
            trade.Log($"{label} hit @ {exitPrice:F2}, closing {exitQuantity} units ({exitPercent:P0})");
            
            OnOrderRequest?.Invoke(new OrderRequest
            {
                TradeId = trade.Id,
                Instrument = trade.Signal.Instrument,
                Direction = trade.Signal.IsLong ? TradeDirection.Short : TradeDirection.Long,
                OrderType = OrderType.Market,
                Quantity = exitQuantity,
                AccountId = trade.AccountId
            });
            
            trade.ActualPositionSize -= exitQuantity;
            LogExecution(new ExecutionLog { TradeId = trade.Id, Action = ExecutionActionType.PartialExit, Price = exitPrice, Quantity = exitQuantity, Timestamp = DateTime.Now, Details = $"{label}: {exitQuantity} units @ {exitPrice:F2}" });
        }
        #endregion

        #region Time-Based Exit
        private bool CheckTimeExit(TradeSetup trade, DateTime currentTime)
        {
            if (!Settings.EnableTimeExit) return false;
            
            if (Settings.MaxTradeDurationMinutes > 0)
            {
                TimeSpan duration = currentTime - (trade.ExecutedAt ?? trade.CreatedAt);
                if (duration.TotalMinutes >= Settings.MaxTradeDurationMinutes)
                {
                    ClosePosition(trade, ExitReason.TimeExit);
                    return true;
                }
            }
            
            if (Settings.ExitAtFixedTime && Settings.FixedExitTime.HasValue)
            {
                TimeSpan exitTime = Settings.FixedExitTime.Value;
                if (currentTime.TimeOfDay >= exitTime && trade.ExecutedAt?.TimeOfDay < exitTime)
                {
                    ClosePosition(trade, ExitReason.SessionEnd);
                    return true;
                }
            }
            
            if (Settings.ExitAtSessionEnd)
            {
                TradingSession currentSession = SophonHelpers.GetCurrentSession(currentTime);
                if (currentSession == TradingSession.Closed)
                {
                    ClosePosition(trade, ExitReason.SessionEnd);
                    return true;
                }
            }
            
            return false;
        }
        #endregion

        #region Pyramiding
        private void CheckPyramiding(TradeSetup trade, double currentPrice, double currentATR)
        {
            if (trade.PyramidLevel >= Settings.MaxPyramidLevels) return;
            
            bool isLong = trade.Signal.IsLong;
            double pyramidThreshold = trade.Risk.StopLossDistance * Settings.PyramidTriggerRR;
            double unrealizedProfit = isLong ? currentPrice - trade.ActualEntryPrice : trade.ActualEntryPrice - currentPrice;
            
            if (unrealizedProfit < pyramidThreshold) return;
            
            double sizeMultiplier = Math.Pow(Settings.PyramidSizeReduction, trade.PyramidLevel);
            int addSize = (int)Math.Floor(trade.Risk.PositionSize * sizeMultiplier);
            if (addSize <= 0) return;
            
            var pyramidSetup = new TradeSetup
            {
                Signal = trade.Signal,
                AccountId = trade.AccountId,
                Risk = new RiskParameters { PositionSize = addSize, StopLossPrice = trade.Risk.StopLossPrice, TakeProfit1Price = trade.Risk.TakeProfit1Price },
                PyramidLevel = trade.PyramidLevel + 1
            };
            
            trade.PyramidTrades.Add(pyramidSetup);
            trade.PyramidLevel++;
            trade.Log($"Pyramid level {trade.PyramidLevel}: adding {addSize} units @ {currentPrice:F2}");
            OnPyramidAdded?.Invoke(this, trade);
            LogExecution(new ExecutionLog { TradeId = trade.Id, Action = ExecutionActionType.PyramidAdd, Price = currentPrice, Quantity = addSize, Timestamp = DateTime.Now, Details = $"Pyramid level {trade.PyramidLevel}: +{addSize} units" });
        }
        #endregion

        #region Action Queue & Cleanup
        public void QueueAction(ExecutionAction action) => _actionQueue.Enqueue(action);

        private void ProcessActionQueue()
        {
            while (_actionQueue.TryDequeue(out var action))
            {
                try { ExecuteAction(action); }
                catch (Exception ex) { OnExecutionError?.Invoke(this, new ExecutionError { TradeId = action.TradeId, Message = $"Action queue error: {ex.Message}", Timestamp = DateTime.Now }); }
            }
        }

        private void ExecuteAction(ExecutionAction action)
        {
            switch (action.Type)
            {
                case ExecutionActionType.ClosePosition:
                    if (_activeTrades.TryGetValue(action.TradeId, out var trade)) ClosePosition(trade, action.ExitReason ?? ExitReason.ManualClose);
                    break;
                case ExecutionActionType.ModifyStopLoss:
                    if (_activeTrades.TryGetValue(action.TradeId, out var tradeSL) && action.NewPrice.HasValue) ModifyStopLoss(tradeSL, action.NewPrice.Value);
                    break;
                case ExecutionActionType.ModifyTakeProfit:
                    if (_activeTrades.TryGetValue(action.TradeId, out var tradeTP) && action.NewPrice.HasValue) ModifyTakeProfit(tradeTP, action.NewPrice.Value);
                    break;
            }
        }

        private void CleanupClosedTrades()
        {
            var closedIds = _activeTrades.Where(kvp => kvp.Value.IsClosed).Select(kvp => kvp.Key).ToList();
            foreach (var id in closedIds) _activeTrades.TryRemove(id, out _);
        }

        private void LogExecution(ExecutionLog log)
        {
            _executionHistory.Add(log);
            while (_executionHistory.Count > Settings.MaxExecutionHistorySize) _executionHistory.RemoveAt(0);
        }

        public List<ExecutionLog> GetExecutionHistory(string tradeId = null) =>
            tradeId == null ? _executionHistory.ToList() : _executionHistory.Where(l => l.TradeId == tradeId).ToList();

        public ExecutionStatistics GetStatistics() => new ExecutionStatistics
        {
            TotalTradesExecuted = _executionHistory.Count(l => l.Action == ExecutionActionType.EntryOrder),
            TotalTradesClosed = _executionHistory.Count(l => l.Action == ExecutionActionType.ClosePosition),
            BreakEvensActivated = _executionHistory.Count(l => l.Details?.Contains("Break-even") == true),
            TrailingsActivated = _executionHistory.Count(l => l.Details?.Contains("Trailing") == true),
            PartialExits = _executionHistory.Count(l => l.Action == ExecutionActionType.PartialExit),
            PyramidsAdded = _executionHistory.Count(l => l.Action == ExecutionActionType.PyramidAdd),
            CurrentOpenTrades = _activeTrades.Count(kvp => kvp.Value.IsOpen)
        };
        #endregion
    }

    #region Supporting Classes
    public class ExecutionSettings
    {
        public OrderType DefaultEntryOrderType { get; set; } = OrderType.Market;
        public bool CloseAllOnShutdown { get; set; } = true;
        public int MaxExecutionHistorySize { get; set; } = 1000;
        public bool EnableBreakEven { get; set; } = true;
        public double BreakEvenTriggerRR { get; set; } = 1.0;
        public double BreakEvenOffset { get; set; } = 0.1;
        public bool EnableTrailingStop { get; set; } = true;
        public double TrailingTriggerRR { get; set; } = 1.5;
        public double TrailingATRMultiplier { get; set; } = 1.5;
        public bool EnablePartialTakeProfits { get; set; } = true;
        public double TP1ExitPercent { get; set; } = 0.5;
        public double TP2ExitPercent { get; set; } = 0.3;
        public bool EnableTimeExit { get; set; } = true;
        public int MaxTradeDurationMinutes { get; set; } = 240;
        public bool ExitAtFixedTime { get; set; } = false;
        public TimeSpan? FixedExitTime { get; set; } = null;
        public bool ExitAtSessionEnd { get; set; } = true;
        public bool EnablePyramiding { get; set; } = false;
        public int MaxPyramidLevels { get; set; } = 3;
        public double PyramidTriggerRR { get; set; } = 1.0;
        public double PyramidSizeReduction { get; set; } = 0.5;
    }

    public enum OrderType { Market, Limit, Stop, StopLimit }

    public class OrderRequest
    {
        public string TradeId { get; set; }
        public string Instrument { get; set; }
        public TradeDirection Direction { get; set; }
        public OrderType OrderType { get; set; }
        public double Price { get; set; }
        public int Quantity { get; set; }
        public double StopLoss { get; set; }
        public double TakeProfit { get; set; }
        public string AccountId { get; set; }
        public DateTime Timestamp { get; set; } = DateTime.Now;
    }

    public class ModifyRequest
    {
        public string TradeId { get; set; }
        public double? NewStopLoss { get; set; }
        public double? NewTakeProfit { get; set; }
        public DateTime Timestamp { get; set; }
    }

    public class CancelRequest
    {
        public string TradeId { get; set; }
        public ExitReason Reason { get; set; }
        public DateTime Timestamp { get; set; }
    }

    public class PendingOrder
    {
        public string OrderId { get; set; }
        public string TradeId { get; set; }
        public OrderRequest Request { get; set; }
        public DateTime SubmittedAt { get; set; }
        public string Status { get; set; }
    }

    public class ExecutionAction
    {
        public string TradeId { get; set; }
        public ExecutionActionType Type { get; set; }
        public double? NewPrice { get; set; }
        public int? NewQuantity { get; set; }
        public ExitReason? ExitReason { get; set; }
        public DateTime QueuedAt { get; set; } = DateTime.Now;
    }

    public enum ExecutionActionType { EntryOrder, ModifyStopLoss, ModifyTakeProfit, PartialExit, ClosePosition, PyramidAdd, CancelOrder }

    public class ExecutionLog
    {
        public string TradeId { get; set; }
        public ExecutionActionType Action { get; set; }
        public double Price { get; set; }
        public int Quantity { get; set; }
        public DateTime Timestamp { get; set; }
        public string Details { get; set; }
        public override string ToString() => $"[{Timestamp:HH:mm:ss}] {TradeId}: {Action} @ {Price:F2} x{Quantity} - {Details}";
    }

    public class ExecutionError
    {
        public string TradeId { get; set; }
        public string Message { get; set; }
        public DateTime Timestamp { get; set; }
        public Exception Exception { get; set; }
        public override string ToString() => $"[{Timestamp:HH:mm:ss}] ERROR {TradeId}: {Message}";
    }

    public class ExecutionStatistics
    {
        public int TotalTradesExecuted { get; set; }
        public int TotalTradesClosed { get; set; }
        public int BreakEvensActivated { get; set; }
        public int TrailingsActivated { get; set; }
        public int PartialExits { get; set; }
        public int PyramidsAdded { get; set; }
        public int CurrentOpenTrades { get; set; }
        public override string ToString() => $"Executed: {TotalTradesExecuted} | Closed: {TotalTradesClosed} | BE: {BreakEvensActivated} | Trail: {TrailingsActivated} | Partial: {PartialExits} | Pyramid: {PyramidsAdded} | Open: {CurrentOpenTrades}";
    }
    #endregion
}
