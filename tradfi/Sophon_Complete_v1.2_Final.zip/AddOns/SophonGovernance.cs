#region Using declarations
using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using System.Threading;
using NinjaTrader.NinjaScript;
#endregion

//===============================================================================
// SOPHON GOVERNANCE MODULE v2.0
// Module Central Non Contournable - Point de Passage Obligatoire
//
// PRINCIPE: Aucun module ne peut trader sans autorisation formelle (TradeAuthorization)
//
// Hiérarchie d'évaluation:
//   0. Kill Switch (absolu)
//   1. Règles Prop Firm (daily/max/trailing DD, position size, temps)
//   2. Cooldown (après pertes, séries)
//   3. Session/Temps (fenêtres autorisées, news)
//   4. Environnement (chop, follow-through, volatilité)
//   5. Limites intraday (trades, drawdown restant)
//   6. Qualité setup (selon agressivité)
//
// Copyright (c) 2026 Algosphere Quant - Emmanuel
//===============================================================================

namespace NinjaTrader.NinjaScript.AddOns.Sophon
{
    public sealed class SophonGovernance : ISophonModule
    {
        #region Singleton & Properties
        private static readonly Lazy<SophonGovernance> _instance = new Lazy<SophonGovernance>(() => new SophonGovernance());
        public static SophonGovernance Instance => _instance.Value;
        
        public string ModuleName => "SophonGovernance";
        public bool IsInitialized { get; private set; }
        public bool IsEnabled { get; set; } = true;
        
        private PropFirmRules _propFirmRules;
        private GovernanceSettings _settings;
        private AccountState _accountState;
        private DailyState _dailyState;
        private CooldownState _cooldownState;
        private EnvironmentState _environmentState;
        
        private ConcurrentDictionary<string, TradeAuthorization> _activeAuthorizations;
        private List<BlockedRequest> _blockedRequests;
        
        private volatile bool _globalKillSwitch;
        private string _killSwitchReason;
        private volatile TradingState _currentState;
        
        private readonly ReaderWriterLockSlim _lock = new ReaderWriterLockSlim();
        
        public event EventHandler<TradingStateChangedEvent> OnStateChanged;
        public event EventHandler<AuthorizationEvent> OnAuthorizationIssued;
        public event EventHandler<KillSwitchEvent> OnKillSwitchActivated;
        public event EventHandler<CooldownEvent> OnCooldownStarted;
        
        private SophonGovernance()
        {
            _propFirmRules = new PropFirmRules();
            _settings = new GovernanceSettings();
            _accountState = new AccountState();
            _dailyState = new DailyState();
            _cooldownState = new CooldownState();
            _environmentState = new EnvironmentState();
            _activeAuthorizations = new ConcurrentDictionary<string, TradeAuthorization>();
            _blockedRequests = new List<BlockedRequest>();
        }
        #endregion

        #region Initialization
        public void Initialize()
        {
            if (IsInitialized) return;
            ResetDailyState();
            _globalKillSwitch = false;
            _currentState = TradingState.Evaluating;
            _activeAuthorizations.Clear();
            IsInitialized = true;
        }

        public void Shutdown() { RevokeAllAuthorizations("Shutdown"); IsInitialized = false; }
        public void Reset() { Shutdown(); Initialize(); }
        public void OnBarUpdate(int bip) { EvaluateTradingState(); }

        public void ConfigurePropFirm(PropFirmRules rules) => _propFirmRules = rules ?? new PropFirmRules();
        public void ConfigureSettings(GovernanceSettings settings) => _settings = settings ?? new GovernanceSettings();
        
        public void InitializeAccount(double startingBalance, double currentBalance)
        {
            _lock.EnterWriteLock();
            try {
                _accountState.StartingBalance = startingBalance;
                _accountState.CurrentBalance = currentBalance;
                _accountState.PeakBalance = Math.Max(startingBalance, currentBalance);
                _accountState.DayStartBalance = currentBalance;
            } finally { _lock.ExitWriteLock(); }
        }
        #endregion

        #region Trading State Evaluation
        public TradingStateResult EvaluateTradingState()
        {
            _lock.EnterUpgradeableReadLock();
            try
            {
                var result = new TradingStateResult { Timestamp = DateTime.Now };
                var previous = _currentState;

                // NIVEAU 0: KILL SWITCH
                if (_globalKillSwitch)
                    return BlockResult(result, TradingState.KillSwitchActive, BlockLevel.KillSwitch, $"Kill switch: {_killSwitchReason}", previous);

                // NIVEAU 1: PROP FIRM
                var pf = EvaluatePropFirmRules();
                if (!pf.IsCompliant)
                {
                    if (pf.IsCritical) ActivateKillSwitch(pf.Message, KillSwitchType.PropFirmBreach);
                    return BlockResult(result, TradingState.PropFirmBlocked, BlockLevel.PropFirmRule, pf.Message, previous);
                }

                // NIVEAU 2: COOLDOWN
                if (_cooldownState.IsActive && DateTime.Now < _cooldownState.EndsAt)
                    return BlockResult(result, TradingState.Cooldown, BlockLevel.Cooldown, $"Cooldown: {_cooldownState.Reason}", previous);
                if (_cooldownState.IsActive) _cooldownState.IsActive = false;

                // NIVEAU 3: SESSION
                var sess = EvaluateSession();
                if (!sess.IsValid)
                    return BlockResult(result, TradingState.OutsideSession, BlockLevel.SessionTime, sess.Reason, previous);

                // NIVEAU 4: NEWS
                if (_environmentState.HighImpactNewsActive)
                    return BlockResult(result, TradingState.NewsBlocked, BlockLevel.News, $"News: {_environmentState.NextNewsEvent}", previous);

                // NIVEAU 5: ENVIRONMENT
                var env = EvaluateEnvironment();
                if (!env.IsFavorable)
                    return BlockResult(result, TradingState.UnfavorableEnvironment, BlockLevel.Environment, env.Reason, previous);

                // NIVEAU 6: DAILY LIMITS
                if (_dailyState.TradeCount >= _dailyState.MaxTradesAllowed)
                    return BlockResult(result, TradingState.DailyLimitReached, BlockLevel.DailyLimit, 
                                       $"Daily limit: {_dailyState.TradeCount}/{_dailyState.MaxTradesAllowed}", previous);

                // AUTORISÉ
                result.State = TradingState.Active;
                result.CanTrade = true;
                result.AggressivenessLevel = CalculateAggressiveness();
                result.MaxRiskMultiplier = GetRiskMultiplier(result.AggressivenessLevel);
                result.MaxTradesRemaining = _dailyState.MaxTradesAllowed - _dailyState.TradeCount;
                result.DrawdownRemaining = GetRemainingDrawdown();
                result.EnvironmentScore = env.Score;
                UpdateState(result.State, previous);
                return result;
            }
            finally { _lock.ExitUpgradeableReadLock(); }
        }

        private TradingStateResult BlockResult(TradingStateResult r, TradingState state, BlockLevel level, string reason, TradingState prev)
        {
            r.State = state; r.CanTrade = false; r.Reason = reason; r.BlockLevel = level;
            UpdateState(state, prev);
            return r;
        }

        private void UpdateState(TradingState newState, TradingState prev)
        {
            if (newState != prev)
            {
                _lock.EnterWriteLock();
                try { _currentState = newState; }
                finally { _lock.ExitWriteLock(); }
                OnStateChanged?.Invoke(this, new TradingStateChangedEvent { PreviousState = prev, NewState = newState });
            }
        }
        #endregion

        #region Rule Evaluations
        private PropFirmEvaluation EvaluatePropFirmRules()
        {
            var r = new PropFirmEvaluation { IsCompliant = true };
            
            double dailyPnL = _accountState.CurrentBalance - _accountState.DayStartBalance;
            double dailyDD = dailyPnL < 0 ? Math.Abs(dailyPnL) / _accountState.DayStartBalance * 100 : 0;
            
            if (dailyDD >= _propFirmRules.DailyDrawdownLimit)
                return new PropFirmEvaluation { IsCompliant = false, IsCritical = true, 
                    ViolationType = PropFirmViolation.DailyDrawdown, 
                    Message = $"DAILY DD: {dailyDD:F2}% >= {_propFirmRules.DailyDrawdownLimit}%" };

            double refBal = _propFirmRules.TrailingDrawdownEnabled ? _accountState.PeakBalance : _accountState.StartingBalance;
            double maxDD = (refBal - _accountState.CurrentBalance) / refBal * 100;
            
            if (maxDD >= _propFirmRules.MaxDrawdownLimit)
                return new PropFirmEvaluation { IsCompliant = false, IsCritical = true,
                    ViolationType = _propFirmRules.TrailingDrawdownEnabled ? PropFirmViolation.TrailingDrawdown : PropFirmViolation.MaxDrawdown,
                    Message = $"MAX DD: {maxDD:F2}% >= {_propFirmRules.MaxDrawdownLimit}%" };

            if (_propFirmRules.MaxPositionSize > 0 && _accountState.CurrentPositionSize > _propFirmRules.MaxPositionSize)
                return new PropFirmEvaluation { IsCompliant = false, ViolationType = PropFirmViolation.PositionSize,
                    Message = $"Position {_accountState.CurrentPositionSize} > {_propFirmRules.MaxPositionSize}" };
            
            return r;
        }

        private SessionEvaluation EvaluateSession()
        {
            var now = DateTime.Now;
            var time = now.TimeOfDay;

            foreach (var p in _propFirmRules.RestrictedPeriods)
                if (time >= p.Start && time <= p.End)
                    return new SessionEvaluation { IsValid = false, Reason = $"Restricted: {p.Reason}" };

            if (_propFirmRules.NoTradingDays.Contains(now.DayOfWeek))
                return new SessionEvaluation { IsValid = false, Reason = $"{now.DayOfWeek} blocked" };

            if (_settings.ForceSessionEnd && time >= _settings.SessionEndTime)
                return new SessionEvaluation { IsValid = false, Reason = "Session ended" };

            if (!_propFirmRules.AllowWeekendHolding && now.DayOfWeek == DayOfWeek.Friday && time >= _settings.FridayCloseTime)
                return new SessionEvaluation { IsValid = false, Reason = "Friday close" };

            return new SessionEvaluation { IsValid = true };
        }

        private EnvironmentEvaluation EvaluateEnvironment()
        {
            var r = new EnvironmentEvaluation { IsFavorable = true, Score = 100 };
            var reasons = new List<string>();

            if (_environmentState.IsChoppy) { r.Score -= 40; reasons.Add("Choppy"); }
            if (_environmentState.NoFollowThrough) { r.Score -= 30; reasons.Add("No follow-through"); }
            if (_environmentState.ATRRatio < _settings.MinATRRatio || _environmentState.ATRRatio > _settings.MaxATRRatio) 
                { r.Score -= 20; reasons.Add($"ATR: {_environmentState.ATRRatio:F2}"); }
            if (_environmentState.CurrentSpread > _settings.MaxSpreadTicks) { r.Score -= 15; reasons.Add("Wide spread"); }
            if (_environmentState.VolumeRatio < _settings.MinVolumeRatio) { r.Score -= 15; reasons.Add("Low volume"); }

            if (r.Score < _settings.MinEnvironmentScore)
            {
                r.IsFavorable = false;
                r.Reason = string.Join("; ", reasons);
            }
            return r;
        }
        #endregion

        #region Trade Authorization (Point de Passage Obligatoire)
        public TradeAuthorization RequestAuthorization(TradeAuthorizationRequest req)
        {
            if (req == null) throw new ArgumentNullException(nameof(req));

            var auth = new TradeAuthorization
            {
                AuthorizationId = $"AUTH_{DateTime.Now:yyyyMMddHHmmss}_{Guid.NewGuid().ToString("N").Substring(0,6)}",
                RequestId = req.RequestId, RequestTime = DateTime.Now,
                Instrument = req.Instrument, Direction = req.Direction, RequestedSetup = req.SetupType
            };

            var state = EvaluateTradingState();
            if (!state.CanTrade)
            {
                auth.IsGranted = false; auth.DenialReason = state.Reason; auth.DenialLevel = state.BlockLevel;
                _blockedRequests.Add(new BlockedRequest { RequestId = req.RequestId, Reason = state.Reason, Level = state.BlockLevel });
                return auth;
            }

            double minQuality = GetMinSetupQuality(state.AggressivenessLevel);
            if (req.SetupQuality < minQuality)
            {
                auth.IsGranted = false; auth.DenialReason = $"Quality {req.SetupQuality:F0} < {minQuality:F0}"; 
                auth.DenialLevel = BlockLevel.SetupQuality;
                return auth;
            }

            var constraints = CalculateConstraints(state);
            
            auth.IsGranted = true;
            auth.GrantedTime = DateTime.Now;
            auth.ExpiresAt = DateTime.Now.AddSeconds(_settings.AuthorizationValiditySeconds);
            auth.AggressivenessLevel = state.AggressivenessLevel;
            auth.RiskMultiplier = state.MaxRiskMultiplier;
            auth.GrantedRiskAmount = Math.Min(req.RequestedRiskAmount, constraints.MaxRisk);
            auth.MaxPositionSize = constraints.MaxSize;
            auth.MaxHoldingMinutes = constraints.MaxHoldingMinutes;
            auth.MustCloseBy = CalculateMustCloseBy();

            _activeAuthorizations[auth.AuthorizationId] = auth;
            _dailyState.AuthorizationsGranted++;
            OnAuthorizationIssued?.Invoke(this, new AuthorizationEvent { Authorization = auth });
            return auth;
        }

        public AuthorizationValidation ValidateAuthorization(string authId)
        {
            if (!_activeAuthorizations.TryGetValue(authId, out var auth))
                return new AuthorizationValidation { IsValid = false, Reason = "Not found" };
            if (DateTime.Now > auth.ExpiresAt) { RevokeAuthorization(authId, "Expired"); return new AuthorizationValidation { IsValid = false, Reason = "Expired" }; }
            var state = EvaluateTradingState();
            if (!state.CanTrade) { RevokeAuthorization(authId, "State changed"); return new AuthorizationValidation { IsValid = false, Reason = state.Reason }; }
            return new AuthorizationValidation { IsValid = true, Authorization = auth };
        }

        public void ConfirmExecution(string authId, ExecutionConfirmation conf)
        {
            if (_activeAuthorizations.TryGetValue(authId, out var auth))
            {
                auth.WasExecuted = true; auth.ExecutionTime = conf.ExecutionTime;
                auth.ActualEntryPrice = conf.EntryPrice; auth.ActualPositionSize = conf.PositionSize;
                _lock.EnterWriteLock();
                try { _accountState.CurrentPositionSize += conf.PositionSize; _dailyState.TradeCount++; }
                finally { _lock.ExitWriteLock(); }
            }
        }

        public void RevokeAuthorization(string authId, string reason)
        {
            if (_activeAuthorizations.TryRemove(authId, out var auth))
            { auth.WasRevoked = true; auth.RevocationReason = reason; }
        }

        public void RevokeAllAuthorizations(string reason)
        { foreach (var id in _activeAuthorizations.Keys.ToList()) RevokeAuthorization(id, reason); }
        #endregion

        #region Kill Switch & Cooldown
        public void ActivateKillSwitch(string reason, KillSwitchType type)
        {
            _lock.EnterWriteLock();
            try { _globalKillSwitch = true; _killSwitchReason = reason; _currentState = TradingState.KillSwitchActive; }
            finally { _lock.ExitWriteLock(); }
            RevokeAllAuthorizations("Kill switch");
            OnKillSwitchActivated?.Invoke(this, new KillSwitchEvent { Type = type, Reason = reason });
        }

        public bool DeactivateKillSwitch(string code)
        {
            if (code != _settings.KillSwitchDeactivationCode) return false;
            _lock.EnterWriteLock();
            try { _globalKillSwitch = false; _killSwitchReason = null; }
            finally { _lock.ExitWriteLock(); }
            return true;
        }

        public void StartCooldown(CooldownType type, string reason, TimeSpan duration)
        {
            _lock.EnterWriteLock();
            try { _cooldownState = new CooldownState { IsActive = true, Type = type, Reason = reason, StartedAt = DateTime.Now, EndsAt = DateTime.Now.Add(duration) }; }
            finally { _lock.ExitWriteLock(); }
            OnCooldownStarted?.Invoke(this, new CooldownEvent { Type = type, Reason = reason, Duration = duration });
        }
        #endregion

        #region Open Trade Management
        public OpenTradeDirective EvaluateOpenTrade(OpenTradeStatus trade, string authId)
        {
            var d = new OpenTradeDirective { TradeId = trade.TradeId, Timestamp = DateTime.Now };
            if (!_activeAuthorizations.TryGetValue(authId, out var auth)) { d.Action = TradeDirectiveAction.CloseImmediately; d.Reason = "Auth not found"; return d; }
            
            double mins = (DateTime.Now - trade.EntryTime).TotalMinutes;
            if (mins >= auth.MaxHoldingMinutes) { d.Action = TradeDirectiveAction.CloseImmediately; d.Reason = "Max time"; return d; }
            if (auth.MustCloseBy.HasValue && DateTime.Now >= auth.MustCloseBy) { d.Action = TradeDirectiveAction.CloseImmediately; d.Reason = "Must close by"; return d; }
            if (_globalKillSwitch) { d.Action = TradeDirectiveAction.CloseImmediately; d.Reason = "Kill switch"; return d; }
            
            var pf = EvaluatePropFirmRules();
            if (!pf.IsCompliant) { d.Action = TradeDirectiveAction.CloseImmediately; d.Reason = pf.Message; return d; }
            
            if (mins >= _settings.ProgressCheckInterval)
            {
                double progress = trade.UnrealizedPnL / trade.InitialRisk;
                if (progress < _settings.MinProgressRatio)
                {
                    if (progress < 0) { d.Action = TradeDirectiveAction.CloseImmediately; d.Reason = $"No progress: {progress:F2}R"; }
                    else { d.Action = TradeDirectiveAction.ReducePosition; d.ReducePercent = 50; d.Reason = "Reduce stagnant"; }
                    return d;
                }
            }
            
            d.Action = TradeDirectiveAction.None;
            return d;
        }
        #endregion

        #region State Updates
        public void RecordTradeResult(TradeResultUpdate result)
        {
            _lock.EnterWriteLock();
            try
            {
                _accountState.CurrentBalance += result.NetPnL;
                if (_accountState.CurrentBalance > _accountState.PeakBalance) _accountState.PeakBalance = _accountState.CurrentBalance;
                _dailyState.DailyPnL += result.NetPnL;
                if (result.IsWinner) { _dailyState.WinCount++; _dailyState.ConsecutiveWins++; _dailyState.ConsecutiveLosses = 0; }
                else { _dailyState.LossCount++; _dailyState.ConsecutiveLosses++; _dailyState.ConsecutiveWins = 0; }
                _accountState.CurrentPositionSize -= result.PositionSize;
                if (!string.IsNullOrEmpty(result.AuthorizationId)) _activeAuthorizations.TryRemove(result.AuthorizationId, out _);
            }
            finally { _lock.ExitWriteLock(); }

            if (!result.IsWinner && _dailyState.ConsecutiveLosses >= _settings.CooldownAfterConsecutiveLosses)
                StartCooldown(CooldownType.ConsecutiveLosses, $"{_dailyState.ConsecutiveLosses} losses", TimeSpan.FromMinutes(_settings.CooldownMinutes));
        }

        public void UpdateEnvironment(EnvironmentUpdate upd)
        {
            _lock.EnterWriteLock();
            try { _environmentState.IsChoppy = upd.IsChoppy; _environmentState.NoFollowThrough = upd.NoFollowThrough;
                  _environmentState.ATRRatio = upd.ATRRatio; _environmentState.VolumeRatio = upd.VolumeRatio;
                  _environmentState.CurrentSpread = upd.CurrentSpread; }
            finally { _lock.ExitWriteLock(); }
        }

        public void UpdateNewsStatus(NewsUpdate upd)
        {
            _lock.EnterWriteLock();
            try { _environmentState.HighImpactNewsActive = upd.IsHighImpactNearby; _environmentState.MinutesToNews = upd.MinutesToNews;
                  _environmentState.NextNewsEvent = upd.NextEventName; }
            finally { _lock.ExitWriteLock(); }
        }

        public void ResetDailyState()
        {
            _lock.EnterWriteLock();
            try { _accountState.DayStartBalance = _accountState.CurrentBalance;
                  _dailyState = new DailyState { Date = DateTime.Today, MaxTradesAllowed = _settings.DefaultMaxTradesPerDay };
                  if (!_settings.CooldownPersistAcrossDays) _cooldownState = new CooldownState(); }
            finally { _lock.ExitWriteLock(); }
        }
        #endregion

        #region Helpers
        private AggressivenessLevel CalculateAggressiveness()
        {
            double pnl = (_accountState.CurrentBalance - _accountState.DayStartBalance) / _accountState.DayStartBalance * 100;
            if (pnl <= -_settings.DefensiveThreshold || _dailyState.ConsecutiveLosses >= 2) return AggressivenessLevel.Defensive;
            if (pnl <= -_settings.CautiousThreshold || _dailyState.ConsecutiveLosses >= 1) return AggressivenessLevel.Cautious;
            if (pnl >= _settings.ConfidentThreshold && _dailyState.ConsecutiveWins >= 2) return AggressivenessLevel.Confident;
            return AggressivenessLevel.Normal;
        }

        private double GetRiskMultiplier(AggressivenessLevel l) => l switch 
        { AggressivenessLevel.Defensive => 0.5, AggressivenessLevel.Cautious => 0.75, 
          AggressivenessLevel.Normal => 1.0, AggressivenessLevel.Confident => 1.15, _ => 1.0 };

        private double GetMinSetupQuality(AggressivenessLevel l) => l switch 
        { AggressivenessLevel.Defensive => 85, AggressivenessLevel.Cautious => 75, 
          AggressivenessLevel.Normal => 65, AggressivenessLevel.Confident => 60, _ => 65 };

        private RiskConstraints CalculateConstraints(TradingStateResult state)
        {
            double remaining = GetRemainingDrawdown();
            return new RiskConstraints {
                MaxRisk = remaining * _settings.MaxRiskPercentOfRemaining / 100 * state.MaxRiskMultiplier,
                MaxSize = _propFirmRules.MaxPositionSize > 0 ? _propFirmRules.MaxPositionSize : 10,
                MaxHoldingMinutes = state.AggressivenessLevel switch { AggressivenessLevel.Defensive => 30, AggressivenessLevel.Cautious => 45, _ => 60 }
            };
        }

        private double GetRemainingDrawdown()
        {
            double dailyLimit = _accountState.DayStartBalance * _propFirmRules.DailyDrawdownLimit / 100;
            double dailyLoss = Math.Max(0, _accountState.DayStartBalance - _accountState.CurrentBalance);
            double maxLimit = _accountState.StartingBalance * _propFirmRules.MaxDrawdownLimit / 100;
            double maxLoss = Math.Max(0, _accountState.StartingBalance - _accountState.CurrentBalance);
            return Math.Min(dailyLimit - dailyLoss, maxLimit - maxLoss);
        }

        private DateTime? CalculateMustCloseBy()
        {
            if (_settings.ForceSessionEnd) return DateTime.Today.Add(_settings.SessionEndTime);
            if (!_propFirmRules.AllowWeekendHolding && DateTime.Now.DayOfWeek == DayOfWeek.Friday) return DateTime.Today.Add(_settings.FridayCloseTime);
            return null;
        }
        #endregion

        #region Public Interface
        public GovernanceStatus GetStatus()
        {
            _lock.EnterReadLock();
            try {
                var agg = CalculateAggressiveness();
                return new GovernanceStatus {
                    CurrentState = _currentState, CanTradeNow = _currentState == TradingState.Active,
                    IsKillSwitchActive = _globalKillSwitch, KillSwitchReason = _killSwitchReason,
                    IsCooldownActive = _cooldownState.IsActive, CooldownEndsAt = _cooldownState.EndsAt,
                    AggressivenessLevel = agg, RiskMultiplier = GetRiskMultiplier(agg),
                    DailyPnL = _dailyState.DailyPnL, TradesExecuted = _dailyState.TradeCount,
                    TradesRemaining = _dailyState.MaxTradesAllowed - _dailyState.TradeCount,
                    ConsecutiveLosses = _dailyState.ConsecutiveLosses, DrawdownRemaining = GetRemainingDrawdown(),
                    ActiveAuthorizations = _activeAuthorizations.Count
                };
            } finally { _lock.ExitReadLock(); }
        }

        public bool CanTradeNow() => EvaluateTradingState().CanTrade;
        #endregion
    }

    #region Supporting Classes
    public class PropFirmRules
    {
        public double DailyDrawdownLimit { get; set; } = 5.0;
        public double MaxDrawdownLimit { get; set; } = 10.0;
        public bool TrailingDrawdownEnabled { get; set; } = false;
        public int MaxPositionSize { get; set; } = 5;
        public List<TimeRestriction> RestrictedPeriods { get; set; } = new List<TimeRestriction>();
        public List<DayOfWeek> NoTradingDays { get; set; } = new List<DayOfWeek> { DayOfWeek.Sunday };
        public bool AllowWeekendHolding { get; set; } = false;
    }

    public class GovernanceSettings
    {
        public int DefaultMaxTradesPerDay { get; set; } = 6;
        public bool ForceSessionEnd { get; set; } = true;
        public TimeSpan SessionEndTime { get; set; } = new TimeSpan(16, 0, 0);
        public TimeSpan FridayCloseTime { get; set; } = new TimeSpan(15, 30, 0);
        public double DefensiveThreshold { get; set; } = 1.5;
        public double CautiousThreshold { get; set; } = 0.5;
        public double ConfidentThreshold { get; set; } = 1.0;
        public double MinATRRatio { get; set; } = 0.5;
        public double MaxATRRatio { get; set; } = 2.5;
        public double MinVolumeRatio { get; set; } = 0.5;
        public double MaxSpreadTicks { get; set; } = 4;
        public double MinEnvironmentScore { get; set; } = 60;
        public int AuthorizationValiditySeconds { get; set; } = 30;
        public int ProgressCheckInterval { get; set; } = 15;
        public double MinProgressRatio { get; set; } = 0.25;
        public double MaxRiskPercentOfRemaining { get; set; } = 20;
        public int CooldownAfterConsecutiveLosses { get; set; } = 2;
        public int CooldownMinutes { get; set; } = 30;
        public bool CooldownPersistAcrossDays { get; set; } = false;
        public string KillSwitchDeactivationCode { get; set; } = "CONFIRM_RESUME";
    }

    public class TimeRestriction { public TimeSpan Start { get; set; } public TimeSpan End { get; set; } public string Reason { get; set; } }
    public class AccountState { public double StartingBalance { get; set; } public double CurrentBalance { get; set; } public double PeakBalance { get; set; } public double DayStartBalance { get; set; } public int CurrentPositionSize { get; set; } }
    public class DailyState { public DateTime Date { get; set; } public double DailyPnL { get; set; } public int TradeCount { get; set; } public int WinCount { get; set; } public int LossCount { get; set; } public int ConsecutiveWins { get; set; } public int ConsecutiveLosses { get; set; } public int MaxTradesAllowed { get; set; } public int AuthorizationsGranted { get; set; } }
    public class CooldownState { public bool IsActive { get; set; } public CooldownType Type { get; set; } public string Reason { get; set; } public DateTime StartedAt { get; set; } public DateTime EndsAt { get; set; } }
    public class EnvironmentState { public bool IsChoppy { get; set; } public bool NoFollowThrough { get; set; } public double ATRRatio { get; set; } = 1.0; public double VolumeRatio { get; set; } = 1.0; public double CurrentSpread { get; set; } public bool HighImpactNewsActive { get; set; } public int MinutesToNews { get; set; } public string NextNewsEvent { get; set; } }
    
    public class TradeAuthorization
    {
        public string AuthorizationId { get; set; } public string RequestId { get; set; } public string Instrument { get; set; } public TradeDirection Direction { get; set; } public string RequestedSetup { get; set; }
        public DateTime RequestTime { get; set; } public DateTime? GrantedTime { get; set; } public DateTime ExpiresAt { get; set; } public DateTime? MustCloseBy { get; set; }
        public bool IsGranted { get; set; } public string DenialReason { get; set; } public BlockLevel DenialLevel { get; set; }
        public AggressivenessLevel AggressivenessLevel { get; set; } public double RiskMultiplier { get; set; } public double GrantedRiskAmount { get; set; } public int MaxPositionSize { get; set; } public int MaxHoldingMinutes { get; set; }
        public bool WasExecuted { get; set; } public DateTime? ExecutionTime { get; set; } public double ActualEntryPrice { get; set; } public int ActualPositionSize { get; set; }
        public bool WasRevoked { get; set; } public string RevocationReason { get; set; }
        public bool IsStillValid => IsGranted && !WasRevoked && !WasExecuted && DateTime.Now <= ExpiresAt;
    }

    public class TradeAuthorizationRequest { public string RequestId { get; set; } public string Instrument { get; set; } public TradeDirection Direction { get; set; } public string SetupType { get; set; } public double SetupQuality { get; set; } public double RequestedRiskAmount { get; set; } }
    public class AuthorizationValidation { public bool IsValid { get; set; } public string Reason { get; set; } public TradeAuthorization Authorization { get; set; } }
    public class ExecutionConfirmation { public DateTime ExecutionTime { get; set; } public double EntryPrice { get; set; } public int PositionSize { get; set; } }
    public class TradingStateResult { public TradingState State { get; set; } public bool CanTrade { get; set; } public string Reason { get; set; } public BlockLevel BlockLevel { get; set; } public AggressivenessLevel AggressivenessLevel { get; set; } public double MaxRiskMultiplier { get; set; } public int MaxTradesRemaining { get; set; } public double DrawdownRemaining { get; set; } public double EnvironmentScore { get; set; } public DateTime Timestamp { get; set; } }
    public class PropFirmEvaluation { public bool IsCompliant { get; set; } public bool IsCritical { get; set; } public PropFirmViolation ViolationType { get; set; } public string Message { get; set; } }
    public class SessionEvaluation { public bool IsValid { get; set; } public string Reason { get; set; } }
    public class EnvironmentEvaluation { public bool IsFavorable { get; set; } public double Score { get; set; } public string Reason { get; set; } }
    public class RiskConstraints { public double MaxRisk { get; set; } public int MaxSize { get; set; } public int MaxHoldingMinutes { get; set; } }
    public class OpenTradeStatus { public string TradeId { get; set; } public DateTime EntryTime { get; set; } public double InitialRisk { get; set; } public double UnrealizedPnL { get; set; } }
    public class OpenTradeDirective { public string TradeId { get; set; } public TradeDirectiveAction Action { get; set; } public string Reason { get; set; } public int ReducePercent { get; set; } public DateTime Timestamp { get; set; } }
    public class TradeResultUpdate { public string AuthorizationId { get; set; } public double NetPnL { get; set; } public bool IsWinner { get; set; } public int PositionSize { get; set; } }
    public class EnvironmentUpdate { public bool IsChoppy { get; set; } public bool NoFollowThrough { get; set; } public double ATRRatio { get; set; } public double VolumeRatio { get; set; } public double CurrentSpread { get; set; } }
    public class NewsUpdate { public bool IsHighImpactNearby { get; set; } public int MinutesToNews { get; set; } public string NextEventName { get; set; } }
    public class BlockedRequest { public string RequestId { get; set; } public string Reason { get; set; } public BlockLevel Level { get; set; } }
    public class GovernanceStatus { public TradingState CurrentState { get; set; } public bool CanTradeNow { get; set; } public bool IsKillSwitchActive { get; set; } public string KillSwitchReason { get; set; } public bool IsCooldownActive { get; set; } public DateTime CooldownEndsAt { get; set; } public AggressivenessLevel AggressivenessLevel { get; set; } public double RiskMultiplier { get; set; } public double DailyPnL { get; set; } public int TradesExecuted { get; set; } public int TradesRemaining { get; set; } public int ConsecutiveLosses { get; set; } public double DrawdownRemaining { get; set; } public int ActiveAuthorizations { get; set; } }

    public class TradingStateChangedEvent { public TradingState PreviousState { get; set; } public TradingState NewState { get; set; } }
    public class AuthorizationEvent { public TradeAuthorization Authorization { get; set; } }
    public class KillSwitchEvent { public KillSwitchType Type { get; set; } public string Reason { get; set; } }
    public class CooldownEvent { public CooldownType Type { get; set; } public string Reason { get; set; } public TimeSpan Duration { get; set; } }

    public enum TradingState { Evaluating, Active, KillSwitchActive, PropFirmBlocked, Cooldown, OutsideSession, NewsBlocked, UnfavorableEnvironment, DailyLimitReached }
    public enum BlockLevel { None, KillSwitch, PropFirmRule, Cooldown, SessionTime, News, Environment, DailyLimit, SetupQuality }
    public enum PropFirmViolation { None, DailyDrawdown, MaxDrawdown, TrailingDrawdown, PositionSize }
    public enum AggressivenessLevel { Defensive, Cautious, Normal, Confident }
    public enum KillSwitchType { Manual, PropFirmBreach, ConsecutiveLosses, SystemError }
    public enum CooldownType { ConsecutiveLosses, LargeDrawdown, Manual }
    public enum TradeDirectiveAction { None, ReducePosition, CloseImmediately }
    #endregion
}
