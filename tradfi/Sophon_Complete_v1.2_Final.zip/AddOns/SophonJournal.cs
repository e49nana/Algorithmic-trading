#region Using declarations
using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using NinjaTrader.Cbi;
using NinjaTrader.NinjaScript;
#endregion

//===============================================================================
// SOPHON JOURNAL MODULE v1.0
// Système de Journalisation et Statistiques de Trading
//
// Ce module implémente:
//   - Logging complet de tous les trades
//   - Statistiques de performance (win rate, profit factor, Sharpe, etc.)
//   - Métriques avancées (MAE, MFE, R-multiples, expectancy)
//   - Export CSV/Excel
//   - Analyse par setup, instrument, session, jour de semaine
//   - Dashboard data feed
//
// Copyright (c) 2026 Algosphere Quant - Emmanuel
//===============================================================================

namespace NinjaTrader.NinjaScript.AddOns.Sophon
{
    /// <summary>
    /// Module de journalisation - Enregistre et analyse tous les trades
    /// </summary>
    public class SophonJournal : ISophonModule, ITradeJournal
    {
        #region Properties
        public string ModuleName => "SophonJournal";
        public bool IsInitialized { get; private set; }
        public bool IsEnabled { get; set; }
        
        public JournalSettings Settings { get; set; }
        
        // Stockage des trades
        private List<TradeResult> _tradeHistory;
        private List<LogEntry> _logEntries;
        
        // Statistiques en cache
        private PerformanceStatistics _cachedStats;
        private DateTime _lastStatsUpdate;
        private bool _statsNeedUpdate;
        
        // Statistiques par catégorie
        private Dictionary<SetupType, SetupStatistics> _statsBySetup;
        private Dictionary<string, InstrumentStatistics> _statsByInstrument;
        private Dictionary<TradingSession, SessionStatistics> _statsBySession;
        private Dictionary<DayOfWeek, DayStatistics> _statsByDay;
        
        // Events
        public event EventHandler<TradeResult> OnTradeLogged;
        public event EventHandler<PerformanceStatistics> OnStatsUpdated;
        
        // File paths
        private string _journalDirectory;
        private string _currentLogFile;
        
        private readonly object _lock = new object();
        #endregion

        #region Initialization
        public SophonJournal()
        {
            Settings = new JournalSettings();
            _tradeHistory = new List<TradeResult>();
            _logEntries = new List<LogEntry>();
            _statsBySetup = new Dictionary<SetupType, SetupStatistics>();
            _statsByInstrument = new Dictionary<string, InstrumentStatistics>();
            _statsBySession = new Dictionary<TradingSession, SessionStatistics>();
            _statsByDay = new Dictionary<DayOfWeek, DayStatistics>();
            _statsNeedUpdate = true;
            IsEnabled = true;
        }

        public void Initialize()
        {
            if (IsInitialized) return;
            
            _tradeHistory.Clear();
            _logEntries.Clear();
            ClearStatisticsCache();
            
            // Créer le répertoire de journalisation
            _journalDirectory = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                "NinjaTrader 8", "Sophon", "Journal"
            );
            
            if (!Directory.Exists(_journalDirectory))
                Directory.CreateDirectory(_journalDirectory);
            
            // Fichier de log du jour
            _currentLogFile = Path.Combine(_journalDirectory, $"SophonLog_{DateTime.Now:yyyy-MM-dd}.txt");
            
            // Charger l'historique si configuré
            if (Settings.LoadHistoryOnStart)
                LoadTradeHistory();
            
            IsInitialized = true;
            LogEntry(new LogEntry(LogLevel.Info, ModuleName, "Journal initialized"));
        }

        public void Shutdown()
        {
            // Sauvegarder avant de fermer
            if (Settings.AutoSaveOnShutdown)
            {
                SaveTradeHistory();
                ExportToCsv(Path.Combine(_journalDirectory, $"Trades_{DateTime.Now:yyyy-MM-dd_HHmmss}.csv"));
            }
            
            _tradeHistory.Clear();
            _logEntries.Clear();
            IsInitialized = false;
        }

        public void Reset()
        {
            Shutdown();
            Initialize();
        }

        public void OnBarUpdate(int barsInProgress) { }

        private void ClearStatisticsCache()
        {
            _cachedStats = null;
            _statsBySetup.Clear();
            _statsByInstrument.Clear();
            _statsBySession.Clear();
            _statsByDay.Clear();
            _statsNeedUpdate = true;
        }
        #endregion

        #region Trade Logging
        /// <summary>
        /// Enregistre un trade dans le journal
        /// </summary>
        public void LogTrade(TradeResult result)
        {
            lock (_lock)
            {
                _tradeHistory.Add(result);
                _statsNeedUpdate = true;
                
                // Limiter la taille de l'historique en mémoire
                while (_tradeHistory.Count > Settings.MaxTradesInMemory)
                    _tradeHistory.RemoveAt(0);
            }
            
            // Logger dans le fichier
            if (Settings.LogToFile)
                WriteTradeToFile(result);
            
            OnTradeLogged?.Invoke(this, result);
            
            // Mettre à jour les stats si auto-update
            if (Settings.AutoUpdateStats)
                UpdateStatistics();
        }

        /// <summary>
        /// Enregistre un trade depuis un TradeSetup
        /// </summary>
        public void LogTradeFromSetup(TradeSetup trade)
        {
            var result = TradeResult.FromTradeSetup(trade);
            LogTrade(result);
        }

        /// <summary>
        /// Ajoute une entrée de log
        /// </summary>
        public void LogEntry(LogEntry entry)
        {
            lock (_lock)
            {
                _logEntries.Add(entry);
                
                while (_logEntries.Count > Settings.MaxLogEntries)
                    _logEntries.RemoveAt(0);
            }
            
            if (Settings.LogToFile)
                WriteLogToFile(entry);
        }

        private void WriteTradeToFile(TradeResult trade)
        {
            try
            {
                string tradeFile = Path.Combine(_journalDirectory, $"Trades_{DateTime.Now:yyyy-MM}.csv");
                bool fileExists = File.Exists(tradeFile);
                
                using (var writer = new StreamWriter(tradeFile, true))
                {
                    if (!fileExists)
                    {
                        writer.WriteLine("TradeId,Instrument,Setup,Direction,EntryTime,ExitTime,EntryPrice,ExitPrice," +
                                        "PositionSize,GrossPnL,NetPnL,RMultiple,MFE,MAE,ExitReason,SignalStrength," +
                                        "Session,ConfluenceCount,Duration,Notes");
                    }
                    
                    writer.WriteLine($"{trade.TradeId},{trade.Instrument},{trade.Setup},{trade.Direction}," +
                                    $"{trade.EntryTime:yyyy-MM-dd HH:mm:ss},{trade.ExitTime:yyyy-MM-dd HH:mm:ss}," +
                                    $"{trade.EntryPrice:F5},{trade.ExitPrice:F5},{trade.PositionSize}," +
                                    $"{trade.GrossPnL:F2},{trade.NetPnL:F2},{trade.RMultiple:F2}," +
                                    $"{trade.MFE:F5},{trade.MAE:F5},{trade.ExitReason},{trade.SignalStrength}," +
                                    $"{trade.Session},{trade.ConfluenceCount},{trade.Duration.TotalMinutes:F0}," +
                                    $"\"{trade.Notes?.Replace("\"", "\"\"")}\"");
                }
            }
            catch (Exception ex)
            {
                LogEntry(new LogEntry(LogLevel.Error, ModuleName, $"Failed to write trade to file: {ex.Message}"));
            }
        }

        private void WriteLogToFile(LogEntry entry)
        {
            try
            {
                using (var writer = new StreamWriter(_currentLogFile, true))
                {
                    writer.WriteLine(entry.ToString());
                }
            }
            catch { }
        }
        #endregion

        #region Statistics Calculation
        /// <summary>
        /// Met à jour toutes les statistiques
        /// </summary>
        public void UpdateStatistics()
        {
            if (!_statsNeedUpdate && _cachedStats != null)
                return;
            
            lock (_lock)
            {
                _cachedStats = CalculateStatistics(_tradeHistory);
                CalculateStatsByCategory();
                _lastStatsUpdate = DateTime.Now;
                _statsNeedUpdate = false;
            }
            
            OnStatsUpdated?.Invoke(this, _cachedStats);
        }

        /// <summary>
        /// Calcule les statistiques pour une liste de trades
        /// </summary>
        private PerformanceStatistics CalculateStatistics(List<TradeResult> trades)
        {
            var stats = new PerformanceStatistics();
            
            if (trades == null || trades.Count == 0)
                return stats;
            
            stats.TotalTrades = trades.Count;
            stats.Winners = trades.Count(t => t.IsWinner);
            stats.Losers = trades.Count(t => t.IsLoser);
            stats.BreakEvens = trades.Count(t => t.IsBreakEven);
            
            // Win Rate
            stats.WinRate = stats.TotalTrades > 0 
                ? (double)stats.Winners / stats.TotalTrades 
                : 0;
            
            // P/L
            stats.GrossProfit = trades.Where(t => t.NetPnL > 0).Sum(t => t.NetPnL);
            stats.GrossLoss = Math.Abs(trades.Where(t => t.NetPnL < 0).Sum(t => t.NetPnL));
            stats.NetProfit = stats.GrossProfit - stats.GrossLoss;
            stats.TotalCommissions = trades.Sum(t => t.Commission);
            
            // Profit Factor
            stats.ProfitFactor = stats.GrossLoss > 0 
                ? stats.GrossProfit / stats.GrossLoss 
                : stats.GrossProfit > 0 ? double.MaxValue : 0;
            
            // Average Win/Loss
            stats.AverageWin = stats.Winners > 0 
                ? trades.Where(t => t.IsWinner).Average(t => t.NetPnL) 
                : 0;
            stats.AverageLoss = stats.Losers > 0 
                ? Math.Abs(trades.Where(t => t.IsLoser).Average(t => t.NetPnL)) 
                : 0;
            stats.AverageTrade = trades.Average(t => t.NetPnL);
            
            // Largest Win/Loss
            stats.LargestWin = trades.Any(t => t.IsWinner) 
                ? trades.Where(t => t.IsWinner).Max(t => t.NetPnL) 
                : 0;
            stats.LargestLoss = trades.Any(t => t.IsLoser) 
                ? Math.Abs(trades.Where(t => t.IsLoser).Min(t => t.NetPnL)) 
                : 0;
            
            // Expectancy (R-based)
            var tradesWithR = trades.Where(t => !double.IsNaN(t.RMultiple) && !double.IsInfinity(t.RMultiple)).ToList();
            if (tradesWithR.Count > 0)
            {
                stats.Expectancy = tradesWithR.Average(t => t.RMultiple);
                stats.AverageRMultiple = stats.Expectancy;
            }
            
            // Consecutive wins/losses
            CalculateConsecutiveStats(trades, stats);
            
            // Drawdown
            CalculateDrawdownStats(trades, stats);
            
            // Sharpe Ratio (simplified - daily returns)
            CalculateSharpeRatio(trades, stats);
            
            // Duration stats
            if (trades.Count > 0)
            {
                stats.AverageDuration = TimeSpan.FromMinutes(trades.Average(t => t.Duration.TotalMinutes));
                stats.ShortestTrade = trades.Min(t => t.Duration);
                stats.LongestTrade = trades.Max(t => t.Duration);
            }
            
            // MFE/MAE
            var tradesWithMFE = trades.Where(t => t.MFE > 0).ToList();
            var tradesWithMAE = trades.Where(t => t.MAE > 0).ToList();
            
            if (tradesWithMFE.Count > 0)
                stats.AverageMFE = tradesWithMFE.Average(t => t.MFE);
            if (tradesWithMAE.Count > 0)
                stats.AverageMAE = tradesWithMAE.Average(t => t.MAE);
            
            // Edge Ratio (MFE/MAE)
            if (stats.AverageMAE > 0)
                stats.EdgeRatio = stats.AverageMFE / stats.AverageMAE;
            
            // Payoff Ratio
            if (stats.AverageLoss > 0)
                stats.PayoffRatio = stats.AverageWin / stats.AverageLoss;
            
            // Kelly Criterion
            if (stats.PayoffRatio > 0)
                stats.KellyCriterion = stats.WinRate - ((1 - stats.WinRate) / stats.PayoffRatio);
            
            stats.LastUpdated = DateTime.Now;
            
            return stats;
        }

        private void CalculateConsecutiveStats(List<TradeResult> trades, PerformanceStatistics stats)
        {
            int currentWinStreak = 0;
            int currentLossStreak = 0;
            int maxWinStreak = 0;
            int maxLossStreak = 0;
            
            foreach (var trade in trades.OrderBy(t => t.ExitTime))
            {
                if (trade.IsWinner)
                {
                    currentWinStreak++;
                    currentLossStreak = 0;
                    maxWinStreak = Math.Max(maxWinStreak, currentWinStreak);
                }
                else if (trade.IsLoser)
                {
                    currentLossStreak++;
                    currentWinStreak = 0;
                    maxLossStreak = Math.Max(maxLossStreak, currentLossStreak);
                }
            }
            
            stats.MaxConsecutiveWins = maxWinStreak;
            stats.MaxConsecutiveLosses = maxLossStreak;
            stats.CurrentWinStreak = currentWinStreak;
            stats.CurrentLossStreak = currentLossStreak;
        }

        private void CalculateDrawdownStats(List<TradeResult> trades, PerformanceStatistics stats)
        {
            if (trades.Count == 0) return;
            
            var orderedTrades = trades.OrderBy(t => t.ExitTime).ToList();
            
            double cumulativePnL = 0;
            double peak = 0;
            double maxDrawdown = 0;
            double currentDrawdown = 0;
            DateTime drawdownStart = DateTime.MinValue;
            DateTime maxDrawdownStart = DateTime.MinValue;
            DateTime maxDrawdownEnd = DateTime.MinValue;
            
            foreach (var trade in orderedTrades)
            {
                cumulativePnL += trade.NetPnL;
                
                if (cumulativePnL > peak)
                {
                    peak = cumulativePnL;
                    currentDrawdown = 0;
                    drawdownStart = trade.ExitTime;
                }
                else
                {
                    currentDrawdown = peak - cumulativePnL;
                    
                    if (currentDrawdown > maxDrawdown)
                    {
                        maxDrawdown = currentDrawdown;
                        maxDrawdownStart = drawdownStart;
                        maxDrawdownEnd = trade.ExitTime;
                    }
                }
            }
            
            stats.MaxDrawdown = maxDrawdown;
            stats.MaxDrawdownPercent = peak > 0 ? maxDrawdown / peak : 0;
            stats.CurrentDrawdown = currentDrawdown;
            
            // Calcul du nombre de trades pour récupérer du max drawdown
            if (maxDrawdown > 0)
            {
                double recovery = 0;
                int tradesInRecovery = 0;
                bool inRecovery = false;
                
                foreach (var trade in orderedTrades)
                {
                    if (trade.ExitTime >= maxDrawdownEnd)
                    {
                        inRecovery = true;
                    }
                    
                    if (inRecovery)
                    {
                        recovery += trade.NetPnL;
                        tradesInRecovery++;
                        
                        if (recovery >= maxDrawdown)
                            break;
                    }
                }
                
                stats.RecoveryTrades = tradesInRecovery;
            }
        }

        private void CalculateSharpeRatio(List<TradeResult> trades, PerformanceStatistics stats)
        {
            if (trades.Count < 2) return;
            
            // Grouper par jour
            var dailyReturns = trades
                .GroupBy(t => t.ExitTime.Date)
                .Select(g => g.Sum(t => t.NetPnL))
                .ToList();
            
            if (dailyReturns.Count < 2) return;
            
            double avgReturn = dailyReturns.Average();
            double stdDev = Math.Sqrt(dailyReturns.Average(r => Math.Pow(r - avgReturn, 2)));
            
            // Sharpe annualisé (252 trading days)
            if (stdDev > 0)
                stats.SharpeRatio = (avgReturn / stdDev) * Math.Sqrt(252);
            
            // Sortino (downside deviation only)
            var negativeReturns = dailyReturns.Where(r => r < 0).ToList();
            if (negativeReturns.Count > 0)
            {
                double downsideDev = Math.Sqrt(negativeReturns.Average(r => Math.Pow(r, 2)));
                if (downsideDev > 0)
                    stats.SortinoRatio = (avgReturn / downsideDev) * Math.Sqrt(252);
            }
        }

        private void CalculateStatsByCategory()
        {
            var trades = _tradeHistory.ToList();
            
            // Par Setup
            _statsBySetup.Clear();
            foreach (var group in trades.GroupBy(t => t.Setup))
            {
                _statsBySetup[group.Key] = new SetupStatistics
                {
                    Setup = group.Key,
                    Stats = CalculateStatistics(group.ToList())
                };
            }
            
            // Par Instrument
            _statsByInstrument.Clear();
            foreach (var group in trades.GroupBy(t => t.Instrument))
            {
                _statsByInstrument[group.Key] = new InstrumentStatistics
                {
                    Instrument = group.Key,
                    Stats = CalculateStatistics(group.ToList())
                };
            }
            
            // Par Session
            _statsBySession.Clear();
            foreach (var group in trades.GroupBy(t => t.Session))
            {
                _statsBySession[group.Key] = new SessionStatistics
                {
                    Session = group.Key,
                    Stats = CalculateStatistics(group.ToList())
                };
            }
            
            // Par Jour de la semaine
            _statsByDay.Clear();
            foreach (var group in trades.GroupBy(t => t.EntryTime.DayOfWeek))
            {
                _statsByDay[group.Key] = new DayStatistics
                {
                    Day = group.Key,
                    Stats = CalculateStatistics(group.ToList())
                };
            }
        }
        #endregion

        #region Query Interface
        /// <summary>
        /// Obtient les trades avec filtres optionnels
        /// </summary>
        public List<TradeResult> GetTrades(DateTime? from = null, DateTime? to = null, string instrument = null)
        {
            lock (_lock)
            {
                IEnumerable<TradeResult> query = _tradeHistory;
                
                if (from.HasValue)
                    query = query.Where(t => t.EntryTime >= from.Value);
                
                if (to.HasValue)
                    query = query.Where(t => t.ExitTime <= to.Value);
                
                if (!string.IsNullOrEmpty(instrument))
                    query = query.Where(t => t.Instrument.Equals(instrument, StringComparison.OrdinalIgnoreCase));
                
                return query.ToList();
            }
        }

        /// <summary>
        /// Obtient les trades par setup
        /// </summary>
        public List<TradeResult> GetTradesBySetup(SetupType setup)
        {
            lock (_lock)
            {
                return _tradeHistory.Where(t => t.Setup == setup).ToList();
            }
        }

        /// <summary>
        /// Obtient les trades par session
        /// </summary>
        public List<TradeResult> GetTradesBySession(TradingSession session)
        {
            lock (_lock)
            {
                return _tradeHistory.Where(t => t.Session == session).ToList();
            }
        }

        /// <summary>
        /// Obtient les statistiques globales
        /// </summary>
        public Dictionary<string, double> GetStatistics(DateTime? from = null, DateTime? to = null)
        {
            var trades = GetTrades(from, to);
            var stats = CalculateStatistics(trades);
            
            return new Dictionary<string, double>
            {
                ["TotalTrades"] = stats.TotalTrades,
                ["Winners"] = stats.Winners,
                ["Losers"] = stats.Losers,
                ["WinRate"] = stats.WinRate,
                ["NetProfit"] = stats.NetProfit,
                ["ProfitFactor"] = stats.ProfitFactor,
                ["AverageWin"] = stats.AverageWin,
                ["AverageLoss"] = stats.AverageLoss,
                ["Expectancy"] = stats.Expectancy,
                ["MaxDrawdown"] = stats.MaxDrawdown,
                ["SharpeRatio"] = stats.SharpeRatio,
                ["MaxConsecutiveWins"] = stats.MaxConsecutiveWins,
                ["MaxConsecutiveLosses"] = stats.MaxConsecutiveLosses
            };
        }

        /// <summary>
        /// Obtient les statistiques complètes
        /// </summary>
        public PerformanceStatistics GetFullStatistics()
        {
            if (_statsNeedUpdate)
                UpdateStatistics();
            
            return _cachedStats ?? new PerformanceStatistics();
        }

        /// <summary>
        /// Obtient les statistiques par setup
        /// </summary>
        public Dictionary<SetupType, SetupStatistics> GetStatsBySetup()
        {
            if (_statsNeedUpdate)
                UpdateStatistics();
            
            return new Dictionary<SetupType, SetupStatistics>(_statsBySetup);
        }

        /// <summary>
        /// Obtient les statistiques par instrument
        /// </summary>
        public Dictionary<string, InstrumentStatistics> GetStatsByInstrument()
        {
            if (_statsNeedUpdate)
                UpdateStatistics();
            
            return new Dictionary<string, InstrumentStatistics>(_statsByInstrument);
        }

        /// <summary>
        /// Obtient les statistiques par session
        /// </summary>
        public Dictionary<TradingSession, SessionStatistics> GetStatsBySession()
        {
            if (_statsNeedUpdate)
                UpdateStatistics();
            
            return new Dictionary<TradingSession, SessionStatistics>(_statsBySession);
        }

        /// <summary>
        /// Obtient les statistiques par jour
        /// </summary>
        public Dictionary<DayOfWeek, DayStatistics> GetStatsByDay()
        {
            if (_statsNeedUpdate)
                UpdateStatistics();
            
            return new Dictionary<DayOfWeek, DayStatistics>(_statsByDay);
        }

        /// <summary>
        /// Obtient les entrées de log récentes
        /// </summary>
        public List<LogEntry> GetRecentLogs(int count = 100, LogLevel? minLevel = null)
        {
            lock (_lock)
            {
                IEnumerable<LogEntry> query = _logEntries;
                
                if (minLevel.HasValue)
                    query = query.Where(l => l.Level >= minLevel.Value);
                
                return query.TakeLast(count).ToList();
            }
        }
        #endregion

        #region Export
        /// <summary>
        /// Exporte les trades vers CSV
        /// </summary>
        public void ExportToCsv(string filePath)
        {
            try
            {
                var trades = GetTrades();
                
                using (var writer = new StreamWriter(filePath, false, Encoding.UTF8))
                {
                    // Header
                    writer.WriteLine("TradeId,Instrument,Setup,Direction,EntryTime,ExitTime,EntryPrice,ExitPrice," +
                                    "PositionSize,GrossPnL,Commission,NetPnL,RMultiple,MFE,MAE,ExitReason," +
                                    "SignalStrength,Session,ConfluenceCount,DurationMinutes,Notes");
                    
                    // Data
                    foreach (var trade in trades)
                    {
                        writer.WriteLine($"{trade.TradeId},{trade.Instrument},{trade.Setup},{trade.Direction}," +
                                        $"{trade.EntryTime:yyyy-MM-dd HH:mm:ss},{trade.ExitTime:yyyy-MM-dd HH:mm:ss}," +
                                        $"{trade.EntryPrice.ToString(CultureInfo.InvariantCulture)}," +
                                        $"{trade.ExitPrice.ToString(CultureInfo.InvariantCulture)}," +
                                        $"{trade.PositionSize}," +
                                        $"{trade.GrossPnL.ToString(CultureInfo.InvariantCulture)}," +
                                        $"{trade.Commission.ToString(CultureInfo.InvariantCulture)}," +
                                        $"{trade.NetPnL.ToString(CultureInfo.InvariantCulture)}," +
                                        $"{trade.RMultiple.ToString(CultureInfo.InvariantCulture)}," +
                                        $"{trade.MFE.ToString(CultureInfo.InvariantCulture)}," +
                                        $"{trade.MAE.ToString(CultureInfo.InvariantCulture)}," +
                                        $"{trade.ExitReason},{trade.SignalStrength},{trade.Session}," +
                                        $"{trade.ConfluenceCount},{trade.Duration.TotalMinutes:F0}," +
                                        $"\"{trade.Notes?.Replace("\"", "\"\"")}\"");
                    }
                }
                
                LogEntry(new LogEntry(LogLevel.Info, ModuleName, $"Exported {trades.Count} trades to {filePath}"));
            }
            catch (Exception ex)
            {
                LogEntry(new LogEntry(LogLevel.Error, ModuleName, $"Export failed: {ex.Message}"));
            }
        }

        /// <summary>
        /// Exporte les statistiques vers un fichier texte
        /// </summary>
        public void ExportStatistics(string filePath)
        {
            try
            {
                var stats = GetFullStatistics();
                
                using (var writer = new StreamWriter(filePath, false, Encoding.UTF8))
                {
                    writer.WriteLine("═══════════════════════════════════════════════════════════════");
                    writer.WriteLine("                    SOPHON PERFORMANCE REPORT");
                    writer.WriteLine($"                    Generated: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
                    writer.WriteLine("═══════════════════════════════════════════════════════════════");
                    writer.WriteLine();
                    
                    writer.WriteLine("SUMMARY");
                    writer.WriteLine("───────────────────────────────────────────────────────────────");
                    writer.WriteLine($"Total Trades:          {stats.TotalTrades}");
                    writer.WriteLine($"Winners:               {stats.Winners} ({stats.WinRate:P1})");
                    writer.WriteLine($"Losers:                {stats.Losers}");
                    writer.WriteLine($"Break-Even:            {stats.BreakEvens}");
                    writer.WriteLine();
                    
                    writer.WriteLine("PROFIT & LOSS");
                    writer.WriteLine("───────────────────────────────────────────────────────────────");
                    writer.WriteLine($"Net Profit:            ${stats.NetProfit:N2}");
                    writer.WriteLine($"Gross Profit:          ${stats.GrossProfit:N2}");
                    writer.WriteLine($"Gross Loss:            ${stats.GrossLoss:N2}");
                    writer.WriteLine($"Profit Factor:         {stats.ProfitFactor:F2}");
                    writer.WriteLine($"Expectancy:            {stats.Expectancy:F2}R");
                    writer.WriteLine();
                    
                    writer.WriteLine("AVERAGES");
                    writer.WriteLine("───────────────────────────────────────────────────────────────");
                    writer.WriteLine($"Average Win:           ${stats.AverageWin:N2}");
                    writer.WriteLine($"Average Loss:          ${stats.AverageLoss:N2}");
                    writer.WriteLine($"Average Trade:         ${stats.AverageTrade:N2}");
                    writer.WriteLine($"Payoff Ratio:          {stats.PayoffRatio:F2}");
                    writer.WriteLine();
                    
                    writer.WriteLine("RISK METRICS");
                    writer.WriteLine("───────────────────────────────────────────────────────────────");
                    writer.WriteLine($"Max Drawdown:          ${stats.MaxDrawdown:N2} ({stats.MaxDrawdownPercent:P1})");
                    writer.WriteLine($"Sharpe Ratio:          {stats.SharpeRatio:F2}");
                    writer.WriteLine($"Sortino Ratio:         {stats.SortinoRatio:F2}");
                    writer.WriteLine($"Kelly Criterion:       {stats.KellyCriterion:P1}");
                    writer.WriteLine();
                    
                    writer.WriteLine("STREAKS");
                    writer.WriteLine("───────────────────────────────────────────────────────────────");
                    writer.WriteLine($"Max Consecutive Wins:  {stats.MaxConsecutiveWins}");
                    writer.WriteLine($"Max Consecutive Losses:{stats.MaxConsecutiveLosses}");
                    writer.WriteLine($"Largest Win:           ${stats.LargestWin:N2}");
                    writer.WriteLine($"Largest Loss:          ${stats.LargestLoss:N2}");
                    writer.WriteLine();
                    
                    writer.WriteLine("EXECUTION");
                    writer.WriteLine("───────────────────────────────────────────────────────────────");
                    writer.WriteLine($"Average Duration:      {stats.AverageDuration.TotalMinutes:F0} minutes");
                    writer.WriteLine($"Average MFE:           {stats.AverageMFE:F4}");
                    writer.WriteLine($"Average MAE:           {stats.AverageMAE:F4}");
                    writer.WriteLine($"Edge Ratio:            {stats.EdgeRatio:F2}");
                    writer.WriteLine();
                    
                    // Stats par Setup
                    writer.WriteLine("═══════════════════════════════════════════════════════════════");
                    writer.WriteLine("                      STATISTICS BY SETUP");
                    writer.WriteLine("═══════════════════════════════════════════════════════════════");
                    foreach (var kvp in _statsBySetup.OrderByDescending(k => k.Value.Stats.NetProfit))
                    {
                        var s = kvp.Value.Stats;
                        writer.WriteLine($"{kvp.Key,-20} | Trades: {s.TotalTrades,4} | WR: {s.WinRate,6:P0} | PF: {s.ProfitFactor,5:F2} | Net: ${s.NetProfit,10:N2}");
                    }
                    writer.WriteLine();
                    
                    // Stats par Instrument
                    writer.WriteLine("═══════════════════════════════════════════════════════════════");
                    writer.WriteLine("                    STATISTICS BY INSTRUMENT");
                    writer.WriteLine("═══════════════════════════════════════════════════════════════");
                    foreach (var kvp in _statsByInstrument.OrderByDescending(k => k.Value.Stats.NetProfit))
                    {
                        var s = kvp.Value.Stats;
                        writer.WriteLine($"{kvp.Key,-10} | Trades: {s.TotalTrades,4} | WR: {s.WinRate,6:P0} | PF: {s.ProfitFactor,5:F2} | Net: ${s.NetProfit,10:N2}");
                    }
                    writer.WriteLine();
                    
                    // Stats par Session
                    writer.WriteLine("═══════════════════════════════════════════════════════════════");
                    writer.WriteLine("                     STATISTICS BY SESSION");
                    writer.WriteLine("═══════════════════════════════════════════════════════════════");
                    foreach (var kvp in _statsBySession.OrderByDescending(k => k.Value.Stats.NetProfit))
                    {
                        var s = kvp.Value.Stats;
                        writer.WriteLine($"{kvp.Key,-15} | Trades: {s.TotalTrades,4} | WR: {s.WinRate,6:P0} | PF: {s.ProfitFactor,5:F2} | Net: ${s.NetProfit,10:N2}");
                    }
                }
                
                LogEntry(new LogEntry(LogLevel.Info, ModuleName, $"Exported statistics to {filePath}"));
            }
            catch (Exception ex)
            {
                LogEntry(new LogEntry(LogLevel.Error, ModuleName, $"Stats export failed: {ex.Message}"));
            }
        }
        #endregion

        #region Persistence
        private void SaveTradeHistory()
        {
            try
            {
                string historyFile = Path.Combine(_journalDirectory, "TradeHistory.json");
                // Simplified - in production, use proper JSON serialization
                File.WriteAllText(historyFile, $"{{\"count\": {_tradeHistory.Count}}}");
            }
            catch { }
        }

        private void LoadTradeHistory()
        {
            try
            {
                // Load from CSV files in journal directory
                var csvFiles = Directory.GetFiles(_journalDirectory, "Trades_*.csv");
                foreach (var file in csvFiles.OrderBy(f => f))
                {
                    LoadTradesFromCsv(file);
                }
            }
            catch { }
        }

        private void LoadTradesFromCsv(string filePath)
        {
            try
            {
                var lines = File.ReadAllLines(filePath).Skip(1); // Skip header
                foreach (var line in lines)
                {
                    var trade = ParseTradeFromCsv(line);
                    if (trade != null)
                        _tradeHistory.Add(trade);
                }
            }
            catch { }
        }

        private TradeResult ParseTradeFromCsv(string line)
        {
            try
            {
                var parts = line.Split(',');
                if (parts.Length < 15) return null;
                
                return new TradeResult
                {
                    TradeId = parts[0],
                    Instrument = parts[1],
                    Setup = Enum.TryParse<SetupType>(parts[2], out var setup) ? setup : SetupType.None,
                    Direction = Enum.TryParse<TradeDirection>(parts[3], out var dir) ? dir : TradeDirection.Flat,
                    EntryTime = DateTime.Parse(parts[4]),
                    ExitTime = DateTime.Parse(parts[5]),
                    EntryPrice = double.Parse(parts[6], CultureInfo.InvariantCulture),
                    ExitPrice = double.Parse(parts[7], CultureInfo.InvariantCulture),
                    PositionSize = int.Parse(parts[8]),
                    GrossPnL = double.Parse(parts[9], CultureInfo.InvariantCulture),
                    NetPnL = double.Parse(parts[10], CultureInfo.InvariantCulture),
                    RMultiple = double.Parse(parts[11], CultureInfo.InvariantCulture),
                    MFE = double.Parse(parts[12], CultureInfo.InvariantCulture),
                    MAE = double.Parse(parts[13], CultureInfo.InvariantCulture),
                    ExitReason = Enum.TryParse<ExitReason>(parts[14], out var reason) ? reason : ExitReason.ManualClose
                };
            }
            catch
            {
                return null;
            }
        }
        #endregion
    }

    #region Supporting Classes
    /// <summary>
    /// Paramètres de configuration du journal
    /// </summary>
    public class JournalSettings
    {
        public bool LogToFile { get; set; } = true;
        public bool AutoUpdateStats { get; set; } = true;
        public bool AutoSaveOnShutdown { get; set; } = true;
        public bool LoadHistoryOnStart { get; set; } = true;
        public int MaxTradesInMemory { get; set; } = 10000;
        public int MaxLogEntries { get; set; } = 5000;
    }

    /// <summary>
    /// Statistiques de performance complètes
    /// </summary>
    public class PerformanceStatistics
    {
        // Counts
        public int TotalTrades { get; set; }
        public int Winners { get; set; }
        public int Losers { get; set; }
        public int BreakEvens { get; set; }
        
        // Rates
        public double WinRate { get; set; }
        
        // P/L
        public double GrossProfit { get; set; }
        public double GrossLoss { get; set; }
        public double NetProfit { get; set; }
        public double TotalCommissions { get; set; }
        public double ProfitFactor { get; set; }
        
        // Averages
        public double AverageWin { get; set; }
        public double AverageLoss { get; set; }
        public double AverageTrade { get; set; }
        public double AverageRMultiple { get; set; }
        public double Expectancy { get; set; }
        public double PayoffRatio { get; set; }
        
        // Extremes
        public double LargestWin { get; set; }
        public double LargestLoss { get; set; }
        
        // Streaks
        public int MaxConsecutiveWins { get; set; }
        public int MaxConsecutiveLosses { get; set; }
        public int CurrentWinStreak { get; set; }
        public int CurrentLossStreak { get; set; }
        
        // Drawdown
        public double MaxDrawdown { get; set; }
        public double MaxDrawdownPercent { get; set; }
        public double CurrentDrawdown { get; set; }
        public int RecoveryTrades { get; set; }
        
        // Risk Metrics
        public double SharpeRatio { get; set; }
        public double SortinoRatio { get; set; }
        public double KellyCriterion { get; set; }
        
        // Duration
        public TimeSpan AverageDuration { get; set; }
        public TimeSpan ShortestTrade { get; set; }
        public TimeSpan LongestTrade { get; set; }
        
        // MFE/MAE
        public double AverageMFE { get; set; }
        public double AverageMAE { get; set; }
        public double EdgeRatio { get; set; }
        
        public DateTime LastUpdated { get; set; }

        public override string ToString() =>
            $"Trades: {TotalTrades} | WR: {WinRate:P1} | PF: {ProfitFactor:F2} | Net: ${NetProfit:N2} | Sharpe: {SharpeRatio:F2}";
    }

    /// <summary>
    /// Statistiques par type de setup
    /// </summary>
    public class SetupStatistics
    {
        public SetupType Setup { get; set; }
        public PerformanceStatistics Stats { get; set; }
    }

    /// <summary>
    /// Statistiques par instrument
    /// </summary>
    public class InstrumentStatistics
    {
        public string Instrument { get; set; }
        public PerformanceStatistics Stats { get; set; }
    }

    /// <summary>
    /// Statistiques par session
    /// </summary>
    public class SessionStatistics
    {
        public TradingSession Session { get; set; }
        public PerformanceStatistics Stats { get; set; }
    }

    /// <summary>
    /// Statistiques par jour de la semaine
    /// </summary>
    public class DayStatistics
    {
        public DayOfWeek Day { get; set; }
        public PerformanceStatistics Stats { get; set; }
    }
    #endregion
}
