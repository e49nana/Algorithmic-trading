#region Using declarations
using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using NinjaTrader.Cbi;
using NinjaTrader.NinjaScript;
#endregion

//===============================================================================
// SOPHON MULTI-ACCOUNT MODULE v1.0
// Système de Gestion Multi-Comptes Avancé
//
// Ce module implémente:
//   - Gestion simultanée de plusieurs comptes
//   - Allocation proportionnelle des trades
//   - Copy trading (master → followers)
//   - Mirror trading (inversion possible)
//   - Limites et règles par compte
//   - Synchronisation des positions
//   - Agrégation des statistiques
//
// Copyright (c) 2026 Algosphere Quant - Emmanuel
//===============================================================================

namespace NinjaTrader.NinjaScript.AddOns.Sophon
{
    /// <summary>
    /// Module de gestion multi-comptes
    /// </summary>
    public class SophonMultiAccount : ISophonModule
    {
        #region Properties
        public string ModuleName => "SophonMultiAccount";
        public bool IsInitialized { get; private set; }
        public bool IsEnabled { get; set; }
        
        public MultiAccountSettings Settings { get; set; }
        
        // Comptes enregistrés
        private ConcurrentDictionary<string, ManagedAccount> _accounts;
        
        // Groupes de comptes
        private Dictionary<string, AccountGroup> _accountGroups;
        
        // Compte master pour le copy trading
        private string _masterAccountId;
        
        // Positions agrégées
        private ConcurrentDictionary<string, AggregatedPosition> _aggregatedPositions;
        
        // File d'attente des ordres à propager
        private ConcurrentQueue<PropagationOrder> _orderQueue;
        
        // Historique des allocations
        private List<AllocationRecord> _allocationHistory;
        
        // Events
        public event EventHandler<AccountEvent> OnAccountAdded;
        public event EventHandler<AccountEvent> OnAccountRemoved;
        public event EventHandler<AccountEvent> OnAccountStateChanged;
        public event EventHandler<TradeAllocationEvent> OnTradeAllocated;
        public event EventHandler<PropagationEvent> OnTradePropagated;
        public event EventHandler<SyncEvent> OnPositionsSynced;
        
        // Référence au module de risque
        private SophonRisk _riskModule;
        private SophonExecution _executionModule;
        
        private readonly object _lock = new object();
        private Timer _syncTimer;
        #endregion

        #region Initialization
        public SophonMultiAccount()
        {
            Settings = new MultiAccountSettings();
            _accounts = new ConcurrentDictionary<string, ManagedAccount>();
            _accountGroups = new Dictionary<string, AccountGroup>();
            _aggregatedPositions = new ConcurrentDictionary<string, AggregatedPosition>();
            _orderQueue = new ConcurrentQueue<PropagationOrder>();
            _allocationHistory = new List<AllocationRecord>();
            IsEnabled = true;
        }

        public void Initialize()
        {
            if (IsInitialized) return;
            
            _accounts.Clear();
            _accountGroups.Clear();
            _aggregatedPositions.Clear();
            while (_orderQueue.TryDequeue(out _)) { }
            _allocationHistory.Clear();
            
            // Démarrer le timer de synchronisation
            if (Settings.EnableAutoSync)
            {
                _syncTimer = new Timer(SyncCallback, null, 
                    TimeSpan.FromSeconds(10), 
                    TimeSpan.FromSeconds(Settings.SyncIntervalSeconds));
            }
            
            IsInitialized = true;
        }

        public void Shutdown()
        {
            _syncTimer?.Dispose();
            _syncTimer = null;
            
            // Sauvegarder l'état si configuré
            if (Settings.SaveStateOnShutdown)
                SaveState();
            
            _accounts.Clear();
            _accountGroups.Clear();
            IsInitialized = false;
        }

        public void Reset()
        {
            Shutdown();
            Initialize();
        }

        public void OnBarUpdate(int barsInProgress) { }

        /// <summary>
        /// Injecte les modules de dépendance
        /// </summary>
        public void InjectDependencies(SophonRisk riskModule, SophonExecution executionModule)
        {
            _riskModule = riskModule;
            _executionModule = executionModule;
        }
        #endregion

        #region Account Management
        /// <summary>
        /// Ajoute un compte à gérer
        /// </summary>
        public bool AddAccount(AccountConfig config)
        {
            if (string.IsNullOrEmpty(config.AccountId))
                return false;
            
            var managedAccount = new ManagedAccount(config);
            
            if (_accounts.TryAdd(config.AccountId, managedAccount))
            {
                // Enregistrer aussi dans le module de risque
                _riskModule?.RegisterAccount(config);
                
                OnAccountAdded?.Invoke(this, new AccountEvent
                {
                    AccountId = config.AccountId,
                    EventType = AccountEventType.Added,
                    Timestamp = DateTime.Now
                });
                
                return true;
            }
            
            return false;
        }

        /// <summary>
        /// Retire un compte de la gestion
        /// </summary>
        public bool RemoveAccount(string accountId)
        {
            if (_accounts.TryRemove(accountId, out var account))
            {
                // Fermer les positions si configuré
                if (Settings.ClosePositionsOnRemove)
                {
                    CloseAllPositionsForAccount(accountId);
                }
                
                OnAccountRemoved?.Invoke(this, new AccountEvent
                {
                    AccountId = accountId,
                    EventType = AccountEventType.Removed,
                    Timestamp = DateTime.Now
                });
                
                return true;
            }
            
            return false;
        }

        /// <summary>
        /// Met à jour la configuration d'un compte
        /// </summary>
        public bool UpdateAccount(AccountConfig config)
        {
            if (_accounts.TryGetValue(config.AccountId, out var account))
            {
                account.Config = config;
                account.LastUpdate = DateTime.Now;
                
                // Mettre à jour aussi dans le module de risque
                _riskModule?.RegisterAccount(config);
                
                OnAccountStateChanged?.Invoke(this, new AccountEvent
                {
                    AccountId = config.AccountId,
                    EventType = AccountEventType.Updated,
                    Timestamp = DateTime.Now
                });
                
                return true;
            }
            
            return false;
        }

        /// <summary>
        /// Active ou désactive un compte
        /// </summary>
        public bool SetAccountActive(string accountId, bool isActive)
        {
            if (_accounts.TryGetValue(accountId, out var account))
            {
                account.Config.IsActive = isActive;
                account.LastUpdate = DateTime.Now;
                
                OnAccountStateChanged?.Invoke(this, new AccountEvent
                {
                    AccountId = accountId,
                    EventType = isActive ? AccountEventType.Activated : AccountEventType.Deactivated,
                    Timestamp = DateTime.Now
                });
                
                return true;
            }
            
            return false;
        }

        /// <summary>
        /// Définit le compte master pour le copy trading
        /// </summary>
        public void SetMasterAccount(string accountId)
        {
            if (_accounts.ContainsKey(accountId))
            {
                _masterAccountId = accountId;
                _accounts[accountId].IsMaster = true;
                
                // Retirer le flag master des autres comptes
                foreach (var kvp in _accounts.Where(a => a.Key != accountId))
                {
                    kvp.Value.IsMaster = false;
                }
            }
        }

        /// <summary>
        /// Obtient un compte par ID
        /// </summary>
        public ManagedAccount GetAccount(string accountId)
        {
            return _accounts.TryGetValue(accountId, out var account) ? account : null;
        }

        /// <summary>
        /// Obtient tous les comptes actifs
        /// </summary>
        public List<ManagedAccount> GetActiveAccounts()
        {
            return _accounts.Values.Where(a => a.Config.IsActive).ToList();
        }

        /// <summary>
        /// Obtient tous les comptes
        /// </summary>
        public List<ManagedAccount> GetAllAccounts()
        {
            return _accounts.Values.ToList();
        }
        #endregion

        #region Account Groups
        /// <summary>
        /// Crée un groupe de comptes
        /// </summary>
        public void CreateGroup(string groupId, string name, List<string> accountIds)
        {
            var group = new AccountGroup
            {
                GroupId = groupId,
                Name = name,
                AccountIds = accountIds,
                CreatedAt = DateTime.Now
            };
            
            lock (_lock)
            {
                _accountGroups[groupId] = group;
            }
        }

        /// <summary>
        /// Ajoute un compte à un groupe
        /// </summary>
        public void AddToGroup(string groupId, string accountId)
        {
            lock (_lock)
            {
                if (_accountGroups.ContainsKey(groupId) && !_accountGroups[groupId].AccountIds.Contains(accountId))
                {
                    _accountGroups[groupId].AccountIds.Add(accountId);
                }
            }
        }

        /// <summary>
        /// Retire un compte d'un groupe
        /// </summary>
        public void RemoveFromGroup(string groupId, string accountId)
        {
            lock (_lock)
            {
                if (_accountGroups.ContainsKey(groupId))
                {
                    _accountGroups[groupId].AccountIds.Remove(accountId);
                }
            }
        }

        /// <summary>
        /// Obtient les comptes d'un groupe
        /// </summary>
        public List<ManagedAccount> GetGroupAccounts(string groupId)
        {
            lock (_lock)
            {
                if (!_accountGroups.ContainsKey(groupId))
                    return new List<ManagedAccount>();
                
                return _accountGroups[groupId].AccountIds
                    .Where(id => _accounts.ContainsKey(id))
                    .Select(id => _accounts[id])
                    .ToList();
            }
        }
        #endregion

        #region Trade Allocation
        /// <summary>
        /// Alloue un trade à tous les comptes éligibles
        /// </summary>
        public List<TradeAllocation> AllocateTrade(TradeSetup baseTrade, AllocationMode mode = AllocationMode.Proportional)
        {
            var allocations = new List<TradeAllocation>();
            var eligibleAccounts = GetEligibleAccounts(baseTrade);
            
            if (eligibleAccounts.Count == 0)
                return allocations;
            
            // Calculer l'allocation totale
            double totalAllocation = eligibleAccounts.Sum(a => a.Config.AllocationPercent);
            
            foreach (var account in eligibleAccounts)
            {
                var allocation = CreateAllocation(baseTrade, account, mode, totalAllocation);
                
                if (allocation != null && allocation.PositionSize > 0)
                {
                    allocations.Add(allocation);
                    
                    // Enregistrer l'allocation
                    RecordAllocation(allocation);
                    
                    OnTradeAllocated?.Invoke(this, new TradeAllocationEvent
                    {
                        Allocation = allocation,
                        Timestamp = DateTime.Now
                    });
                }
            }
            
            return allocations;
        }

        /// <summary>
        /// Obtient les comptes éligibles pour un trade
        /// </summary>
        private List<ManagedAccount> GetEligibleAccounts(TradeSetup trade)
        {
            return _accounts.Values.Where(a => 
                a.Config.IsActive &&
                !a.IsPaused &&
                (_riskModule?.CanOpenTrade(a.Config) ?? true) &&
                IsInstrumentAllowed(a, trade.Signal?.Instrument) &&
                IsSessionAllowed(a, trade.Signal?.Session ?? TradingSession.All)
            ).ToList();
        }

        /// <summary>
        /// Vérifie si un instrument est autorisé pour un compte
        /// </summary>
        private bool IsInstrumentAllowed(ManagedAccount account, string instrument)
        {
            if (string.IsNullOrEmpty(instrument))
                return true;
            
            if (account.Config.AllowedInstruments == null || account.Config.AllowedInstruments.Count == 0)
                return true;
            
            return account.Config.AllowedInstruments.Contains(instrument);
        }

        /// <summary>
        /// Vérifie si une session est autorisée pour un compte
        /// </summary>
        private bool IsSessionAllowed(ManagedAccount account, TradingSession session)
        {
            if (account.Config.AllowedSessions == null || account.Config.AllowedSessions.Count == 0)
                return true;
            
            return account.Config.AllowedSessions.Contains(session) ||
                   account.Config.AllowedSessions.Contains(TradingSession.All);
        }

        /// <summary>
        /// Crée une allocation pour un compte
        /// </summary>
        private TradeAllocation CreateAllocation(TradeSetup baseTrade, ManagedAccount account, 
                                                  AllocationMode mode, double totalAllocation)
        {
            var allocation = new TradeAllocation
            {
                AllocationId = Guid.NewGuid().ToString("N").Substring(0, 8),
                AccountId = account.Config.AccountId,
                BaseTradeId = baseTrade.Id,
                Instrument = baseTrade.Signal?.Instrument,
                Direction = baseTrade.Signal?.Direction ?? TradeDirection.Flat,
                EntryPrice = baseTrade.Signal?.EntryPrice ?? 0,
                StopLoss = baseTrade.Risk?.StopLossPrice ?? 0,
                TakeProfit = baseTrade.Risk?.TakeProfit1Price ?? 0,
                AllocatedAt = DateTime.Now
            };
            
            // Calculer la taille selon le mode
            switch (mode)
            {
                case AllocationMode.Proportional:
                    // Proportionnel à l'allocation du compte
                    double ratio = totalAllocation > 0 
                        ? account.Config.AllocationPercent / totalAllocation 
                        : 1.0 / _accounts.Count;
                    allocation.PositionSize = (int)Math.Floor(baseTrade.Risk.PositionSize * ratio);
                    break;
                    
                case AllocationMode.Fixed:
                    // Taille fixe par compte
                    allocation.PositionSize = account.Config.FixedPositionSize;
                    break;
                    
                case AllocationMode.RiskBased:
                    // Basé sur le risque par compte
                    if (_riskModule != null)
                    {
                        var riskParams = _riskModule.CalculateRisk(baseTrade.Signal, account.Config, 
                                                                    baseTrade.Risk?.ATRValue ?? 1.0);
                        allocation.PositionSize = riskParams.PositionSize;
                        allocation.RiskAmount = riskParams.RiskAmount;
                    }
                    else
                    {
                        allocation.PositionSize = baseTrade.Risk?.PositionSize ?? 1;
                    }
                    break;
                    
                case AllocationMode.Equal:
                    // Même taille pour tous
                    allocation.PositionSize = baseTrade.Risk?.PositionSize ?? 1;
                    break;
            }
            
            // Appliquer les limites du compte
            allocation.PositionSize = Math.Min(allocation.PositionSize, account.Config.MaxPositionSize);
            allocation.PositionSize = Math.Max(allocation.PositionSize, 1);
            
            return allocation;
        }

        /// <summary>
        /// Enregistre une allocation dans l'historique
        /// </summary>
        private void RecordAllocation(TradeAllocation allocation)
        {
            lock (_lock)
            {
                _allocationHistory.Add(new AllocationRecord
                {
                    Allocation = allocation,
                    RecordedAt = DateTime.Now
                });
                
                // Limiter l'historique
                while (_allocationHistory.Count > Settings.MaxAllocationHistory)
                {
                    _allocationHistory.RemoveAt(0);
                }
            }
        }
        #endregion

        #region Copy Trading
        /// <summary>
        /// Propage un trade du master vers les followers
        /// </summary>
        public void PropagateFromMaster(TradeSetup masterTrade)
        {
            if (string.IsNullOrEmpty(_masterAccountId))
                return;
            
            if (!Settings.EnableCopyTrading)
                return;
            
            var followers = _accounts.Values
                .Where(a => a.Config.IsActive && !a.IsMaster && a.Config.AccountId != _masterAccountId)
                .ToList();
            
            foreach (var follower in followers)
            {
                var propagationOrder = new PropagationOrder
                {
                    OrderId = Guid.NewGuid().ToString("N").Substring(0, 8),
                    SourceAccountId = _masterAccountId,
                    TargetAccountId = follower.Config.AccountId,
                    SourceTradeId = masterTrade.Id,
                    Instrument = masterTrade.Signal?.Instrument,
                    Direction = masterTrade.Signal?.Direction ?? TradeDirection.Flat,
                    EntryPrice = masterTrade.Signal?.EntryPrice ?? 0,
                    StopLoss = masterTrade.Risk?.StopLossPrice ?? 0,
                    TakeProfit = masterTrade.Risk?.TakeProfit1Price ?? 0,
                    PropagationType = PropagationType.Copy,
                    CreatedAt = DateTime.Now
                };
                
                // Appliquer le multiplicateur du follower
                double sizeMultiplier = follower.Config.CopyMultiplier;
                propagationOrder.PositionSize = (int)Math.Floor(masterTrade.Risk.PositionSize * sizeMultiplier);
                
                // Inverser si mirror
                if (follower.Config.MirrorTrades)
                {
                    propagationOrder.Direction = propagationOrder.Direction == TradeDirection.Long 
                        ? TradeDirection.Short 
                        : TradeDirection.Long;
                    propagationOrder.PropagationType = PropagationType.Mirror;
                    
                    // Inverser SL et TP
                    double tempSL = propagationOrder.StopLoss;
                    propagationOrder.StopLoss = propagationOrder.TakeProfit;
                    propagationOrder.TakeProfit = tempSL;
                }
                
                // Ajouter à la file
                _orderQueue.Enqueue(propagationOrder);
            }
            
            // Traiter la file
            ProcessPropagationQueue();
        }

        /// <summary>
        /// Traite la file d'ordres à propager
        /// </summary>
        private void ProcessPropagationQueue()
        {
            while (_orderQueue.TryDequeue(out var order))
            {
                try
                {
                    ExecutePropagation(order);
                }
                catch (Exception ex)
                {
                    order.Status = PropagationStatus.Failed;
                    order.ErrorMessage = ex.Message;
                }
                
                OnTradePropagated?.Invoke(this, new PropagationEvent
                {
                    Order = order,
                    Timestamp = DateTime.Now
                });
            }
        }

        /// <summary>
        /// Exécute une propagation d'ordre
        /// </summary>
        private void ExecutePropagation(PropagationOrder order)
        {
            if (!_accounts.TryGetValue(order.TargetAccountId, out var targetAccount))
            {
                order.Status = PropagationStatus.Failed;
                order.ErrorMessage = "Target account not found";
                return;
            }
            
            // Vérifier si le compte peut trader
            if (!targetAccount.Config.IsActive || targetAccount.IsPaused)
            {
                order.Status = PropagationStatus.Skipped;
                order.ErrorMessage = "Target account inactive or paused";
                return;
            }
            
            // Créer le trade setup pour le compte cible
            var targetTrade = new TradeSetup
            {
                AccountId = order.TargetAccountId,
                Signal = new SMCSignal
                {
                    Instrument = order.Instrument,
                    Direction = order.Direction,
                    EntryPrice = order.EntryPrice,
                    StopLoss = order.StopLoss,
                    TakeProfit1 = order.TakeProfit
                },
                Risk = new RiskParameters
                {
                    PositionSize = order.PositionSize,
                    StopLossPrice = order.StopLoss,
                    TakeProfit1Price = order.TakeProfit
                }
            };
            
            // Exécuter via le module d'exécution
            if (_executionModule != null)
            {
                _executionModule.ExecuteTrade(targetTrade);
                order.Status = PropagationStatus.Executed;
                order.ExecutedAt = DateTime.Now;
                
                // Mettre à jour le compte
                targetAccount.OpenPositions++;
                targetAccount.LastTradeTime = DateTime.Now;
            }
            else
            {
                order.Status = PropagationStatus.Pending;
            }
        }
        #endregion

        #region Position Synchronization
        /// <summary>
        /// Synchronise les positions entre les comptes
        /// </summary>
        public void SyncPositions()
        {
            if (!Settings.EnablePositionSync)
                return;
            
            // Agréger les positions par instrument
            UpdateAggregatedPositions();
            
            // Vérifier les écarts
            var discrepancies = FindPositionDiscrepancies();
            
            // Corriger si configuré
            if (Settings.AutoCorrectDiscrepancies && discrepancies.Count > 0)
            {
                foreach (var disc in discrepancies)
                {
                    CorrectDiscrepancy(disc);
                }
            }
            
            OnPositionsSynced?.Invoke(this, new SyncEvent
            {
                Timestamp = DateTime.Now,
                DiscrepanciesFound = discrepancies.Count,
                Corrected = Settings.AutoCorrectDiscrepancies
            });
        }

        /// <summary>
        /// Met à jour les positions agrégées
        /// </summary>
        private void UpdateAggregatedPositions()
        {
            _aggregatedPositions.Clear();
            
            foreach (var account in _accounts.Values.Where(a => a.Config.IsActive))
            {
                foreach (var position in account.Positions)
                {
                    string key = position.Instrument;
                    
                    if (!_aggregatedPositions.TryGetValue(key, out var agg))
                    {
                        agg = new AggregatedPosition { Instrument = key };
                        _aggregatedPositions[key] = agg;
                    }
                    
                    agg.TotalLongSize += position.Direction == TradeDirection.Long ? position.Size : 0;
                    agg.TotalShortSize += position.Direction == TradeDirection.Short ? position.Size : 0;
                    agg.AccountCount++;
                    agg.AccountPositions[account.Config.AccountId] = position;
                }
            }
        }

        /// <summary>
        /// Trouve les écarts de position entre comptes
        /// </summary>
        private List<PositionDiscrepancy> FindPositionDiscrepancies()
        {
            var discrepancies = new List<PositionDiscrepancy>();
            
            foreach (var agg in _aggregatedPositions.Values)
            {
                if (agg.AccountPositions.Count < 2)
                    continue;
                
                // Vérifier si tous les comptes ont la même direction
                var directions = agg.AccountPositions.Values.Select(p => p.Direction).Distinct().ToList();
                
                if (directions.Count > 1)
                {
                    discrepancies.Add(new PositionDiscrepancy
                    {
                        Instrument = agg.Instrument,
                        Type = DiscrepancyType.DirectionMismatch,
                        Details = $"Mixed directions: {string.Join(", ", directions)}"
                    });
                }
                
                // Vérifier les tailles proportionnelles
                var expectedRatios = agg.AccountPositions.Keys
                    .Where(id => _accounts.ContainsKey(id))
                    .ToDictionary(id => id, id => _accounts[id].Config.AllocationPercent);
                
                double totalExpected = expectedRatios.Values.Sum();
                
                foreach (var kvp in agg.AccountPositions)
                {
                    if (!expectedRatios.ContainsKey(kvp.Key))
                        continue;
                    
                    double expectedRatio = expectedRatios[kvp.Key] / totalExpected;
                    double actualRatio = (double)kvp.Value.Size / (agg.TotalLongSize + agg.TotalShortSize);
                    
                    if (Math.Abs(expectedRatio - actualRatio) > Settings.DiscrepancyThreshold)
                    {
                        discrepancies.Add(new PositionDiscrepancy
                        {
                            Instrument = agg.Instrument,
                            AccountId = kvp.Key,
                            Type = DiscrepancyType.SizeMismatch,
                            ExpectedSize = (int)(kvp.Value.Size * expectedRatio / actualRatio),
                            ActualSize = kvp.Value.Size,
                            Details = $"Expected ratio: {expectedRatio:P1}, Actual: {actualRatio:P1}"
                        });
                    }
                }
            }
            
            return discrepancies;
        }

        /// <summary>
        /// Corrige un écart de position
        /// </summary>
        private void CorrectDiscrepancy(PositionDiscrepancy discrepancy)
        {
            // Logique de correction selon le type
            switch (discrepancy.Type)
            {
                case DiscrepancyType.SizeMismatch:
                    // Ajuster la taille de la position
                    int adjustment = discrepancy.ExpectedSize - discrepancy.ActualSize;
                    if (adjustment > 0)
                    {
                        // Ajouter à la position
                        // _executionModule?.AddToPosition(...)
                    }
                    else if (adjustment < 0)
                    {
                        // Réduire la position
                        // _executionModule?.ReducePosition(...)
                    }
                    break;
                    
                case DiscrepancyType.DirectionMismatch:
                    // Alerter - ne pas corriger automatiquement
                    break;
            }
        }

        /// <summary>
        /// Callback de synchronisation périodique
        /// </summary>
        private void SyncCallback(object state)
        {
            if (!IsEnabled || !IsInitialized)
                return;
            
            try
            {
                SyncPositions();
            }
            catch { }
        }
        #endregion

        #region Account Operations
        /// <summary>
        /// Ferme toutes les positions d'un compte
        /// </summary>
        public void CloseAllPositionsForAccount(string accountId)
        {
            if (_executionModule != null)
            {
                _executionModule.CloseAllPositions(accountId, ExitReason.ManualClose);
            }
            
            if (_accounts.TryGetValue(accountId, out var account))
            {
                account.Positions.Clear();
                account.OpenPositions = 0;
            }
        }

        /// <summary>
        /// Met en pause un compte
        /// </summary>
        public void PauseAccount(string accountId)
        {
            if (_accounts.TryGetValue(accountId, out var account))
            {
                account.IsPaused = true;
                account.PausedAt = DateTime.Now;
                
                OnAccountStateChanged?.Invoke(this, new AccountEvent
                {
                    AccountId = accountId,
                    EventType = AccountEventType.Paused,
                    Timestamp = DateTime.Now
                });
            }
        }

        /// <summary>
        /// Reprend un compte
        /// </summary>
        public void ResumeAccount(string accountId)
        {
            if (_accounts.TryGetValue(accountId, out var account))
            {
                account.IsPaused = false;
                account.PausedAt = null;
                
                OnAccountStateChanged?.Invoke(this, new AccountEvent
                {
                    AccountId = accountId,
                    EventType = AccountEventType.Resumed,
                    Timestamp = DateTime.Now
                });
            }
        }

        /// <summary>
        /// Met à jour le solde d'un compte
        /// </summary>
        public void UpdateAccountBalance(string accountId, double balance)
        {
            if (_accounts.TryGetValue(accountId, out var account))
            {
                account.Config.CurrentBalance = balance;
                account.LastUpdate = DateTime.Now;
                
                // Mettre à jour aussi dans le module de risque
                _riskModule?.UpdateAccountBalance(accountId, balance);
            }
        }
        #endregion

        #region Statistics & Reports
        /// <summary>
        /// Obtient un résumé de tous les comptes
        /// </summary>
        public MultiAccountSummary GetSummary()
        {
            var summary = new MultiAccountSummary
            {
                TotalAccounts = _accounts.Count,
                ActiveAccounts = _accounts.Values.Count(a => a.Config.IsActive),
                PausedAccounts = _accounts.Values.Count(a => a.IsPaused),
                Timestamp = DateTime.Now
            };
            
            foreach (var account in _accounts.Values)
            {
                summary.TotalBalance += account.Config.CurrentBalance;
                summary.TotalOpenPositions += account.OpenPositions;
                
                summary.AccountSummaries.Add(new AccountSummaryItem
                {
                    AccountId = account.Config.AccountId,
                    AccountName = account.Config.AccountName,
                    Balance = account.Config.CurrentBalance,
                    OpenPositions = account.OpenPositions,
                    IsActive = account.Config.IsActive,
                    IsPaused = account.IsPaused,
                    IsMaster = account.IsMaster,
                    AllocationPercent = account.Config.AllocationPercent
                });
            }
            
            return summary;
        }

        /// <summary>
        /// Obtient l'historique des allocations
        /// </summary>
        public List<AllocationRecord> GetAllocationHistory(string accountId = null, int count = 100)
        {
            lock (_lock)
            {
                var query = _allocationHistory.AsEnumerable();
                
                if (!string.IsNullOrEmpty(accountId))
                    query = query.Where(r => r.Allocation.AccountId == accountId);
                
                return query.TakeLast(count).ToList();
            }
        }

        /// <summary>
        /// Obtient les positions agrégées
        /// </summary>
        public Dictionary<string, AggregatedPosition> GetAggregatedPositions()
        {
            return new Dictionary<string, AggregatedPosition>(_aggregatedPositions);
        }
        #endregion

        #region Persistence
        private void SaveState()
        {
            // Sauvegarder l'état des comptes
            // (implémentation simplifiée)
        }
        #endregion
    }

    #region Supporting Classes
    public class MultiAccountSettings
    {
        public bool EnableCopyTrading { get; set; } = true;
        public bool EnablePositionSync { get; set; } = true;
        public bool EnableAutoSync { get; set; } = true;
        public int SyncIntervalSeconds { get; set; } = 30;
        public bool AutoCorrectDiscrepancies { get; set; } = false;
        public double DiscrepancyThreshold { get; set; } = 0.1;
        public bool ClosePositionsOnRemove { get; set; } = true;
        public bool SaveStateOnShutdown { get; set; } = true;
        public int MaxAllocationHistory { get; set; } = 1000;
    }

    public class ManagedAccount
    {
        public AccountConfig Config { get; set; }
        public bool IsMaster { get; set; }
        public bool IsPaused { get; set; }
        public DateTime? PausedAt { get; set; }
        public DateTime LastUpdate { get; set; }
        public DateTime? LastTradeTime { get; set; }
        public int OpenPositions { get; set; }
        public List<AccountPosition> Positions { get; set; }

        public ManagedAccount(AccountConfig config)
        {
            Config = config;
            Positions = new List<AccountPosition>();
            LastUpdate = DateTime.Now;
        }
    }

    public class AccountPosition
    {
        public string Instrument { get; set; }
        public TradeDirection Direction { get; set; }
        public int Size { get; set; }
        public double EntryPrice { get; set; }
        public DateTime OpenedAt { get; set; }
    }

    public class AccountGroup
    {
        public string GroupId { get; set; }
        public string Name { get; set; }
        public List<string> AccountIds { get; set; }
        public DateTime CreatedAt { get; set; }
    }

    public class TradeAllocation
    {
        public string AllocationId { get; set; }
        public string AccountId { get; set; }
        public string BaseTradeId { get; set; }
        public string Instrument { get; set; }
        public TradeDirection Direction { get; set; }
        public int PositionSize { get; set; }
        public double EntryPrice { get; set; }
        public double StopLoss { get; set; }
        public double TakeProfit { get; set; }
        public double RiskAmount { get; set; }
        public DateTime AllocatedAt { get; set; }
    }

    public class AllocationRecord
    {
        public TradeAllocation Allocation { get; set; }
        public DateTime RecordedAt { get; set; }
    }

    public enum AllocationMode { Proportional, Fixed, RiskBased, Equal }

    public class PropagationOrder
    {
        public string OrderId { get; set; }
        public string SourceAccountId { get; set; }
        public string TargetAccountId { get; set; }
        public string SourceTradeId { get; set; }
        public string Instrument { get; set; }
        public TradeDirection Direction { get; set; }
        public int PositionSize { get; set; }
        public double EntryPrice { get; set; }
        public double StopLoss { get; set; }
        public double TakeProfit { get; set; }
        public PropagationType PropagationType { get; set; }
        public PropagationStatus Status { get; set; }
        public string ErrorMessage { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? ExecutedAt { get; set; }
    }

    public enum PropagationType { Copy, Mirror }
    public enum PropagationStatus { Pending, Executed, Failed, Skipped }

    public class AggregatedPosition
    {
        public string Instrument { get; set; }
        public int TotalLongSize { get; set; }
        public int TotalShortSize { get; set; }
        public int AccountCount { get; set; }
        public Dictionary<string, AccountPosition> AccountPositions { get; set; } = new Dictionary<string, AccountPosition>();
        
        public int NetPosition => TotalLongSize - TotalShortSize;
        public TradeDirection NetDirection => NetPosition > 0 ? TradeDirection.Long : NetPosition < 0 ? TradeDirection.Short : TradeDirection.Flat;
    }

    public class PositionDiscrepancy
    {
        public string Instrument { get; set; }
        public string AccountId { get; set; }
        public DiscrepancyType Type { get; set; }
        public int ExpectedSize { get; set; }
        public int ActualSize { get; set; }
        public string Details { get; set; }
    }

    public enum DiscrepancyType { SizeMismatch, DirectionMismatch, MissingPosition }

    public class AccountEvent
    {
        public string AccountId { get; set; }
        public AccountEventType EventType { get; set; }
        public DateTime Timestamp { get; set; }
    }

    public enum AccountEventType { Added, Removed, Updated, Activated, Deactivated, Paused, Resumed }

    public class TradeAllocationEvent
    {
        public TradeAllocation Allocation { get; set; }
        public DateTime Timestamp { get; set; }
    }

    public class PropagationEvent
    {
        public PropagationOrder Order { get; set; }
        public DateTime Timestamp { get; set; }
    }

    public class SyncEvent
    {
        public DateTime Timestamp { get; set; }
        public int DiscrepanciesFound { get; set; }
        public bool Corrected { get; set; }
    }

    public class MultiAccountSummary
    {
        public int TotalAccounts { get; set; }
        public int ActiveAccounts { get; set; }
        public int PausedAccounts { get; set; }
        public double TotalBalance { get; set; }
        public int TotalOpenPositions { get; set; }
        public DateTime Timestamp { get; set; }
        public List<AccountSummaryItem> AccountSummaries { get; set; } = new List<AccountSummaryItem>();
    }

    public class AccountSummaryItem
    {
        public string AccountId { get; set; }
        public string AccountName { get; set; }
        public double Balance { get; set; }
        public int OpenPositions { get; set; }
        public bool IsActive { get; set; }
        public bool IsPaused { get; set; }
        public bool IsMaster { get; set; }
        public double AllocationPercent { get; set; }
    }
    #endregion
}
