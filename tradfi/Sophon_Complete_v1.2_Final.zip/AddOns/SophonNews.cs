#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using NinjaTrader.NinjaScript;
#endregion

//===============================================================================
// SOPHON NEWS MODULE v1.0
// Système de Calendrier Économique et Filtrage des News
//
// Ce module implémente:
//   - Calendrier économique multi-sources
//   - Classification des événements par impact (High/Medium/Low)
//   - Mapping événements → instruments affectés
//   - Buffer de protection avant/après événements
//   - Cache local des événements
//   - Alertes pour événements imminents
//
// Copyright (c) 2026 Algosphere Quant - Emmanuel
//===============================================================================

namespace NinjaTrader.NinjaScript.AddOns.Sophon
{
    /// <summary>
    /// Module de gestion des news économiques
    /// </summary>
    public class SophonNews : ISophonModule
    {
        #region Properties
        public string ModuleName => "SophonNews";
        public bool IsInitialized { get; private set; }
        public bool IsEnabled { get; set; }
        
        public NewsSettings Settings { get; set; }
        
        // Événements stockés
        private List<EconomicEvent> _allEvents;
        private List<EconomicEvent> _todayEvents;
        private List<EconomicEvent> _upcomingHighImpact;
        
        // Cache et mise à jour
        private DateTime _lastUpdate;
        private DateTime _lastCacheRefresh;
        private string _cacheDirectory;
        private string _cacheFile;
        
        // Mapping devise → instruments
        private Dictionary<string, List<string>> _currencyInstrumentMap;
        
        // Events
        public event EventHandler<EconomicEvent> OnHighImpactEventApproaching;
        public event EventHandler<EconomicEvent> OnEventStarted;
        public event EventHandler<EconomicEvent> OnEventEnded;
        public event EventHandler<NewsFilterStatus> OnFilterStatusChanged;
        
        private readonly object _lock = new object();
        #endregion

        #region Initialization
        public SophonNews()
        {
            Settings = new NewsSettings();
            _allEvents = new List<EconomicEvent>();
            _todayEvents = new List<EconomicEvent>();
            _upcomingHighImpact = new List<EconomicEvent>();
            _currencyInstrumentMap = new Dictionary<string, List<string>>();
            IsEnabled = true;
            
            InitializeCurrencyMapping();
        }

        public void Initialize()
        {
            if (IsInitialized) return;
            
            _allEvents.Clear();
            _todayEvents.Clear();
            _upcomingHighImpact.Clear();
            
            // Répertoire de cache
            _cacheDirectory = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                "NinjaTrader 8", "Sophon", "NewsCache"
            );
            
            if (!Directory.Exists(_cacheDirectory))
                Directory.CreateDirectory(_cacheDirectory);
            
            _cacheFile = Path.Combine(_cacheDirectory, $"EconomicCalendar_{DateTime.Now:yyyy-MM}.json");
            
            // Charger le cache local
            LoadCachedEvents();
            
            // Mettre à jour depuis les sources
            if (Settings.AutoRefreshOnStart)
                RefreshCalendar();
            
            IsInitialized = true;
        }

        public void Shutdown()
        {
            SaveCachedEvents();
            _allEvents.Clear();
            _todayEvents.Clear();
            IsInitialized = false;
        }

        public void Reset()
        {
            Shutdown();
            Initialize();
        }

        public void OnBarUpdate(int barsInProgress) { }

        /// <summary>
        /// Initialise le mapping devise → instruments
        /// </summary>
        private void InitializeCurrencyMapping()
        {
            _currencyInstrumentMap = new Dictionary<string, List<string>>
            {
                // USD affecte tous les indices US et commodités
                ["USD"] = new List<string> { "MES", "ES", "MNQ", "NQ", "M2K", "MYM", "MGC", "GC", "MCL", "CL", "DX" },
                
                // EUR
                ["EUR"] = new List<string> { "EURUSD", "6E", "DAX", "FDAX" },
                
                // GBP
                ["GBP"] = new List<string> { "GBPUSD", "6B", "FTSE" },
                
                // JPY
                ["JPY"] = new List<string> { "USDJPY", "6J", "NKD" },
                
                // CAD
                ["CAD"] = new List<string> { "USDCAD", "6C", "MCL", "CL" },
                
                // AUD
                ["AUD"] = new List<string> { "AUDUSD", "6A" },
                
                // CHF
                ["CHF"] = new List<string> { "USDCHF", "6S" },
                
                // NZD
                ["NZD"] = new List<string> { "NZDUSD", "6N" },
                
                // Or
                ["XAU"] = new List<string> { "MGC", "GC", "XAUUSD" },
                
                // Pétrole
                ["OIL"] = new List<string> { "MCL", "CL", "USOIL" },
                
                // CNY
                ["CNY"] = new List<string> { "USDCNH", "FXI" }
            };
        }
        #endregion

        #region Calendar Update
        /// <summary>
        /// Rafraîchit le calendrier économique
        /// </summary>
        public void RefreshCalendar()
        {
            try
            {
                // Charger depuis le fichier local si disponible et récent
                if (Settings.UseLocalCalendarFile && File.Exists(Settings.LocalCalendarPath))
                {
                    LoadFromLocalFile(Settings.LocalCalendarPath);
                }
                
                // Parser les événements intégrés (fallback)
                if (_allEvents.Count == 0 || Settings.UseBuiltInCalendar)
                {
                    LoadBuiltInEvents();
                }
                
                // Filtrer les événements du jour
                UpdateTodayEvents();
                
                // Mettre à jour les événements high-impact à venir
                UpdateUpcomingHighImpact();
                
                _lastUpdate = DateTime.Now;
                
                // Sauvegarder en cache
                SaveCachedEvents();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"SophonNews RefreshCalendar error: {ex.Message}");
            }
        }

        /// <summary>
        /// Charge les événements depuis un fichier local CSV
        /// </summary>
        private void LoadFromLocalFile(string filePath)
        {
            try
            {
                var lines = File.ReadAllLines(filePath).Skip(1); // Skip header
                
                foreach (var line in lines)
                {
                    var evt = ParseEventFromCsv(line);
                    if (evt != null && evt.Timestamp >= DateTime.Now.AddDays(-1))
                    {
                        _allEvents.Add(evt);
                    }
                }
            }
            catch { }
        }

        /// <summary>
        /// Parse un événement depuis une ligne CSV
        /// </summary>
        private EconomicEvent ParseEventFromCsv(string line)
        {
            try
            {
                var parts = line.Split(',');
                if (parts.Length < 5) return null;
                
                var evt = new EconomicEvent
                {
                    Id = Guid.NewGuid().ToString("N").Substring(0, 8),
                    Timestamp = DateTime.Parse(parts[0]),
                    Currency = parts[1].Trim().ToUpper(),
                    Name = parts[2].Trim(),
                    Impact = ParseImpact(parts[3]),
                    Forecast = parts.Length > 4 ? parts[4].Trim() : "",
                    Previous = parts.Length > 5 ? parts[5].Trim() : ""
                };
                
                // Mapper les instruments affectés
                evt.AffectedInstruments = GetAffectedInstruments(evt.Currency);
                
                return evt;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// Charge les événements intégrés (événements récurrents connus)
        /// </summary>
        private void LoadBuiltInEvents()
        {
            var today = DateTime.Today;
            var events = new List<EconomicEvent>();
            
            // Générer les événements récurrents pour les 2 prochaines semaines
            for (int day = 0; day < 14; day++)
            {
                var date = today.AddDays(day);
                
                // NFP - Premier vendredi du mois
                if (date.DayOfWeek == DayOfWeek.Friday && date.Day <= 7)
                {
                    events.Add(new EconomicEvent
                    {
                        Id = $"NFP_{date:yyyyMMdd}",
                        Name = "Non-Farm Payrolls",
                        Currency = "USD",
                        Impact = NewsImpact.High,
                        Timestamp = date.AddHours(13).AddMinutes(30), // 8:30 AM ET
                        AffectedInstruments = _currencyInstrumentMap["USD"],
                        Description = "US Employment Report - Major market mover"
                    });
                }
                
                // CPI - Généralement le 2ème mardi/mercredi du mois
                if (date.DayOfWeek == DayOfWeek.Wednesday && date.Day >= 10 && date.Day <= 15)
                {
                    events.Add(new EconomicEvent
                    {
                        Id = $"CPI_{date:yyyyMMdd}",
                        Name = "CPI (Consumer Price Index)",
                        Currency = "USD",
                        Impact = NewsImpact.High,
                        Timestamp = date.AddHours(13).AddMinutes(30),
                        AffectedInstruments = _currencyInstrumentMap["USD"],
                        Description = "US Inflation Data"
                    });
                }
                
                // FOMC - 8 fois par an (simulé ici)
                if (date.DayOfWeek == DayOfWeek.Wednesday && (date.Month % 2 == 0) && date.Day >= 15 && date.Day <= 21)
                {
                    events.Add(new EconomicEvent
                    {
                        Id = $"FOMC_{date:yyyyMMdd}",
                        Name = "FOMC Rate Decision",
                        Currency = "USD",
                        Impact = NewsImpact.High,
                        Timestamp = date.AddHours(19), // 2:00 PM ET
                        AffectedInstruments = _currencyInstrumentMap["USD"],
                        Description = "Federal Reserve Interest Rate Decision"
                    });
                }
                
                // ECB - Premier jeudi du mois
                if (date.DayOfWeek == DayOfWeek.Thursday && date.Day <= 7)
                {
                    events.Add(new EconomicEvent
                    {
                        Id = $"ECB_{date:yyyyMMdd}",
                        Name = "ECB Rate Decision",
                        Currency = "EUR",
                        Impact = NewsImpact.High,
                        Timestamp = date.AddHours(12).AddMinutes(45), // 12:45 UTC
                        AffectedInstruments = _currencyInstrumentMap["EUR"],
                        Description = "European Central Bank Interest Rate Decision"
                    });
                }
                
                // Jobless Claims - Chaque jeudi
                if (date.DayOfWeek == DayOfWeek.Thursday)
                {
                    events.Add(new EconomicEvent
                    {
                        Id = $"CLAIMS_{date:yyyyMMdd}",
                        Name = "Initial Jobless Claims",
                        Currency = "USD",
                        Impact = NewsImpact.Medium,
                        Timestamp = date.AddHours(13).AddMinutes(30),
                        AffectedInstruments = _currencyInstrumentMap["USD"],
                        Description = "Weekly Unemployment Claims"
                    });
                }
                
                // ISM Manufacturing - Premier jour ouvrable du mois
                if (date.Day <= 3 && date.DayOfWeek != DayOfWeek.Saturday && date.DayOfWeek != DayOfWeek.Sunday)
                {
                    events.Add(new EconomicEvent
                    {
                        Id = $"ISM_{date:yyyyMMdd}",
                        Name = "ISM Manufacturing PMI",
                        Currency = "USD",
                        Impact = NewsImpact.High,
                        Timestamp = date.AddHours(15), // 10:00 AM ET
                        AffectedInstruments = _currencyInstrumentMap["USD"],
                        Description = "US Manufacturing Activity Index"
                    });
                }
                
                // GDP - Fin de mois
                if (date.Day >= 25 && date.Day <= 28 && date.DayOfWeek != DayOfWeek.Saturday && date.DayOfWeek != DayOfWeek.Sunday)
                {
                    events.Add(new EconomicEvent
                    {
                        Id = $"GDP_{date:yyyyMMdd}",
                        Name = "GDP (Preliminary)",
                        Currency = "USD",
                        Impact = NewsImpact.High,
                        Timestamp = date.AddHours(13).AddMinutes(30),
                        AffectedInstruments = _currencyInstrumentMap["USD"],
                        Description = "US Gross Domestic Product"
                    });
                }
                
                // Retail Sales - Mi-mois
                if (date.Day >= 13 && date.Day <= 16 && date.DayOfWeek != DayOfWeek.Saturday && date.DayOfWeek != DayOfWeek.Sunday)
                {
                    events.Add(new EconomicEvent
                    {
                        Id = $"RETAIL_{date:yyyyMMdd}",
                        Name = "Retail Sales",
                        Currency = "USD",
                        Impact = NewsImpact.Medium,
                        Timestamp = date.AddHours(13).AddMinutes(30),
                        AffectedInstruments = _currencyInstrumentMap["USD"],
                        Description = "US Retail Sales Data"
                    });
                }
            }
            
            // Fusionner avec les événements existants (éviter doublons)
            foreach (var evt in events)
            {
                if (!_allEvents.Any(e => e.Id == evt.Id))
                {
                    _allEvents.Add(evt);
                }
            }
        }

        private NewsImpact ParseImpact(string impact)
        {
            return impact.ToLower() switch
            {
                "high" or "3" or "red" => NewsImpact.High,
                "medium" or "2" or "orange" => NewsImpact.Medium,
                "low" or "1" or "yellow" => NewsImpact.Low,
                _ => NewsImpact.None
            };
        }

        private List<string> GetAffectedInstruments(string currency)
        {
            if (_currencyInstrumentMap.ContainsKey(currency))
                return _currencyInstrumentMap[currency];
            return new List<string>();
        }
        #endregion

        #region Event Filtering
        /// <summary>
        /// Met à jour la liste des événements du jour
        /// </summary>
        private void UpdateTodayEvents()
        {
            lock (_lock)
            {
                _todayEvents = _allEvents
                    .Where(e => e.Timestamp.Date == DateTime.Today)
                    .OrderBy(e => e.Timestamp)
                    .ToList();
            }
        }

        /// <summary>
        /// Met à jour la liste des événements high-impact à venir
        /// </summary>
        private void UpdateUpcomingHighImpact()
        {
            lock (_lock)
            {
                _upcomingHighImpact = _allEvents
                    .Where(e => e.IsHighImpact && e.IsUpcoming)
                    .OrderBy(e => e.Timestamp)
                    .Take(10)
                    .ToList();
            }
        }

        /// <summary>
        /// Vérifie si le trading doit être bloqué pour un instrument
        /// </summary>
        public bool ShouldBlockTrading(string instrument)
        {
            if (!IsEnabled || !Settings.BlockTradingDuringNews)
                return false;
            
            return IsInNewsWindow(instrument, Settings.MinutesBeforeBlock, Settings.MinutesAfterBlock);
        }

        /// <summary>
        /// Vérifie si un instrument est dans une fenêtre de news
        /// </summary>
        public bool IsInNewsWindow(string instrument, int minutesBefore, int minutesAfter)
        {
            lock (_lock)
            {
                foreach (var evt in _allEvents.Where(e => e.IsHighImpact || (Settings.IncludeMediumImpact && e.IsMediumImpact)))
                {
                    // Vérifier si l'instrument est affecté
                    bool isAffected = evt.AffectedInstruments.Count == 0 || // Tous les instruments
                                     evt.AffectedInstruments.Any(i => 
                                         instrument.ToUpper().Contains(i.ToUpper()) ||
                                         i.ToUpper().Contains(instrument.ToUpper()));
                    
                    if (!isAffected) continue;
                    
                    // Vérifier si dans la fenêtre
                    if (evt.IsWithinWindow(minutesBefore, minutesAfter))
                        return true;
                }
            }
            
            return false;
        }

        /// <summary>
        /// Obtient le prochain événement high-impact pour un instrument
        /// </summary>
        public EconomicEvent GetNextHighImpactEvent(string instrument)
        {
            lock (_lock)
            {
                return _upcomingHighImpact
                    .Where(e => e.AffectedInstruments.Count == 0 ||
                               e.AffectedInstruments.Any(i => 
                                   instrument.ToUpper().Contains(i.ToUpper()) ||
                                   i.ToUpper().Contains(instrument.ToUpper())))
                    .FirstOrDefault();
            }
        }

        /// <summary>
        /// Obtient le temps restant avant le prochain événement high-impact
        /// </summary>
        public TimeSpan? GetTimeToNextHighImpact(string instrument)
        {
            var next = GetNextHighImpactEvent(instrument);
            if (next == null) return null;
            return next.Timestamp - DateTime.Now;
        }

        /// <summary>
        /// Obtient le statut actuel du filtre news
        /// </summary>
        public NewsFilterStatus GetFilterStatus(string instrument)
        {
            var status = new NewsFilterStatus
            {
                Instrument = instrument,
                Timestamp = DateTime.Now,
                IsBlocked = ShouldBlockTrading(instrument)
            };
            
            var nextEvent = GetNextHighImpactEvent(instrument);
            if (nextEvent != null)
            {
                status.NextEvent = nextEvent;
                status.TimeToNextEvent = nextEvent.Timestamp - DateTime.Now;
                status.IsInPreEventWindow = nextEvent.IsWithinWindow(Settings.MinutesBeforeBlock, 0);
                status.IsInPostEventWindow = nextEvent.IsWithinWindow(0, Settings.MinutesAfterBlock);
            }
            
            return status;
        }
        #endregion

        #region Update Loop
        /// <summary>
        /// Met à jour le module (appelé périodiquement)
        /// </summary>
        public void Update()
        {
            if (!IsEnabled || !IsInitialized) return;
            
            // Rafraîchir le calendrier si nécessaire
            if ((DateTime.Now - _lastUpdate).TotalMinutes >= Settings.RefreshIntervalMinutes)
            {
                RefreshCalendar();
            }
            
            // Vérifier les événements imminents
            CheckUpcomingEvents();
            
            // Vérifier les événements qui commencent/finissent
            CheckEventTransitions();
        }

        /// <summary>
        /// Vérifie les événements imminents et déclenche les alertes
        /// </summary>
        private void CheckUpcomingEvents()
        {
            lock (_lock)
            {
                foreach (var evt in _upcomingHighImpact)
                {
                    var timeToEvent = evt.Timestamp - DateTime.Now;
                    
                    // Alerte 15 minutes avant
                    if (timeToEvent.TotalMinutes > 14 && timeToEvent.TotalMinutes <= 15 && !evt.AlertSent15Min)
                    {
                        evt.AlertSent15Min = true;
                        OnHighImpactEventApproaching?.Invoke(this, evt);
                    }
                    
                    // Alerte 5 minutes avant
                    if (timeToEvent.TotalMinutes > 4 && timeToEvent.TotalMinutes <= 5 && !evt.AlertSent5Min)
                    {
                        evt.AlertSent5Min = true;
                        OnHighImpactEventApproaching?.Invoke(this, evt);
                    }
                    
                    // Alerte 1 minute avant
                    if (timeToEvent.TotalMinutes > 0 && timeToEvent.TotalMinutes <= 1 && !evt.AlertSent1Min)
                    {
                        evt.AlertSent1Min = true;
                        OnHighImpactEventApproaching?.Invoke(this, evt);
                    }
                }
            }
        }

        /// <summary>
        /// Vérifie les transitions d'événements (début/fin)
        /// </summary>
        private void CheckEventTransitions()
        {
            lock (_lock)
            {
                foreach (var evt in _todayEvents)
                {
                    var timeSinceEvent = DateTime.Now - evt.Timestamp;
                    
                    // Événement vient de commencer (dans la dernière minute)
                    if (timeSinceEvent.TotalMinutes >= 0 && timeSinceEvent.TotalMinutes < 1 && !evt.StartNotified)
                    {
                        evt.StartNotified = true;
                        OnEventStarted?.Invoke(this, evt);
                    }
                    
                    // Fenêtre post-événement terminée
                    if (timeSinceEvent.TotalMinutes >= Settings.MinutesAfterBlock && !evt.EndNotified)
                    {
                        evt.EndNotified = true;
                        OnEventEnded?.Invoke(this, evt);
                    }
                }
            }
        }
        #endregion

        #region Query Interface
        /// <summary>
        /// Obtient tous les événements du jour
        /// </summary>
        public List<EconomicEvent> GetTodayEvents()
        {
            lock (_lock)
            {
                return _todayEvents.ToList();
            }
        }

        /// <summary>
        /// Obtient les événements high-impact du jour
        /// </summary>
        public List<EconomicEvent> GetTodayHighImpactEvents()
        {
            lock (_lock)
            {
                return _todayEvents.Where(e => e.IsHighImpact).ToList();
            }
        }

        /// <summary>
        /// Obtient les événements à venir
        /// </summary>
        public List<EconomicEvent> GetUpcomingEvents(int count = 10)
        {
            lock (_lock)
            {
                return _allEvents
                    .Where(e => e.IsUpcoming)
                    .OrderBy(e => e.Timestamp)
                    .Take(count)
                    .ToList();
            }
        }

        /// <summary>
        /// Obtient les événements par devise
        /// </summary>
        public List<EconomicEvent> GetEventsByCurrency(string currency)
        {
            lock (_lock)
            {
                return _allEvents
                    .Where(e => e.Currency.Equals(currency, StringComparison.OrdinalIgnoreCase))
                    .OrderBy(e => e.Timestamp)
                    .ToList();
            }
        }

        /// <summary>
        /// Obtient les événements dans une plage de dates
        /// </summary>
        public List<EconomicEvent> GetEvents(DateTime from, DateTime to)
        {
            lock (_lock)
            {
                return _allEvents
                    .Where(e => e.Timestamp >= from && e.Timestamp <= to)
                    .OrderBy(e => e.Timestamp)
                    .ToList();
            }
        }

        /// <summary>
        /// Ajoute un événement personnalisé
        /// </summary>
        public void AddCustomEvent(EconomicEvent evt)
        {
            if (string.IsNullOrEmpty(evt.Id))
                evt.Id = Guid.NewGuid().ToString("N").Substring(0, 8);
            
            if (evt.AffectedInstruments == null || evt.AffectedInstruments.Count == 0)
                evt.AffectedInstruments = GetAffectedInstruments(evt.Currency);
            
            lock (_lock)
            {
                _allEvents.Add(evt);
            }
            
            UpdateTodayEvents();
            UpdateUpcomingHighImpact();
        }

        /// <summary>
        /// Supprime un événement
        /// </summary>
        public void RemoveEvent(string eventId)
        {
            lock (_lock)
            {
                _allEvents.RemoveAll(e => e.Id == eventId);
            }
            
            UpdateTodayEvents();
            UpdateUpcomingHighImpact();
        }
        #endregion

        #region Persistence
        private void SaveCachedEvents()
        {
            try
            {
                var sb = new StringBuilder();
                sb.AppendLine("DateTime,Currency,Name,Impact,Forecast,Previous,Description");
                
                foreach (var evt in _allEvents.Where(e => e.Timestamp >= DateTime.Now.AddDays(-1)))
                {
                    sb.AppendLine($"{evt.Timestamp:yyyy-MM-dd HH:mm:ss},{evt.Currency},{evt.Name},{evt.Impact},{evt.Forecast},{evt.Previous},\"{evt.Description}\"");
                }
                
                File.WriteAllText(_cacheFile, sb.ToString());
            }
            catch { }
        }

        private void LoadCachedEvents()
        {
            try
            {
                if (!File.Exists(_cacheFile)) return;
                
                var fileInfo = new FileInfo(_cacheFile);
                if ((DateTime.Now - fileInfo.LastWriteTime).TotalHours > 24)
                    return; // Cache trop vieux
                
                LoadFromLocalFile(_cacheFile);
                _lastCacheRefresh = fileInfo.LastWriteTime;
            }
            catch { }
        }
        #endregion
    }

    #region Supporting Classes
    /// <summary>
    /// Paramètres du module News
    /// </summary>
    public class NewsSettings
    {
        public bool BlockTradingDuringNews { get; set; } = true;
        public int MinutesBeforeBlock { get; set; } = 15;
        public int MinutesAfterBlock { get; set; } = 5;
        public bool IncludeMediumImpact { get; set; } = false;
        public int RefreshIntervalMinutes { get; set; } = 60;
        public bool AutoRefreshOnStart { get; set; } = true;
        public bool UseLocalCalendarFile { get; set; } = false;
        public string LocalCalendarPath { get; set; } = "";
        public bool UseBuiltInCalendar { get; set; } = true;
        public bool EnableAlerts { get; set; } = true;
    }

    /// <summary>
    /// Niveau d'impact d'une news
    /// </summary>
    public enum NewsImpact
    {
        None = 0,
        Low = 1,
        Medium = 2,
        High = 3
    }

    /// <summary>
    /// Statut du filtre news
    /// </summary>
    public class NewsFilterStatus
    {
        public string Instrument { get; set; }
        public DateTime Timestamp { get; set; }
        public bool IsBlocked { get; set; }
        public EconomicEvent NextEvent { get; set; }
        public TimeSpan? TimeToNextEvent { get; set; }
        public bool IsInPreEventWindow { get; set; }
        public bool IsInPostEventWindow { get; set; }

        public string GetStatusMessage()
        {
            if (!IsBlocked && NextEvent == null)
                return "No upcoming high-impact news";
            
            if (IsBlocked && IsInPreEventWindow)
                return $"BLOCKED: {NextEvent?.Name} in {TimeToNextEvent?.TotalMinutes:F0} min";
            
            if (IsBlocked && IsInPostEventWindow)
                return $"BLOCKED: Post-{NextEvent?.Name} window";
            
            if (NextEvent != null)
                return $"Next: {NextEvent.Name} in {TimeToNextEvent?.TotalMinutes:F0} min";
            
            return "Unknown status";
        }
    }
    #endregion
}
