#region Using declarations
using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
#endregion

//===============================================================================
// SOPHON RISK MODULE v1.0
// Gestion Intelligente du Risque Dynamique
//
// Ce module implémente:
//   - Position sizing basé sur l'ATR (volatilité)
//   - Calcul et validation du risque par trade
//   - Gestion des corrélations entre positions
//   - Limites par compte (daily loss, drawdown, trades max)
//   - Filtre de news économiques
//   - Ajustement dynamique selon régime de marché
//
// Copyright (c) 2026 Algosphere Quant - Emmanuel
//===============================================================================

namespace NinjaTrader.NinjaScript.AddOns.Sophon
{
    /// <summary>
    /// Module de gestion du risque - Filtre et valide tous les trades avant exécution
    /// </summary>
    public class SophonRisk : ISophonModule, IRiskManager
    {
        #region Properties
        public string ModuleName => "SophonRisk";
        public bool IsInitialized { get; private set; }
        public bool IsEnabled { get; set; }
        
        public RiskSettings Settings { get; set; }
        
        // Comptes gérés
        private Dictionary<string, AccountRiskState> _accountStates;
        
        // Corrélations entre instruments
        private Dictionary<string, Dictionary<string, double>> _correlationMatrix;
        private DateTime _lastCorrelationUpdate;
        
        // Historique des prix pour calcul de corrélation
        private Dictionary<string, CircularBuffer<double>> _priceHistory;
        
        // News filter
        private List<EconomicEvent> _upcomingEvents;
        private DateTime _lastNewsUpdate;
        
        // Cache
        private CalculationCache<string, RiskParameters> _riskCache;
        
        // Events
        public event EventHandler<RiskValidationResult> OnSignalValidated;
        public event EventHandler<RiskValidationResult> OnSignalRejected;
        public event EventHandler<string> OnRiskLimitReached;
        public event EventHandler<AccountRiskState> OnAccountStateChanged;
        
        // Lock for thread safety
        private readonly object _stateLock = new object();
        #endregion

        #region Initialization
        public SophonRisk()
        {
            Settings = new RiskSettings();
            _accountStates = new Dictionary<string, AccountRiskState>();
            _correlationMatrix = new Dictionary<string, Dictionary<string, double>>();
            _priceHistory = new Dictionary<string, CircularBuffer<double>>();
            _upcomingEvents = new List<EconomicEvent>();
            _riskCache = new CalculationCache<string, RiskParameters>(TimeSpan.FromSeconds(10));
            IsEnabled = true;
        }

        public void Initialize()
        {
            if (IsInitialized) return;
            
            _accountStates.Clear();
            _correlationMatrix.Clear();
            _priceHistory.Clear();
            _upcomingEvents.Clear();
            _riskCache.Clear();
            _lastCorrelationUpdate = DateTime.MinValue;
            _lastNewsUpdate = DateTime.MinValue;
            
            IsInitialized = true;
        }

        public void Shutdown()
        {
            _accountStates.Clear();
            _correlationMatrix.Clear();
            _priceHistory.Clear();
            _riskCache.Clear();
            IsInitialized = false;
        }

        public void Reset()
        {
            Shutdown();
            Initialize();
        }

        public void OnBarUpdate(int barsInProgress) { }
        #endregion

        #region Account Management
        /// <summary>
        /// Enregistre un compte pour la gestion du risque
        /// </summary>
        public void RegisterAccount(AccountConfig config)
        {
            lock (_stateLock)
            {
                if (!_accountStates.ContainsKey(config.AccountId))
                {
                    _accountStates[config.AccountId] = new AccountRiskState(config);
                }
                else
                {
                    _accountStates[config.AccountId].Config = config;
                }
            }
        }

        /// <summary>
        /// Met à jour le solde d'un compte
        /// </summary>
        public void UpdateAccountBalance(string accountId, double newBalance)
        {
            lock (_stateLock)
            {
                if (_accountStates.ContainsKey(accountId))
                {
                    var state = _accountStates[accountId];
                    state.CurrentBalance = newBalance;
                    state.UpdateDrawdown();
                    OnAccountStateChanged?.Invoke(this, state);
                }
            }
        }

        /// <summary>
        /// Enregistre un trade ouvert pour un compte
        /// </summary>
        public void RecordTradeOpened(string accountId, TradeSetup trade)
        {
            lock (_stateLock)
            {
                if (_accountStates.ContainsKey(accountId))
                {
                    var state = _accountStates[accountId];
                    state.OpenTrades.Add(trade);
                    state.TradesToday++;
                    state.TotalRiskExposed += trade.Risk.RiskAmount;
                    OnAccountStateChanged?.Invoke(this, state);
                }
            }
        }

        /// <summary>
        /// Enregistre un trade fermé pour un compte
        /// </summary>
        public void RecordTradeClosed(string accountId, TradeSetup trade, double pnl)
        {
            lock (_stateLock)
            {
                if (_accountStates.ContainsKey(accountId))
                {
                    var state = _accountStates[accountId];
                    state.OpenTrades.Remove(trade);
                    state.DailyPnL += pnl;
                    state.TotalRiskExposed -= trade.Risk.RiskAmount;
                    
                    if (pnl > 0)
                        state.WinsToday++;
                    else if (pnl < 0)
                        state.LossesToday++;
                    
                    state.UpdateDrawdown();
                    OnAccountStateChanged?.Invoke(this, state);
                    
                    // Vérifier les limites
                    CheckAccountLimits(state);
                }
            }
        }

        /// <summary>
        /// Réinitialise les compteurs journaliers (à appeler chaque jour)
        /// </summary>
        public void ResetDailyCounters()
        {
            lock (_stateLock)
            {
                foreach (var state in _accountStates.Values)
                {
                    state.ResetDaily();
                }
            }
        }

        /// <summary>
        /// Vérifie les limites de risque d'un compte
        /// </summary>
        private void CheckAccountLimits(AccountRiskState state)
        {
            var config = state.Config;
            
            // Vérifier la perte journalière max
            if (state.DailyPnL < 0 && Math.Abs(state.DailyPnL) >= config.MaxDailyLoss * config.InitialBalance)
            {
                state.IsDailyLimitReached = true;
                OnRiskLimitReached?.Invoke(this, $"Daily loss limit reached for {config.AccountId}");
            }
            
            // Vérifier le drawdown max
            if (state.CurrentDrawdown >= config.MaxDrawdown)
            {
                state.IsDrawdownLimitReached = true;
                OnRiskLimitReached?.Invoke(this, $"Max drawdown reached for {config.AccountId}");
            }
            
            // Vérifier le nombre de trades max
            if (state.TradesToday >= config.MaxTradesPerDay)
            {
                state.IsTradesLimitReached = true;
                OnRiskLimitReached?.Invoke(this, $"Max trades per day reached for {config.AccountId}");
            }
        }
        #endregion

        #region Signal Validation
        /// <summary>
        /// Valide un signal avant exécution
        /// </summary>
        public bool ValidateSignal(SMCSignal signal, AccountConfig account)
        {
            if (!IsEnabled) return true;
            
            var result = new RiskValidationResult
            {
                Signal = signal,
                AccountId = account.AccountId,
                Timestamp = DateTime.Now
            };

            lock (_stateLock)
            {
                if (!_accountStates.ContainsKey(account.AccountId))
                {
                    RegisterAccount(account);
                }
                
                var state = _accountStates[account.AccountId];
                
                // 1. Vérifier si le compte peut encore trader
                if (!CanOpenTrade(account))
                {
                    result.IsValid = false;
                    result.RejectionReasons.Add("Account trading limits reached");
                    OnSignalRejected?.Invoke(this, result);
                    return false;
                }
                
                // 2. Vérifier l'instrument autorisé
                if (account.AllowedInstruments.Count > 0 && 
                    !account.AllowedInstruments.Contains(signal.Instrument))
                {
                    result.IsValid = false;
                    result.RejectionReasons.Add($"Instrument {signal.Instrument} not allowed for this account");
                    OnSignalRejected?.Invoke(this, result);
                    return false;
                }
                
                // 3. Vérifier la session autorisée
                if (account.AllowedSessions.Count > 0 && 
                    !account.AllowedSessions.Contains(signal.Session) &&
                    !account.AllowedSessions.Contains(TradingSession.All))
                {
                    result.IsValid = false;
                    result.RejectionReasons.Add($"Session {signal.Session} not allowed for this account");
                    OnSignalRejected?.Invoke(this, result);
                    return false;
                }
                
                // 4. Vérifier les corrélations avec les positions existantes
                if (!IsCorrelationSafe(signal.Instrument, state.OpenTrades))
                {
                    result.IsValid = false;
                    result.RejectionReasons.Add("High correlation with existing positions");
                    OnSignalRejected?.Invoke(this, result);
                    return false;
                }
                
                // 5. Vérifier le filtre news
                if (Settings.UseNewsFilter && IsHighImpactNewsImminent(signal.Instrument))
                {
                    result.IsValid = false;
                    result.RejectionReasons.Add("High impact news imminent");
                    OnSignalRejected?.Invoke(this, result);
                    return false;
                }
                
                // 6. Vérifier le R:R minimum
                if (signal.RiskRewardRatio < Settings.MinRiskReward)
                {
                    result.IsValid = false;
                    result.RejectionReasons.Add($"R:R {signal.RiskRewardRatio:F2} below minimum {Settings.MinRiskReward:F2}");
                    OnSignalRejected?.Invoke(this, result);
                    return false;
                }
                
                // 7. Vérifier la force du signal minimum
                if ((int)signal.Strength < (int)Settings.MinSignalStrength)
                {
                    result.IsValid = false;
                    result.RejectionReasons.Add($"Signal strength {signal.Strength} below minimum {Settings.MinSignalStrength}");
                    OnSignalRejected?.Invoke(this, result);
                    return false;
                }
                
                // 8. Vérifier le nombre max de trades sur le même instrument
                int tradesOnInstrument = state.OpenTrades.Count(t => t.Signal?.Instrument == signal.Instrument);
                if (tradesOnInstrument >= Settings.MaxTradesPerInstrument)
                {
                    result.IsValid = false;
                    result.RejectionReasons.Add($"Max trades on {signal.Instrument} reached");
                    OnSignalRejected?.Invoke(this, result);
                    return false;
                }
            }
            
            result.IsValid = true;
            OnSignalValidated?.Invoke(this, result);
            return true;
        }

        /// <summary>
        /// Vérifie si un compte peut ouvrir un nouveau trade
        /// </summary>
        public bool CanOpenTrade(AccountConfig account)
        {
            lock (_stateLock)
            {
                if (!_accountStates.ContainsKey(account.AccountId))
                    return true;
                
                var state = _accountStates[account.AccountId];
                
                // Vérifier toutes les limites
                if (state.IsDailyLimitReached) return false;
                if (state.IsDrawdownLimitReached) return false;
                if (state.IsTradesLimitReached) return false;
                if (!state.Config.IsActive) return false;
                
                // Vérifier le nombre de trades ouverts
                if (state.OpenTrades.Count >= account.MaxOpenTrades)
                    return false;
                
                // Vérifier le risque total exposé
                double maxRiskExposed = account.CurrentBalance * Settings.MaxTotalRiskExposed;
                if (state.TotalRiskExposed >= maxRiskExposed)
                    return false;
                
                return true;
            }
        }
        #endregion

        #region Position Sizing
        /// <summary>
        /// Calcule les paramètres de risque pour un signal
        /// </summary>
        public RiskParameters CalculateRisk(SMCSignal signal, AccountConfig account, double atr)
        {
            string cacheKey = $"{account.AccountId}_{signal.Id}_{atr:F4}";
            
            return _riskCache.GetOrCompute(cacheKey, () =>
            {
                var riskParams = new RiskParameters();
                
                // Calculer le risque en pourcentage selon le profil
                double riskPercent = GetRiskPercentForProfile(account.RiskProfile);
                if (account.RiskProfile == RiskProfile.Custom)
                    riskPercent = account.MaxRiskPerTrade;
                
                // Ajuster selon la force du signal
                riskPercent = AdjustRiskBySignalStrength(riskPercent, signal.Strength);
                
                // Ajuster selon les conditions de marché
                riskPercent = AdjustRiskByMarketConditions(riskPercent, signal, atr);
                
                riskParams.RiskPercent = riskPercent;
                riskParams.RiskAmount = account.CurrentBalance * riskPercent;
                
                // Calculer la distance du stop-loss
                if (signal.StopLoss > 0 && signal.EntryPrice > 0)
                {
                    riskParams.StopLossPrice = signal.StopLoss;
                    riskParams.StopLossDistance = Math.Abs(signal.EntryPrice - signal.StopLoss);
                }
                else
                {
                    // Stop-loss basé sur l'ATR
                    riskParams.StopLossDistance = atr * Settings.DefaultATRMultiplier;
                    riskParams.StopLossPrice = signal.IsLong 
                        ? signal.EntryPrice - riskParams.StopLossDistance
                        : signal.EntryPrice + riskParams.StopLossDistance;
                }
                
                // Calculer la taille de position
                double pointValue = GetPointValue(signal.Instrument);
                riskParams.PositionSize = CalculatePositionSize(
                    riskParams.RiskAmount, 
                    riskParams.StopLossDistance, 
                    pointValue
                );
                
                // Appliquer les limites min/max
                riskParams.PositionSize = Math.Max(Settings.MinPositionSize, riskParams.PositionSize);
                riskParams.PositionSize = Math.Min(Settings.MaxPositionSize, riskParams.PositionSize);
                
                // Calculer les take-profits
                riskParams.TakeProfit1Price = signal.TakeProfit1 > 0 ? signal.TakeProfit1 
                    : CalculateTakeProfit(signal.EntryPrice, riskParams.StopLossDistance, Settings.TP1RRRatio, signal.IsLong);
                riskParams.TakeProfit2Price = signal.TakeProfit2 > 0 ? signal.TakeProfit2 
                    : CalculateTakeProfit(signal.EntryPrice, riskParams.StopLossDistance, Settings.TP2RRRatio, signal.IsLong);
                riskParams.TakeProfit3Price = signal.TakeProfit3 > 0 ? signal.TakeProfit3 
                    : CalculateTakeProfit(signal.EntryPrice, riskParams.StopLossDistance, Settings.TP3RRRatio, signal.IsLong);
                
                // Calculer le R:R
                riskParams.RiskRewardRatio = Math.Abs(riskParams.TakeProfit1Price - signal.EntryPrice) 
                                            / riskParams.StopLossDistance;
                
                riskParams.ATRValue = atr;
                riskParams.ATRMultiplier = Settings.DefaultATRMultiplier;
                
                return riskParams;
            });
        }

        /// <summary>
        /// Calcule la taille de position optimale
        /// </summary>
        private int CalculatePositionSize(double riskAmount, double stopDistance, double pointValue)
        {
            if (stopDistance <= 0 || pointValue <= 0)
                return Settings.MinPositionSize;
            
            double rawSize = riskAmount / (stopDistance * pointValue);
            return (int)Math.Floor(rawSize);
        }

        /// <summary>
        /// Calcule le take-profit basé sur le R:R
        /// </summary>
        private double CalculateTakeProfit(double entry, double stopDistance, double rrRatio, bool isLong)
        {
            double tpDistance = stopDistance * rrRatio;
            return isLong ? entry + tpDistance : entry - tpDistance;
        }

        /// <summary>
        /// Obtient le pourcentage de risque selon le profil
        /// </summary>
        private double GetRiskPercentForProfile(RiskProfile profile)
        {
            return profile switch
            {
                RiskProfile.UltraConservative => 0.0025,
                RiskProfile.Conservative => 0.005,
                RiskProfile.Normal => 0.01,
                RiskProfile.Aggressive => 0.015,
                RiskProfile.VeryAggressive => 0.02,
                _ => 0.01
            };
        }

        /// <summary>
        /// Ajuste le risque selon la force du signal
        /// </summary>
        private double AdjustRiskBySignalStrength(double baseRisk, SignalStrength strength)
        {
            if (!Settings.AdjustRiskByStrength)
                return baseRisk;
            
            double multiplier = strength switch
            {
                SignalStrength.VeryStrong => 1.2,
                SignalStrength.Strong => 1.1,
                SignalStrength.Medium => 1.0,
                SignalStrength.Weak => 0.75,
                SignalStrength.VeryWeak => 0.5,
                _ => 1.0
            };
            
            return baseRisk * multiplier;
        }

        /// <summary>
        /// Ajuste le risque selon les conditions de marché
        /// </summary>
        private double AdjustRiskByMarketConditions(double baseRisk, SMCSignal signal, double atr)
        {
            if (!Settings.AdjustRiskByVolatility)
                return baseRisk;
            
            // Réduire le risque si haute volatilité
            // On compare l'ATR actuel à une baseline (approximation)
            // Dans un vrai système, on comparerait à l'ATR moyen historique
            double volatilityRatio = 1.0;
            
            // Réduire le risque pendant l'overlap (haute volatilité)
            if (signal.Session == TradingSession.LondonNYOverlap)
                volatilityRatio *= 0.9;
            
            // Réduire le risque si le prix est en zone d'équilibre (moins de conviction)
            if (signal.PricePosition == PricePosition.Equilibrium)
                volatilityRatio *= 0.85;
            
            // Augmenter légèrement si aligné avec HTF
            if (signal.ConfluenceFactors.Contains("HTF_Aligned"))
                volatilityRatio *= 1.1;
            
            return Math.Min(baseRisk * volatilityRatio, Settings.MaxRiskPercent);
        }

        /// <summary>
        /// Obtient la valeur d'un point pour un instrument
        /// </summary>
        private double GetPointValue(string instrument)
        {
            // Valeurs standard pour les instruments courants
            // Dans un vrai système, on récupérerait cela depuis NinjaTrader
            return instrument.ToUpper() switch
            {
                "MES" => 5.0,      // Micro E-mini S&P 500
                "MNQ" => 2.0,      // Micro E-mini Nasdaq
                "MGC" => 10.0,     // Micro Gold
                "MCL" => 10.0,     // Micro Crude Oil
                "M2K" => 5.0,      // Micro Russell 2000
                "MYM" => 0.5,      // Micro Dow
                "ES" => 50.0,      // E-mini S&P 500
                "NQ" => 20.0,      // E-mini Nasdaq
                "GC" => 100.0,     // Gold
                "CL" => 1000.0,    // Crude Oil
                _ => 1.0
            };
        }
        #endregion

        #region Correlation Management
        /// <summary>
        /// Met à jour les prix pour le calcul de corrélation
        /// </summary>
        public void UpdatePriceForCorrelation(string instrument, double price)
        {
            if (!_priceHistory.ContainsKey(instrument))
            {
                _priceHistory[instrument] = new CircularBuffer<double>(Settings.CorrelationPeriod);
            }
            _priceHistory[instrument].Add(price);
            
            // Recalculer les corrélations périodiquement
            if ((DateTime.Now - _lastCorrelationUpdate).TotalMinutes >= Settings.CorrelationUpdateMinutes)
            {
                UpdateCorrelationMatrix();
                _lastCorrelationUpdate = DateTime.Now;
            }
        }

        /// <summary>
        /// Vérifie si un nouveau trade respecte les contraintes de corrélation
        /// </summary>
        public bool IsCorrelationSafe(string instrument, List<TradeSetup> openTrades)
        {
            if (!Settings.UseCorrelationFilter || openTrades.Count == 0)
                return true;
            
            foreach (var trade in openTrades)
            {
                if (trade.Signal == null) continue;
                
                double correlation = GetCorrelation(instrument, trade.Signal.Instrument);
                
                // Si fortement corrélé dans la même direction, attention
                if (Math.Abs(correlation) >= Settings.MaxCorrelation)
                {
                    // Même direction sur actifs corrélés = trop de risque
                    bool sameDirection = (trade.Signal.IsLong && correlation > 0) || 
                                        (trade.Signal.IsShort && correlation < 0);
                    if (sameDirection)
                        return false;
                }
            }
            
            return true;
        }

        /// <summary>
        /// Obtient la corrélation entre deux instruments
        /// </summary>
        public double GetCorrelation(string instrument1, string instrument2)
        {
            if (instrument1 == instrument2) return 1.0;
            
            string key1 = $"{instrument1}_{instrument2}";
            string key2 = $"{instrument2}_{instrument1}";
            
            if (_correlationMatrix.ContainsKey(instrument1) && 
                _correlationMatrix[instrument1].ContainsKey(instrument2))
            {
                return _correlationMatrix[instrument1][instrument2];
            }
            
            // Corrélations par défaut si pas de données
            return GetDefaultCorrelation(instrument1, instrument2);
        }

        /// <summary>
        /// Met à jour la matrice de corrélation
        /// </summary>
        private void UpdateCorrelationMatrix()
        {
            var instruments = _priceHistory.Keys.ToList();
            
            foreach (var inst1 in instruments)
            {
                if (!_correlationMatrix.ContainsKey(inst1))
                    _correlationMatrix[inst1] = new Dictionary<string, double>();
                
                foreach (var inst2 in instruments)
                {
                    if (inst1 == inst2) continue;
                    
                    var prices1 = _priceHistory[inst1].ToArray();
                    var prices2 = _priceHistory[inst2].ToArray();
                    
                    if (prices1.Length >= Settings.MinCorrelationSamples && 
                        prices2.Length >= Settings.MinCorrelationSamples)
                    {
                        // Calculer les rendements
                        var returns1 = CalculateReturns(prices1);
                        var returns2 = CalculateReturns(prices2);
                        
                        // Prendre la même longueur
                        int minLen = Math.Min(returns1.Length, returns2.Length);
                        returns1 = returns1.TakeLast(minLen).ToArray();
                        returns2 = returns2.TakeLast(minLen).ToArray();
                        
                        double corr = SophonHelpers.CalculateCorrelation(returns1, returns2);
                        _correlationMatrix[inst1][inst2] = corr;
                    }
                }
            }
        }

        /// <summary>
        /// Calcule les rendements à partir des prix
        /// </summary>
        private double[] CalculateReturns(double[] prices)
        {
            if (prices.Length < 2) return new double[0];
            
            double[] returns = new double[prices.Length - 1];
            for (int i = 1; i < prices.Length; i++)
            {
                returns[i - 1] = (prices[i] - prices[i - 1]) / prices[i - 1];
            }
            return returns;
        }

        /// <summary>
        /// Corrélations par défaut connues
        /// </summary>
        private double GetDefaultCorrelation(string inst1, string inst2)
        {
            // Normaliser
            inst1 = inst1.ToUpper();
            inst2 = inst2.ToUpper();
            
            // Indices US - haute corrélation entre eux
            var usIndices = new HashSet<string> { "MES", "ES", "MNQ", "NQ", "M2K", "MYM" };
            if (usIndices.Contains(inst1) && usIndices.Contains(inst2))
                return 0.85;
            
            // Forex EUR vs GBP - corrélés
            if ((inst1.Contains("EUR") && inst2.Contains("GBP")) ||
                (inst1.Contains("GBP") && inst2.Contains("EUR")))
                return 0.75;
            
            // Or vs USD - inverse
            if ((inst1.Contains("GC") || inst1.Contains("GOLD")) && 
                (inst2.Contains("USD") || inst2.Contains("DX")))
                return -0.5;
            
            // Pétrole vs indices - modérément corrélé
            if ((inst1.Contains("CL") || inst1.Contains("MCL")) && usIndices.Contains(inst2))
                return 0.4;
            
            // Par défaut, faible corrélation
            return 0.2;
        }
        #endregion

        #region News Filter
        /// <summary>
        /// Met à jour la liste des événements économiques
        /// </summary>
        public void UpdateEconomicEvents(List<EconomicEvent> events)
        {
            _upcomingEvents = events
                .Where(e => e.Timestamp > DateTime.Now)
                .OrderBy(e => e.Timestamp)
                .ToList();
            _lastNewsUpdate = DateTime.Now;
        }

        /// <summary>
        /// Vérifie si une news à fort impact est imminente pour un instrument
        /// </summary>
        public bool IsHighImpactNewsImminent(string instrument)
        {
            if (!Settings.UseNewsFilter || _upcomingEvents.Count == 0)
                return false;
            
            foreach (var evt in _upcomingEvents.Where(e => e.IsHighImpact))
            {
                // Vérifier si l'événement affecte l'instrument
                bool affects = evt.AffectedInstruments.Count == 0 || // Tous les instruments
                               evt.AffectedInstruments.Any(i => 
                                   instrument.ToUpper().Contains(i.ToUpper()) ||
                                   i.ToUpper().Contains(instrument.ToUpper()));
                
                if (!affects) continue;
                
                // Vérifier si dans la fenêtre d'avertissement
                if (evt.IsWithinWindow(Settings.NewsFilterMinutesBefore, Settings.NewsFilterMinutesAfter))
                    return true;
            }
            
            return false;
        }

        /// <summary>
        /// Obtient les prochains événements à fort impact
        /// </summary>
        public List<EconomicEvent> GetUpcomingHighImpactEvents(int count = 5)
        {
            return _upcomingEvents
                .Where(e => e.IsHighImpact && e.IsUpcoming)
                .Take(count)
                .ToList();
        }
        #endregion

        #region Public Interface
        /// <summary>
        /// Obtient le drawdown actuel d'un compte
        /// </summary>
        public double GetCurrentDrawdown(string accountId)
        {
            lock (_stateLock)
            {
                return _accountStates.ContainsKey(accountId) 
                    ? _accountStates[accountId].CurrentDrawdown 
                    : 0;
            }
        }

        /// <summary>
        /// Obtient le P/L journalier d'un compte
        /// </summary>
        public double GetDailyPnL(string accountId)
        {
            lock (_stateLock)
            {
                return _accountStates.ContainsKey(accountId) 
                    ? _accountStates[accountId].DailyPnL 
                    : 0;
            }
        }

        /// <summary>
        /// Obtient le nombre de trades ouverts d'un compte
        /// </summary>
        public int GetOpenTradesCount(string accountId)
        {
            lock (_stateLock)
            {
                return _accountStates.ContainsKey(accountId) 
                    ? _accountStates[accountId].OpenTrades.Count 
                    : 0;
            }
        }

        /// <summary>
        /// Obtient l'état complet d'un compte
        /// </summary>
        public AccountRiskState GetAccountState(string accountId)
        {
            lock (_stateLock)
            {
                return _accountStates.ContainsKey(accountId) 
                    ? _accountStates[accountId] 
                    : null;
            }
        }

        /// <summary>
        /// Obtient un résumé des risques de tous les comptes
        /// </summary>
        public Dictionary<string, AccountRiskSummary> GetAllAccountsSummary()
        {
            lock (_stateLock)
            {
                var summary = new Dictionary<string, AccountRiskSummary>();
                
                foreach (var kvp in _accountStates)
                {
                    var state = kvp.Value;
                    summary[kvp.Key] = new AccountRiskSummary
                    {
                        AccountId = kvp.Key,
                        CurrentBalance = state.CurrentBalance,
                        DailyPnL = state.DailyPnL,
                        CurrentDrawdown = state.CurrentDrawdown,
                        OpenTradesCount = state.OpenTrades.Count,
                        TotalRiskExposed = state.TotalRiskExposed,
                        WinRate = state.TradesToday > 0 
                            ? (double)state.WinsToday / state.TradesToday 
                            : 0,
                        CanTrade = CanOpenTrade(state.Config)
                    };
                }
                
                return summary;
            }
        }
        #endregion
    }

    #region Supporting Classes
    /// <summary>
    /// Paramètres de configuration du module de risque
    /// </summary>
    public class RiskSettings
    {
        // Position Sizing
        public double DefaultATRMultiplier { get; set; } = 1.5;
        public int MinPositionSize { get; set; } = 1;
        public int MaxPositionSize { get; set; } = 100;
        public double MaxRiskPercent { get; set; } = 0.02;
        public double MaxTotalRiskExposed { get; set; } = 0.06;
        
        // Take Profits
        public double TP1RRRatio { get; set; } = 1.5;
        public double TP2RRRatio { get; set; } = 3.0;
        public double TP3RRRatio { get; set; } = 5.0;
        
        // Validation
        public double MinRiskReward { get; set; } = 1.5;
        public SignalStrength MinSignalStrength { get; set; } = SignalStrength.Weak;
        public int MaxTradesPerInstrument { get; set; } = 2;
        
        // Adjustments
        public bool AdjustRiskByStrength { get; set; } = true;
        public bool AdjustRiskByVolatility { get; set; } = true;
        
        // Correlation
        public bool UseCorrelationFilter { get; set; } = true;
        public double MaxCorrelation { get; set; } = 0.7;
        public int CorrelationPeriod { get; set; } = 100;
        public int MinCorrelationSamples { get; set; } = 30;
        public int CorrelationUpdateMinutes { get; set; } = 15;
        
        // News
        public bool UseNewsFilter { get; set; } = true;
        public int NewsFilterMinutesBefore { get; set; } = 15;
        public int NewsFilterMinutesAfter { get; set; } = 5;
    }

    /// <summary>
    /// État de risque d'un compte
    /// </summary>
    public class AccountRiskState
    {
        public AccountConfig Config { get; set; }
        public double CurrentBalance { get; set; }
        public double PeakBalance { get; set; }
        public double CurrentDrawdown { get; set; }
        public double DailyPnL { get; set; }
        public double TotalRiskExposed { get; set; }
        public int TradesToday { get; set; }
        public int WinsToday { get; set; }
        public int LossesToday { get; set; }
        public List<TradeSetup> OpenTrades { get; set; }
        public bool IsDailyLimitReached { get; set; }
        public bool IsDrawdownLimitReached { get; set; }
        public bool IsTradesLimitReached { get; set; }
        public DateTime LastUpdate { get; set; }

        public AccountRiskState(AccountConfig config)
        {
            Config = config;
            CurrentBalance = config.CurrentBalance;
            PeakBalance = config.CurrentBalance;
            OpenTrades = new List<TradeSetup>();
            LastUpdate = DateTime.Now;
        }

        public void UpdateDrawdown()
        {
            if (CurrentBalance > PeakBalance)
                PeakBalance = CurrentBalance;
            
            CurrentDrawdown = PeakBalance > 0 
                ? (PeakBalance - CurrentBalance) / PeakBalance 
                : 0;
            
            LastUpdate = DateTime.Now;
        }

        public void ResetDaily()
        {
            DailyPnL = 0;
            TradesToday = 0;
            WinsToday = 0;
            LossesToday = 0;
            IsDailyLimitReached = false;
            IsTradesLimitReached = false;
            // Ne pas reset IsDrawdownLimitReached
        }
    }

    /// <summary>
    /// Résultat de validation d'un signal
    /// </summary>
    public class RiskValidationResult
    {
        public SMCSignal Signal { get; set; }
        public string AccountId { get; set; }
        public bool IsValid { get; set; }
        public List<string> RejectionReasons { get; set; }
        public RiskParameters SuggestedRisk { get; set; }
        public DateTime Timestamp { get; set; }

        public RiskValidationResult()
        {
            RejectionReasons = new List<string>();
        }

        public override string ToString()
        {
            if (IsValid)
                return $"VALID: {Signal?.Instrument} {Signal?.Setup}";
            return $"REJECTED: {Signal?.Instrument} - {string.Join(", ", RejectionReasons)}";
        }
    }

    /// <summary>
    /// Résumé de risque d'un compte
    /// </summary>
    public class AccountRiskSummary
    {
        public string AccountId { get; set; }
        public double CurrentBalance { get; set; }
        public double DailyPnL { get; set; }
        public double CurrentDrawdown { get; set; }
        public int OpenTradesCount { get; set; }
        public double TotalRiskExposed { get; set; }
        public double WinRate { get; set; }
        public bool CanTrade { get; set; }

        public override string ToString() =>
            $"{AccountId}: {CurrentBalance:C} | PnL: {DailyPnL:+0.00;-0.00} | DD: {CurrentDrawdown:P1} | Open: {OpenTradesCount}";
    }
    #endregion
}
