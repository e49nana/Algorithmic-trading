#region Using declarations
using System;
using System.Collections.Generic;
using System.Linq;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
#endregion

//===============================================================================
// SOPHON SMC MODULE v1.0
// Moteur d'Analyse Smart Money Concepts (SMC) & ICT
// Copyright (c) 2026 Algosphere Quant - Emmanuel
//===============================================================================

namespace NinjaTrader.NinjaScript.AddOns.Sophon
{
    /// <summary>
    /// Moteur d'analyse SMC/ICT - Cœur analytique du système Sophon
    /// </summary>
    public class SophonSMC : ISophonModule, ISignalProvider
    {
        #region Properties
        public string ModuleName => "SophonSMC";
        public bool IsInitialized { get; private set; }
        public bool IsEnabled { get; set; }
        public SMCSettings Settings { get; set; }
        
        private Dictionary<string, InstrumentSMCData> _instrumentData;
        private List<SMCSignal> _activeSignals;
        private readonly object _signalLock = new object();
        private CalculationCache<string, MarketContext> _contextCache;

        public event EventHandler<SMCSignal> OnNewSignal;
        public event EventHandler<SMCSignal> OnSignalInvalidated;
        public event EventHandler<MarketStructureShift> OnStructureShift;
        public event EventHandler<OrderBlock> OnOrderBlockCreated;
        public event EventHandler<FairValueGap> OnFVGCreated;
        public event EventHandler<LiquidityZone> OnLiquidityTaken;
        #endregion

        #region Initialization
        public SophonSMC()
        {
            Settings = new SMCSettings();
            _instrumentData = new Dictionary<string, InstrumentSMCData>();
            _activeSignals = new List<SMCSignal>();
            _contextCache = new CalculationCache<string, MarketContext>(TimeSpan.FromSeconds(5));
            IsEnabled = true;
        }

        public void Initialize()
        {
            if (IsInitialized) return;
            _instrumentData.Clear();
            _activeSignals.Clear();
            _contextCache.Clear();
            IsInitialized = true;
        }

        public void Shutdown()
        {
            _instrumentData.Clear();
            _activeSignals.Clear();
            _contextCache.Clear();
            IsInitialized = false;
        }

        public void Reset() { Shutdown(); Initialize(); }

        public void RegisterInstrument(string instrument)
        {
            if (!_instrumentData.ContainsKey(instrument))
                _instrumentData[instrument] = new InstrumentSMCData(instrument, Settings);
        }

        public void UnregisterInstrument(string instrument) => _instrumentData.Remove(instrument);
        
        public void OnBarUpdate(int barsInProgress) { }
        #endregion

        #region Main Update
        public void UpdateInstrument(string instrument, double open, double high, double low, double close, 
                                     double volume, DateTime time, int barIndex, double atr)
        {
            if (!IsEnabled || !IsInitialized || !_instrumentData.ContainsKey(instrument)) return;

            var data = _instrumentData[instrument];
            data.AddBar(open, high, low, close, volume, time, barIndex);
            data.CurrentATR = atr;
            
            UpdatePivots(data);
            UpdateMarketStructure(data);
            UpdateOrderBlocks(data);
            UpdateFairValueGaps(data);
            UpdateLiquidityZones(data);
            UpdatePremiumDiscount(data);
            CleanExpiredZones(data, barIndex);
            _contextCache.Invalidate(instrument);
            CheckForSignals(data);
        }
        #endregion

        #region Pivot Detection
        private void UpdatePivots(InstrumentSMCData data)
        {
            int lookback = Settings.PivotLookback;
            if (data.Bars.Count < lookback * 2 + 1) return;

            int currentBar = data.Bars.Count - 1 - lookback;
            if (currentBar < 0) return;

            var bar = data.Bars[currentBar];
            bool isSwingHigh = true, isSwingLow = true;

            for (int i = 1; i <= lookback; i++)
            {
                if (currentBar - i >= 0 && data.Bars[currentBar - i].High >= bar.High) isSwingHigh = false;
                if (currentBar + i < data.Bars.Count && data.Bars[currentBar + i].High >= bar.High) isSwingHigh = false;
                if (currentBar - i >= 0 && data.Bars[currentBar - i].Low <= bar.Low) isSwingLow = false;
                if (currentBar + i < data.Bars.Count && data.Bars[currentBar + i].Low <= bar.Low) isSwingLow = false;
            }

            if (isSwingHigh)
            {
                var lastPivotHigh = data.PivotHighs.LastOrDefault();
                PivotType type = lastPivotHigh.Price > 0 
                    ? (bar.High > lastPivotHigh.Price ? PivotType.HH 
                       : Math.Abs(bar.High - lastPivotHigh.Price) <= data.CurrentATR * 0.1 ? PivotType.EQH 
                       : PivotType.LH)
                    : PivotType.HH;

                var pivot = new PivotPoint(bar.High, bar.Time, bar.Index, type, true, lookback);
                data.PivotHighs.Add(pivot);
                data.AllPivots.Add(pivot);
                while (data.PivotHighs.Count > SophonConstants.MAX_PIVOTS) data.PivotHighs.RemoveAt(0);
            }

            if (isSwingLow)
            {
                var lastPivotLow = data.PivotLows.LastOrDefault();
                PivotType type = lastPivotLow.Price > 0 
                    ? (bar.Low < lastPivotLow.Price ? PivotType.LL 
                       : Math.Abs(bar.Low - lastPivotLow.Price) <= data.CurrentATR * 0.1 ? PivotType.EQL 
                       : PivotType.HL)
                    : PivotType.LL;

                var pivot = new PivotPoint(bar.Low, bar.Time, bar.Index, type, true, lookback);
                data.PivotLows.Add(pivot);
                data.AllPivots.Add(pivot);
                while (data.PivotLows.Count > SophonConstants.MAX_PIVOTS) data.PivotLows.RemoveAt(0);
            }

            while (data.AllPivots.Count > SophonConstants.MAX_PIVOTS * 2) data.AllPivots.RemoveAt(0);
        }
        #endregion

        #region Market Structure
        private void UpdateMarketStructure(InstrumentSMCData data)
        {
            if (data.PivotHighs.Count < 2 || data.PivotLows.Count < 2) return;

            var currentBar = data.CurrentBar;
            var lastHigh = data.PivotHighs.Last();
            var lastLow = data.PivotLows.Last();
            var prevHigh = data.PivotHighs.Count >= 2 ? data.PivotHighs[data.PivotHighs.Count - 2] : default;
            var prevLow = data.PivotLows.Count >= 2 ? data.PivotLows[data.PivotLows.Count - 2] : default;

            MarketStructure previousStructure = data.CurrentStructure;
            MarketStructureShift shift = MarketStructureShift.None;

            bool hasHH = lastHigh.Type == PivotType.HH;
            bool hasHL = lastLow.Type == PivotType.HL;
            bool hasLH = lastHigh.Type == PivotType.LH;
            bool hasLL = lastLow.Type == PivotType.LL;

            if (hasHH && hasHL) data.CurrentStructure = MarketStructure.Bullish;
            else if (hasLH && hasLL) data.CurrentStructure = MarketStructure.Bearish;
            else data.CurrentStructure = MarketStructure.Ranging;

            double currentClose = currentBar.Close;

            // BOS Detection
            if (previousStructure == MarketStructure.Bullish && prevHigh.Price > 0 && currentClose > prevHigh.Price)
            {
                shift = MarketStructureShift.BOS;
                data.LastBOS = new StructureShiftEvent
                {
                    Type = shift, Price = prevHigh.Price, Time = currentBar.Time,
                    BarIndex = currentBar.Index, Direction = TradeDirection.Long,
                    PreviousStructure = previousStructure
                };
            }
            
            if (previousStructure == MarketStructure.Bearish && prevLow.Price > 0 && currentClose < prevLow.Price)
            {
                shift = MarketStructureShift.BOS;
                data.LastBOS = new StructureShiftEvent
                {
                    Type = shift, Price = prevLow.Price, Time = currentBar.Time,
                    BarIndex = currentBar.Index, Direction = TradeDirection.Short,
                    PreviousStructure = previousStructure
                };
            }

            // ChoCH Detection
            if (previousStructure == MarketStructure.Bearish && prevHigh.Price > 0 && currentClose > prevHigh.Price)
            {
                shift = MarketStructureShift.ChoCH;
                data.CurrentStructure = MarketStructure.Bullish;
                data.LastChoCH = new StructureShiftEvent
                {
                    Type = shift, Price = prevHigh.Price, Time = currentBar.Time,
                    BarIndex = currentBar.Index, Direction = TradeDirection.Long,
                    PreviousStructure = previousStructure
                };
            }
            
            if (previousStructure == MarketStructure.Bullish && prevLow.Price > 0 && currentClose < prevLow.Price)
            {
                shift = MarketStructureShift.ChoCH;
                data.CurrentStructure = MarketStructure.Bearish;
                data.LastChoCH = new StructureShiftEvent
                {
                    Type = shift, Price = prevLow.Price, Time = currentBar.Time,
                    BarIndex = currentBar.Index, Direction = TradeDirection.Short,
                    PreviousStructure = previousStructure
                };
            }

            if (shift != MarketStructureShift.None) OnStructureShift?.Invoke(this, shift);
        }
        #endregion

        #region Order Blocks
        private void UpdateOrderBlocks(InstrumentSMCData data)
        {
            if (data.Bars.Count < Settings.OBLookback + 3) return;

            int currentIdx = data.Bars.Count - 1;
            var currentBar = data.Bars[currentIdx];
            
            double impulsiveMove = CalculateImpulsiveMove(data, currentIdx, Settings.OBLookback);
            double impulsiveThreshold = data.CurrentATR * Settings.OBImpulseMultiplier;

            if (Math.Abs(impulsiveMove) < impulsiveThreshold) return;

            bool isBullishImpulse = impulsiveMove > 0;
            
            for (int i = currentIdx - 1; i >= Math.Max(0, currentIdx - Settings.OBLookback); i--)
            {
                var bar = data.Bars[i];
                bool isBearishCandle = bar.Close < bar.Open;
                bool isBullishCandle = bar.Close > bar.Open;

                if (isBullishImpulse && isBearishCandle)
                {
                    if (!data.OrderBlocks.Any(ob => ob.CreatedBar == bar.Index && ob.Type == OrderBlockType.Bullish))
                    {
                        var ob = new OrderBlock
                        {
                            HighPrice = bar.High, LowPrice = bar.Low, OpenPrice = bar.Open, ClosePrice = bar.Close,
                            CreatedAt = bar.Time, CreatedBar = bar.Index, Type = OrderBlockType.Bullish,
                            Volume = bar.Volume, ImpulseStrength = Math.Abs(impulsiveMove) / data.CurrentATR,
                            Instrument = data.Instrument, ExpirationBars = Settings.OBExpirationBars
                        };
                        data.OrderBlocks.Add(ob);
                        OnOrderBlockCreated?.Invoke(this, ob);
                        while (data.OrderBlocks.Count > SophonConstants.MAX_ORDER_BLOCKS) data.OrderBlocks.RemoveAt(0);
                    }
                    break;
                }

                if (!isBullishImpulse && isBullishCandle)
                {
                    if (!data.OrderBlocks.Any(ob => ob.CreatedBar == bar.Index && ob.Type == OrderBlockType.Bearish))
                    {
                        var ob = new OrderBlock
                        {
                            HighPrice = bar.High, LowPrice = bar.Low, OpenPrice = bar.Open, ClosePrice = bar.Close,
                            CreatedAt = bar.Time, CreatedBar = bar.Index, Type = OrderBlockType.Bearish,
                            Volume = bar.Volume, ImpulseStrength = Math.Abs(impulsiveMove) / data.CurrentATR,
                            Instrument = data.Instrument, ExpirationBars = Settings.OBExpirationBars
                        };
                        data.OrderBlocks.Add(ob);
                        OnOrderBlockCreated?.Invoke(this, ob);
                        while (data.OrderBlocks.Count > SophonConstants.MAX_ORDER_BLOCKS) data.OrderBlocks.RemoveAt(0);
                    }
                    break;
                }
            }

            UpdateOrderBlockStates(data, currentBar);
        }

        private void UpdateOrderBlockStates(InstrumentSMCData data, BarData currentBar)
        {
            foreach (var ob in data.OrderBlocks.Where(o => o.IsActive))
            {
                if (ob.Contains(currentBar.Low) || ob.Contains(currentBar.High)) ob.RecordTouch();
                if (ob.IsBullish && currentBar.Close < ob.LowPrice - data.CurrentATR * 0.1) ob.State = ZoneState.Broken;
                if (ob.IsBearish && currentBar.Close > ob.HighPrice + data.CurrentATR * 0.1) ob.State = ZoneState.Broken;
                if (ob.State == ZoneState.Broken)
                    ob.Type = ob.IsBullish ? OrderBlockType.BearishBreaker : OrderBlockType.BullishBreaker;
            }
        }

        private double CalculateImpulsiveMove(InstrumentSMCData data, int endIndex, int lookback)
        {
            int startIndex = Math.Max(0, endIndex - lookback);
            if (startIndex >= endIndex) return 0;
            return data.Bars[endIndex].Close - data.Bars[startIndex].Close;
        }
        #endregion

        #region Fair Value Gaps
        private void UpdateFairValueGaps(InstrumentSMCData data)
        {
            if (data.Bars.Count < 3) return;

            int idx = data.Bars.Count - 2;
            var bar1 = data.Bars[idx - 1];
            var bar2 = data.Bars[idx];
            var bar3 = data.Bars[idx + 1];

            if (bar3.Low > bar1.High)
            {
                double gapSize = bar3.Low - bar1.High;
                if (gapSize >= data.CurrentATR * Settings.FVGMinATRRatio)
                {
                    if (!data.FairValueGaps.Any(f => f.CreatedBar == bar2.Index && f.Type == FVGType.Bullish))
                    {
                        var fvg = new FairValueGap
                        {
                            HighPrice = bar3.Low, LowPrice = bar1.High, CreatedAt = bar2.Time,
                            CreatedBar = bar2.Index, Type = FVGType.Bullish, Instrument = data.Instrument,
                            ExpirationBars = Settings.FVGExpirationBars
                        };
                        data.FairValueGaps.Add(fvg);
                        OnFVGCreated?.Invoke(this, fvg);
                        while (data.FairValueGaps.Count > SophonConstants.MAX_FVGS) data.FairValueGaps.RemoveAt(0);
                    }
                }
            }

            if (bar3.High < bar1.Low)
            {
                double gapSize = bar1.Low - bar3.High;
                if (gapSize >= data.CurrentATR * Settings.FVGMinATRRatio)
                {
                    if (!data.FairValueGaps.Any(f => f.CreatedBar == bar2.Index && f.Type == FVGType.Bearish))
                    {
                        var fvg = new FairValueGap
                        {
                            HighPrice = bar1.Low, LowPrice = bar3.High, CreatedAt = bar2.Time,
                            CreatedBar = bar2.Index, Type = FVGType.Bearish, Instrument = data.Instrument,
                            ExpirationBars = Settings.FVGExpirationBars
                        };
                        data.FairValueGaps.Add(fvg);
                        OnFVGCreated?.Invoke(this, fvg);
                        while (data.FairValueGaps.Count > SophonConstants.MAX_FVGS) data.FairValueGaps.RemoveAt(0);
                    }
                }
            }

            UpdateFVGStates(data, data.CurrentBar);
        }

        private void UpdateFVGStates(InstrumentSMCData data, BarData currentBar)
        {
            foreach (var fvg in data.FairValueGaps.Where(f => f.IsActive))
            {
                if (fvg.IsBullish && currentBar.Low <= fvg.HighPrice && currentBar.Low >= fvg.LowPrice)
                    fvg.UpdateFill(currentBar.Low);
                else if (fvg.IsBearish && currentBar.High >= fvg.LowPrice && currentBar.High <= fvg.HighPrice)
                    fvg.UpdateFill(currentBar.High);
            }
        }
        #endregion

        #region Liquidity Zones
        private void UpdateLiquidityZones(InstrumentSMCData data)
        {
            if (data.CurrentBar.Index == 0) return;
            DetectEqualLevels(data, true);
            DetectEqualLevels(data, false);
            UpdateDailyLevels(data);
            CheckLiquidityTaken(data, data.CurrentBar);
        }

        private void DetectEqualLevels(InstrumentSMCData data, bool isHigh)
        {
            var pivots = isHigh ? data.PivotHighs : data.PivotLows;
            if (pivots.Count < 2) return;

            double tolerance = data.CurrentATR * 0.15;
            var recentPivots = pivots.TakeLast(5).ToList();
            
            for (int i = 0; i < recentPivots.Count - 1; i++)
            {
                for (int j = i + 1; j < recentPivots.Count; j++)
                {
                    if (Math.Abs(recentPivots[i].Price - recentPivots[j].Price) <= tolerance)
                    {
                        double avgPrice = (recentPivots[i].Price + recentPivots[j].Price) / 2;
                        var liqType = isHigh ? LiquidityType.EqualHighs : LiquidityType.EqualLows;
                        
                        if (!data.LiquidityZones.Any(l => Math.Abs(l.Price - avgPrice) <= tolerance && l.Type == liqType))
                        {
                            data.LiquidityZones.Add(new LiquidityZone
                            {
                                Price = avgPrice, CreatedAt = recentPivots[j].Timestamp,
                                CreatedBar = recentPivots[j].BarIndex, Type = liqType,
                                TouchCount = 2, EstimatedVolume = 1.0, Instrument = data.Instrument
                            });
                            while (data.LiquidityZones.Count > SophonConstants.MAX_LIQUIDITY_ZONES) 
                                data.LiquidityZones.RemoveAt(0);
                        }
                    }
                }
            }
        }

        private void UpdateDailyLevels(InstrumentSMCData data)
        {
            if (data.Bars.Count < 2) return;
            var currentBar = data.CurrentBar;
            var prevBar = data.Bars[data.Bars.Count - 2];
            
            if (currentBar.Time.Date != prevBar.Time.Date)
            {
                var previousDayBars = data.Bars.Where(b => b.Time.Date == prevBar.Time.Date).ToList();
                if (previousDayBars.Count > 0)
                {
                    data.PreviousDayHigh = previousDayBars.Max(b => b.High);
                    data.PreviousDayLow = previousDayBars.Min(b => b.Low);
                    
                    data.LiquidityZones.Add(new LiquidityZone
                    {
                        Price = data.PreviousDayHigh, CreatedAt = currentBar.Time,
                        CreatedBar = currentBar.Index, Type = LiquidityType.PDH, Instrument = data.Instrument
                    });
                    data.LiquidityZones.Add(new LiquidityZone
                    {
                        Price = data.PreviousDayLow, CreatedAt = currentBar.Time,
                        CreatedBar = currentBar.Index, Type = LiquidityType.PDL, Instrument = data.Instrument
                    });
                }
            }
        }

        private void CheckLiquidityTaken(InstrumentSMCData data, BarData currentBar)
        {
            foreach (var liq in data.LiquidityZones.Where(l => l.IsActive))
            {
                bool taken = liq.IsBuySide ? currentBar.High > liq.Price : currentBar.Low < liq.Price;
                if (taken)
                {
                    liq.MarkAsTaken(currentBar.Time);
                    data.LastLiquiditySweep = new LiquiditySweepEvent
                    {
                        Zone = liq, Time = currentBar.Time, BarIndex = currentBar.Index,
                        SweepPrice = liq.IsBuySide ? currentBar.High : currentBar.Low
                    };
                    OnLiquidityTaken?.Invoke(this, liq);
                }
            }
        }
        #endregion

        #region Premium/Discount
        private void UpdatePremiumDiscount(InstrumentSMCData data)
        {
            if (data.AllPivots.Count >= 4)
            {
                var recentPivots = data.AllPivots.TakeLast(10).ToList();
                double rangeHigh = recentPivots.Max(p => p.Price);
                double rangeLow = recentPivots.Min(p => p.Price);
                
                data.CurrentSwingRange = new PriceRange(rangeHigh, rangeLow,
                    recentPivots.First().Timestamp, recentPivots.Last().Timestamp,
                    recentPivots.First().BarIndex, recentPivots.Last().BarIndex);
                data.CurrentPricePosition = data.CurrentSwingRange.GetPosition(data.CurrentBar.Close);
            }
        }
        #endregion

        #region Signal Generation
        private void CheckForSignals(InstrumentSMCData data)
        {
            if (!IsEnabled) return;
            
            List<SMCSignal> newSignals = new List<SMCSignal>();

            var obFvgSignal = CheckOBFVGSetup(data);
            if (obFvgSignal != null) newSignals.Add(obFvgSignal);

            var liqSweepSignal = CheckLiquiditySweepSetup(data);
            if (liqSweepSignal != null) newSignals.Add(liqSweepSignal);

            var bosSignal = CheckBOSContinuationSetup(data);
            if (bosSignal != null) newSignals.Add(bosSignal);

            var chochSignal = CheckChoCHReversalSetup(data);
            if (chochSignal != null) newSignals.Add(chochSignal);

            lock (_signalLock)
            {
                foreach (var signal in newSignals)
                {
                    _activeSignals.Add(signal);
                    OnNewSignal?.Invoke(this, signal);
                }

                var expired = _activeSignals.Where(s => s.IsExpired).ToList();
                foreach (var signal in expired)
                {
                    signal.IsValid = false;
                    OnSignalInvalidated?.Invoke(this, signal);
                    _activeSignals.Remove(signal);
                }

                while (_activeSignals.Count > SophonConstants.MAX_SIGNALS)
                    _activeSignals.RemoveAt(0);
            }
        }

        private SMCSignal CheckOBFVGSetup(InstrumentSMCData data)
        {
            var currentBar = data.CurrentBar;
            
            foreach (var ob in data.OrderBlocks.Where(o => o.IsActive))
            {
                foreach (var fvg in data.FairValueGaps.Where(f => f.IsActive))
                {
                    bool sameDirection = (ob.IsBullish && fvg.IsBullish) || (ob.IsBearish && fvg.IsBearish);
                    if (!sameDirection) continue;

                    bool overlaps = ob.LowPrice <= fvg.HighPrice && ob.HighPrice >= fvg.LowPrice;
                    if (!overlaps) continue;

                    double confluenceHigh = Math.Min(ob.HighPrice, fvg.HighPrice);
                    double confluenceLow = Math.Max(ob.LowPrice, fvg.LowPrice);
                    
                    bool priceInZone = currentBar.Low <= confluenceHigh && currentBar.High >= confluenceLow;
                    if (!priceInZone) continue;

                    bool structureAligned = (ob.IsBullish && data.CurrentStructure == MarketStructure.Bullish) ||
                                           (ob.IsBearish && data.CurrentStructure == MarketStructure.Bearish);
                    if (!structureAligned && Settings.RequireStructureAlignment) continue;

                    var signal = CreateSignal(data, SetupType.E_OB_FVG, ob.IsBullish);
                    signal.RelatedOB = ob;
                    signal.RelatedFVG = fvg;
                    
                    if (ob.IsBullish)
                    {
                        signal.EntryPrice = confluenceLow;
                        signal.StopLoss = ob.LowPrice - data.CurrentATR * Settings.SLATRMultiplier;
                    }
                    else
                    {
                        signal.EntryPrice = confluenceHigh;
                        signal.StopLoss = ob.HighPrice + data.CurrentATR * Settings.SLATRMultiplier;
                    }
                    
                    double risk = Math.Abs(signal.EntryPrice - signal.StopLoss);
                    signal.TakeProfit1 = ob.IsBullish ? signal.EntryPrice + risk * Settings.TP1RRRatio 
                                                      : signal.EntryPrice - risk * Settings.TP1RRRatio;
                    signal.TakeProfit2 = ob.IsBullish ? signal.EntryPrice + risk * Settings.TP2RRRatio 
                                                      : signal.EntryPrice - risk * Settings.TP2RRRatio;

                    signal.AddConfluence("OrderBlock");
                    signal.AddConfluence("FVG");
                    if (structureAligned) signal.AddConfluence("StructureAligned");
                    signal.RiskRewardRatio = Settings.TP1RRRatio;

                    return signal;
                }
            }
            return null;
        }

        private SMCSignal CheckLiquiditySweepSetup(InstrumentSMCData data)
        {
            if (data.LastLiquiditySweep == null || data.LastChoCH == null) return null;

            var currentBar = data.CurrentBar;
            var sweep = data.LastLiquiditySweep;
            var choch = data.LastChoCH;

            if (currentBar.Index - sweep.BarIndex > 10 || currentBar.Index - choch.BarIndex > 10) return null;
            if (sweep.BarIndex >= choch.BarIndex) return null;

            bool isLong = sweep.Zone.IsSellSide;
            if (isLong && choch.Direction != TradeDirection.Long) return null;
            if (!isLong && choch.Direction != TradeDirection.Short) return null;

            var signal = CreateSignal(data, SetupType.F_LiquiditySweep, isLong);
            signal.RelatedLiquidity = sweep.Zone;
            signal.EntryPrice = currentBar.Close;
            signal.StopLoss = isLong ? sweep.Zone.Price - data.CurrentATR * Settings.SLATRMultiplier
                                     : sweep.Zone.Price + data.CurrentATR * Settings.SLATRMultiplier;
            
            double risk = Math.Abs(signal.EntryPrice - signal.StopLoss);
            signal.TakeProfit1 = isLong ? signal.EntryPrice + risk * Settings.TP1RRRatio 
                                        : signal.EntryPrice - risk * Settings.TP1RRRatio;
            signal.TakeProfit2 = isLong ? signal.EntryPrice + risk * Settings.TP2RRRatio 
                                        : signal.EntryPrice - risk * Settings.TP2RRRatio;

            signal.AddConfluence("LiquiditySweep");
            signal.AddConfluence("ChoCH");
            signal.RiskRewardRatio = Settings.TP1RRRatio;

            data.LastLiquiditySweep = null;
            data.LastChoCH = null;
            return signal;
        }

        private SMCSignal CheckBOSContinuationSetup(InstrumentSMCData data)
        {
            if (data.LastBOS == null) return null;
            
            var currentBar = data.CurrentBar;
            int barsSinceBOS = currentBar.Index - data.LastBOS.BarIndex;
            if (barsSinceBOS > 5 || barsSinceBOS < 1) return null;

            bool isLong = data.LastBOS.Direction == TradeDirection.Long;

            OrderBlock relevantOB = data.OrderBlocks
                .Where(o => o.IsActive && o.IsBullish == isLong && o.CreatedBar < data.LastBOS.BarIndex)
                .FirstOrDefault(o => o.Contains(currentBar.Low) || o.Contains(currentBar.High));

            if (relevantOB == null) return null;

            var signal = CreateSignal(data, SetupType.G_BOS_Continuation, isLong);
            signal.RelatedOB = relevantOB;
            signal.EntryPrice = relevantOB.MidPrice;
            signal.StopLoss = isLong ? relevantOB.LowPrice - data.CurrentATR * 0.5
                                     : relevantOB.HighPrice + data.CurrentATR * 0.5;
            
            double risk = Math.Abs(signal.EntryPrice - signal.StopLoss);
            signal.TakeProfit1 = isLong ? signal.EntryPrice + risk * Settings.TP1RRRatio 
                                        : signal.EntryPrice - risk * Settings.TP1RRRatio;
            signal.TakeProfit2 = isLong ? signal.EntryPrice + risk * Settings.TP2RRRatio 
                                        : signal.EntryPrice - risk * Settings.TP2RRRatio;

            signal.AddConfluence("BOS");
            signal.AddConfluence("OrderBlock");
            signal.RiskRewardRatio = Settings.TP1RRRatio;

            data.LastBOS = null;
            return signal;
        }

        private SMCSignal CheckChoCHReversalSetup(InstrumentSMCData data)
        {
            if (data.LastChoCH == null) return null;
            
            var currentBar = data.CurrentBar;
            if (currentBar.Index - data.LastChoCH.BarIndex > 2) return null;

            bool isLong = data.LastChoCH.Direction == TradeDirection.Long;
            if (isLong && data.CurrentPricePosition != PricePosition.Discount) return null;
            if (!isLong && data.CurrentPricePosition != PricePosition.Premium) return null;

            var signal = CreateSignal(data, SetupType.H_ChoCH_Reversal, isLong);
            signal.EntryPrice = currentBar.Close;
            signal.StopLoss = isLong ? currentBar.Low - data.CurrentATR * Settings.SLATRMultiplier
                                     : currentBar.High + data.CurrentATR * Settings.SLATRMultiplier;
            
            double risk = Math.Abs(signal.EntryPrice - signal.StopLoss);
            signal.TakeProfit1 = isLong ? signal.EntryPrice + risk * Settings.TP1RRRatio 
                                        : signal.EntryPrice - risk * Settings.TP1RRRatio;
            signal.TakeProfit2 = isLong ? signal.EntryPrice + risk * Settings.TP2RRRatio 
                                        : signal.EntryPrice - risk * Settings.TP2RRRatio;

            signal.AddConfluence("ChoCH");
            signal.AddConfluence("Reversal");
            signal.AddConfluence(isLong ? "Discount" : "Premium");
            signal.RiskRewardRatio = Settings.TP1RRRatio;

            return signal;
        }

        private SMCSignal CreateSignal(InstrumentSMCData data, SetupType setup, bool isLong)
        {
            var currentBar = data.CurrentBar;
            return new SMCSignal
            {
                Instrument = data.Instrument,
                Timestamp = currentBar.Time,
                BarIndex = currentBar.Index,
                Setup = setup,
                Direction = isLong ? TradeDirection.Long : TradeDirection.Short,
                Structure = data.CurrentStructure,
                PricePosition = data.CurrentPricePosition,
                Session = SophonHelpers.GetCurrentSession(currentBar.Time),
                ExpiresAt = DateTime.Now.AddMinutes(Settings.SignalExpiryMinutes)
            };
        }
        #endregion

        #region Cleanup
        private void CleanExpiredZones(InstrumentSMCData data, int currentBar)
        {
            data.OrderBlocks.RemoveAll(ob => currentBar - ob.CreatedBar > ob.ExpirationBars || ob.State == ZoneState.Mitigated);
            data.FairValueGaps.RemoveAll(fvg => currentBar - fvg.CreatedBar > fvg.ExpirationBars || fvg.State == ZoneState.Mitigated);
            data.LiquidityZones.RemoveAll(liq => liq.WasTaken);
        }
        #endregion

        #region Public Interface
        public List<SMCSignal> GetActiveSignals()
        {
            lock (_signalLock) { return _activeSignals.Where(s => s.IsValid && !s.IsExpired).ToList(); }
        }

        public SMCSignal GetSignal(string instrument)
        {
            lock (_signalLock) { return _activeSignals.FirstOrDefault(s => s.Instrument == instrument && s.IsValid && !s.IsExpired); }
        }

        public void InvalidateSignal(string signalId)
        {
            lock (_signalLock)
            {
                var signal = _activeSignals.FirstOrDefault(s => s.Id == signalId);
                if (signal != null) { signal.IsValid = false; OnSignalInvalidated?.Invoke(this, signal); }
            }
        }

        public MarketContext GetMarketContext(string instrument)
        {
            return _contextCache.GetOrCompute(instrument, () =>
            {
                if (!_instrumentData.ContainsKey(instrument)) return new MarketContext { Instrument = instrument };
                var data = _instrumentData[instrument];
                
                return new MarketContext
                {
                    Instrument = instrument, Timestamp = DateTime.Now,
                    Structure = data.CurrentStructure, CurrentPosition = data.CurrentPricePosition,
                    CurrentSession = SophonHelpers.GetCurrentSession(DateTime.Now),
                    ATR = data.CurrentATR, CurrentSwingRange = data.CurrentSwingRange,
                    RecentPivots = data.AllPivots.TakeLast(10).ToList(),
                    ActiveOrderBlocks = data.OrderBlocks.Where(o => o.IsActive).ToList(),
                    ActiveFVGs = data.FairValueGaps.Where(f => f.IsActive).ToList(),
                    ActiveLiquidity = data.LiquidityZones.Where(l => l.IsActive).ToList(),
                    HasBullishBias = data.CurrentStructure == MarketStructure.Bullish,
                    HasBearishBias = data.CurrentStructure == MarketStructure.Bearish
                };
            });
        }

        public List<OrderBlock> GetActiveOrderBlocks(string instrument) =>
            _instrumentData.ContainsKey(instrument) ? _instrumentData[instrument].OrderBlocks.Where(o => o.IsActive).ToList() : new List<OrderBlock>();

        public List<FairValueGap> GetActiveFVGs(string instrument) =>
            _instrumentData.ContainsKey(instrument) ? _instrumentData[instrument].FairValueGaps.Where(f => f.IsActive).ToList() : new List<FairValueGap>();

        public List<LiquidityZone> GetActiveLiquidity(string instrument) =>
            _instrumentData.ContainsKey(instrument) ? _instrumentData[instrument].LiquidityZones.Where(l => l.IsActive).ToList() : new List<LiquidityZone>();
        #endregion
    }

    #region Supporting Classes
    public class SMCSettings
    {
        public int PivotLookback { get; set; } = 5;
        public int OBLookback { get; set; } = 10;
        public double OBImpulseMultiplier { get; set; } = 2.0;
        public int OBExpirationBars { get; set; } = 100;
        public double FVGMinATRRatio { get; set; } = 0.3;
        public int FVGExpirationBars { get; set; } = 50;
        public int SignalExpiryMinutes { get; set; } = 30;
        public bool RequireStructureAlignment { get; set; } = true;
        public double SLATRMultiplier { get; set; } = 1.5;
        public double TP1RRRatio { get; set; } = 1.5;
        public double TP2RRRatio { get; set; } = 3.0;
        public double TP3RRRatio { get; set; } = 5.0;
    }

    public class InstrumentSMCData
    {
        public string Instrument { get; }
        public SMCSettings Settings { get; }
        public List<BarData> Bars { get; }
        public BarData CurrentBar => Bars.Count > 0 ? Bars.Last() : default;
        public List<PivotPoint> PivotHighs { get; }
        public List<PivotPoint> PivotLows { get; }
        public List<PivotPoint> AllPivots { get; }
        public MarketStructure CurrentStructure { get; set; }
        public PricePosition CurrentPricePosition { get; set; }
        public PriceRange CurrentSwingRange { get; set; }
        public List<OrderBlock> OrderBlocks { get; }
        public List<FairValueGap> FairValueGaps { get; }
        public List<LiquidityZone> LiquidityZones { get; }
        public StructureShiftEvent LastBOS { get; set; }
        public StructureShiftEvent LastChoCH { get; set; }
        public LiquiditySweepEvent LastLiquiditySweep { get; set; }
        public double PreviousDayHigh { get; set; }
        public double PreviousDayLow { get; set; }
        public double CurrentATR { get; set; }

        public InstrumentSMCData(string instrument, SMCSettings settings)
        {
            Instrument = instrument;
            Settings = settings;
            Bars = new List<BarData>();
            PivotHighs = new List<PivotPoint>();
            PivotLows = new List<PivotPoint>();
            AllPivots = new List<PivotPoint>();
            OrderBlocks = new List<OrderBlock>();
            FairValueGaps = new List<FairValueGap>();
            LiquidityZones = new List<LiquidityZone>();
            CurrentStructure = MarketStructure.Unknown;
            CurrentPricePosition = PricePosition.Equilibrium;
        }

        public void AddBar(double open, double high, double low, double close, double volume, DateTime time, int index)
        {
            Bars.Add(new BarData { Open = open, High = high, Low = low, Close = close, Volume = volume, Time = time, Index = index });
            while (Bars.Count > 500) Bars.RemoveAt(0);
        }
    }

    public struct BarData
    {
        public double Open, High, Low, Close, Volume;
        public DateTime Time;
        public int Index;
        public double Body => Math.Abs(Close - Open);
        public double Range => High - Low;
        public bool IsBullish => Close > Open;
        public bool IsBearish => Close < Open;
        public double MidPoint => (High + Low) / 2;
    }

    public class StructureShiftEvent
    {
        public MarketStructureShift Type { get; set; }
        public double Price { get; set; }
        public DateTime Time { get; set; }
        public int BarIndex { get; set; }
        public TradeDirection Direction { get; set; }
        public MarketStructure PreviousStructure { get; set; }
    }

    public class LiquiditySweepEvent
    {
        public LiquidityZone Zone { get; set; }
        public DateTime Time { get; set; }
        public int BarIndex { get; set; }
        public double SweepPrice { get; set; }
    }
    #endregion
}
