#region Using declarations
using System;
using System.Collections.Generic;
using System.Linq;
using NinjaTrader.NinjaScript;
#endregion

//===============================================================================
// SOPHON SCALPING MODULE v1.0
// Extension du Système Sophon - Logique de Scalping Originale
//
// Ce module intègre le système ESS (Emmanuel Scalping System) original:
//   - Setup A: SMA + Zone S/R Confluence
//   - Setup B: Breakout Consolidation
//   - Setup C: Trendline Bounce/Rejection
//   - Setup D: Retest après Breakout
//
// Analyse technique:
//   - SMA 19/50 pour trend et confluence
//   - Zones Support/Résistance automatiques
//   - Détection de consolidation
//   - Trendlines dynamiques
//   - 24 patterns de bougies
//   - Volume analysis
//   - RSI filtering
//
// Copyright (c) 2026 Algosphere Quant - Emmanuel
//===============================================================================

namespace NinjaTrader.NinjaScript.AddOns.Sophon
{
    /// <summary>
    /// Module de Scalping - Setups A, B, C, D originaux
    /// </summary>
    public class SophonScalping : ISophonModule
    {
        #region Properties
        public string ModuleName => "SophonScalping";
        public bool IsInitialized { get; private set; }
        public bool IsEnabled { get; set; }
        
        public ScalpingSettings Settings { get; set; }
        
        // Données par instrument
        private Dictionary<string, ScalpingData> _dataByInstrument;
        
        // Signaux générés
        private List<ScalpingSignal> _activeSignals;
        
        // Events
        public event EventHandler<ScalpingSignal> OnSetupDetected;
        public event EventHandler<ScalpingSignal> OnSetupInvalidated;
        public event EventHandler<TrendChangeEvent> OnTrendChange;
        public event EventHandler<ZoneEvent> OnZoneCreated;
        public event EventHandler<ZoneEvent> OnZoneBroken;
        
        private readonly object _lock = new object();
        #endregion

        #region Initialization
        public SophonScalping()
        {
            Settings = new ScalpingSettings();
            _dataByInstrument = new Dictionary<string, ScalpingData>();
            _activeSignals = new List<ScalpingSignal>();
            IsEnabled = true;
        }

        public void Initialize()
        {
            if (IsInitialized) return;
            
            _dataByInstrument.Clear();
            _activeSignals.Clear();
            
            IsInitialized = true;
        }

        public void Shutdown()
        {
            _dataByInstrument.Clear();
            _activeSignals.Clear();
            IsInitialized = false;
        }

        public void Reset()
        {
            Shutdown();
            Initialize();
        }

        public void OnBarUpdate(int barsInProgress) { }

        /// <summary>
        /// Enregistre un instrument pour le scalping
        /// </summary>
        public void RegisterInstrument(string instrument)
        {
            lock (_lock)
            {
                if (!_dataByInstrument.ContainsKey(instrument))
                {
                    _dataByInstrument[instrument] = new ScalpingData(instrument, Settings);
                }
            }
        }
        #endregion

        #region Data Update
        /// <summary>
        /// Met à jour les données pour un instrument
        /// </summary>
        public void Update(string instrument, double open, double high, double low, double close,
                          double volume, DateTime time, int barIndex, double atr,
                          double sma19, double sma50, double rsi, double volumeSMA)
        {
            lock (_lock)
            {
                if (!_dataByInstrument.ContainsKey(instrument))
                    RegisterInstrument(instrument);
                
                var data = _dataByInstrument[instrument];
                
                // Ajouter la bougie
                var candle = new CandleData
                {
                    Open = open,
                    High = high,
                    Low = low,
                    Close = close,
                    Volume = volume,
                    Time = time,
                    BarIndex = barIndex
                };
                
                data.Candles.Add(candle);
                data.ATR = atr;
                data.SMA19 = sma19;
                data.SMA50 = sma50;
                data.RSI = rsi;
                data.VolumeSMA = volumeSMA;
                data.LastUpdate = time;
                
                // Limiter l'historique
                while (data.Candles.Count > Settings.MaxCandleHistory)
                    data.Candles.RemoveAt(0);
                
                // Analyser la structure
                UpdatePivots(data);
                UpdateSRZones(data);
                UpdateConsolidation(data);
                UpdateTrendlines(data);
                UpdateHTFTrend(data);
                DetectCandlePattern(data, candle);
                
                // Vérifier les setups
                CheckAllSetups(data);
                
                // Nettoyer les signaux expirés
                CleanupExpiredSignals(time);
            }
        }
        #endregion

        #region Structure Analysis
        /// <summary>
        /// Met à jour les pivots high/low
        /// </summary>
        private void UpdatePivots(ScalpingData data)
        {
            if (data.Candles.Count < Settings.PivotLookback * 2 + 1)
                return;
            
            int pivotBar = data.Candles.Count - 1 - Settings.PivotLookback;
            if (pivotBar < Settings.PivotLookback) return;
            
            var candles = data.Candles;
            double pivotHigh = candles[pivotBar].High;
            double pivotLow = candles[pivotBar].Low;
            bool isHigh = true;
            bool isLow = true;
            
            // Vérifier si c'est un pivot
            for (int i = pivotBar - Settings.PivotLookback; i <= pivotBar + Settings.PivotLookback; i++)
            {
                if (i == pivotBar) continue;
                if (i < 0 || i >= candles.Count) continue;
                
                if (candles[i].High >= pivotHigh) isHigh = false;
                if (candles[i].Low <= pivotLow) isLow = false;
            }
            
            if (isHigh)
            {
                data.PivotHighs.Add(new PivotPoint
                {
                    Price = pivotHigh,
                    BarIndex = candles[pivotBar].BarIndex,
                    Time = candles[pivotBar].Time,
                    Type = PivotType.High
                });
                
                // Limiter le nombre de pivots
                while (data.PivotHighs.Count > Settings.MaxPivots)
                    data.PivotHighs.RemoveAt(0);
            }
            
            if (isLow)
            {
                data.PivotLows.Add(new PivotPoint
                {
                    Price = pivotLow,
                    BarIndex = candles[pivotBar].BarIndex,
                    Time = candles[pivotBar].Time,
                    Type = PivotType.Low
                });
                
                while (data.PivotLows.Count > Settings.MaxPivots)
                    data.PivotLows.RemoveAt(0);
            }
        }

        /// <summary>
        /// Met à jour les zones Support/Résistance
        /// </summary>
        private void UpdateSRZones(ScalpingData data)
        {
            if (data.Candles.Count < 20) return;
            
            var current = data.Candles.Last();
            double tolerance = data.ATR * Settings.ZoneTolerance;
            
            // Vérifier les touches sur les zones existantes
            foreach (var zone in data.SupportZones.Concat(data.ResistanceZones))
            {
                if (current.Low <= zone.HighPrice + tolerance && 
                    current.High >= zone.LowPrice - tolerance)
                {
                    zone.TouchCount++;
                    zone.LastTouchBar = current.BarIndex;
                }
            }
            
            // Créer de nouvelles zones à partir des pivots
            foreach (var pivot in data.PivotLows.TakeLast(5))
            {
                bool zoneExists = data.SupportZones.Any(z => 
                    Math.Abs(z.MidPrice - pivot.Price) < tolerance);
                
                if (!zoneExists && data.SupportZones.Count < Settings.MaxSRZones)
                {
                    var zone = new SRZone
                    {
                        Id = Guid.NewGuid().ToString("N").Substring(0, 8),
                        Type = SRZoneType.Support,
                        HighPrice = pivot.Price + data.ATR * 0.2,
                        LowPrice = pivot.Price - data.ATR * 0.2,
                        CreatedBar = pivot.BarIndex,
                        TouchCount = 1
                    };
                    data.SupportZones.Add(zone);
                    
                    OnZoneCreated?.Invoke(this, new ZoneEvent { Zone = zone, Instrument = data.Instrument });
                }
            }
            
            foreach (var pivot in data.PivotHighs.TakeLast(5))
            {
                bool zoneExists = data.ResistanceZones.Any(z => 
                    Math.Abs(z.MidPrice - pivot.Price) < tolerance);
                
                if (!zoneExists && data.ResistanceZones.Count < Settings.MaxSRZones)
                {
                    var zone = new SRZone
                    {
                        Id = Guid.NewGuid().ToString("N").Substring(0, 8),
                        Type = SRZoneType.Resistance,
                        HighPrice = pivot.Price + data.ATR * 0.2,
                        LowPrice = pivot.Price - data.ATR * 0.2,
                        CreatedBar = pivot.BarIndex,
                        TouchCount = 1
                    };
                    data.ResistanceZones.Add(zone);
                    
                    OnZoneCreated?.Invoke(this, new ZoneEvent { Zone = zone, Instrument = data.Instrument });
                }
            }
            
            // Supprimer les zones cassées
            var brokenSupports = data.SupportZones
                .Where(z => current.Close < z.LowPrice - tolerance * 2)
                .ToList();
            
            foreach (var zone in brokenSupports)
            {
                data.SupportZones.Remove(zone);
                OnZoneBroken?.Invoke(this, new ZoneEvent { Zone = zone, Instrument = data.Instrument });
            }
            
            var brokenResistances = data.ResistanceZones
                .Where(z => current.Close > z.HighPrice + tolerance * 2)
                .ToList();
            
            foreach (var zone in brokenResistances)
            {
                data.ResistanceZones.Remove(zone);
                OnZoneBroken?.Invoke(this, new ZoneEvent { Zone = zone, Instrument = data.Instrument });
            }
            
            // Limiter le nombre de zones
            while (data.SupportZones.Count > Settings.MaxSRZones)
                data.SupportZones.RemoveAt(0);
            while (data.ResistanceZones.Count > Settings.MaxSRZones)
                data.ResistanceZones.RemoveAt(0);
        }

        /// <summary>
        /// Met à jour la zone de consolidation
        /// </summary>
        private void UpdateConsolidation(ScalpingData data)
        {
            if (data.Candles.Count < Settings.MinConsolidationBars)
                return;
            
            var recentCandles = data.Candles.TakeLast(Settings.ConsolidationLookback).ToList();
            
            double rangeHigh = recentCandles.Max(c => c.High);
            double rangeLow = recentCandles.Min(c => c.Low);
            double range = rangeHigh - rangeLow;
            
            // Consolidation = range < 1.5 × ATR
            bool isConsolidating = range < data.ATR * Settings.ConsolidationATRMult;
            
            if (isConsolidating)
            {
                if (data.ActiveConsolidation == null)
                {
                    data.ActiveConsolidation = new ConsolidationZone
                    {
                        Id = Guid.NewGuid().ToString("N").Substring(0, 8),
                        HighPrice = rangeHigh,
                        LowPrice = rangeLow,
                        StartBar = recentCandles.First().BarIndex,
                        BarCount = recentCandles.Count
                    };
                }
                else
                {
                    // Étendre la consolidation
                    data.ActiveConsolidation.HighPrice = Math.Max(data.ActiveConsolidation.HighPrice, rangeHigh);
                    data.ActiveConsolidation.LowPrice = Math.Min(data.ActiveConsolidation.LowPrice, rangeLow);
                    data.ActiveConsolidation.BarCount++;
                }
            }
            else if (data.ActiveConsolidation != null)
            {
                // Vérifier si breakout
                var current = data.Candles.Last();
                
                if (current.Close > data.ActiveConsolidation.HighPrice)
                {
                    data.ActiveConsolidation.IsBroken = true;
                    data.ActiveConsolidation.BreakoutDirection = TradeDirection.Long;
                    data.ActiveConsolidation.BreakoutBar = current.BarIndex;
                    data.LastBrokenConsolidation = data.ActiveConsolidation;
                    data.ActiveConsolidation = null;
                }
                else if (current.Close < data.ActiveConsolidation.LowPrice)
                {
                    data.ActiveConsolidation.IsBroken = true;
                    data.ActiveConsolidation.BreakoutDirection = TradeDirection.Short;
                    data.ActiveConsolidation.BreakoutBar = current.BarIndex;
                    data.LastBrokenConsolidation = data.ActiveConsolidation;
                    data.ActiveConsolidation = null;
                }
            }
        }

        /// <summary>
        /// Met à jour les trendlines
        /// </summary>
        private void UpdateTrendlines(ScalpingData data)
        {
            // Trendline ascendante (connecte les pivot lows)
            if (data.PivotLows.Count >= Settings.MinTrendlineTouches)
            {
                var validLows = data.PivotLows.TakeLast(5).OrderBy(p => p.BarIndex).ToList();
                
                for (int i = 0; i < validLows.Count - 1; i++)
                {
                    for (int j = i + 1; j < validLows.Count; j++)
                    {
                        var p1 = validLows[i];
                        var p2 = validLows[j];
                        
                        // Pente positive = trendline ascendante
                        if (p2.Price > p1.Price)
                        {
                            double slope = (p2.Price - p1.Price) / (p2.BarIndex - p1.BarIndex);
                            
                            // Compter les touches
                            int touches = CountTrendlineTouches(data, p1.Price, p1.BarIndex, slope, true);
                            
                            if (touches >= Settings.MinTrendlineTouches)
                            {
                                data.TrendlineUp = new Trendline
                                {
                                    Id = Guid.NewGuid().ToString("N").Substring(0, 8),
                                    StartPrice = p1.Price,
                                    StartBar = p1.BarIndex,
                                    Slope = slope,
                                    Direction = TrendlineDirection.Up,
                                    TouchCount = touches,
                                    IsValid = true
                                };
                                break;
                            }
                        }
                    }
                    if (data.TrendlineUp != null) break;
                }
            }
            
            // Trendline descendante (connecte les pivot highs)
            if (data.PivotHighs.Count >= Settings.MinTrendlineTouches)
            {
                var validHighs = data.PivotHighs.TakeLast(5).OrderBy(p => p.BarIndex).ToList();
                
                for (int i = 0; i < validHighs.Count - 1; i++)
                {
                    for (int j = i + 1; j < validHighs.Count; j++)
                    {
                        var p1 = validHighs[i];
                        var p2 = validHighs[j];
                        
                        // Pente négative = trendline descendante
                        if (p2.Price < p1.Price)
                        {
                            double slope = (p2.Price - p1.Price) / (p2.BarIndex - p1.BarIndex);
                            
                            int touches = CountTrendlineTouches(data, p1.Price, p1.BarIndex, slope, false);
                            
                            if (touches >= Settings.MinTrendlineTouches)
                            {
                                data.TrendlineDown = new Trendline
                                {
                                    Id = Guid.NewGuid().ToString("N").Substring(0, 8),
                                    StartPrice = p1.Price,
                                    StartBar = p1.BarIndex,
                                    Slope = slope,
                                    Direction = TrendlineDirection.Down,
                                    TouchCount = touches,
                                    IsValid = true
                                };
                                break;
                            }
                        }
                    }
                    if (data.TrendlineDown != null) break;
                }
            }
        }

        private int CountTrendlineTouches(ScalpingData data, double startPrice, int startBar, 
                                          double slope, bool isAscending)
        {
            int touches = 0;
            double tolerance = data.ATR * Settings.TrendlineTolerance;
            
            foreach (var candle in data.Candles.Where(c => c.BarIndex >= startBar))
            {
                double trendlinePrice = startPrice + slope * (candle.BarIndex - startBar);
                double checkPrice = isAscending ? candle.Low : candle.High;
                
                if (Math.Abs(checkPrice - trendlinePrice) <= tolerance)
                    touches++;
            }
            
            return touches;
        }

        /// <summary>
        /// Met à jour la tendance HTF
        /// </summary>
        private void UpdateHTFTrend(ScalpingData data)
        {
            var previousTrend = data.HTFTrend;
            
            if (data.SMA19 > data.SMA50 && data.Candles.Last().Close > data.SMA19)
            {
                data.HTFTrend = ScalpingTrendDirection.Bullish;
            }
            else if (data.SMA19 < data.SMA50 && data.Candles.Last().Close < data.SMA19)
            {
                data.HTFTrend = ScalpingTrendDirection.Bearish;
            }
            else
            {
                data.HTFTrend = ScalpingTrendDirection.Flat;
            }
            
            if (previousTrend != data.HTFTrend && previousTrend != ScalpingTrendDirection.Unknown)
            {
                OnTrendChange?.Invoke(this, new TrendChangeEvent
                {
                    Instrument = data.Instrument,
                    PreviousTrend = previousTrend,
                    NewTrend = data.HTFTrend,
                    Time = data.LastUpdate
                });
            }
        }
        #endregion

        #region Candle Pattern Detection
        /// <summary>
        /// Détecte le pattern de bougie
        /// </summary>
        private void DetectCandlePattern(ScalpingData data, CandleData candle)
        {
            double body = Math.Abs(candle.Close - candle.Open);
            double range = candle.High - candle.Low;
            double upperWick = candle.High - Math.Max(candle.Open, candle.Close);
            double lowerWick = Math.Min(candle.Open, candle.Close) - candle.Low;
            bool isBullish = candle.Close > candle.Open;
            
            candle.Pattern = CandlePattern.None;
            
            if (range < 0.0001) return;
            
            double bodyRatio = body / range;
            double upperWickRatio = upperWick / range;
            double lowerWickRatio = lowerWick / range;
            
            // Doji
            if (bodyRatio < 0.1)
            {
                candle.Pattern = CandlePattern.Doji;
                return;
            }
            
            // Hammer (bullish, longue mèche basse)
            if (isBullish && lowerWickRatio > 0.6 && upperWickRatio < 0.1)
            {
                candle.Pattern = CandlePattern.Hammer;
                return;
            }
            
            // Inverted Hammer
            if (isBullish && upperWickRatio > 0.6 && lowerWickRatio < 0.1)
            {
                candle.Pattern = CandlePattern.InvertedHammer;
                return;
            }
            
            // Shooting Star (bearish, longue mèche haute)
            if (!isBullish && upperWickRatio > 0.6 && lowerWickRatio < 0.1)
            {
                candle.Pattern = CandlePattern.ShootingStar;
                return;
            }
            
            // Hanging Man
            if (!isBullish && lowerWickRatio > 0.6 && upperWickRatio < 0.1)
            {
                candle.Pattern = CandlePattern.HangingMan;
                return;
            }
            
            // Pin Bar (très longue mèche d'un côté)
            if (lowerWickRatio > 0.7 && bodyRatio < 0.2)
            {
                candle.Pattern = CandlePattern.BullishPinBar;
                return;
            }
            if (upperWickRatio > 0.7 && bodyRatio < 0.2)
            {
                candle.Pattern = CandlePattern.BearishPinBar;
                return;
            }
            
            // Marubozu (pas de mèches)
            if (bodyRatio > 0.9)
            {
                candle.Pattern = isBullish ? CandlePattern.BullishMarubozu : CandlePattern.BearishMarubozu;
                return;
            }
            
            // Engulfing (nécessite la bougie précédente)
            if (data.Candles.Count >= 2)
            {
                var prev = data.Candles[data.Candles.Count - 2];
                bool prevBullish = prev.Close > prev.Open;
                
                if (isBullish && !prevBullish && 
                    candle.Open <= prev.Close && candle.Close >= prev.Open)
                {
                    candle.Pattern = CandlePattern.BullishEngulfing;
                    return;
                }
                
                if (!isBullish && prevBullish && 
                    candle.Open >= prev.Close && candle.Close <= prev.Open)
                {
                    candle.Pattern = CandlePattern.BearishEngulfing;
                    return;
                }
            }
        }
        #endregion

        #region Setup Detection
        /// <summary>
        /// Vérifie tous les setups
        /// </summary>
        private void CheckAllSetups(ScalpingData data)
        {
            var current = data.Candles.LastOrDefault();
            if (current == null) return;
            
            // Setup A: SMA + S/R Confluence
            CheckSetupA(data, current);
            
            // Setup B: Breakout Consolidation
            CheckSetupB(data, current);
            
            // Setup C: Trendline Bounce/Rejection
            CheckSetupC(data, current);
            
            // Setup D: Retest après Breakout
            CheckSetupD(data, current);
        }

        /// <summary>
        /// Setup A: SMA bounce dans une zone S/R
        /// </summary>
        private void CheckSetupA(ScalpingData data, CandleData current)
        {
            double smaTolerance = data.ATR * Settings.SMATolerance;
            bool nearSMA = Math.Abs(current.Close - data.SMA19) < smaTolerance;
            
            if (!nearSMA) return;
            
            // Vérifier SMA dans zone Support → Long
            foreach (var zone in data.SupportZones.Where(z => z.TouchCount >= Settings.MinZoneTouches))
            {
                if (data.SMA19 >= zone.LowPrice && data.SMA19 <= zone.HighPrice)
                {
                    // Pattern bullish requis
                    if (IsBullishPattern(current.Pattern) && 
                        (data.HTFTrend == ScalpingTrendDirection.Bullish || data.HTFTrend == ScalpingTrendDirection.Flat))
                    {
                        // Volume confirmation
                        if (current.Volume >= data.VolumeSMA * Settings.VolumeConfirmMin)
                        {
                            GenerateSignal(data, ScalpingSetupType.A, true, current, 
                                          $"SMA19 in Support Zone ({zone.TouchCount} touches)");
                        }
                    }
                }
            }
            
            // Vérifier SMA dans zone Résistance → Short
            foreach (var zone in data.ResistanceZones.Where(z => z.TouchCount >= Settings.MinZoneTouches))
            {
                if (data.SMA19 >= zone.LowPrice && data.SMA19 <= zone.HighPrice)
                {
                    if (IsBearishPattern(current.Pattern) && 
                        (data.HTFTrend == ScalpingTrendDirection.Bearish || data.HTFTrend == ScalpingTrendDirection.Flat))
                    {
                        if (current.Volume >= data.VolumeSMA * Settings.VolumeConfirmMin)
                        {
                            GenerateSignal(data, ScalpingSetupType.A, false, current,
                                          $"SMA19 in Resistance Zone ({zone.TouchCount} touches)");
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Setup B: Breakout de consolidation
        /// </summary>
        private void CheckSetupB(ScalpingData data, CandleData current)
        {
            if (data.LastBrokenConsolidation == null) return;
            if (current.BarIndex - data.LastBrokenConsolidation.BreakoutBar > 3) return; // Breakout récent
            
            var consol = data.LastBrokenConsolidation;
            
            // Volume spike requis
            if (current.Volume < data.VolumeSMA * Settings.BreakoutVolumeMult)
                return;
            
            // Body fort requis
            double body = Math.Abs(current.Close - current.Open);
            double range = current.High - current.Low;
            if (range > 0 && body / range < Settings.BreakoutBodyRatio)
                return;
            
            bool isBullish = current.Close > current.Open;
            
            // Breakout haussier
            if (consol.BreakoutDirection == TradeDirection.Long && isBullish)
            {
                GenerateSignal(data, ScalpingSetupType.B, true, current,
                              $"Breakout above consolidation ({consol.BarCount} bars)");
            }
            // Breakdown baissier
            else if (consol.BreakoutDirection == TradeDirection.Short && !isBullish)
            {
                GenerateSignal(data, ScalpingSetupType.B, false, current,
                              $"Breakdown below consolidation ({consol.BarCount} bars)");
            }
            
            // Reset après utilisation
            data.LastBrokenConsolidation = null;
        }

        /// <summary>
        /// Setup C: Bounce/Rejection sur trendline
        /// </summary>
        private void CheckSetupC(ScalpingData data, CandleData current)
        {
            double tolerance = data.ATR * Settings.TrendlineTolerance;
            
            // Trendline ascendante → Long (bounce)
            if (data.TrendlineUp != null && data.TrendlineUp.IsValid)
            {
                double trendPrice = data.TrendlineUp.GetPriceAtBar(current.BarIndex);
                
                if (Math.Abs(current.Low - trendPrice) < tolerance)
                {
                    if (IsBullishPattern(current.Pattern) && data.RSI < Settings.RSIOversold)
                    {
                        GenerateSignal(data, ScalpingSetupType.C, true, current,
                                      $"Bounce on ascending trendline ({data.TrendlineUp.TouchCount} touches)");
                    }
                }
            }
            
            // Trendline descendante → Short (rejection)
            if (data.TrendlineDown != null && data.TrendlineDown.IsValid)
            {
                double trendPrice = data.TrendlineDown.GetPriceAtBar(current.BarIndex);
                
                if (Math.Abs(current.High - trendPrice) < tolerance)
                {
                    if (IsBearishPattern(current.Pattern) && data.RSI > Settings.RSIOverbought)
                    {
                        GenerateSignal(data, ScalpingSetupType.C, false, current,
                                      $"Rejection on descending trendline ({data.TrendlineDown.TouchCount} touches)");
                    }
                }
            }
        }

        /// <summary>
        /// Setup D: Retest après breakout
        /// </summary>
        private void CheckSetupD(ScalpingData data, CandleData current)
        {
            // Chercher une zone récemment cassée
            foreach (var zone in data.BrokenZones.Where(z => 
                current.BarIndex - z.BrokenBar <= Settings.RetestMaxBars &&
                current.BarIndex - z.BrokenBar >= Settings.RetestMinBars))
            {
                double tolerance = data.ATR * Settings.ZoneTolerance;
                
                // Retest d'un support cassé (ancien support = nouvelle résistance) → Short
                if (zone.Type == SRZoneType.Support && zone.BreakoutDirection == TradeDirection.Short)
                {
                    if (current.High >= zone.LowPrice - tolerance && current.High <= zone.HighPrice + tolerance)
                    {
                        if (IsBearishPattern(current.Pattern) && 
                            current.Volume < data.VolumeSMA * Settings.RetestVolumeMax)
                        {
                            GenerateSignal(data, ScalpingSetupType.D, false, current,
                                          "Retest of broken support");
                        }
                    }
                }
                
                // Retest d'une résistance cassée (ancienne résistance = nouveau support) → Long
                if (zone.Type == SRZoneType.Resistance && zone.BreakoutDirection == TradeDirection.Long)
                {
                    if (current.Low >= zone.LowPrice - tolerance && current.Low <= zone.HighPrice + tolerance)
                    {
                        if (IsBullishPattern(current.Pattern) && 
                            current.Volume < data.VolumeSMA * Settings.RetestVolumeMax)
                        {
                            GenerateSignal(data, ScalpingSetupType.D, true, current,
                                          "Retest of broken resistance");
                        }
                    }
                }
            }
        }
        #endregion

        #region Signal Generation
        /// <summary>
        /// Génère un signal de scalping
        /// </summary>
        private void GenerateSignal(ScalpingData data, ScalpingSetupType setup, bool isLong, 
                                    CandleData candle, string description)
        {
            // Éviter les doublons
            if (_activeSignals.Any(s => s.Instrument == data.Instrument && 
                                        s.Setup == setup && 
                                        s.BarIndex == candle.BarIndex))
                return;
            
            var signal = new ScalpingSignal
            {
                Id = Guid.NewGuid().ToString("N").Substring(0, 8),
                Instrument = data.Instrument,
                Setup = setup,
                IsLong = isLong,
                EntryPrice = candle.Close,
                Time = candle.Time,
                BarIndex = candle.BarIndex,
                Description = description,
                ATR = data.ATR,
                SMA19 = data.SMA19,
                RSI = data.RSI,
                Volume = candle.Volume,
                VolumeSMA = data.VolumeSMA,
                Pattern = candle.Pattern,
                HTFTrend = data.HTFTrend
            };
            
            // Calculer SL et TP
            double slDistance = data.ATR * Settings.StopLossATRMult;
            signal.StopLoss = isLong ? candle.Close - slDistance : candle.Close + slDistance;
            signal.TakeProfit1 = isLong ? candle.Close + slDistance * Settings.TP1RRRatio : candle.Close - slDistance * Settings.TP1RRRatio;
            signal.TakeProfit2 = isLong ? candle.Close + slDistance * Settings.TP2RRRatio : candle.Close - slDistance * Settings.TP2RRRatio;
            
            // Calculer le score de confluence
            signal.Strength = CalculateSignalStrength(data, signal);
            
            _activeSignals.Add(signal);
            
            OnSetupDetected?.Invoke(this, signal);
        }

        /// <summary>
        /// Calcule la force du signal (0-100)
        /// </summary>
        private int CalculateSignalStrength(ScalpingData data, ScalpingSignal signal)
        {
            int strength = 50; // Base
            
            // Bonus trend aligné
            if ((signal.IsLong && data.HTFTrend == ScalpingTrendDirection.Bullish) ||
                (!signal.IsLong && data.HTFTrend == ScalpingTrendDirection.Bearish))
                strength += 15;
            
            // Bonus pattern fort
            if (signal.Pattern == CandlePattern.BullishEngulfing || 
                signal.Pattern == CandlePattern.BearishEngulfing ||
                signal.Pattern == CandlePattern.BullishPinBar ||
                signal.Pattern == CandlePattern.BearishPinBar)
                strength += 10;
            
            // Bonus volume
            if (signal.Volume > signal.VolumeSMA * 1.5)
                strength += 10;
            
            // Bonus RSI extrême
            if ((signal.IsLong && data.RSI < 30) || (!signal.IsLong && data.RSI > 70))
                strength += 10;
            
            // Bonus setup type
            strength += signal.Setup switch
            {
                ScalpingSetupType.A => 5,  // SMA + S/R très fiable
                ScalpingSetupType.B => 10, // Breakout fort
                ScalpingSetupType.C => 5,
                ScalpingSetupType.D => 0,
                _ => 0
            };
            
            return Math.Min(100, Math.Max(0, strength));
        }

        private bool IsBullishPattern(CandlePattern pattern)
        {
            return pattern == CandlePattern.Hammer ||
                   pattern == CandlePattern.InvertedHammer ||
                   pattern == CandlePattern.BullishEngulfing ||
                   pattern == CandlePattern.BullishPinBar ||
                   pattern == CandlePattern.BullishMarubozu ||
                   pattern == CandlePattern.Doji;
        }

        private bool IsBearishPattern(CandlePattern pattern)
        {
            return pattern == CandlePattern.ShootingStar ||
                   pattern == CandlePattern.HangingMan ||
                   pattern == CandlePattern.BearishEngulfing ||
                   pattern == CandlePattern.BearishPinBar ||
                   pattern == CandlePattern.BearishMarubozu ||
                   pattern == CandlePattern.Doji;
        }

        private void CleanupExpiredSignals(DateTime currentTime)
        {
            _activeSignals.RemoveAll(s => (currentTime - s.Time).TotalMinutes > Settings.SignalExpiryMinutes);
        }
        #endregion

        #region Public Interface
        /// <summary>
        /// Obtient les signaux actifs
        /// </summary>
        public List<ScalpingSignal> GetActiveSignals(string instrument = null)
        {
            lock (_lock)
            {
                if (string.IsNullOrEmpty(instrument))
                    return _activeSignals.ToList();
                
                return _activeSignals.Where(s => s.Instrument == instrument).ToList();
            }
        }

        /// <summary>
        /// Obtient les données de scalping pour un instrument
        /// </summary>
        public ScalpingData GetScalpingData(string instrument)
        {
            lock (_lock)
            {
                return _dataByInstrument.TryGetValue(instrument, out var data) ? data : null;
            }
        }

        /// <summary>
        /// Obtient les zones S/R
        /// </summary>
        public (List<SRZone> Supports, List<SRZone> Resistances) GetSRZones(string instrument)
        {
            var data = GetScalpingData(instrument);
            if (data == null) return (new List<SRZone>(), new List<SRZone>());
            return (data.SupportZones.ToList(), data.ResistanceZones.ToList());
        }

        /// <summary>
        /// Obtient les trendlines
        /// </summary>
        public (Trendline Up, Trendline Down) GetTrendlines(string instrument)
        {
            var data = GetScalpingData(instrument);
            return (data?.TrendlineUp, data?.TrendlineDown);
        }

        /// <summary>
        /// Obtient la consolidation active
        /// </summary>
        public ConsolidationZone GetActiveConsolidation(string instrument)
        {
            return GetScalpingData(instrument)?.ActiveConsolidation;
        }
        #endregion
    }

    #region Supporting Classes
    public class ScalpingSettings
    {
        // Pivots
        public int PivotLookback { get; set; } = 5;
        public int MaxPivots { get; set; } = 20;
        
        // Zones S/R
        public int MaxSRZones { get; set; } = 3;
        public double ZoneTolerance { get; set; } = 0.3; // × ATR
        public int MinZoneTouches { get; set; } = 2;
        
        // Consolidation
        public int MinConsolidationBars { get; set; } = 8;
        public int ConsolidationLookback { get; set; } = 15;
        public double ConsolidationATRMult { get; set; } = 1.5;
        
        // Trendlines
        public int MinTrendlineTouches { get; set; } = 2;
        public double TrendlineTolerance { get; set; } = 0.2; // × ATR
        
        // SMA
        public double SMATolerance { get; set; } = 0.3; // × ATR
        
        // Volume
        public double VolumeConfirmMin { get; set; } = 0.6;
        public double BreakoutVolumeMult { get; set; } = 1.5;
        public double RetestVolumeMax { get; set; } = 1.2;
        
        // Breakout
        public double BreakoutBodyRatio { get; set; } = 0.6;
        
        // Retest
        public int RetestMinBars { get; set; } = 1;
        public int RetestMaxBars { get; set; } = 20;
        
        // RSI
        public double RSIOversold { get; set; } = 40;
        public double RSIOverbought { get; set; } = 60;
        
        // Risk
        public double StopLossATRMult { get; set; } = 1.5;
        public double TP1RRRatio { get; set; } = 1.5;
        public double TP2RRRatio { get; set; } = 2.5;
        
        // Général
        public int MaxCandleHistory { get; set; } = 200;
        public int SignalExpiryMinutes { get; set; } = 60;
    }

    public class ScalpingData
    {
        public string Instrument { get; set; }
        public List<CandleData> Candles { get; set; }
        public double ATR { get; set; }
        public double SMA19 { get; set; }
        public double SMA50 { get; set; }
        public double RSI { get; set; }
        public double VolumeSMA { get; set; }
        public DateTime LastUpdate { get; set; }
        
        // Pivots
        public List<PivotPoint> PivotHighs { get; set; }
        public List<PivotPoint> PivotLows { get; set; }
        
        // Zones
        public List<SRZone> SupportZones { get; set; }
        public List<SRZone> ResistanceZones { get; set; }
        public List<SRZone> BrokenZones { get; set; }
        
        // Consolidation
        public ConsolidationZone ActiveConsolidation { get; set; }
        public ConsolidationZone LastBrokenConsolidation { get; set; }
        
        // Trendlines
        public Trendline TrendlineUp { get; set; }
        public Trendline TrendlineDown { get; set; }
        
        // Trend
        public ScalpingTrendDirection HTFTrend { get; set; }
        
        public ScalpingData(string instrument, ScalpingSettings settings)
        {
            Instrument = instrument;
            Candles = new List<CandleData>();
            PivotHighs = new List<PivotPoint>();
            PivotLows = new List<PivotPoint>();
            SupportZones = new List<SRZone>();
            ResistanceZones = new List<SRZone>();
            BrokenZones = new List<SRZone>();
            HTFTrend = ScalpingTrendDirection.Unknown;
        }
    }

    public class CandleData
    {
        public double Open { get; set; }
        public double High { get; set; }
        public double Low { get; set; }
        public double Close { get; set; }
        public double Volume { get; set; }
        public DateTime Time { get; set; }
        public int BarIndex { get; set; }
        public CandlePattern Pattern { get; set; }
    }

    public class PivotPoint
    {
        public double Price { get; set; }
        public int BarIndex { get; set; }
        public DateTime Time { get; set; }
        public PivotType Type { get; set; }
    }

    public enum PivotType { High, Low }

    public class SRZone
    {
        public string Id { get; set; }
        public SRZoneType Type { get; set; }
        public double HighPrice { get; set; }
        public double LowPrice { get; set; }
        public double MidPrice => (HighPrice + LowPrice) / 2;
        public int CreatedBar { get; set; }
        public int TouchCount { get; set; }
        public int LastTouchBar { get; set; }
        public bool IsBroken { get; set; }
        public int BrokenBar { get; set; }
        public TradeDirection BreakoutDirection { get; set; }
    }

    public enum SRZoneType { Support, Resistance }

    public class ConsolidationZone
    {
        public string Id { get; set; }
        public double HighPrice { get; set; }
        public double LowPrice { get; set; }
        public int StartBar { get; set; }
        public int BarCount { get; set; }
        public bool IsBroken { get; set; }
        public TradeDirection BreakoutDirection { get; set; }
        public int BreakoutBar { get; set; }
    }

    public class Trendline
    {
        public string Id { get; set; }
        public double StartPrice { get; set; }
        public int StartBar { get; set; }
        public double Slope { get; set; }
        public TrendlineDirection Direction { get; set; }
        public int TouchCount { get; set; }
        public bool IsValid { get; set; }
        
        public double GetPriceAtBar(int barIndex)
        {
            return StartPrice + Slope * (barIndex - StartBar);
        }
    }

    public enum TrendlineDirection { Up, Down }

    public enum CandlePattern
    {
        None,
        Doji,
        Hammer,
        InvertedHammer,
        ShootingStar,
        HangingMan,
        BullishEngulfing,
        BearishEngulfing,
        BullishPinBar,
        BearishPinBar,
        BullishMarubozu,
        BearishMarubozu,
        MorningStar,
        EveningStar,
        ThreeWhiteSoldiers,
        ThreeBlackCrows
    }

    public enum ScalpingSetupType { A, B, C, D }
    public enum ScalpingTrendDirection { Unknown, Bullish, Bearish, Flat }

    public class ScalpingSignal
    {
        public string Id { get; set; }
        public string Instrument { get; set; }
        public ScalpingSetupType Setup { get; set; }
        public bool IsLong { get; set; }
        public double EntryPrice { get; set; }
        public double StopLoss { get; set; }
        public double TakeProfit1 { get; set; }
        public double TakeProfit2 { get; set; }
        public DateTime Time { get; set; }
        public int BarIndex { get; set; }
        public int Strength { get; set; }
        public string Description { get; set; }
        
        // Contexte
        public double ATR { get; set; }
        public double SMA19 { get; set; }
        public double RSI { get; set; }
        public double Volume { get; set; }
        public double VolumeSMA { get; set; }
        public CandlePattern Pattern { get; set; }
        public ScalpingTrendDirection HTFTrend { get; set; }
        
        public string SetupLabel => $"{Setup}{(IsLong ? "↑" : "↓")}";
        public double RiskReward1 => Math.Abs(TakeProfit1 - EntryPrice) / Math.Abs(EntryPrice - StopLoss);
    }

    public class TrendChangeEvent
    {
        public string Instrument { get; set; }
        public ScalpingTrendDirection PreviousTrend { get; set; }
        public ScalpingTrendDirection NewTrend { get; set; }
        public DateTime Time { get; set; }
    }

    public class ZoneEvent
    {
        public SRZone Zone { get; set; }
        public string Instrument { get; set; }
    }
    #endregion
}
