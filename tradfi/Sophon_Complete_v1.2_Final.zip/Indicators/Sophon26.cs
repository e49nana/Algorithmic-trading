#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.AddOns.Sophon;
#endregion

//===============================================================================
// SOPHON26 DASHBOARD v5.0
// Indicateur Visuel Avancé pour NinjaTrader
//
// Ce dashboard affiche:
//   - Zones SMC (Order Blocks, FVG, Liquidity)
//   - Structure de marché (Pivots, BOS, ChoCH)
//   - Signaux actifs avec niveaux SL/TP
//   - Panel d'information en temps réel
//   - Statistiques de performance
//   - Contrôles manuels (via boutons)
//   - Alertes visuelles et sonores
//
// Copyright (c) 2026 Algosphere Quant - Emmanuel
//===============================================================================

namespace NinjaTrader.NinjaScript.Indicators
{
    public class Sophon26 : Indicator
    {
        #region ═══════════════════════════════════════════════════════════════
        //                          MODULES REFERENCE
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        // Référence aux modules Sophon (injectés depuis la stratégie ou créés localement)
        private SophonSMC _smcModule;
        private SophonAI _aiModule;
        private bool _useExternalModules;
        
        // Indicateurs techniques
        private ATR _atr;
        private SMA _sma20;
        private SMA _sma50;
        
        // État du dashboard
        private DashboardState _state;
        private DateTime _lastPanelUpdate;
        private string _currentInstrument;
        
        // Objets de dessin
        private Dictionary<string, string> _drawnObjects;
        private int _maxDrawnObjects = 100;

        #region ═══════════════════════════════════════════════════════════════
        //                      USER PARAMETERS
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        #region 1. Display Settings
        [NinjaScriptProperty]
        [Display(Name = "Show Order Blocks", Order = 1, GroupName = "1. Display")]
        public bool ShowOrderBlocks { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show FVG Zones", Order = 2, GroupName = "1. Display")]
        public bool ShowFVG { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Liquidity Zones", Order = 3, GroupName = "1. Display")]
        public bool ShowLiquidity { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Pivots", Order = 4, GroupName = "1. Display")]
        public bool ShowPivots { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Structure Labels", Order = 5, GroupName = "1. Display")]
        public bool ShowStructureLabels { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Signals", Order = 6, GroupName = "1. Display")]
        public bool ShowSignals { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Info Panel", Order = 7, GroupName = "1. Display")]
        public bool ShowInfoPanel { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Premium/Discount", Order = 8, GroupName = "1. Display")]
        public bool ShowPremiumDiscount { get; set; }
        #endregion

        #region 2. Colors
        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Bullish OB Color", Order = 1, GroupName = "2. Colors")]
        public Brush BullishOBColor { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Bearish OB Color", Order = 2, GroupName = "2. Colors")]
        public Brush BearishOBColor { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Bullish FVG Color", Order = 3, GroupName = "2. Colors")]
        public Brush BullishFVGColor { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Bearish FVG Color", Order = 4, GroupName = "2. Colors")]
        public Brush BearishFVGColor { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Buy Liquidity Color", Order = 5, GroupName = "2. Colors")]
        public Brush BuyLiquidityColor { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Sell Liquidity Color", Order = 6, GroupName = "2. Colors")]
        public Brush SellLiquidityColor { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Premium Zone Color", Order = 7, GroupName = "2. Colors")]
        public Brush PremiumColor { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Discount Zone Color", Order = 8, GroupName = "2. Colors")]
        public Brush DiscountColor { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Signal Long Color", Order = 9, GroupName = "2. Colors")]
        public Brush SignalLongColor { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Signal Short Color", Order = 10, GroupName = "2. Colors")]
        public Brush SignalShortColor { get; set; }
        #endregion

        #region 3. SMC Settings
        [NinjaScriptProperty]
        [Range(3, 10)]
        [Display(Name = "Pivot Lookback", Order = 1, GroupName = "3. SMC")]
        public int PivotLookback { get; set; }

        [NinjaScriptProperty]
        [Range(5, 50)]
        [Display(Name = "Max Order Blocks", Order = 2, GroupName = "3. SMC")]
        public int MaxOrderBlocks { get; set; }

        [NinjaScriptProperty]
        [Range(5, 50)]
        [Display(Name = "Max FVG Zones", Order = 3, GroupName = "3. SMC")]
        public int MaxFVGZones { get; set; }

        [NinjaScriptProperty]
        [Range(1.0, 5.0)]
        [Display(Name = "OB Impulse Multiplier", Order = 4, GroupName = "3. SMC")]
        public double OBImpulseMultiplier { get; set; }

        [NinjaScriptProperty]
        [Range(0.1, 1.0)]
        [Display(Name = "FVG Min ATR Ratio", Order = 5, GroupName = "3. SMC")]
        public double FVGMinATRRatio { get; set; }
        #endregion

        #region 4. Panel Settings
        [NinjaScriptProperty]
        [Display(Name = "Panel Position", Order = 1, GroupName = "4. Panel")]
        public PanelPosition InfoPanelPosition { get; set; }

        [NinjaScriptProperty]
        [Range(150, 400)]
        [Display(Name = "Panel Width", Order = 2, GroupName = "4. Panel")]
        public int PanelWidth { get; set; }

        [NinjaScriptProperty]
        [Range(8, 14)]
        [Display(Name = "Font Size", Order = 3, GroupName = "4. Panel")]
        public int FontSize { get; set; }

        [NinjaScriptProperty]
        [Range(30, 80)]
        [Display(Name = "Panel Opacity %", Order = 4, GroupName = "4. Panel")]
        public int PanelOpacity { get; set; }
        #endregion

        #region 5. Alerts
        [NinjaScriptProperty]
        [Display(Name = "Enable Alerts", Order = 1, GroupName = "5. Alerts")]
        public bool EnableAlerts { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Alert on New Signal", Order = 2, GroupName = "5. Alerts")]
        public bool AlertOnSignal { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Alert on Structure Change", Order = 3, GroupName = "5. Alerts")]
        public bool AlertOnStructureChange { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Alert on Liquidity Sweep", Order = 4, GroupName = "5. Alerts")]
        public bool AlertOnLiquiditySweep { get; set; }
        #endregion

        #region ═══════════════════════════════════════════════════════════════
        //                     INITIALIZATION
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        protected override void OnStateChange()
        {
            switch (State)
            {
                case State.SetDefaults:
                    SetDefaults();
                    break;
                    
                case State.Configure:
                    ConfigureIndicator();
                    break;
                    
                case State.DataLoaded:
                    InitializeModules();
                    break;
                    
                case State.Historical:
                    break;
                    
                case State.Realtime:
                    _state.IsRealtime = true;
                    break;
                    
                case State.Terminated:
                    CleanupDrawings();
                    break;
            }
        }

        private void SetDefaults()
        {
            Description = "Sophon26 - Advanced SMC Dashboard with Real-time Analysis";
            Name = "Sophon26";
            Calculate = Calculate.OnBarClose;
            IsOverlay = true;
            DisplayInDataBox = false;
            DrawOnPricePanel = true;
            DrawHorizontalGridLines = false;
            DrawVerticalGridLines = false;
            PaintPriceMarkers = false;
            ScaleJustification = ScaleJustification.Right;
            IsSuspendedWhileInactive = true;

            // Display defaults
            ShowOrderBlocks = true;
            ShowFVG = true;
            ShowLiquidity = true;
            ShowPivots = true;
            ShowStructureLabels = true;
            ShowSignals = true;
            ShowInfoPanel = true;
            ShowPremiumDiscount = true;

            // Color defaults
            BullishOBColor = Brushes.DarkGreen;
            BearishOBColor = Brushes.DarkRed;
            BullishFVGColor = Brushes.LimeGreen;
            BearishFVGColor = Brushes.OrangeRed;
            BuyLiquidityColor = Brushes.DodgerBlue;
            SellLiquidityColor = Brushes.Magenta;
            PremiumColor = Brushes.LightCoral;
            DiscountColor = Brushes.LightGreen;
            SignalLongColor = Brushes.Lime;
            SignalShortColor = Brushes.Red;

            // SMC defaults
            PivotLookback = 5;
            MaxOrderBlocks = 20;
            MaxFVGZones = 15;
            OBImpulseMultiplier = 2.0;
            FVGMinATRRatio = 0.3;

            // Panel defaults
            InfoPanelPosition = PanelPosition.TopRight;
            PanelWidth = 250;
            FontSize = 10;
            PanelOpacity = 70;

            // Alert defaults
            EnableAlerts = true;
            AlertOnSignal = true;
            AlertOnStructureChange = true;
            AlertOnLiquiditySweep = true;
        }

        private void ConfigureIndicator()
        {
            _drawnObjects = new Dictionary<string, string>();
            _state = new DashboardState();
        }

        private void InitializeModules()
        {
            _currentInstrument = Instrument.MasterInstrument.Name;
            
            // Créer les indicateurs techniques
            _atr = ATR(14);
            _sma20 = SMA(20);
            _sma50 = SMA(50);
            
            // Initialiser le module SMC local
            _smcModule = new SophonSMC();
            _smcModule.Settings = new SMCSettings
            {
                PivotLookback = PivotLookback,
                OBImpulseMultiplier = OBImpulseMultiplier,
                FVGMinATRRatio = FVGMinATRRatio
            };
            _smcModule.Initialize();
            _smcModule.RegisterInstrument(_currentInstrument);
            
            // Connecter les événements
            _smcModule.OnNewSignal += OnNewSignal;
            _smcModule.OnStructureShift += OnStructureShift;
            _smcModule.OnLiquiditySweep += OnLiquiditySweep;
            
            // Initialiser le module AI (optionnel)
            _aiModule = new SophonAI();
            _aiModule.Initialize();
            
            _useExternalModules = false;
        }

        /// <summary>
        /// Injecte des modules externes (depuis SophonStrategy)
        /// </summary>
        public void InjectModules(SophonSMC smcModule, SophonAI aiModule)
        {
            if (smcModule != null)
            {
                _smcModule = smcModule;
                _useExternalModules = true;
            }
            if (aiModule != null)
            {
                _aiModule = aiModule;
            }
        }

        #region ═══════════════════════════════════════════════════════════════
        //                      MAIN UPDATE LOOP
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        protected override void OnBarUpdate()
        {
            if (CurrentBar < 50) return;
            
            double currentATR = _atr[0];
            
            // Mettre à jour le module SMC avec les nouvelles données
            if (_smcModule != null && !_useExternalModules)
            {
                _smcModule.UpdateInstrument(
                    _currentInstrument,
                    Open[0], High[0], Low[0], Close[0],
                    Volume[0], Time[0], CurrentBar, currentATR
                );
            }
            
            // Mettre à jour le module AI
            if (_aiModule != null)
            {
                _aiModule.UpdateRegimeData(_currentInstrument, Close[0], High[0], Low[0], 
                                           currentATR, Volume[0], Time[0]);
            }
            
            // Dessiner les éléments
            DrawSMCElements();
            
            // Mettre à jour le panel d'information
            if (ShowInfoPanel && (DateTime.Now - _lastPanelUpdate).TotalMilliseconds > 500)
            {
                UpdateInfoPanel();
                _lastPanelUpdate = DateTime.Now;
            }
        }

        #region ═══════════════════════════════════════════════════════════════
        //                      DRAWING METHODS
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        private void DrawSMCElements()
        {
            if (_smcModule == null) return;
            
            // Nettoyer les anciens dessins
            CleanupOldDrawings();
            
            // Dessiner dans l'ordre (du fond vers l'avant)
            if (ShowPremiumDiscount)
                DrawPremiumDiscountZones();
            
            if (ShowOrderBlocks)
                DrawOrderBlocks();
            
            if (ShowFVG)
                DrawFVGZones();
            
            if (ShowLiquidity)
                DrawLiquidityZones();
            
            if (ShowPivots)
                DrawPivots();
            
            if (ShowStructureLabels)
                DrawStructureLabels();
            
            if (ShowSignals)
                DrawSignals();
        }

        private void DrawOrderBlocks()
        {
            var orderBlocks = _smcModule.GetActiveOrderBlocks(_currentInstrument);
            if (orderBlocks == null) return;
            
            int count = 0;
            foreach (var ob in orderBlocks.Where(o => o.State != ZoneState.Broken).Take(MaxOrderBlocks))
            {
                string tag = $"OB_{ob.Id}";
                
                Brush color = ob.Type == OrderBlockType.Bullish || ob.Type == OrderBlockType.BullishBreaker
                    ? BullishOBColor : BearishOBColor;
                
                // Ajuster l'opacité selon l'état
                int opacity = ob.State switch
                {
                    ZoneState.Fresh => 60,
                    ZoneState.Tested => 40,
                    ZoneState.Weakened => 25,
                    _ => 15
                };
                
                Brush fillBrush = new SolidColorBrush(((SolidColorBrush)color).Color) { Opacity = opacity / 100.0 };
                
                int startBar = Math.Max(0, CurrentBar - ob.BarIndex);
                int endBar = 0;
                
                Draw.Rectangle(this, tag, false, startBar, ob.HighPrice, endBar, ob.LowPrice, 
                              color, fillBrush, opacity);
                
                // Label
                if (ShowStructureLabels)
                {
                    string label = ob.Type == OrderBlockType.BullishBreaker || ob.Type == OrderBlockType.BearishBreaker
                        ? "BB" : "OB";
                    Draw.Text(this, $"{tag}_lbl", label, startBar, 
                             ob.Type == OrderBlockType.Bullish ? ob.LowPrice : ob.HighPrice,
                             color);
                }
                
                RegisterDrawnObject(tag);
                count++;
            }
        }

        private void DrawFVGZones()
        {
            var fvgs = _smcModule.GetActiveFVGs(_currentInstrument);
            if (fvgs == null) return;
            
            foreach (var fvg in fvgs.Where(f => f.State != ZoneState.Mitigated).Take(MaxFVGZones))
            {
                string tag = $"FVG_{fvg.Id}";
                
                Brush color = fvg.Type == FVGType.Bullish ? BullishFVGColor : BearishFVGColor;
                
                int opacity = fvg.FillPercent < 0.3 ? 40 : fvg.FillPercent < 0.6 ? 25 : 15;
                Brush fillBrush = new SolidColorBrush(((SolidColorBrush)color).Color) { Opacity = opacity / 100.0 };
                
                int startBar = Math.Max(0, CurrentBar - fvg.BarIndex);
                int endBar = 0;
                
                Draw.Rectangle(this, tag, false, startBar, fvg.HighPrice, endBar, fvg.LowPrice,
                              color, fillBrush, opacity);
                
                // CE Level (50%)
                double ceLevel = (fvg.HighPrice + fvg.LowPrice) / 2;
                Draw.Line(this, $"{tag}_ce", startBar, ceLevel, endBar, ceLevel, 
                         Brushes.Yellow, DashStyleHelper.Dot, 1);
                
                RegisterDrawnObject(tag);
            }
        }

        private void DrawLiquidityZones()
        {
            var liquidityZones = _smcModule.GetActiveLiquidity(_currentInstrument);
            if (liquidityZones == null) return;
            
            foreach (var liq in liquidityZones.Where(l => !l.IsTaken).Take(20))
            {
                string tag = $"LIQ_{liq.Id}";
                
                Brush color = liq.Type == LiquidityType.BuySide || 
                              liq.Type == LiquidityType.EqualHighs ||
                              liq.Type == LiquidityType.PDH
                    ? BuyLiquidityColor : SellLiquidityColor;
                
                int startBar = Math.Max(0, CurrentBar - liq.BarIndex);
                
                // Ligne pointillée pour la liquidité
                Draw.Line(this, tag, startBar, liq.Price, 0, liq.Price,
                         color, DashStyleHelper.Dash, 2);
                
                // Label avec type
                string label = liq.Type switch
                {
                    LiquidityType.EqualHighs => "EQH",
                    LiquidityType.EqualLows => "EQL",
                    LiquidityType.PDH => "PDH",
                    LiquidityType.PDL => "PDL",
                    LiquidityType.PWH => "PWH",
                    LiquidityType.PWL => "PWL",
                    _ => "LIQ"
                };
                
                Draw.Text(this, $"{tag}_lbl", label, 2, liq.Price, color);
                
                RegisterDrawnObject(tag);
            }
        }

        private void DrawPivots()
        {
            var context = _smcModule.GetMarketContext(_currentInstrument);
            if (context == null || context.RecentPivots == null) return;
            
            foreach (var pivot in context.RecentPivots.Take(20))
            {
                string tag = $"PVT_{pivot.BarIndex}_{pivot.Type}";
                
                Brush color = pivot.Type == PivotType.HH || pivot.Type == PivotType.HL
                    ? Brushes.LimeGreen
                    : pivot.Type == PivotType.LH || pivot.Type == PivotType.LL
                        ? Brushes.Red
                        : Brushes.Yellow;
                
                int barAgo = Math.Max(0, CurrentBar - pivot.BarIndex);
                
                // Triangle marker
                bool isHigh = pivot.Type == PivotType.HH || pivot.Type == PivotType.LH || pivot.Type == PivotType.EQH;
                double yOffset = isHigh ? pivot.Price + _atr[0] * 0.3 : pivot.Price - _atr[0] * 0.3;
                
                Draw.Text(this, tag, pivot.Type.ToString(), barAgo, yOffset, color);
                
                RegisterDrawnObject(tag);
            }
        }

        private void DrawStructureLabels()
        {
            var context = _smcModule.GetMarketContext(_currentInstrument);
            if (context == null) return;
            
            // Afficher BOS/ChoCH récents
            // Note: Dans une implémentation complète, on stockerait l'historique des événements
        }

        private void DrawPremiumDiscountZones()
        {
            var context = _smcModule.GetMarketContext(_currentInstrument);
            if (context == null) return;
            
            // Calculer les zones basées sur le swing range récent
            double swingHigh = context.RecentPivots?
                .Where(p => p.Type == PivotType.HH || p.Type == PivotType.LH)
                .OrderByDescending(p => p.Price)
                .FirstOrDefault()?.Price ?? High[0];
            
            double swingLow = context.RecentPivots?
                .Where(p => p.Type == PivotType.LL || p.Type == PivotType.HL)
                .OrderBy(p => p.Price)
                .FirstOrDefault()?.Price ?? Low[0];
            
            double range = swingHigh - swingLow;
            if (range <= 0) return;
            
            double equilibrium = swingLow + range * 0.5;
            double premiumStart = swingLow + range * 0.618;
            double discountEnd = swingLow + range * 0.382;
            
            // Premium zone (top)
            Draw.Rectangle(this, "PremiumZone", false, 50, swingHigh, 0, premiumStart,
                          Brushes.Transparent, PremiumColor, 15);
            
            // Discount zone (bottom)
            Draw.Rectangle(this, "DiscountZone", false, 50, discountEnd, 0, swingLow,
                          Brushes.Transparent, DiscountColor, 15);
            
            // Equilibrium line
            Draw.Line(this, "Equilibrium", 50, equilibrium, 0, equilibrium,
                     Brushes.White, DashStyleHelper.Dash, 1);
            
            RegisterDrawnObject("PremiumZone");
            RegisterDrawnObject("DiscountZone");
            RegisterDrawnObject("Equilibrium");
        }

        private void DrawSignals()
        {
            var signals = _smcModule.GetActiveSignals();
            if (signals == null) return;
            
            foreach (var signal in signals.Where(s => s.Instrument == _currentInstrument && !s.IsExpired))
            {
                string tag = $"SIG_{signal.Id}";
                
                Brush color = signal.IsLong ? SignalLongColor : SignalShortColor;
                
                // Entry arrow
                int barAgo = Math.Max(0, CurrentBar - signal.BarIndex);
                
                if (signal.IsLong)
                {
                    Draw.ArrowUp(this, $"{tag}_entry", barAgo, signal.EntryPrice - _atr[0] * 0.2, color);
                }
                else
                {
                    Draw.ArrowDown(this, $"{tag}_entry", barAgo, signal.EntryPrice + _atr[0] * 0.2, color);
                }
                
                // SL line
                Draw.Line(this, $"{tag}_sl", barAgo, signal.StopLoss, 0, signal.StopLoss,
                         Brushes.Red, DashStyleHelper.Solid, 2);
                
                // TP1 line
                if (signal.TakeProfit1 > 0)
                {
                    Draw.Line(this, $"{tag}_tp1", barAgo, signal.TakeProfit1, 0, signal.TakeProfit1,
                             Brushes.Green, DashStyleHelper.Solid, 2);
                }
                
                // TP2 line
                if (signal.TakeProfit2 > 0)
                {
                    Draw.Line(this, $"{tag}_tp2", barAgo, signal.TakeProfit2, 0, signal.TakeProfit2,
                             Brushes.DarkGreen, DashStyleHelper.Dash, 1);
                }
                
                // Signal label
                string label = $"{signal.GetSetupLabel()}\nR:R {signal.RiskRewardRatio:F1}";
                double labelY = signal.IsLong ? signal.EntryPrice - _atr[0] * 0.5 : signal.EntryPrice + _atr[0] * 0.5;
                Draw.Text(this, $"{tag}_lbl", label, barAgo, labelY, color);
                
                RegisterDrawnObject(tag);
            }
        }

        #region ═══════════════════════════════════════════════════════════════
        //                      INFO PANEL
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        private void UpdateInfoPanel()
        {
            if (!ShowInfoPanel) return;
            
            var context = _smcModule?.GetMarketContext(_currentInstrument);
            var regime = _aiModule?.GetCurrentRegime(_currentInstrument) ?? MarketRegime.Unknown;
            var signals = _smcModule?.GetActiveSignals()?.Where(s => s.Instrument == _currentInstrument).ToList();
            
            // Construire le texte du panel
            var sb = new System.Text.StringBuilder();
            
            sb.AppendLine("═══ SOPHON26 DASHBOARD ═══");
            sb.AppendLine($"Instrument: {_currentInstrument}");
            sb.AppendLine($"Time: {Time[0]:HH:mm:ss}");
            sb.AppendLine();
            
            // Structure
            sb.AppendLine("── MARKET STRUCTURE ──");
            sb.AppendLine($"Structure: {context?.Structure ?? MarketStructure.Unknown}");
            sb.AppendLine($"Position: {context?.CurrentPosition ?? PricePosition.Equilibrium}");
            sb.AppendLine($"Regime: {regime}");
            sb.AppendLine();
            
            // Zones actives
            sb.AppendLine("── ACTIVE ZONES ──");
            var obs = _smcModule?.GetActiveOrderBlocks(_currentInstrument);
            var fvgs = _smcModule?.GetActiveFVGs(_currentInstrument);
            var liqs = _smcModule?.GetActiveLiquidity(_currentInstrument);
            
            sb.AppendLine($"Order Blocks: {obs?.Count ?? 0}");
            sb.AppendLine($"FVG Zones: {fvgs?.Count ?? 0}");
            sb.AppendLine($"Liquidity: {liqs?.Count ?? 0}");
            sb.AppendLine();
            
            // Signaux
            sb.AppendLine("── SIGNALS ──");
            if (signals != null && signals.Count > 0)
            {
                foreach (var sig in signals.Take(3))
                {
                    sb.AppendLine($"• {sig.GetSetupLabel()} {sig.Direction}");
                    sb.AppendLine($"  Entry: {sig.EntryPrice:F2} | SL: {sig.StopLoss:F2}");
                }
            }
            else
            {
                sb.AppendLine("No active signals");
            }
            sb.AppendLine();
            
            // Technical
            sb.AppendLine("── TECHNICALS ──");
            sb.AppendLine($"ATR(14): {_atr[0]:F2}");
            sb.AppendLine($"SMA20: {_sma20[0]:F2}");
            sb.AppendLine($"SMA50: {_sma50[0]:F2}");
            
            // Trend
            string trend = Close[0] > _sma20[0] && _sma20[0] > _sma50[0] ? "▲ BULLISH"
                         : Close[0] < _sma20[0] && _sma20[0] < _sma50[0] ? "▼ BEARISH"
                         : "◆ NEUTRAL";
            sb.AppendLine($"Trend: {trend}");
            
            // Session
            var session = SophonHelpers.GetCurrentSession(Time[0]);
            sb.AppendLine($"Session: {session}");
            
            // Dessiner le panel
            DrawInfoPanelText(sb.ToString());
        }

        private void DrawInfoPanelText(string text)
        {
            // Position du panel
            int xOffset = InfoPanelPosition == PanelPosition.TopRight || InfoPanelPosition == PanelPosition.BottomRight
                ? ChartPanel.W - PanelWidth - 10 : 10;
            int yOffset = InfoPanelPosition == PanelPosition.TopLeft || InfoPanelPosition == PanelPosition.TopRight
                ? 10 : ChartPanel.H - 300;
            
            // Utiliser Draw.TextFixed pour le panel
            Draw.TextFixed(this, "InfoPanel", text, 
                          InfoPanelPosition == PanelPosition.TopRight ? TextPosition.TopRight :
                          InfoPanelPosition == PanelPosition.TopLeft ? TextPosition.TopLeft :
                          InfoPanelPosition == PanelPosition.BottomRight ? TextPosition.BottomRight :
                          TextPosition.BottomLeft,
                          Brushes.White, new SimpleFont("Consolas", FontSize), Brushes.Black, Brushes.DimGray, PanelOpacity);
        }

        #region ═══════════════════════════════════════════════════════════════
        //                      EVENT HANDLERS
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        private void OnNewSignal(object sender, SMCSignal signal)
        {
            if (!EnableAlerts || !AlertOnSignal) return;
            if (signal.Instrument != _currentInstrument) return;
            
            string message = $"SOPHON: New {signal.GetSetupLabel()} {signal.Direction} @ {signal.EntryPrice:F2}";
            
            Alert($"NewSignal_{signal.Id}", Priority.High, message,
                  NinjaTrader.Core.Globals.InstallDir + @"\sounds\Alert2.wav", 10,
                  signal.IsLong ? SignalLongColor : SignalShortColor, Brushes.White);
            
            _state.LastSignalTime = DateTime.Now;
            _state.SignalsToday++;
        }

        private void OnStructureShift(object sender, StructureShiftEvent shift)
        {
            if (!EnableAlerts || !AlertOnStructureChange) return;
            
            string message = $"SOPHON: {shift.Type} detected - {shift.Direction}";
            
            Alert($"Structure_{shift.BarIndex}", Priority.Medium, message,
                  NinjaTrader.Core.Globals.InstallDir + @"\sounds\Alert3.wav", 5,
                  Brushes.Yellow, Brushes.Black);
        }

        private void OnLiquiditySweep(object sender, LiquiditySweepEvent sweep)
        {
            if (!EnableAlerts || !AlertOnLiquiditySweep) return;
            
            string message = $"SOPHON: Liquidity Sweep @ {sweep.SweepPrice:F2}";
            
            Alert($"Sweep_{sweep.BarIndex}", Priority.Medium, message,
                  NinjaTrader.Core.Globals.InstallDir + @"\sounds\Alert4.wav", 5,
                  Brushes.Magenta, Brushes.White);
        }

        #region ═══════════════════════════════════════════════════════════════
        //                      UTILITIES
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        private void RegisterDrawnObject(string tag)
        {
            if (!_drawnObjects.ContainsKey(tag))
            {
                _drawnObjects[tag] = DateTime.Now.ToString("HHmmss");
            }
            
            // Nettoyer si trop d'objets
            if (_drawnObjects.Count > _maxDrawnObjects)
            {
                var oldestKeys = _drawnObjects
                    .OrderBy(kvp => kvp.Value)
                    .Take(20)
                    .Select(kvp => kvp.Key)
                    .ToList();
                
                foreach (var key in oldestKeys)
                {
                    RemoveDrawObject(key);
                    _drawnObjects.Remove(key);
                }
            }
        }

        private void CleanupOldDrawings()
        {
            // Supprimer les objets liés à des zones expirées
            var keysToRemove = new List<string>();
            
            foreach (var key in _drawnObjects.Keys.ToList())
            {
                // Vérifier si l'objet doit être supprimé
                // (zones qui n'existent plus, etc.)
            }
            
            foreach (var key in keysToRemove)
            {
                RemoveDrawObject(key);
                _drawnObjects.Remove(key);
            }
        }

        private void CleanupDrawings()
        {
            foreach (var key in _drawnObjects.Keys.ToList())
            {
                RemoveDrawObject(key);
            }
            _drawnObjects.Clear();
        }

        #region ═══════════════════════════════════════════════════════════════
        //                      PUBLIC INTERFACE
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        /// <summary>
        /// Force le rafraîchissement du dashboard
        /// </summary>
        public void RefreshDashboard()
        {
            CleanupDrawings();
            DrawSMCElements();
            UpdateInfoPanel();
        }

        /// <summary>
        /// Obtient l'état actuel du dashboard
        /// </summary>
        public DashboardState GetState()
        {
            return _state;
        }

        /// <summary>
        /// Obtient le contexte de marché actuel
        /// </summary>
        public MarketContext GetCurrentContext()
        {
            return _smcModule?.GetMarketContext(_currentInstrument);
        }

        /// <summary>
        /// Obtient les signaux actifs
        /// </summary>
        public List<SMCSignal> GetActiveSignals()
        {
            return _smcModule?.GetActiveSignals()?
                .Where(s => s.Instrument == _currentInstrument)
                .ToList() ?? new List<SMCSignal>();
        }
    }

    #region Supporting Classes
    /// <summary>
    /// Position du panel d'information
    /// </summary>
    public enum PanelPosition
    {
        TopLeft,
        TopRight,
        BottomLeft,
        BottomRight
    }

    /// <summary>
    /// État du dashboard
    /// </summary>
    public class DashboardState
    {
        public bool IsRealtime { get; set; }
        public DateTime LastSignalTime { get; set; }
        public int SignalsToday { get; set; }
        public int AlertsToday { get; set; }
        public MarketStructure CurrentStructure { get; set; }
        public MarketRegime CurrentRegime { get; set; }
    }
    #endregion
}
