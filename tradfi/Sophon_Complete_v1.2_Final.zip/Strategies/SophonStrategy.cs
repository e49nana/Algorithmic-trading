#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.AddOns.Sophon;
#endregion

//===============================================================================
// SOPHON STRATEGY v1.0
// Stratégie de Trading Automatisé Avancée pour NinjaTrader
//
// Cette stratégie orchestre tous les modules Sophon:
//   - SophonSMC: Analyse SMC/ICT multi-marchés
//   - SophonRisk: Gestion du risque dynamique
//   - SophonExecution: Exécution automatique des ordres
//   - SophonJournal: Journalisation (à venir)
//
// Modes de fonctionnement:
//   - Automatique: Exécution sans intervention
//   - Semi-automatique: Confirmation manuelle requise
//   - Manuel: Analyse seulement, pas d'exécution
//
// Copyright (c) 2026 Algosphere Quant - Emmanuel
//===============================================================================

namespace NinjaTrader.NinjaScript.Strategies
{
    public class SophonStrategy : Strategy
    {
        #region ═══════════════════════════════════════════════════════════════
        //                          MODULES
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        private SophonSMC _smcModule;
        private SophonRisk _riskModule;
        private SophonExecution _executionModule;
        
        // Indicateurs NinjaTrader
        private Dictionary<string, ATR> _atrIndicators;
        private Dictionary<string, SMA> _smaIndicators;
        private Dictionary<string, RSI> _rsiIndicators;
        
        // État de la stratégie
        private StrategyState _state;
        private DateTime _lastUpdateTime;
        private int _todayTradeCount;
        private double _todayPnL;
        private DateTime _currentDay;
        
        // Signaux en attente de confirmation (mode semi-auto)
        private List<SMCSignal> _pendingSignals;
        private readonly object _signalLock = new object();
        
        // Multi-instruments
        private Dictionary<string, int> _instrumentBarsIndex;
        private List<string> _activeInstruments;

        #region ═══════════════════════════════════════════════════════════════
        //                      USER PARAMETERS
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        #region 1. Mode & General
        [NinjaScriptProperty]
        [Display(Name = "Operation Mode", Order = 1, GroupName = "1. Mode")]
        public OperationMode Mode { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Enable Trading", Order = 2, GroupName = "1. Mode")]
        public bool EnableTrading { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Enable Alerts", Order = 3, GroupName = "1. Mode")]
        public bool EnableAlerts { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Enable Sound", Order = 4, GroupName = "1. Mode")]
        public bool EnableSound { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Debug Mode", Order = 5, GroupName = "1. Mode")]
        public bool DebugMode { get; set; }
        #endregion

        #region 2. Instruments
        [NinjaScriptProperty]
        [Display(Name = "Trade MES", Order = 1, GroupName = "2. Instruments")]
        public bool TradeMES { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Trade MNQ", Order = 2, GroupName = "2. Instruments")]
        public bool TradeMNQ { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Trade MGC", Order = 3, GroupName = "2. Instruments")]
        public bool TradeGC { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Trade MCL", Order = 4, GroupName = "2. Instruments")]
        public bool TradeCL { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Trade M2K", Order = 5, GroupName = "2. Instruments")]
        public bool TradeM2K { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Trade MYM", Order = 6, GroupName = "2. Instruments")]
        public bool TradeMYM { get; set; }
        #endregion

        #region 3. Risk Management
        [NinjaScriptProperty]
        [Display(Name = "Risk Profile", Order = 1, GroupName = "3. Risk")]
        public RiskProfile RiskProfile { get; set; }

        [NinjaScriptProperty]
        [Range(0.001, 0.05)]
        [Display(Name = "Risk Per Trade (%)", Order = 2, GroupName = "3. Risk")]
        public double RiskPerTrade { get; set; }

        [NinjaScriptProperty]
        [Range(0.01, 0.20)]
        [Display(Name = "Max Daily Loss (%)", Order = 3, GroupName = "3. Risk")]
        public double MaxDailyLoss { get; set; }

        [NinjaScriptProperty]
        [Range(0.05, 0.30)]
        [Display(Name = "Max Drawdown (%)", Order = 4, GroupName = "3. Risk")]
        public double MaxDrawdown { get; set; }

        [NinjaScriptProperty]
        [Range(1, 20)]
        [Display(Name = "Max Open Trades", Order = 5, GroupName = "3. Risk")]
        public int MaxOpenTrades { get; set; }

        [NinjaScriptProperty]
        [Range(1, 50)]
        [Display(Name = "Max Trades Per Day", Order = 6, GroupName = "3. Risk")]
        public int MaxTradesPerDay { get; set; }
        #endregion

        #region 4. SMC Settings
        [NinjaScriptProperty]
        [Range(3, 10)]
        [Display(Name = "Pivot Lookback", Order = 1, GroupName = "4. SMC")]
        public int PivotLookback { get; set; }

        [NinjaScriptProperty]
        [Range(5, 20)]
        [Display(Name = "OB Lookback", Order = 2, GroupName = "4. SMC")]
        public int OBLookback { get; set; }

        [NinjaScriptProperty]
        [Range(1.0, 5.0)]
        [Display(Name = "OB Impulse Multiplier", Order = 3, GroupName = "4. SMC")]
        public double OBImpulseMultiplier { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Require Structure Alignment", Order = 4, GroupName = "4. SMC")]
        public bool RequireStructureAlignment { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Use Correlation Filter", Order = 5, GroupName = "4. SMC")]
        public bool UseCorrelationFilter { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Use News Filter", Order = 6, GroupName = "4. SMC")]
        public bool UseNewsFilter { get; set; }
        #endregion

        #region 5. Execution Settings
        [NinjaScriptProperty]
        [Display(Name = "Enable Break-Even", Order = 1, GroupName = "5. Execution")]
        public bool EnableBreakEven { get; set; }

        [NinjaScriptProperty]
        [Range(0.5, 3.0)]
        [Display(Name = "Break-Even Trigger (R)", Order = 2, GroupName = "5. Execution")]
        public double BreakEvenTriggerRR { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Enable Trailing Stop", Order = 3, GroupName = "5. Execution")]
        public bool EnableTrailingStop { get; set; }

        [NinjaScriptProperty]
        [Range(1.0, 5.0)]
        [Display(Name = "Trailing Trigger (R)", Order = 4, GroupName = "5. Execution")]
        public double TrailingTriggerRR { get; set; }

        [NinjaScriptProperty]
        [Range(0.5, 3.0)]
        [Display(Name = "Trailing ATR Multiplier", Order = 5, GroupName = "5. Execution")]
        public double TrailingATRMultiplier { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Enable Partial TPs", Order = 6, GroupName = "5. Execution")]
        public bool EnablePartialTPs { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Enable Pyramiding", Order = 7, GroupName = "5. Execution")]
        public bool EnablePyramiding { get; set; }

        [NinjaScriptProperty]
        [Range(1, 5)]
        [Display(Name = "Max Pyramid Levels", Order = 8, GroupName = "5. Execution")]
        public int MaxPyramidLevels { get; set; }
        #endregion

        #region 6. Sessions
        [NinjaScriptProperty]
        [Display(Name = "Trade Asian Session", Order = 1, GroupName = "6. Sessions")]
        public bool TradeAsianSession { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Trade London Session", Order = 2, GroupName = "6. Sessions")]
        public bool TradeLondonSession { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Trade NY Session", Order = 3, GroupName = "6. Sessions")]
        public bool TradeNYSession { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Trade Overlap Only", Order = 4, GroupName = "6. Sessions")]
        public bool TradeOverlapOnly { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Exit At Session End", Order = 5, GroupName = "6. Sessions")]
        public bool ExitAtSessionEnd { get; set; }
        #endregion

        #region 7. Take Profits
        [NinjaScriptProperty]
        [Range(1.0, 5.0)]
        [Display(Name = "TP1 R:R Ratio", Order = 1, GroupName = "7. Take Profits")]
        public double TP1RRRatio { get; set; }

        [NinjaScriptProperty]
        [Range(2.0, 10.0)]
        [Display(Name = "TP2 R:R Ratio", Order = 2, GroupName = "7. Take Profits")]
        public double TP2RRRatio { get; set; }

        [NinjaScriptProperty]
        [Range(3.0, 15.0)]
        [Display(Name = "TP3 R:R Ratio", Order = 3, GroupName = "7. Take Profits")]
        public double TP3RRRatio { get; set; }

        [NinjaScriptProperty]
        [Range(0.1, 1.0)]
        [Display(Name = "TP1 Exit %", Order = 4, GroupName = "7. Take Profits")]
        public double TP1ExitPercent { get; set; }

        [NinjaScriptProperty]
        [Range(0.1, 1.0)]
        [Display(Name = "TP2 Exit %", Order = 5, GroupName = "7. Take Profits")]
        public double TP2ExitPercent { get; set; }
        #endregion

        #region ═══════════════════════════════════════════════════════════════
        //                     INITIALIZATION
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        protected override void OnStateChange()
        {
            switch (State)
            {
                case State.SetDefaults:
                    SetDefaults();
                    break;
                    
                case State.Configure:
                    ConfigureStrategy();
                    break;
                    
                case State.DataLoaded:
                    InitializeModules();
                    break;
                    
                case State.Historical:
                    // Mode historique pour backtest
                    break;
                    
                case State.Realtime:
                    OnRealtimeStart();
                    break;
                    
                case State.Terminated:
                    OnTerminate();
                    break;
            }
        }

        private void SetDefaults()
        {
            Description = "Sophon - Advanced Automated Trading System based on SMC/ICT";
            Name = "SophonStrategy";
            Calculate = Calculate.OnBarClose;
            EntriesPerDirection = 1;
            EntryHandling = EntryHandling.AllEntries;
            IsExitOnSessionCloseStrategy = false;
            ExitOnSessionCloseSeconds = 30;
            IsFillLimitOnTouch = false;
            MaximumBarsLookBack = MaximumBarsLookBack.TwoHundredFiftySix;
            OrderFillResolution = OrderFillResolution.Standard;
            Slippage = 1;
            StartBehavior = StartBehavior.WaitUntilFlat;
            TimeInForce = TimeInForce.Gtc;
            TraceOrders = false;
            RealtimeErrorHandling = RealtimeErrorHandling.StopCancelClose;
            StopTargetHandling = StopTargetHandling.PerEntryExecution;
            BarsRequiredToTrade = 50;
            IsInstantiatedOnEachOptimizationIteration = true;

            // Default parameters
            Mode = OperationMode.SemiAutomatic;
            EnableTrading = true;
            EnableAlerts = true;
            EnableSound = true;
            DebugMode = false;

            TradeMES = true;
            TradeMNQ = true;
            TradeGC = true;
            TradeCL = false;
            TradeM2K = false;
            TradeMYM = false;

            RiskProfile = RiskProfile.Normal;
            RiskPerTrade = 0.01;
            MaxDailyLoss = 0.03;
            MaxDrawdown = 0.10;
            MaxOpenTrades = 5;
            MaxTradesPerDay = 10;

            PivotLookback = 5;
            OBLookback = 10;
            OBImpulseMultiplier = 2.0;
            RequireStructureAlignment = true;
            UseCorrelationFilter = true;
            UseNewsFilter = true;

            EnableBreakEven = true;
            BreakEvenTriggerRR = 1.0;
            EnableTrailingStop = true;
            TrailingTriggerRR = 1.5;
            TrailingATRMultiplier = 1.5;
            EnablePartialTPs = true;
            EnablePyramiding = false;
            MaxPyramidLevels = 3;

            TradeAsianSession = false;
            TradeLondonSession = true;
            TradeNYSession = true;
            TradeOverlapOnly = false;
            ExitAtSessionEnd = true;

            TP1RRRatio = 1.5;
            TP2RRRatio = 3.0;
            TP3RRRatio = 5.0;
            TP1ExitPercent = 0.5;
            TP2ExitPercent = 0.3;
        }

        private void ConfigureStrategy()
        {
            _activeInstruments = new List<string>();
            _instrumentBarsIndex = new Dictionary<string, int>();
            
            // Ajouter les instruments sélectionnés
            int barsIndex = 0;
            
            // L'instrument principal est déjà BarsInProgress = 0
            string primaryInstrument = Instrument.MasterInstrument.Name;
            _activeInstruments.Add(primaryInstrument);
            _instrumentBarsIndex[primaryInstrument] = barsIndex++;
            
            // Ajouter les instruments supplémentaires
            if (TradeMES && !_activeInstruments.Contains("MES"))
            {
                AddDataSeries("MES", BarsPeriodType.Minute, 3);
                _activeInstruments.Add("MES");
                _instrumentBarsIndex["MES"] = barsIndex++;
            }
            if (TradeMNQ && !_activeInstruments.Contains("MNQ"))
            {
                AddDataSeries("MNQ", BarsPeriodType.Minute, 3);
                _activeInstruments.Add("MNQ");
                _instrumentBarsIndex["MNQ"] = barsIndex++;
            }
            if (TradeGC && !_activeInstruments.Contains("MGC"))
            {
                AddDataSeries("MGC", BarsPeriodType.Minute, 3);
                _activeInstruments.Add("MGC");
                _instrumentBarsIndex["MGC"] = barsIndex++;
            }
            if (TradeCL && !_activeInstruments.Contains("MCL"))
            {
                AddDataSeries("MCL", BarsPeriodType.Minute, 3);
                _activeInstruments.Add("MCL");
                _instrumentBarsIndex["MCL"] = barsIndex++;
            }
            if (TradeM2K && !_activeInstruments.Contains("M2K"))
            {
                AddDataSeries("M2K", BarsPeriodType.Minute, 3);
                _activeInstruments.Add("M2K");
                _instrumentBarsIndex["M2K"] = barsIndex++;
            }
            if (TradeMYM && !_activeInstruments.Contains("MYM"))
            {
                AddDataSeries("MYM", BarsPeriodType.Minute, 3);
                _activeInstruments.Add("MYM");
                _instrumentBarsIndex["MYM"] = barsIndex++;
            }
        }

        private void InitializeModules()
        {
            // Initialiser les collections
            _atrIndicators = new Dictionary<string, ATR>();
            _smaIndicators = new Dictionary<string, SMA>();
            _rsiIndicators = new Dictionary<string, RSI>();
            _pendingSignals = new List<SMCSignal>();
            
            // Créer les indicateurs pour chaque instrument
            foreach (var kvp in _instrumentBarsIndex)
            {
                string instrument = kvp.Key;
                int barsIdx = kvp.Value;
                
                _atrIndicators[instrument] = ATR(BarsArray[barsIdx], 14);
                _smaIndicators[instrument] = SMA(BarsArray[barsIdx], 20);
                _rsiIndicators[instrument] = RSI(BarsArray[barsIdx], 14, 3);
            }
            
            // Initialiser le module SMC
            _smcModule = new SophonSMC();
            _smcModule.Settings = new SMCSettings
            {
                PivotLookback = PivotLookback,
                OBLookback = OBLookback,
                OBImpulseMultiplier = OBImpulseMultiplier,
                RequireStructureAlignment = RequireStructureAlignment,
                TP1RRRatio = TP1RRRatio,
                TP2RRRatio = TP2RRRatio,
                TP3RRRatio = TP3RRRatio
            };
            _smcModule.Initialize();
            _smcModule.OnNewSignal += OnNewSignalReceived;
            _smcModule.OnSignalInvalidated += OnSignalInvalidated;
            
            // Enregistrer les instruments
            foreach (var instrument in _activeInstruments)
            {
                _smcModule.RegisterInstrument(instrument);
            }
            
            // Initialiser le module Risk
            _riskModule = new SophonRisk();
            _riskModule.Settings = new RiskSettings
            {
                MinRiskReward = TP1RRRatio,
                UseCorrelationFilter = UseCorrelationFilter,
                UseNewsFilter = UseNewsFilter,
                TP1RRRatio = TP1RRRatio,
                TP2RRRatio = TP2RRRatio,
                TP3RRRatio = TP3RRRatio
            };
            _riskModule.Initialize();
            
            // Enregistrer le compte
            var accountConfig = CreateAccountConfig();
            _riskModule.RegisterAccount(accountConfig);
            
            // Initialiser le module Execution
            _executionModule = new SophonExecution();
            _executionModule.Settings = new ExecutionSettings
            {
                EnableBreakEven = EnableBreakEven,
                BreakEvenTriggerRR = BreakEvenTriggerRR,
                EnableTrailingStop = EnableTrailingStop,
                TrailingTriggerRR = TrailingTriggerRR,
                TrailingATRMultiplier = TrailingATRMultiplier,
                EnablePartialTakeProfits = EnablePartialTPs,
                TP1ExitPercent = TP1ExitPercent,
                TP2ExitPercent = TP2ExitPercent,
                EnablePyramiding = EnablePyramiding,
                MaxPyramidLevels = MaxPyramidLevels,
                ExitAtSessionEnd = ExitAtSessionEnd
            };
            _executionModule.Initialize();
            
            // Connecter les callbacks d'exécution
            _executionModule.OnOrderRequest = HandleOrderRequest;
            _executionModule.OnModifyRequest = HandleModifyRequest;
            _executionModule.OnCancelRequest = HandleCancelRequest;
            _executionModule.OnTradeOpened += OnTradeOpened;
            _executionModule.OnTradeClosed += OnTradeClosed;
            
            // Initialiser l'état
            _state = new StrategyState();
            _currentDay = DateTime.Today;
            _todayTradeCount = 0;
            _todayPnL = 0;
            
            LogMessage("Sophon Strategy initialized successfully", LogLevel.Info);
        }

        private void OnRealtimeStart()
        {
            _state.IsRealtime = true;
            LogMessage("Sophon Strategy started in REALTIME mode", LogLevel.Info);
            
            if (EnableAlerts)
            {
                Alert("SophonStart", Priority.Medium, "Sophon Strategy is now active", 
                      NinjaTrader.Core.Globals.InstallDir + @"\sounds\Alert1.wav", 10, Brushes.Green, Brushes.White);
            }
        }

        private void OnTerminate()
        {
            // Fermer tous les trades si nécessaire
            if (_executionModule != null && _executionModule.IsInitialized)
            {
                _executionModule.CloseAllPositions(null, ExitReason.SystemError);
                _executionModule.Shutdown();
            }
            
            _smcModule?.Shutdown();
            _riskModule?.Shutdown();
            
            LogMessage("Sophon Strategy terminated", LogLevel.Info);
        }

        private AccountConfig CreateAccountConfig()
        {
            return new AccountConfig
            {
                AccountId = Account?.Name ?? "Default",
                AccountName = Account?.Name ?? "Default",
                InitialBalance = Account?.Get(AccountItem.CashValue, Currency.UsDollar) ?? 100000,
                CurrentBalance = Account?.Get(AccountItem.CashValue, Currency.UsDollar) ?? 100000,
                RiskProfile = RiskProfile,
                MaxRiskPerTrade = RiskPerTrade,
                MaxDailyLoss = MaxDailyLoss,
                MaxDrawdown = MaxDrawdown,
                MaxOpenTrades = MaxOpenTrades,
                MaxTradesPerDay = MaxTradesPerDay,
                AllowedInstruments = _activeInstruments,
                AllowedSessions = GetAllowedSessions(),
                IsActive = true,
                IsMaster = true
            };
        }

        private List<TradingSession> GetAllowedSessions()
        {
            var sessions = new List<TradingSession>();
            if (TradeAsianSession) sessions.Add(TradingSession.Asian);
            if (TradeLondonSession) sessions.Add(TradingSession.London);
            if (TradeNYSession) sessions.Add(TradingSession.NewYork);
            if (TradeOverlapOnly) 
            {
                sessions.Clear();
                sessions.Add(TradingSession.LondonNYOverlap);
            }
            if (sessions.Count == 0) sessions.Add(TradingSession.All);
            return sessions;
        }

        #region ═══════════════════════════════════════════════════════════════
        //                      MAIN UPDATE LOOP
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        protected override void OnBarUpdate()
        {
            // Vérifier que nous avons assez de barres
            if (CurrentBar < BarsRequiredToTrade) return;
            
            // Identifier l'instrument courant
            string currentInstrument = BarsInProgress < BarsArray.Length 
                ? BarsArray[BarsInProgress].Instrument.MasterInstrument.Name 
                : Instrument.MasterInstrument.Name;
            
            // Vérifier le changement de jour
            CheckNewDay();
            
            // Obtenir l'ATR courant
            double currentATR = 0;
            if (_atrIndicators.ContainsKey(currentInstrument))
            {
                currentATR = _atrIndicators[currentInstrument][0];
            }
            
            // Mettre à jour le module SMC avec les nouvelles données
            if (_smcModule != null && _smcModule.IsInitialized)
            {
                _smcModule.UpdateInstrument(
                    currentInstrument,
                    Open[0],
                    High[0],
                    Low[0],
                    Close[0],
                    Volume[0],
                    Time[0],
                    CurrentBar,
                    currentATR
                );
            }
            
            // Mettre à jour les corrélations
            if (_riskModule != null && UseCorrelationFilter)
            {
                _riskModule.UpdatePriceForCorrelation(currentInstrument, Close[0]);
            }
            
            // Mettre à jour le module d'exécution (pour trailing, BE, etc.)
            if (_executionModule != null && _executionModule.IsInitialized)
            {
                _executionModule.Update(Close[0], currentATR, Time[0], CurrentBar);
            }
            
            // Traiter les signaux en attente (mode semi-auto)
            ProcessPendingSignals();
            
            // Logger si mode debug
            if (DebugMode && BarsInProgress == 0)
            {
                LogDebugInfo(currentInstrument, currentATR);
            }
        }

        private void CheckNewDay()
        {
            if (Time[0].Date != _currentDay)
            {
                // Nouveau jour
                _currentDay = Time[0].Date;
                _todayTradeCount = 0;
                _todayPnL = 0;
                
                // Reset des compteurs journaliers du module de risque
                _riskModule?.ResetDailyCounters();
                
                LogMessage($"New trading day: {_currentDay:yyyy-MM-dd}", LogLevel.Info);
            }
        }

        #region ═══════════════════════════════════════════════════════════════
        //                      SIGNAL HANDLING
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        private void OnNewSignalReceived(object sender, SMCSignal signal)
        {
            if (!EnableTrading) return;
            if (!IsSessionAllowed(signal.Session)) return;
            
            LogMessage($"New signal: {signal}", LogLevel.Trade);
            
            // Valider avec le module de risque
            var accountConfig = CreateAccountConfig();
            if (!_riskModule.ValidateSignal(signal, accountConfig))
            {
                LogMessage($"Signal rejected by risk module: {signal.Instrument} {signal.Setup}", LogLevel.Warning);
                return;
            }
            
            // Selon le mode de fonctionnement
            switch (Mode)
            {
                case OperationMode.Automatic:
                    ExecuteSignal(signal);
                    break;
                    
                case OperationMode.SemiAutomatic:
                    AddToPendingSignals(signal);
                    NotifyPendingSignal(signal);
                    break;
                    
                case OperationMode.ManualOnly:
                    NotifySignalForManualReview(signal);
                    break;
            }
        }

        private void OnSignalInvalidated(object sender, SMCSignal signal)
        {
            LogMessage($"Signal invalidated: {signal.Instrument} {signal.Setup}", LogLevel.Info);
            
            // Retirer des signaux en attente
            lock (_signalLock)
            {
                _pendingSignals.RemoveAll(s => s.Id == signal.Id);
            }
        }

        private void AddToPendingSignals(SMCSignal signal)
        {
            lock (_signalLock)
            {
                // Éviter les doublons
                if (!_pendingSignals.Any(s => s.Id == signal.Id))
                {
                    _pendingSignals.Add(signal);
                }
            }
        }

        private void ProcessPendingSignals()
        {
            if (Mode != OperationMode.SemiAutomatic) return;
            
            lock (_signalLock)
            {
                // Retirer les signaux expirés
                _pendingSignals.RemoveAll(s => s.IsExpired);
            }
        }

        /// <summary>
        /// Confirme manuellement un signal en attente (appelé depuis le dashboard)
        /// </summary>
        public void ConfirmSignal(string signalId)
        {
            SMCSignal signal = null;
            
            lock (_signalLock)
            {
                signal = _pendingSignals.FirstOrDefault(s => s.Id == signalId);
                if (signal != null)
                {
                    _pendingSignals.Remove(signal);
                }
            }
            
            if (signal != null && !signal.IsExpired)
            {
                ExecuteSignal(signal);
            }
        }

        /// <summary>
        /// Rejette manuellement un signal en attente
        /// </summary>
        public void RejectSignal(string signalId)
        {
            lock (_signalLock)
            {
                _pendingSignals.RemoveAll(s => s.Id == signalId);
            }
            LogMessage($"Signal manually rejected: {signalId}", LogLevel.Info);
        }

        private void NotifyPendingSignal(SMCSignal signal)
        {
            if (EnableAlerts)
            {
                string message = $"SOPHON: {signal.GetSetupLabel()} on {signal.Instrument} @ {signal.EntryPrice:F2}";
                Alert($"Signal_{signal.Id}", Priority.High, message,
                      NinjaTrader.Core.Globals.InstallDir + @"\sounds\Alert2.wav", 10, 
                      signal.IsLong ? Brushes.Green : Brushes.Red, Brushes.White);
            }
            
            // Dessiner sur le graphique
            DrawSignalOnChart(signal);
        }

        private void NotifySignalForManualReview(SMCSignal signal)
        {
            if (EnableAlerts)
            {
                string message = $"SOPHON MANUAL: {signal.GetSetupLabel()} on {signal.Instrument}";
                Alert($"Manual_{signal.Id}", Priority.Medium, message,
                      NinjaTrader.Core.Globals.InstallDir + @"\sounds\Alert3.wav", 5, 
                      Brushes.Yellow, Brushes.Black);
            }
            
            DrawSignalOnChart(signal);
        }

        private bool IsSessionAllowed(TradingSession session)
        {
            if (TradeOverlapOnly)
                return session == TradingSession.LondonNYOverlap;
            
            switch (session)
            {
                case TradingSession.Asian:
                    return TradeAsianSession;
                case TradingSession.London:
                    return TradeLondonSession;
                case TradingSession.NewYork:
                    return TradeNYSession;
                case TradingSession.LondonNYOverlap:
                    return TradeLondonSession || TradeNYSession;
                default:
                    return false;
            }
        }

        #region ═══════════════════════════════════════════════════════════════
        //                      TRADE EXECUTION
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        private void ExecuteSignal(SMCSignal signal)
        {
            if (!EnableTrading) return;
            if (_todayTradeCount >= MaxTradesPerDay)
            {
                LogMessage("Max trades per day reached", LogLevel.Warning);
                return;
            }
            
            // Obtenir l'ATR pour le calcul de risque
            double atr = 0;
            if (_atrIndicators.ContainsKey(signal.Instrument))
            {
                int barsIdx = _instrumentBarsIndex[signal.Instrument];
                atr = _atrIndicators[signal.Instrument][0];
            }
            
            // Calculer les paramètres de risque
            var accountConfig = CreateAccountConfig();
            var riskParams = _riskModule.CalculateRisk(signal, accountConfig, atr);
            
            if (riskParams.PositionSize <= 0)
            {
                LogMessage($"Invalid position size for {signal.Instrument}", LogLevel.Warning);
                return;
            }
            
            // Créer le trade setup
            var tradeSetup = new TradeSetup(signal)
            {
                AccountId = accountConfig.AccountId,
                Risk = riskParams
            };
            
            // Exécuter via le module d'exécution
            _executionModule.ExecuteTrade(tradeSetup);
            
            LogMessage($"Executing trade: {signal.Instrument} {signal.Direction} @ {signal.EntryPrice:F2} x{riskParams.PositionSize}", LogLevel.Trade);
        }

        private void HandleOrderRequest(OrderRequest request)
        {
            // Traduire en ordres NinjaTrader
            try
            {
                int barsIdx = _instrumentBarsIndex.ContainsKey(request.Instrument) 
                    ? _instrumentBarsIndex[request.Instrument] 
                    : 0;
                
                string entryName = $"Sophon_{request.TradeId}";
                
                if (request.Direction == TradeDirection.Long)
                {
                    EnterLong(barsIdx, request.Quantity, entryName);
                    
                    // Placer SL et TP
                    SetStopLoss(entryName, CalculationMode.Price, request.StopLoss, false);
                    SetProfitTarget(entryName, CalculationMode.Price, request.TakeProfit);
                }
                else if (request.Direction == TradeDirection.Short)
                {
                    EnterShort(barsIdx, request.Quantity, entryName);
                    
                    SetStopLoss(entryName, CalculationMode.Price, request.StopLoss, false);
                    SetProfitTarget(entryName, CalculationMode.Price, request.TakeProfit);
                }
                
                LogMessage($"Order submitted: {request.Direction} {request.Instrument} x{request.Quantity}", LogLevel.Trade);
            }
            catch (Exception ex)
            {
                LogMessage($"Order error: {ex.Message}", LogLevel.Error);
            }
        }

        private void HandleModifyRequest(ModifyRequest request)
        {
            try
            {
                string entryName = $"Sophon_{request.TradeId}";
                
                if (request.NewStopLoss.HasValue)
                {
                    SetStopLoss(entryName, CalculationMode.Price, request.NewStopLoss.Value, false);
                }
                
                if (request.NewTakeProfit.HasValue)
                {
                    SetProfitTarget(entryName, CalculationMode.Price, request.NewTakeProfit.Value);
                }
                
                LogMessage($"Order modified: {request.TradeId}", LogLevel.Info);
            }
            catch (Exception ex)
            {
                LogMessage($"Modify error: {ex.Message}", LogLevel.Error);
            }
        }

        private void HandleCancelRequest(CancelRequest request)
        {
            try
            {
                string entryName = $"Sophon_{request.TradeId}";
                
                // Fermer la position
                if (Position.MarketPosition == MarketPosition.Long)
                    ExitLong(entryName);
                else if (Position.MarketPosition == MarketPosition.Short)
                    ExitShort(entryName);
                
                LogMessage($"Position closed: {request.TradeId} ({request.Reason})", LogLevel.Trade);
            }
            catch (Exception ex)
            {
                LogMessage($"Cancel error: {ex.Message}", LogLevel.Error);
            }
        }

        #region ═══════════════════════════════════════════════════════════════
        //                      TRADE EVENTS
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        private void OnTradeOpened(object sender, TradeSetup trade)
        {
            _todayTradeCount++;
            _riskModule.RecordTradeOpened(trade.AccountId, trade);
            
            LogMessage($"Trade opened: {trade.Signal.Instrument} {trade.Signal.Direction} @ {trade.ActualEntryPrice:F2}", LogLevel.Trade);
            
            if (EnableAlerts)
            {
                Alert($"Open_{trade.Id}", Priority.Medium, 
                      $"TRADE OPENED: {trade.Signal.Instrument} {trade.Signal.Direction}",
                      NinjaTrader.Core.Globals.InstallDir + @"\sounds\OrderFilled.wav", 5, 
                      Brushes.Blue, Brushes.White);
            }
        }

        private void OnTradeClosed(object sender, TradeSetup trade)
        {
            double pnl = CalculatePnL(trade);
            _todayPnL += pnl;
            _riskModule.RecordTradeClosed(trade.AccountId, trade, pnl);
            
            LogMessage($"Trade closed: {trade.Signal.Instrument} P/L: {pnl:+0.00;-0.00} ({trade.ExitReason})", LogLevel.Trade);
            
            if (EnableAlerts)
            {
                Brush bgColor = pnl >= 0 ? Brushes.Green : Brushes.Red;
                Alert($"Close_{trade.Id}", Priority.Medium,
                      $"TRADE CLOSED: {trade.Signal.Instrument} P/L: {pnl:+0.00;-0.00}",
                      NinjaTrader.Core.Globals.InstallDir + @"\sounds\Alert4.wav", 5,
                      bgColor, Brushes.White);
            }
        }

        protected override void OnExecutionUpdate(Execution execution, string executionId, double price, int quantity, 
                                                   MarketPosition marketPosition, string orderId, DateTime time)
        {
            // Confirmer l'ouverture au module d'exécution
            if (execution.Order != null && execution.Order.Name.StartsWith("Sophon_"))
            {
                string tradeId = execution.Order.Name.Replace("Sophon_", "");
                _executionModule.ConfirmTradeOpened(tradeId, price, quantity, time);
            }
        }

        private double CalculatePnL(TradeSetup trade)
        {
            if (trade.ActualEntryPrice == 0 || trade.ActualExitPrice == 0)
                return 0;
            
            double pointValue = GetPointValue(trade.Signal.Instrument);
            double priceDiff = trade.Signal.IsLong 
                ? trade.ActualExitPrice - trade.ActualEntryPrice 
                : trade.ActualEntryPrice - trade.ActualExitPrice;
            
            return priceDiff * trade.ActualPositionSize * pointValue;
        }

        private double GetPointValue(string instrument)
        {
            return instrument.ToUpper() switch
            {
                "MES" => 5.0,
                "MNQ" => 2.0,
                "MGC" => 10.0,
                "MCL" => 10.0,
                "M2K" => 5.0,
                "MYM" => 0.5,
                _ => 1.0
            };
        }

        #region ═══════════════════════════════════════════════════════════════
        //                      DRAWING & LOGGING
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        private void DrawSignalOnChart(SMCSignal signal)
        {
            if (!_instrumentBarsIndex.ContainsKey(signal.Instrument)) return;
            
            int barsIdx = _instrumentBarsIndex[signal.Instrument];
            string tag = $"Signal_{signal.Id}";
            
            // Dessiner le label du setup
            Brush color = signal.IsLong ? Brushes.LimeGreen : Brushes.Red;
            double yOffset = signal.IsLong ? Low[0] - (High[0] - Low[0]) * 0.5 : High[0] + (High[0] - Low[0]) * 0.5;
            
            Draw.Text(this, tag, signal.GetSetupLabel(), 0, yOffset, color);
            
            // Dessiner les niveaux SL/TP
            Draw.HorizontalLine(this, $"{tag}_SL", signal.StopLoss, Brushes.Red, DashStyleHelper.Dash, 1);
            Draw.HorizontalLine(this, $"{tag}_TP1", signal.TakeProfit1, Brushes.Green, DashStyleHelper.Dash, 1);
            
            if (signal.TakeProfit2 > 0)
                Draw.HorizontalLine(this, $"{tag}_TP2", signal.TakeProfit2, Brushes.DarkGreen, DashStyleHelper.Dot, 1);
        }

        private void LogMessage(string message, LogLevel level)
        {
            string prefix = level switch
            {
                LogLevel.Error => "[ERROR]",
                LogLevel.Warning => "[WARN]",
                LogLevel.Trade => "[TRADE]",
                LogLevel.Debug => "[DEBUG]",
                _ => "[INFO]"
            };
            
            Print($"{Time[0]:HH:mm:ss} SOPHON {prefix} {message}");
            
            if (level == LogLevel.Error)
            {
                Log($"SOPHON: {message}", NinjaTrader.Cbi.LogLevel.Error);
            }
        }

        private void LogDebugInfo(string instrument, double atr)
        {
            if (_smcModule == null) return;
            
            var context = _smcModule.GetMarketContext(instrument);
            Print($"[DEBUG] {instrument}: Structure={context.Structure} | Position={context.CurrentPosition} | ATR={atr:F2} | OBs={context.ActiveOrderBlocks.Count} | FVGs={context.ActiveFVGs.Count}");
        }

        #region ═══════════════════════════════════════════════════════════════
        //                      PUBLIC INTERFACE
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        /// <summary>
        /// Obtient les signaux en attente (mode semi-auto)
        /// </summary>
        public List<SMCSignal> GetPendingSignals()
        {
            lock (_signalLock)
            {
                return _pendingSignals.Where(s => !s.IsExpired).ToList();
            }
        }

        /// <summary>
        /// Obtient les trades ouverts
        /// </summary>
        public List<TradeSetup> GetOpenTrades()
        {
            return _executionModule?.GetOpenTrades() ?? new List<TradeSetup>();
        }

        /// <summary>
        /// Obtient le contexte de marché pour un instrument
        /// </summary>
        public MarketContext GetMarketContext(string instrument)
        {
            return _smcModule?.GetMarketContext(instrument);
        }

        /// <summary>
        /// Obtient les statistiques d'exécution
        /// </summary>
        public ExecutionStatistics GetExecutionStats()
        {
            return _executionModule?.GetStatistics();
        }

        /// <summary>
        /// Obtient le résumé des risques
        /// </summary>
        public Dictionary<string, AccountRiskSummary> GetRiskSummary()
        {
            return _riskModule?.GetAllAccountsSummary();
        }

        /// <summary>
        /// Ferme toutes les positions
        /// </summary>
        public void CloseAllPositions(ExitReason reason = ExitReason.ManualClose)
        {
            _executionModule?.CloseAllPositions(null, reason);
        }

        /// <summary>
        /// Met en pause le trading
        /// </summary>
        public void PauseTrading()
        {
            EnableTrading = false;
            LogMessage("Trading PAUSED", LogLevel.Warning);
        }

        /// <summary>
        /// Reprend le trading
        /// </summary>
        public void ResumeTrading()
        {
            EnableTrading = true;
            LogMessage("Trading RESUMED", LogLevel.Info);
        }
    }

    #region Supporting Classes
    /// <summary>
    /// État interne de la stratégie
    /// </summary>
    public class StrategyState
    {
        public bool IsRealtime { get; set; }
        public bool IsPaused { get; set; }
        public DateTime LastSignalTime { get; set; }
        public int SignalsToday { get; set; }
        public int TradesWonToday { get; set; }
        public int TradesLostToday { get; set; }
    }
    #endregion
}
