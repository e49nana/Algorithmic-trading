================================================================================
       CORRELATION MATRIX PRO v3.1 - MQL5 MARKET SUBMISSION PACKAGE
================================================================================

                         ALGOSPHERE CAPITAL LTD.
                              December 2025

================================================================================
QUICK START
================================================================================

1. READ: Documentation/SUBMISSION_GUIDE.txt (in Smart Money Dashboard package)

2. COMPILE: Open Indicator/CorrelationMatrixPro.mq5 in MetaEditor, press F7

3. SUBMIT: Upload .ex5 file + logos + screenshots to MQL5 Market

================================================================================
PACKAGE CONTENTS
================================================================================

CorrelationMatrix_Package/
|
+-- Indicator/
|   +-- CorrelationMatrixPro.mq5      Source code (compile to .ex5)
|   +-- algosphere_icon_32.bmp        Panel icon (copy to MQL5/Images/)
|
+-- Logos/                             Upload ALL to MQL5 Market
|   +-- logo_200x200.png              Main showcase image
|   +-- logo_140x140.png              Category listing image
|   +-- logo_60x60.png                Small display image
|
+-- Screenshots/                       Upload to MQL5 Market
|   (Add your own screenshots)
|
+-- Documentation/
|   +-- PRODUCT_DESCRIPTION.txt       Copy-paste product description
|   +-- CorrelationMatrixPro_UserManual.pdf  User documentation
|
+-- README.txt                         This file

================================================================================
VERSION 3.1 ENHANCEMENTS
================================================================================

+ Algosphere Capital branding and logo
+ 3-State collapsible panel (Expanded/Collapsed/Minimized)
+ Timeframe change detection with automatic recalculation
+ Panel state preservation during chart events
+ [+]/[-]/[_] control buttons
+ Expand button in minimized mode
+ Current timeframe display in subtitle
+ Improved chart event handling

================================================================================
FEATURES
================================================================================

- Real-time correlation heatmap matrix
- Multi-asset support (up to 12 symbols)
- Divergence detection with alerts
- Multi-period analysis (20/50/100/200 bars)
- Pre-defined symbol sets (Majors, Crosses, Commodities, Indices)
- Custom symbol support
- 4 color themes (Dark, Matrix, Bloomberg, Light)
- Statistics panel (avg correlation, strong pairs, etc.)
- Chart theme application

================================================================================
INSTALLATION
================================================================================

1. Copy CorrelationMatrixPro.mq5 to:
   [MT5 Data Folder]/MQL5/Indicators/

2. Copy algosphere_icon_32.bmp to:
   [MT5 Data Folder]/MQL5/Images/

3. Compile in MetaEditor (F7)

4. Drag indicator onto chart

================================================================================
PANEL CONTROLS
================================================================================

   [-]  = Collapse to stats only
   [+]  = Expand to full matrix
   [_]  = Minimize to title bar
   Expand = Restore from minimized

================================================================================
SUPPORT
================================================================================

Website: www.algosphere.capital
Email: support@algosphere.capital

================================================================================
               Copyright (c) 2025 Algosphere Capital Ltd.
================================================================================
