//+------------------------------------------------------------------+
//|                                 ExMachina_GridRecovery.mq5       |
//|                          Copyright 2026, ExMachina Trading Systems|
//|                   https://www.mql5.com/en/users/williammukam      |
//+------------------------------------------------------------------+
#property copyright "ExMachina Trading Systems"
#property link "https://www.mql5.com/en/users/williammukam"
#property version "1.00"
#property description "ExMachina Grid Recovery EA"
#property description "Conservative grid with max positions limit,"
#property description "global SL, profit target. The grid EA that"
#property description "doesn't blow accounts. Precision before profit."

#include <Trade\Trade.mqh>

input group "══════ Grid Settings ══════"
input double InpLotSize=0.01;     // Starting Lot Size
input int InpGridStep=200;        // Grid Step (points)
input double InpMultiplier=1.5;   // Lot Multiplier per Level
input int InpMaxPositions=5;      // Max Open Positions
input double InpTakeProfit=100.0; // Take Profit per Cycle ($)
input double InpGlobalSL=500.0;   // Global Stop Loss ($)

input group "══════ Filters ══════"
input int InpStartHour=1;input int InpEndHour=23;
input long InpMagic=202601;

input group "══════ Dashboard ══════"
input bool InpShowDashboard=true;
input int InpDashX=20;input int InpDashY=40;input int InpDashFontSize=9;
input color InpDashBgColor=C'8,10,18';input color InpDashTextColor=C'160,168,180';

string g_objPrefix="EXSS_GR_";
CTrade g_trade;
int g_cyclesWon=0,g_cyclesLost=0;

int OnInit(){
   g_trade.SetExpertMagicNumber(InpMagic);g_trade.SetDeviationInPoints(20);
   if(InpShowDashboard) CreateDashboard();
   Print("⚠ WARNING: Grid/Recovery EAs carry significant risk. Use conservative settings and small lots.");
   return(INIT_SUCCEEDED);
}
void OnDeinit(const int reason){ObjectsDeleteAll(0,g_objPrefix);ChartRedraw(0);}

void OnTick(){
   MqlDateTime dt;TimeToStruct(TimeCurrent(),dt);
   if(dt.hour<InpStartHour||dt.hour>=InpEndHour) return;

   int myPositions=CountMyPositions();
   double floatingPL=GetFloatingPL();

   // Check global SL
   if(floatingPL<=-InpGlobalSL&&myPositions>0){
      CloseAll();g_cyclesLost++;
      Print("ExMachina Grid: Global SL hit. Cycle lost.");
      if(InpShowDashboard) UpdateDashboard(0,0);
      return;
   }

   // Check TP
   if(floatingPL>=InpTakeProfit&&myPositions>0){
      CloseAll();g_cyclesWon++;
      Print("ExMachina Grid: TP reached. Cycle won.");
      if(InpShowDashboard) UpdateDashboard(0,0);
      return;
   }

   // Open initial trade if no positions
   if(myPositions==0){
      double ask=SymbolInfoDouble(_Symbol,SYMBOL_ASK);
      g_trade.Buy(InpLotSize,_Symbol,ask,0,0,"ExMachina Grid L1");
      if(InpShowDashboard) UpdateDashboard(1,0);
      return;
   }

   // Check if we need to add grid level
   if(myPositions<InpMaxPositions){
      double lastOpenPrice=GetLastOpenPrice();
      double bid=SymbolInfoDouble(_Symbol,SYMBOL_BID);
      if(lastOpenPrice-bid>=InpGridStep*_Point){
         double lots=InpLotSize*MathPow(InpMultiplier,myPositions);
         double minLot=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN);
         double lotStep=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP);
         lots=MathFloor(lots/lotStep)*lotStep;if(lots<minLot)lots=minLot;
         g_trade.Buy(lots,_Symbol,SymbolInfoDouble(_Symbol,SYMBOL_ASK),0,0,"ExMachina Grid L"+IntegerToString(myPositions+1));
      }
   }

   if(InpShowDashboard) UpdateDashboard(myPositions,floatingPL);
}

int CountMyPositions(){int c=0;for(int i=PositionsTotal()-1;i>=0;i--){ulong t=PositionGetTicket(i);if(t>0&&PositionGetInteger(POSITION_MAGIC)==InpMagic&&PositionGetString(POSITION_SYMBOL)==_Symbol)c++;}return c;}
double GetFloatingPL(){double pl=0;for(int i=PositionsTotal()-1;i>=0;i--){ulong t=PositionGetTicket(i);if(t>0&&PositionGetInteger(POSITION_MAGIC)==InpMagic&&PositionGetString(POSITION_SYMBOL)==_Symbol)pl+=PositionGetDouble(POSITION_PROFIT)+PositionGetDouble(POSITION_SWAP);}return pl;}
double GetLastOpenPrice(){double p=0;datetime lt=0;for(int i=PositionsTotal()-1;i>=0;i--){ulong t=PositionGetTicket(i);if(t>0&&PositionGetInteger(POSITION_MAGIC)==InpMagic&&PositionGetString(POSITION_SYMBOL)==_Symbol){datetime ot=(datetime)PositionGetInteger(POSITION_TIME);if(ot>lt){lt=ot;p=PositionGetDouble(POSITION_PRICE_OPEN);}}}return p;}
void CloseAll(){for(int i=PositionsTotal()-1;i>=0;i--){ulong t=PositionGetTicket(i);if(t>0&&PositionGetInteger(POSITION_MAGIC)==InpMagic&&PositionGetString(POSITION_SYMBOL)==_Symbol)g_trade.PositionClose(t,50);}}

void CreateDashboard(){
   int w=270,h=185;string bg=g_objPrefix+"BG";
   ObjectCreate(0,bg,OBJ_RECTANGLE_LABEL,0,0,0);ObjectSetInteger(0,bg,OBJPROP_XDISTANCE,InpDashX);ObjectSetInteger(0,bg,OBJPROP_YDISTANCE,InpDashY);ObjectSetInteger(0,bg,OBJPROP_XSIZE,w);ObjectSetInteger(0,bg,OBJPROP_YSIZE,h);ObjectSetInteger(0,bg,OBJPROP_BGCOLOR,InpDashBgColor);ObjectSetInteger(0,bg,OBJPROP_BORDER_COLOR,C'30,34,46');ObjectSetInteger(0,bg,OBJPROP_BORDER_TYPE,BORDER_FLAT);ObjectSetInteger(0,bg,OBJPROP_CORNER,CORNER_LEFT_UPPER);ObjectSetInteger(0,bg,OBJPROP_BACK,false);ObjectSetInteger(0,bg,OBJPROP_SELECTABLE,false);
   ML("Title",InpDashX+10,InpDashY+8,"EXMACHINA GRID RECOVERY",C'90,180,220',InpDashFontSize+1);
   ML("Warn",InpDashX+10,InpDashY+26,"⚠ HIGH RISK — Use small lots",C'220,50,80',InpDashFontSize-1);
   ML("Sep1",InpDashX+10,InpDashY+42,"──────────────────────────",C'30,34,46',InpDashFontSize-2);
   ML("PsLbl",InpDashX+10,InpDashY+56,"Positions:",C'90,95,110',InpDashFontSize);ML("PsVal",InpDashX+150,InpDashY+56,"0/"+IntegerToString(InpMaxPositions),InpDashTextColor,InpDashFontSize);
   ML("PlLbl",InpDashX+10,InpDashY+74,"Floating P/L:",C'90,95,110',InpDashFontSize);ML("PlVal",InpDashX+150,InpDashY+74,"$0.00",InpDashTextColor,InpDashFontSize);
   ML("TpLbl",InpDashX+10,InpDashY+92,"TP Target:",C'90,95,110',InpDashFontSize);ML("TpVal",InpDashX+150,InpDashY+92,"$"+DoubleToString(InpTakeProfit,0),C'0,185,140',InpDashFontSize);
   ML("SlLbl",InpDashX+10,InpDashY+110,"Global SL:",C'90,95,110',InpDashFontSize);ML("SlVal",InpDashX+150,InpDashY+110,"-$"+DoubleToString(InpGlobalSL,0),C'220,50,80',InpDashFontSize);
   ML("Sep2",InpDashX+10,InpDashY+128,"──────────────────────────",C'30,34,46',InpDashFontSize-2);
   ML("WnLbl",InpDashX+10,InpDashY+142,"Cycles Won:",C'90,95,110',InpDashFontSize);ML("WnVal",InpDashX+150,InpDashY+142,"0",C'0,185,140',InpDashFontSize);
   ML("LsLbl",InpDashX+10,InpDashY+160,"Cycles Lost:",C'90,95,110',InpDashFontSize);ML("LsVal",InpDashX+150,InpDashY+160,"0",C'220,50,80',InpDashFontSize);
   ML("Brand",InpDashX+10,InpDashY+176,"Precision before profit",C'55,60,75',InpDashFontSize-2);ChartRedraw(0);
}
void ML(string id,int x,int y,string text,color clr,int fs){string name=g_objPrefix+id;ObjectCreate(0,name,OBJ_LABEL,0,0,0);ObjectSetInteger(0,name,OBJPROP_XDISTANCE,x);ObjectSetInteger(0,name,OBJPROP_YDISTANCE,y);ObjectSetString(0,name,OBJPROP_TEXT,text);ObjectSetInteger(0,name,OBJPROP_COLOR,clr);ObjectSetInteger(0,name,OBJPROP_FONTSIZE,fs);ObjectSetString(0,name,OBJPROP_FONT,"Consolas");ObjectSetInteger(0,name,OBJPROP_CORNER,CORNER_LEFT_UPPER);ObjectSetInteger(0,name,OBJPROP_ANCHOR,ANCHOR_LEFT_UPPER);ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,name,OBJPROP_BACK,false);}
void UpdateDashboard(int pos,double pl){
   ObjectSetString(0,g_objPrefix+"PsVal",OBJPROP_TEXT,IntegerToString(pos)+"/"+IntegerToString(InpMaxPositions));
   color plClr=(pl>=0)?C'0,185,140':C'220,50,80';string plSign=(pl>=0)?"+":"";
   ObjectSetString(0,g_objPrefix+"PlVal",OBJPROP_TEXT,plSign+"$"+DoubleToString(MathAbs(pl),2));ObjectSetInteger(0,g_objPrefix+"PlVal",OBJPROP_COLOR,plClr);
   ObjectSetString(0,g_objPrefix+"WnVal",OBJPROP_TEXT,IntegerToString(g_cyclesWon));
   ObjectSetString(0,g_objPrefix+"LsVal",OBJPROP_TEXT,IntegerToString(g_cyclesLost));ChartRedraw(0);
}
