//+------------------------------------------------------------------+
//|                                ExMachina_LiquidityZones.mq5      |
//|                          Copyright 2026, ExMachina Trading Systems|
//|                   https://www.mql5.com/en/users/williammukam      |
//+------------------------------------------------------------------+
#property copyright   "ExMachina Trading Systems"
#property link        "https://www.mql5.com/en/users/williammukam"
#property version     "1.00"
#property description "ExMachina Liquidity Zones"
#property description "Detect equal highs/lows, swing clusters where"
#property description "stop hunting is probable. Touch count labels."
#property description "Precision before profit."
#property indicator_chart_window
#property indicator_buffers 2
#property indicator_plots   2
#property strict

#property indicator_label1  "Liquidity High"
#property indicator_type1   DRAW_ARROW
#property indicator_color1  clrOrangeRed
#property indicator_width1  2
#property indicator_label2  "Liquidity Low"
#property indicator_type2   DRAW_ARROW
#property indicator_color2  clrDodgerBlue
#property indicator_width2  2

input group "══════ Detection ══════"
input int    InpSwingLen      = 5;        // Swing Length
input int    InpLookback      = 500;      // Lookback Bars
input double InpTolerance     = 0.5;      // Equal Level Tolerance (pips)
input int    InpMinTouches    = 2;        // Min Touches for Liquidity Zone
input int    InpMaxZones      = 20;       // Max Zones Displayed

input group "══════ Visual ══════"
input color  InpBuyLiqColor   = C'220,120,40';  // Buy-Side Liquidity (highs)
input color  InpSellLiqColor  = C'40,120,200';  // Sell-Side Liquidity (lows)
input bool   InpShowLabels    = true;
input bool   InpShowDashboard = true;

input group "══════ Alerts ══════"
input bool   InpAlertTouch    = true;
input bool   InpAlertPopup    = true;
input bool   InpAlertSound    = true;
input bool   InpAlertPush     = false;

input group "══════ Dashboard ══════"
input int    InpDashX = 20;
input int    InpDashY = 40;
input int    InpDashFontSize = 9;
input color  InpDashBgColor = C'8,10,18';
input color  InpDashTextColor = C'160,168,180';

string g_objPrefix = "EXSS_LQ_";
double BuffHi[], BuffLo[];
datetime g_lastAlertTime = 0;

struct LiqZone { double price; int touches; bool isHigh; datetime firstTime; };
LiqZone g_zones[];
int g_zoneCount = 0;
int g_hiZones = 0, g_loZones = 0;

int OnInit(){
   SetIndexBuffer(0,BuffHi,INDICATOR_DATA); SetIndexBuffer(1,BuffLo,INDICATOR_DATA);
   PlotIndexSetDouble(0,PLOT_EMPTY_VALUE,EMPTY_VALUE); PlotIndexSetDouble(1,PLOT_EMPTY_VALUE,EMPTY_VALUE);
   PlotIndexSetInteger(0,PLOT_ARROW,159); PlotIndexSetInteger(1,PLOT_ARROW,159);
   PlotIndexSetInteger(0,PLOT_LINE_COLOR,InpBuyLiqColor); PlotIndexSetInteger(1,PLOT_LINE_COLOR,InpSellLiqColor);
   IndicatorSetString(INDICATOR_SHORTNAME,"ExMachina Liquidity Zones");
   if(InpShowDashboard) CreateDashboard();
   return(INIT_SUCCEEDED);
}
void OnDeinit(const int reason){ObjectsDeleteAll(0,g_objPrefix);ChartRedraw(0);}

int OnCalculate(const int rates_total,const int prev_calculated,const datetime &time[],const double &open[],const double &high[],const double &low[],const double &close[],const long &tick_volume[],const long &volume[],const int &spread[]){
   if(rates_total<InpSwingLen*2+1) return(0);
   int limit=MathMin(InpLookback,rates_total-InpSwingLen-1); int start=rates_total-limit;
   if(start<InpSwingLen) start=InpSwingLen;

   if(prev_calculated==0){ObjectsDeleteAll(0,g_objPrefix+"ZN_");ObjectsDeleteAll(0,g_objPrefix+"LBL_");
      for(int i=0;i<rates_total;i++){BuffHi[i]=EMPTY_VALUE;BuffLo[i]=EMPTY_VALUE;}}

   // Collect swing points
   double swingPrices[]; bool swingIsHigh[]; datetime swingTimes[]; int swCount=0;
   int digits=(int)SymbolInfoInteger(_Symbol,SYMBOL_DIGITS);
   double pipSize=(digits==3||digits==5)?_Point*10:_Point;
   double tol=InpTolerance*pipSize;

   for(int i=start;i<rates_total-InpSwingLen;i++){
      bool isH=true,isL=true;
      for(int j=1;j<=InpSwingLen;j++){
         if(i-j<0||i+j>=rates_total){isH=false;isL=false;break;}
         if(high[i-j]>=high[i]||high[i+j]>=high[i]) isH=false;
         if(low[i-j]<=low[i]||low[i+j]<=low[i]) isL=false;
      }
      if(isH){swCount++;ArrayResize(swingPrices,swCount);ArrayResize(swingIsHigh,swCount);ArrayResize(swingTimes,swCount);
         swingPrices[swCount-1]=high[i];swingIsHigh[swCount-1]=true;swingTimes[swCount-1]=time[i];BuffHi[i]=high[i];}
      if(isL){swCount++;ArrayResize(swingPrices,swCount);ArrayResize(swingIsHigh,swCount);ArrayResize(swingTimes,swCount);
         swingPrices[swCount-1]=low[i];swingIsHigh[swCount-1]=false;swingTimes[swCount-1]=time[i];BuffLo[i]=low[i];}
   }

   // Cluster equal levels
   ArrayResize(g_zones,0); g_zoneCount=0; g_hiZones=0; g_loZones=0;
   bool used[]; ArrayResize(used,swCount); ArrayInitialize(used,false);

   for(int i=0;i<swCount;i++){
      if(used[i]) continue;
      double avgPrice=swingPrices[i]; int touches=1; datetime firstT=swingTimes[i]; bool isHi=swingIsHigh[i];
      for(int j=i+1;j<swCount;j++){
         if(used[j]) continue;
         if(swingIsHigh[j]!=isHi) continue;
         if(MathAbs(swingPrices[j]-avgPrice)<tol){touches++;used[j]=true;avgPrice=(avgPrice*(touches-1)+swingPrices[j])/touches;}
      }
      used[i]=true;
      if(touches>=InpMinTouches){
         g_zoneCount++;ArrayResize(g_zones,g_zoneCount);
         g_zones[g_zoneCount-1].price=avgPrice;g_zones[g_zoneCount-1].touches=touches;
         g_zones[g_zoneCount-1].isHigh=isHi;g_zones[g_zoneCount-1].firstTime=firstT;
         if(isHi) g_hiZones++; else g_loZones++;
      }
   }

   // Draw zones
   ObjectsDeleteAll(0,g_objPrefix+"ZN_"); ObjectsDeleteAll(0,g_objPrefix+"LBL_");
   int drawn=0;
   for(int i=g_zoneCount-1;i>=0&&drawn<InpMaxZones;i--){
      color clr=g_zones[i].isHigh?InpBuyLiqColor:InpSellLiqColor;
      string id=IntegerToString(i);
      datetime endT=time[rates_total-1]+PeriodSeconds()*5;
      // Line
      string ln=g_objPrefix+"ZN_"+id;
      ObjectCreate(0,ln,OBJ_TREND,0,g_zones[i].firstTime,g_zones[i].price,endT,g_zones[i].price);
      ObjectSetInteger(0,ln,OBJPROP_COLOR,clr);ObjectSetInteger(0,ln,OBJPROP_STYLE,STYLE_DOT);
      ObjectSetInteger(0,ln,OBJPROP_WIDTH,1);ObjectSetInteger(0,ln,OBJPROP_RAY_RIGHT,false);
      ObjectSetInteger(0,ln,OBJPROP_BACK,true);ObjectSetInteger(0,ln,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,ln,OBJPROP_HIDDEN,true);
      if(InpShowLabels){
         string lb=g_objPrefix+"LBL_"+id;
         string txt=(g_zones[i].isHigh?"BSL":"SSL")+" x"+IntegerToString(g_zones[i].touches);
         ObjectCreate(0,lb,OBJ_TEXT,0,g_zones[i].firstTime,g_zones[i].price);
         ObjectSetString(0,lb,OBJPROP_TEXT,txt);ObjectSetInteger(0,lb,OBJPROP_COLOR,clr);
         ObjectSetString(0,lb,OBJPROP_FONT,"Consolas");ObjectSetInteger(0,lb,OBJPROP_FONTSIZE,7);
         ObjectSetInteger(0,lb,OBJPROP_ANCHOR,g_zones[i].isHigh?ANCHOR_LEFT_LOWER:ANCHOR_LEFT_UPPER);
         ObjectSetInteger(0,lb,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,lb,OBJPROP_HIDDEN,true);
      }
      drawn++;
   }

   // Alerts
   if(InpAlertTouch&&rates_total>1){
      double cl=close[rates_total-1],hi=high[rates_total-1],lo=low[rates_total-1];
      if(time[rates_total-1]>g_lastAlertTime){
         for(int i=g_zoneCount-1;i>=0;i--){
            if(lo<=g_zones[i].price+tol&&hi>=g_zones[i].price-tol){
               string d=g_zones[i].isHigh?"BSL (Buy-Side)":"SSL (Sell-Side)";
               string msg="ExMachina LQ | "+_Symbol+" | Price at "+d+" x"+IntegerToString(g_zones[i].touches)+" @ "+DoubleToString(g_zones[i].price,_Digits);
               if(InpAlertPopup)Alert(msg);if(InpAlertSound)PlaySound("alert.wav");if(InpAlertPush)SendNotification(msg);Print(msg);
               g_lastAlertTime=time[rates_total-1]; break;
            }
         }
      }
   }

   if(InpShowDashboard) UpdateDashboard();
   return(rates_total);
}

void CreateDashboard(){
   int w=240,h=130;
   string bg=g_objPrefix+"DASH_BG";
   ObjectCreate(0,bg,OBJ_RECTANGLE_LABEL,0,0,0);ObjectSetInteger(0,bg,OBJPROP_XDISTANCE,InpDashX);ObjectSetInteger(0,bg,OBJPROP_YDISTANCE,InpDashY);
   ObjectSetInteger(0,bg,OBJPROP_XSIZE,w);ObjectSetInteger(0,bg,OBJPROP_YSIZE,h);ObjectSetInteger(0,bg,OBJPROP_BGCOLOR,InpDashBgColor);
   ObjectSetInteger(0,bg,OBJPROP_BORDER_COLOR,C'30,34,46');ObjectSetInteger(0,bg,OBJPROP_BORDER_TYPE,BORDER_FLAT);
   ObjectSetInteger(0,bg,OBJPROP_CORNER,CORNER_LEFT_UPPER);ObjectSetInteger(0,bg,OBJPROP_BACK,false);ObjectSetInteger(0,bg,OBJPROP_SELECTABLE,false);
   ML("Title",InpDashX+10,InpDashY+8,"EXMACHINA LIQUIDITY ZONES",C'90,180,220',InpDashFontSize+1);
   ML("Sep1",InpDashX+10,InpDashY+26,"────────────────────────",C'30,34,46',InpDashFontSize-2);
   ML("TLbl",InpDashX+10,InpDashY+40,"Total Zones:",C'90,95,110',InpDashFontSize); ML("TVal",InpDashX+150,InpDashY+40,"---",InpDashTextColor,InpDashFontSize);
   ML("HLbl",InpDashX+10,InpDashY+58,"BSL (Highs):",C'90,95,110',InpDashFontSize); ML("HVal",InpDashX+150,InpDashY+58,"---",InpBuyLiqColor,InpDashFontSize);
   ML("LLbl",InpDashX+10,InpDashY+76,"SSL (Lows):",C'90,95,110',InpDashFontSize); ML("LVal",InpDashX+150,InpDashY+76,"---",InpSellLiqColor,InpDashFontSize);
   ML("Sep2",InpDashX+10,InpDashY+94,"────────────────────────",C'30,34,46',InpDashFontSize-2);
   ML("Brand",InpDashX+10,InpDashY+108,"Precision before profit",C'55,60,75',InpDashFontSize-2);
   ChartRedraw(0);
}
void ML(string id,int x,int y,string text,color clr,int fs){
   string name=g_objPrefix+"DASH_"+id;ObjectCreate(0,name,OBJ_LABEL,0,0,0);
   ObjectSetInteger(0,name,OBJPROP_XDISTANCE,x);ObjectSetInteger(0,name,OBJPROP_YDISTANCE,y);
   ObjectSetString(0,name,OBJPROP_TEXT,text);ObjectSetInteger(0,name,OBJPROP_COLOR,clr);
   ObjectSetInteger(0,name,OBJPROP_FONTSIZE,fs);ObjectSetString(0,name,OBJPROP_FONT,"Consolas");
   ObjectSetInteger(0,name,OBJPROP_CORNER,CORNER_LEFT_UPPER);ObjectSetInteger(0,name,OBJPROP_ANCHOR,ANCHOR_LEFT_UPPER);
   ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,name,OBJPROP_BACK,false);
}
void UpdateDashboard(){
   ObjectSetString(0,g_objPrefix+"DASH_TVal",OBJPROP_TEXT,IntegerToString(g_zoneCount));
   ObjectSetString(0,g_objPrefix+"DASH_HVal",OBJPROP_TEXT,IntegerToString(g_hiZones));
   ObjectSetString(0,g_objPrefix+"DASH_LVal",OBJPROP_TEXT,IntegerToString(g_loZones));
   ChartRedraw(0);
}
