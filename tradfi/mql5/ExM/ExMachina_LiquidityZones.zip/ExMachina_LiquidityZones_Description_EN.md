# ExMachina Liquidity Zones — MQL5 Code Base Description (English)

## Title
ExMachina Liquidity Zones

## Short Description
Equal highs/lows cluster detection with touch count, BSL/SSL labels, sweep alerts. ICT concept. Free.

## Full Description

**ExMachina Liquidity Zones** — part of the ExMachina Trading Systems free Code Base collection. Professional quality with ExMachina steel palette design, dashboard panel, and alert system.

All graphical objects use the EXSS_ prefix for clean chart management. Colors fully customizable. Works on all symbols and timeframes.

Developed by ExMachina Trading Systems — Precision before profit.

For professional trading tools, visit: https://www.mql5.com/en/users/williammukam

## Tags (comma-separated)
liquidity,equal highs,equal lows,BSL,SSL,stop hunt,ICT,smart money,sweep,free,forex,gold

## Category
Technical Indicators

## Subcategory
Support and Resistance
