//+------------------------------------------------------------------+
//|                                ExMachina_MACrossoverEA.mq5       |
//|                          Copyright 2026, ExMachina Trading Systems|
//|                   https://www.mql5.com/en/users/williammukam      |
//+------------------------------------------------------------------+
#property copyright "ExMachina Trading Systems"
#property link "https://www.mql5.com/en/users/williammukam"
#property version "1.00"
#property description "ExMachina MA Crossover EA"
#property description "Complete EA: MA cross entry, SL/TP, trailing,"
#property description "breakeven, session filter, money management."
#property description "Precision before profit."

#include <Trade\Trade.mqh>

input group "══════ MA Settings ══════"
input int InpFastPeriod=10;input int InpSlowPeriod=50;
input ENUM_MA_METHOD InpMAMethod=MODE_EMA;
input ENUM_APPLIED_PRICE InpPrice=PRICE_CLOSE;

input group "══════ Trade Settings ══════"
input double InpLotSize=0.01;input double InpRiskPercent=1.0;input bool InpUseRisk=false;
input int InpSLPoints=300;input int InpTPPoints=600;
input int InpBETrigger=200;input int InpBEProtect=20;
input int InpTrailPoints=250;input int InpTrailStep=50;

input group "══════ Session Filter ══════"
input bool InpUseSession=false;input int InpStartHour=8;input int InpEndHour=20;

input group "══════ General ══════"
input long InpMagic=202630;input int InpMaxSpread=30;
input bool InpShowDashboard=true;
input int InpDashX=20;input int InpDashY=40;input int InpDashFontSize=9;
input color InpDashBgColor=C'8,10,18';input color InpDashTextColor=C'160,168,180';

string g_objPrefix="EXSS_MAC_";
CTrade g_trade;
datetime g_lastBar=0;
int g_totalTrades=0,g_wins=0,g_losses=0;

int OnInit(){
   g_trade.SetExpertMagicNumber(InpMagic);g_trade.SetDeviationInPoints(20);
   if(InpShowDashboard) CreateDashboard();
   return(INIT_SUCCEEDED);
}
void OnDeinit(const int reason){ObjectsDeleteAll(0,g_objPrefix);ChartRedraw(0);}

void OnTick(){
   // One signal per bar
   datetime barTime=iTime(_Symbol,PERIOD_CURRENT,0);
   if(barTime==g_lastBar) {ManagePositions();if(InpShowDashboard)UpdateDashboard();return;}
   g_lastBar=barTime;

   // Session filter
   if(InpUseSession){MqlDateTime dt;TimeToStruct(TimeCurrent(),dt);if(dt.hour<InpStartHour||dt.hour>=InpEndHour){if(InpShowDashboard)UpdateDashboard();return;}}

   // Spread filter
   if((int)SymbolInfoInteger(_Symbol,SYMBOL_SPREAD)>InpMaxSpread){if(InpShowDashboard)UpdateDashboard();return;}

   // Get MA values
   int fastH=iMA(_Symbol,PERIOD_CURRENT,InpFastPeriod,0,InpMAMethod,InpPrice);
   int slowH=iMA(_Symbol,PERIOD_CURRENT,InpSlowPeriod,0,InpMAMethod,InpPrice);
   if(fastH==INVALID_HANDLE||slowH==INVALID_HANDLE) return;
   double fast[2],slow[2];
   if(CopyBuffer(fastH,0,1,2,fast)!=2||CopyBuffer(slowH,0,1,2,slow)!=2){IndicatorRelease(fastH);IndicatorRelease(slowH);return;}
   IndicatorRelease(fastH);IndicatorRelease(slowH);

   // Cross detection (bar 1 vs bar 0 from shift 1)
   bool bullCross=(fast[1]>slow[1]&&fast[0]<=slow[0]);
   bool bearCross=(fast[1]<slow[1]&&fast[0]>=slow[0]);

   double ask=SymbolInfoDouble(_Symbol,SYMBOL_ASK);
   double bid=SymbolInfoDouble(_Symbol,SYMBOL_BID);

   // Close opposite positions
   if(bullCross) CloseMyPositions(POSITION_TYPE_SELL);
   if(bearCross) CloseMyPositions(POSITION_TYPE_BUY);

   // Open new position
   double lots=InpLotSize;
   if(InpUseRisk){
      double balance=AccountInfoDouble(ACCOUNT_BALANCE);
      double tickVal=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_VALUE);
      double tickSize=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
      if(tickSize>0&&InpSLPoints>0){
         double riskAmt=balance*InpRiskPercent/100.0;
         double pipVal=tickVal/(tickSize/_Point);
         lots=riskAmt/(InpSLPoints*pipVal);
      }
      double minLot=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN);
      double lotStep=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP);
      if(lotStep>0) lots=MathFloor(lots/lotStep)*lotStep;
      if(lots<minLot) lots=minLot;
   }

   if(bullCross&&CountMyPositions(POSITION_TYPE_BUY)==0){
      double sl=ask-InpSLPoints*_Point; double tp=ask+InpTPPoints*_Point;
      g_trade.Buy(lots,_Symbol,ask,sl,tp,"ExMachina MAC Buy");g_totalTrades++;
   }
   if(bearCross&&CountMyPositions(POSITION_TYPE_SELL)==0){
      double sl=bid+InpSLPoints*_Point; double tp=bid-InpTPPoints*_Point;
      g_trade.Sell(lots,_Symbol,bid,sl,tp,"ExMachina MAC Sell");g_totalTrades++;
   }

   ManagePositions();
   if(InpShowDashboard) UpdateDashboard();
}

void ManagePositions(){
   for(int i=PositionsTotal()-1;i>=0;i--){
      ulong ticket=PositionGetTicket(i);if(ticket==0) continue;
      if(PositionGetInteger(POSITION_MAGIC)!=InpMagic||PositionGetString(POSITION_SYMBOL)!=_Symbol) continue;
      ENUM_POSITION_TYPE type=(ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      double open=PositionGetDouble(POSITION_PRICE_OPEN);double sl=PositionGetDouble(POSITION_SL);double tp=PositionGetDouble(POSITION_TP);
      double bid=SymbolInfoDouble(_Symbol,SYMBOL_BID);double ask=SymbolInfoDouble(_Symbol,SYMBOL_ASK);
      double newSL=sl;

      if(type==POSITION_TYPE_BUY){
         double profit=(bid-open)/_Point;
         // Breakeven
         if(InpBETrigger>0&&profit>=InpBETrigger&&sl<open+InpBEProtect*_Point) newSL=open+InpBEProtect*_Point;
         // Trailing
         if(InpTrailPoints>0&&profit>=InpTrailPoints){double trail=bid-InpTrailPoints*_Point;if(trail>newSL) newSL=trail;}
      }else{
         double profit=(open-ask)/_Point;
         if(InpBETrigger>0&&profit>=InpBETrigger&&(sl>open-InpBEProtect*_Point||sl==0)) newSL=open-InpBEProtect*_Point;
         if(InpTrailPoints>0&&profit>=InpTrailPoints){double trail=ask+InpTrailPoints*_Point;if(trail<newSL||sl==0) newSL=trail;}
      }

      if(newSL!=sl&&newSL!=0) g_trade.PositionModify(ticket,NormalizeDouble(newSL,_Digits),tp);
   }
}

int CountMyPositions(ENUM_POSITION_TYPE type){int c=0;for(int i=PositionsTotal()-1;i>=0;i--){ulong t=PositionGetTicket(i);if(t>0&&PositionGetInteger(POSITION_MAGIC)==InpMagic&&PositionGetString(POSITION_SYMBOL)==_Symbol&&(ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE)==type)c++;}return c;}
void CloseMyPositions(ENUM_POSITION_TYPE type){for(int i=PositionsTotal()-1;i>=0;i--){ulong t=PositionGetTicket(i);if(t>0&&PositionGetInteger(POSITION_MAGIC)==InpMagic&&PositionGetString(POSITION_SYMBOL)==_Symbol&&(ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE)==type)g_trade.PositionClose(t,50);}}

void CreateDashboard(){
   int w=280,h=185;string bg=g_objPrefix+"BG";
   ObjectCreate(0,bg,OBJ_RECTANGLE_LABEL,0,0,0);ObjectSetInteger(0,bg,OBJPROP_XDISTANCE,InpDashX);ObjectSetInteger(0,bg,OBJPROP_YDISTANCE,InpDashY);ObjectSetInteger(0,bg,OBJPROP_XSIZE,w);ObjectSetInteger(0,bg,OBJPROP_YSIZE,h);ObjectSetInteger(0,bg,OBJPROP_BGCOLOR,InpDashBgColor);ObjectSetInteger(0,bg,OBJPROP_BORDER_COLOR,C'30,34,46');ObjectSetInteger(0,bg,OBJPROP_BORDER_TYPE,BORDER_FLAT);ObjectSetInteger(0,bg,OBJPROP_CORNER,CORNER_LEFT_UPPER);ObjectSetInteger(0,bg,OBJPROP_BACK,false);ObjectSetInteger(0,bg,OBJPROP_SELECTABLE,false);
   ML("Title",InpDashX+10,InpDashY+8,"EXMACHINA MA CROSSOVER",C'90,180,220',InpDashFontSize+1);
   ML("Sep1",InpDashX+10,InpDashY+26,"──────────────────────────",C'30,34,46',InpDashFontSize-2);
   ML("MaLbl",InpDashX+10,InpDashY+40,"MAs:",C'90,95,110',InpDashFontSize);ML("MaVal",InpDashX+130,InpDashY+40,"EMA("+IntegerToString(InpFastPeriod)+"/"+IntegerToString(InpSlowPeriod)+")",C'200,170,50',InpDashFontSize);
   ML("SgLbl",InpDashX+10,InpDashY+58,"Signal:",C'90,95,110',InpDashFontSize);ML("SgVal",InpDashX+130,InpDashY+58,"---",InpDashTextColor,InpDashFontSize);
   ML("PsLbl",InpDashX+10,InpDashY+76,"Position:",C'90,95,110',InpDashFontSize);ML("PsVal",InpDashX+130,InpDashY+76,"---",InpDashTextColor,InpDashFontSize);
   ML("Sep2",InpDashX+10,InpDashY+94,"──────────────────────────",C'30,34,46',InpDashFontSize-2);
   ML("TdLbl",InpDashX+10,InpDashY+108,"Trades:",C'90,95,110',InpDashFontSize);ML("TdVal",InpDashX+130,InpDashY+108,"0",InpDashTextColor,InpDashFontSize);
   ML("PlLbl",InpDashX+10,InpDashY+126,"Float P/L:",C'90,95,110',InpDashFontSize);ML("PlVal",InpDashX+130,InpDashY+126,"$0.00",InpDashTextColor,InpDashFontSize);
   ML("SpLbl",InpDashX+10,InpDashY+144,"Spread:",C'90,95,110',InpDashFontSize);ML("SpVal",InpDashX+130,InpDashY+144,"---",InpDashTextColor,InpDashFontSize);
   ML("Sep3",InpDashX+10,InpDashY+162,"──────────────────────────",C'30,34,46',InpDashFontSize-2);
   ML("Brand",InpDashX+10,InpDashY+174,"Precision before profit",C'55,60,75',InpDashFontSize-2);ChartRedraw(0);
}
void ML(string id,int x,int y,string text,color clr,int fs){string name=g_objPrefix+id;ObjectCreate(0,name,OBJ_LABEL,0,0,0);ObjectSetInteger(0,name,OBJPROP_XDISTANCE,x);ObjectSetInteger(0,name,OBJPROP_YDISTANCE,y);ObjectSetString(0,name,OBJPROP_TEXT,text);ObjectSetInteger(0,name,OBJPROP_COLOR,clr);ObjectSetInteger(0,name,OBJPROP_FONTSIZE,fs);ObjectSetString(0,name,OBJPROP_FONT,"Consolas");ObjectSetInteger(0,name,OBJPROP_CORNER,CORNER_LEFT_UPPER);ObjectSetInteger(0,name,OBJPROP_ANCHOR,ANCHOR_LEFT_UPPER);ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,name,OBJPROP_BACK,false);}
void UpdateDashboard(){
   // Signal
   int fastH=iMA(_Symbol,PERIOD_CURRENT,InpFastPeriod,0,InpMAMethod,InpPrice);
   int slowH=iMA(_Symbol,PERIOD_CURRENT,InpSlowPeriod,0,InpMAMethod,InpPrice);
   if(fastH!=INVALID_HANDLE&&slowH!=INVALID_HANDLE){
      double f[1],s[1];
      if(CopyBuffer(fastH,0,0,1,f)==1&&CopyBuffer(slowH,0,0,1,s)==1){
         string sig=(f[0]>s[0])?"▲ BULLISH":"▼ BEARISH";color sc=(f[0]>s[0])?C'0,185,140':C'220,50,80';
         ObjectSetString(0,g_objPrefix+"SgVal",OBJPROP_TEXT,sig);ObjectSetInteger(0,g_objPrefix+"SgVal",OBJPROP_COLOR,sc);
      }
      IndicatorRelease(fastH);IndicatorRelease(slowH);
   }
   // Position
   int buys=CountMyPositions(POSITION_TYPE_BUY);int sells=CountMyPositions(POSITION_TYPE_SELL);
   string ps=(buys>0)?"BUY x"+IntegerToString(buys):(sells>0)?"SELL x"+IntegerToString(sells):"FLAT";
   color pc=(buys>0)?C'0,185,140':(sells>0)?C'220,50,80':C'90,95,110';
   ObjectSetString(0,g_objPrefix+"PsVal",OBJPROP_TEXT,ps);ObjectSetInteger(0,g_objPrefix+"PsVal",OBJPROP_COLOR,pc);
   ObjectSetString(0,g_objPrefix+"TdVal",OBJPROP_TEXT,IntegerToString(g_totalTrades));
   // Float PL
   double pl=0;for(int i=PositionsTotal()-1;i>=0;i--){ulong t=PositionGetTicket(i);if(t>0&&PositionGetInteger(POSITION_MAGIC)==InpMagic&&PositionGetString(POSITION_SYMBOL)==_Symbol)pl+=PositionGetDouble(POSITION_PROFIT)+PositionGetDouble(POSITION_SWAP);}
   string plSign=(pl>=0)?"+":"";color plClr=(pl>=0)?C'0,185,140':C'220,50,80';
   ObjectSetString(0,g_objPrefix+"PlVal",OBJPROP_TEXT,plSign+"$"+DoubleToString(MathAbs(pl),2));ObjectSetInteger(0,g_objPrefix+"PlVal",OBJPROP_COLOR,plClr);
   ObjectSetString(0,g_objPrefix+"SpVal",OBJPROP_TEXT,IntegerToString((int)SymbolInfoInteger(_Symbol,SYMBOL_SPREAD))+" pts");
   ChartRedraw(0);
}
