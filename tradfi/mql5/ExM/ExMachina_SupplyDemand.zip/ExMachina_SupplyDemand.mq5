//+------------------------------------------------------------------+
//|                                 ExMachina_SupplyDemand.mq5       |
//|                          Copyright 2026, ExMachina Trading Systems|
//|                   https://www.mql5.com/en/users/williammukam      |
//+------------------------------------------------------------------+
#property copyright   "ExMachina Trading Systems"
#property link        "https://www.mql5.com/en/users/williammukam"
#property version     "1.00"
#property description "ExMachina Supply & Demand Zones"
#property description "Auto-detect supply/demand from impulse moves."
#property description "Strength rating, freshness tracking, alerts."
#property description "Precision before profit."
#property indicator_chart_window
#property indicator_buffers 0
#property indicator_plots   0
#property strict

input group "══════ Detection ══════"
input int    InpLookback      = 500;
input double InpMinImpulse    = 2.0;      // Min Impulse Size (ATR multiplier)
input int    InpATRPeriod     = 14;
input int    InpMaxZones      = 15;
input bool   InpShowFresh     = true;     // Show Only Fresh Zones

input group "══════ Visual ══════"
input color  InpDemandColor   = C'0,100,80';
input color  InpSupplyColor   = C'130,35,55';
input color  InpTestedColor   = C'35,38,48';
input bool   InpShowLabels    = true;
input bool   InpExtendRight   = true;
input bool   InpShowDashboard = true;

input group "══════ Alerts ══════"
input bool   InpAlertTouch    = true;
input bool   InpAlertPopup    = true;
input bool   InpAlertSound    = true;
input bool   InpAlertPush     = false;

input group "══════ Dashboard ══════"
input int InpDashX=20; input int InpDashY=40; input int InpDashFontSize=9;
input color InpDashBgColor=C'8,10,18'; input color InpDashTextColor=C'160,168,180';

string g_objPrefix="EXSS_SD_";
struct SDZone{datetime t;double hi;double lo;bool isDemand;bool isFresh;int strength;};
SDZone g_zones[]; int g_zoneCount=0;
int g_demandCount=0,g_supplyCount=0,g_freshCount=0;
datetime g_lastAlertTime=0;

int OnInit(){IndicatorSetString(INDICATOR_SHORTNAME,"ExMachina S&D Zones");if(InpShowDashboard)CreateDashboard();return(INIT_SUCCEEDED);}
void OnDeinit(const int reason){ObjectsDeleteAll(0,g_objPrefix);ChartRedraw(0);}

int OnCalculate(const int rates_total,const int prev_calculated,const datetime &time[],const double &open[],const double &high[],const double &low[],const double &close[],const long &tick_volume[],const long &volume[],const int &spread[]){
   if(rates_total<InpATRPeriod+10) return(0);
   if(prev_calculated==0){ObjectsDeleteAll(0,g_objPrefix+"ZN_");ObjectsDeleteAll(0,g_objPrefix+"LBL_");}

   int start=MathMax(rates_total-InpLookback,InpATRPeriod+2);
   // Get ATR for impulse threshold
   int atrH=iATR(_Symbol,PERIOD_CURRENT,InpATRPeriod);
   if(atrH==INVALID_HANDLE) return(0);
   double atrBuf[]; ArraySetAsSeries(atrBuf,false);
   if(CopyBuffer(atrH,0,0,rates_total,atrBuf)<rates_total){IndicatorRelease(atrH);return(0);}
   IndicatorRelease(atrH);

   ArrayResize(g_zones,0);g_zoneCount=0;g_demandCount=0;g_supplyCount=0;g_freshCount=0;

   for(int i=start;i<rates_total-1;i++){
      double body=MathAbs(close[i]-open[i]);
      double atr=atrBuf[i]; if(atr<=0) continue;
      if(body<atr*InpMinImpulse) continue;

      // Bullish impulse → demand zone at base before it
      if(close[i]>open[i]){
         int base=i-1; if(base<0) continue;
         SDZone z; z.t=time[base]; z.hi=MathMax(open[base],close[base]); z.lo=low[base];
         z.isDemand=true; z.isFresh=true; z.strength=(int)(body/atr*10);
         // Check if tested
         for(int j=i+1;j<rates_total;j++) if(close[j]<z.lo){z.isFresh=false;break;}
         g_zoneCount++;ArrayResize(g_zones,g_zoneCount);g_zones[g_zoneCount-1]=z;
         g_demandCount++;if(z.isFresh)g_freshCount++;
      }
      // Bearish impulse → supply zone
      if(close[i]<open[i]){
         int base=i-1; if(base<0) continue;
         SDZone z; z.t=time[base]; z.hi=high[base]; z.lo=MathMin(open[base],close[base]);
         z.isDemand=false; z.isFresh=true; z.strength=(int)(body/atr*10);
         for(int j=i+1;j<rates_total;j++) if(close[j]>z.hi){z.isFresh=false;break;}
         g_zoneCount++;ArrayResize(g_zones,g_zoneCount);g_zones[g_zoneCount-1]=z;
         g_supplyCount++;if(z.isFresh)g_freshCount++;
      }
   }

   // Draw
   ObjectsDeleteAll(0,g_objPrefix+"ZN_");ObjectsDeleteAll(0,g_objPrefix+"LBL_");
   int drawn=0;datetime endT=time[rates_total-1]+PeriodSeconds()*5;
   for(int i=g_zoneCount-1;i>=0&&drawn<InpMaxZones;i--){
      if(InpShowFresh&&!g_zones[i].isFresh) continue;
      color clr=g_zones[i].isFresh?(g_zones[i].isDemand?InpDemandColor:InpSupplyColor):InpTestedColor;
      string id=IntegerToString(i);
      datetime eT=InpExtendRight?endT:g_zones[i].t+PeriodSeconds()*20;
      string bn=g_objPrefix+"ZN_"+id;
      ObjectCreate(0,bn,OBJ_RECTANGLE,0,g_zones[i].t,g_zones[i].hi,eT,g_zones[i].lo);
      ObjectSetInteger(0,bn,OBJPROP_COLOR,clr);ObjectSetInteger(0,bn,OBJPROP_FILL,true);
      ObjectSetInteger(0,bn,OBJPROP_BACK,true);ObjectSetInteger(0,bn,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,bn,OBJPROP_HIDDEN,true);
      if(InpShowLabels){
         string lb=g_objPrefix+"LBL_"+id;
         string txt=(g_zones[i].isDemand?"Demand":"Supply")+(g_zones[i].isFresh?" ●":" [T]")+" S:"+IntegerToString(g_zones[i].strength);
         ObjectCreate(0,lb,OBJ_TEXT,0,g_zones[i].t,g_zones[i].isDemand?g_zones[i].lo:g_zones[i].hi);
         ObjectSetString(0,lb,OBJPROP_TEXT,txt);ObjectSetInteger(0,lb,OBJPROP_COLOR,clr);
         ObjectSetString(0,lb,OBJPROP_FONT,"Consolas");ObjectSetInteger(0,lb,OBJPROP_FONTSIZE,7);
         ObjectSetInteger(0,lb,OBJPROP_ANCHOR,g_zones[i].isDemand?ANCHOR_LEFT_UPPER:ANCHOR_LEFT_LOWER);
         ObjectSetInteger(0,lb,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,lb,OBJPROP_HIDDEN,true);
      }
      drawn++;
   }

   // Alert
   if(InpAlertTouch&&rates_total>1&&time[rates_total-1]>g_lastAlertTime){
      double h=high[rates_total-1],l=low[rates_total-1];
      for(int i=g_zoneCount-1;i>=0;i--){
         if(!g_zones[i].isFresh) continue;
         if(l<=g_zones[i].hi&&h>=g_zones[i].lo){
            string d=g_zones[i].isDemand?"DEMAND":"SUPPLY";
            string msg="ExMachina S&D | "+_Symbol+" | Price entering "+d+" zone";
            if(InpAlertPopup)Alert(msg);if(InpAlertSound)PlaySound("alert.wav");if(InpAlertPush)SendNotification(msg);Print(msg);
            g_lastAlertTime=time[rates_total-1];break;
         }
      }
   }
   if(InpShowDashboard) UpdateDashboard();
   return(rates_total);
}

void CreateDashboard(){
   int w=250,h=150;string bg=g_objPrefix+"DASH_BG";
   ObjectCreate(0,bg,OBJ_RECTANGLE_LABEL,0,0,0);ObjectSetInteger(0,bg,OBJPROP_XDISTANCE,InpDashX);ObjectSetInteger(0,bg,OBJPROP_YDISTANCE,InpDashY);
   ObjectSetInteger(0,bg,OBJPROP_XSIZE,w);ObjectSetInteger(0,bg,OBJPROP_YSIZE,h);ObjectSetInteger(0,bg,OBJPROP_BGCOLOR,InpDashBgColor);
   ObjectSetInteger(0,bg,OBJPROP_BORDER_COLOR,C'30,34,46');ObjectSetInteger(0,bg,OBJPROP_BORDER_TYPE,BORDER_FLAT);ObjectSetInteger(0,bg,OBJPROP_CORNER,CORNER_LEFT_UPPER);
   ObjectSetInteger(0,bg,OBJPROP_BACK,false);ObjectSetInteger(0,bg,OBJPROP_SELECTABLE,false);
   ML("Title",InpDashX+10,InpDashY+8,"EXMACHINA S&D ZONES",C'90,180,220',InpDashFontSize+1);
   ML("Sep1",InpDashX+10,InpDashY+26,"────────────────────────",C'30,34,46',InpDashFontSize-2);
   ML("TLbl",InpDashX+10,InpDashY+40,"Total:",C'90,95,110',InpDashFontSize);ML("TVal",InpDashX+150,InpDashY+40,"---",InpDashTextColor,InpDashFontSize);
   ML("DLbl",InpDashX+10,InpDashY+58,"Demand:",C'90,95,110',InpDashFontSize);ML("DVal",InpDashX+150,InpDashY+58,"---",InpDemandColor,InpDashFontSize);
   ML("SLbl",InpDashX+10,InpDashY+76,"Supply:",C'90,95,110',InpDashFontSize);ML("SVal",InpDashX+150,InpDashY+76,"---",InpSupplyColor,InpDashFontSize);
   ML("FLbl",InpDashX+10,InpDashY+94,"Fresh:",C'90,95,110',InpDashFontSize);ML("FVal",InpDashX+150,InpDashY+94,"---",C'0,185,140',InpDashFontSize);
   ML("Sep2",InpDashX+10,InpDashY+112,"────────────────────────",C'30,34,46',InpDashFontSize-2);
   ML("Brand",InpDashX+10,InpDashY+126,"Precision before profit",C'55,60,75',InpDashFontSize-2);
   ChartRedraw(0);
}
void ML(string id,int x,int y,string text,color clr,int fs){string name=g_objPrefix+"DASH_"+id;ObjectCreate(0,name,OBJ_LABEL,0,0,0);ObjectSetInteger(0,name,OBJPROP_XDISTANCE,x);ObjectSetInteger(0,name,OBJPROP_YDISTANCE,y);ObjectSetString(0,name,OBJPROP_TEXT,text);ObjectSetInteger(0,name,OBJPROP_COLOR,clr);ObjectSetInteger(0,name,OBJPROP_FONTSIZE,fs);ObjectSetString(0,name,OBJPROP_FONT,"Consolas");ObjectSetInteger(0,name,OBJPROP_CORNER,CORNER_LEFT_UPPER);ObjectSetInteger(0,name,OBJPROP_ANCHOR,ANCHOR_LEFT_UPPER);ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);ObjectSetInteger(0,name,OBJPROP_BACK,false);}
void UpdateDashboard(){ObjectSetString(0,g_objPrefix+"DASH_TVal",OBJPROP_TEXT,IntegerToString(g_zoneCount));ObjectSetString(0,g_objPrefix+"DASH_DVal",OBJPROP_TEXT,IntegerToString(g_demandCount));ObjectSetString(0,g_objPrefix+"DASH_SVal",OBJPROP_TEXT,IntegerToString(g_supplyCount));ObjectSetString(0,g_objPrefix+"DASH_FVal",OBJPROP_TEXT,IntegerToString(g_freshCount));ChartRedraw(0);}
