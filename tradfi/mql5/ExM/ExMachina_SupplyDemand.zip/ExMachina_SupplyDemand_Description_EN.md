# ExMachina Supply & Demand Zones — MQL5 Code Base Description (English)

## Title
ExMachina Supply & Demand Zones

## Short Description
Auto-detect supply/demand from impulse candles with ATR filter, strength rating, freshness tracking, alerts. Free.

## Full Description

**ExMachina Supply & Demand Zones** — part of the ExMachina Trading Systems free Code Base collection. Professional quality with ExMachina steel palette design, dashboard panel, and alert system.

All graphical objects use the EXSS_ prefix for clean chart management. Colors fully customizable. Works on all symbols and timeframes.

Developed by ExMachina Trading Systems — Precision before profit.

For professional trading tools, visit: https://www.mql5.com/en/users/williammukam

## Tags (comma-separated)
supply demand,zones,impulse,ATR,strength,fresh,support resistance,price action,free,forex,gold

## Category
Technical Indicators

## Subcategory
Support and Resistance
