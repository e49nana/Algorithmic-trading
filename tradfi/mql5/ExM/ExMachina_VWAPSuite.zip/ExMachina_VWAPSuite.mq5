//+------------------------------------------------------------------+
//|                                      ExMachina_VWAPSuite.mq5     |
//|                          Copyright 2026, ExMachina Trading Systems|
//|                   https://www.mql5.com/en/users/williammukam      |
//+------------------------------------------------------------------+
//|  ExMachina VWAP Suite — Precision before profit                   |
//|  Volume Weighted Average Price with daily/weekly/monthly          |
//|  anchoring, standard deviation bands, and dashboard.              |
//+------------------------------------------------------------------+
#property copyright   "ExMachina Trading Systems"
#property link        "https://www.mql5.com/en/users/williammukam"
#property version     "1.00"
#property description "ExMachina VWAP Suite"
#property description "Daily, Weekly, Monthly VWAP with ±1/2/3σ bands."
#property description "Multi-period display, dashboard, touch alerts."
#property description "Precision before profit."
#property indicator_chart_window
#property indicator_buffers 7
#property indicator_plots   7
#property strict

//--- VWAP line
#property indicator_label1  "VWAP"
#property indicator_type1   DRAW_LINE
#property indicator_color1  clrDodgerBlue
#property indicator_style1  STYLE_SOLID
#property indicator_width1  2

//--- Upper bands
#property indicator_label2  "+1σ"
#property indicator_type2   DRAW_LINE
#property indicator_color2  clrDodgerBlue
#property indicator_style2  STYLE_DOT
#property indicator_width2  1

#property indicator_label3  "+2σ"
#property indicator_type3   DRAW_LINE
#property indicator_color3  clrDodgerBlue
#property indicator_style3  STYLE_DOT
#property indicator_width3  1

#property indicator_label4  "+3σ"
#property indicator_type4   DRAW_LINE
#property indicator_color4  clrDodgerBlue
#property indicator_style4  STYLE_DOT
#property indicator_width4  1

//--- Lower bands
#property indicator_label5  "-1σ"
#property indicator_type5   DRAW_LINE
#property indicator_color5  clrDodgerBlue
#property indicator_style5  STYLE_DOT
#property indicator_width5  1

#property indicator_label6  "-2σ"
#property indicator_type6   DRAW_LINE
#property indicator_color6  clrDodgerBlue
#property indicator_style6  STYLE_DOT
#property indicator_width6  1

#property indicator_label7  "-3σ"
#property indicator_type7   DRAW_LINE
#property indicator_color7  clrDodgerBlue
#property indicator_style7  STYLE_DOT
#property indicator_width7  1

//+------------------------------------------------------------------+
//| Enumerations                                                      |
//+------------------------------------------------------------------+
enum ENUM_VWAP_ANCHOR
  {
   ANCHOR_DAILY   = 0,   // Daily (reset each day)
   ANCHOR_WEEKLY  = 1,   // Weekly (reset each week)
   ANCHOR_MONTHLY = 2,   // Monthly (reset each month)
   ANCHOR_SESSION = 3    // Session (custom hour reset)
  };

//+------------------------------------------------------------------+
//| Input Parameters                                                  |
//+------------------------------------------------------------------+
input group              "══════ VWAP Settings ══════"
input ENUM_VWAP_ANCHOR   InpAnchor          = ANCHOR_DAILY;    // Anchor Period
input int                InpSessionHour     = 0;               // Session Reset Hour (for Session mode)
input ENUM_APPLIED_PRICE InpPriceType       = PRICE_TYPICAL;   // Price Type (HLC/3 default)

input group              "══════ Bands ══════"
input bool               InpShowBand1       = true;            // Show ±1σ Bands
input bool               InpShowBand2       = true;            // Show ±2σ Bands
input bool               InpShowBand3       = false;           // Show ±3σ Bands
input double             InpBandMult1       = 1.0;             // Band 1 Multiplier
input double             InpBandMult2       = 2.0;             // Band 2 Multiplier
input double             InpBandMult3       = 3.0;             // Band 3 Multiplier

input group              "══════ Visual Settings ══════"
input color              InpVWAPColor       = C'90,180,220';   // VWAP Line Color
input color              InpBand1Color      = C'60,130,170';   // Band 1 Color
input color              InpBand2Color      = C'45,100,140';   // Band 2 Color
input color              InpBand3Color      = C'35,75,110';    // Band 3 Color
input int                InpVWAPWidth       = 2;               // VWAP Line Width
input bool               InpShowDashboard   = true;            // Show Dashboard

input group              "══════ Alert Settings ══════"
input bool               InpAlertTouch      = false;           // Alert on VWAP Touch
input bool               InpAlertPopup      = true;            // Popup Alert
input bool               InpAlertSound      = true;            // Sound Alert
input bool               InpAlertPush       = false;           // Push Notification

input group              "══════ Dashboard Settings ══════"
input int                InpDashX           = 20;              // Dashboard X Position
input int                InpDashY           = 40;              // Dashboard Y Position
input int                InpDashFontSize    = 9;               // Font Size
input color              InpDashBgColor     = C'8,10,18';      // Background
input color              InpDashTextColor   = C'160,168,180';  // Text Color

//+------------------------------------------------------------------+
//| Global Variables                                                   |
//+------------------------------------------------------------------+
string g_objPrefix = "EXSS_VWAP_";

double BuffVWAP[];
double BuffUp1[], BuffUp2[], BuffUp3[];
double BuffDn1[], BuffDn2[], BuffDn3[];

datetime g_lastAlertTime = 0;

//+------------------------------------------------------------------+
//| Initialization                                                    |
//+------------------------------------------------------------------+
int OnInit()
  {
   SetIndexBuffer(0, BuffVWAP, INDICATOR_DATA);
   SetIndexBuffer(1, BuffUp1,  INDICATOR_DATA);
   SetIndexBuffer(2, BuffUp2,  INDICATOR_DATA);
   SetIndexBuffer(3, BuffUp3,  INDICATOR_DATA);
   SetIndexBuffer(4, BuffDn1,  INDICATOR_DATA);
   SetIndexBuffer(5, BuffDn2,  INDICATOR_DATA);
   SetIndexBuffer(6, BuffDn3,  INDICATOR_DATA);

   for(int i = 0; i < 7; i++)
      PlotIndexSetDouble(i, PLOT_EMPTY_VALUE, EMPTY_VALUE);

//--- Colors
   PlotIndexSetInteger(0, PLOT_LINE_COLOR, InpVWAPColor);
   PlotIndexSetInteger(0, PLOT_LINE_WIDTH, InpVWAPWidth);

   PlotIndexSetInteger(1, PLOT_LINE_COLOR, InpBand1Color);
   PlotIndexSetInteger(2, PLOT_LINE_COLOR, InpBand2Color);
   PlotIndexSetInteger(3, PLOT_LINE_COLOR, InpBand3Color);
   PlotIndexSetInteger(4, PLOT_LINE_COLOR, InpBand1Color);
   PlotIndexSetInteger(5, PLOT_LINE_COLOR, InpBand2Color);
   PlotIndexSetInteger(6, PLOT_LINE_COLOR, InpBand3Color);

//--- Hide unused bands
   if(!InpShowBand1) { PlotIndexSetInteger(1, PLOT_DRAW_TYPE, DRAW_NONE); PlotIndexSetInteger(4, PLOT_DRAW_TYPE, DRAW_NONE); }
   if(!InpShowBand2) { PlotIndexSetInteger(2, PLOT_DRAW_TYPE, DRAW_NONE); PlotIndexSetInteger(5, PLOT_DRAW_TYPE, DRAW_NONE); }
   if(!InpShowBand3) { PlotIndexSetInteger(3, PLOT_DRAW_TYPE, DRAW_NONE); PlotIndexSetInteger(6, PLOT_DRAW_TYPE, DRAW_NONE); }

   string anchorName = "";
   switch(InpAnchor)
     {
      case ANCHOR_DAILY:   anchorName = "Daily";   break;
      case ANCHOR_WEEKLY:  anchorName = "Weekly";  break;
      case ANCHOR_MONTHLY: anchorName = "Monthly"; break;
      case ANCHOR_SESSION: anchorName = "Session"; break;
     }
   IndicatorSetString(INDICATOR_SHORTNAME, "ExMachina VWAP (" + anchorName + ")");
   IndicatorSetInteger(INDICATOR_DIGITS, _Digits);

   if(InpShowDashboard)
      CreateDashboard();

   return(INIT_SUCCEEDED);
  }

//+------------------------------------------------------------------+
//| Deinitialization                                                  |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   ObjectsDeleteAll(0, g_objPrefix);
   ChartRedraw(0);
  }

//+------------------------------------------------------------------+
//| Main calculation                                                  |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
   if(rates_total < 2)
      return(0);

   int start = (prev_calculated == 0) ? 0 : prev_calculated - 1;

//--- Use tick_volume as volume proxy (real volume if available)
   double cumTPV = 0;  // cumulative (typical price * volume)
   double cumVol = 0;  // cumulative volume
   double cumTPV2 = 0; // cumulative (tp^2 * volume) for std dev

   //--- If resuming, we need to recalculate from last anchor
   if(prev_calculated > 0 && start > 0)
     {
      //--- Find last anchor point before start
      int anchor = FindAnchorBefore(time, start);
      if(anchor >= 0)
        {
         start = anchor;
         cumTPV = 0;
         cumVol = 0;
         cumTPV2 = 0;
        }
     }

   for(int i = start; i < rates_total; i++)
     {
      //--- Check for anchor reset
      if(i == 0 || IsNewAnchor(time, i))
        {
         cumTPV  = 0;
         cumVol  = 0;
         cumTPV2 = 0;
        }

      //--- Get price
      double tp = GetAppliedPrice(InpPriceType, open[i], high[i], low[i], close[i]);

      //--- Get volume
      double vol = (double)tick_volume[i];
      if(vol <= 0) vol = 1;

      //--- Accumulate
      cumTPV  += tp * vol;
      cumVol  += vol;
      cumTPV2 += tp * tp * vol;

      //--- VWAP
      double vwap = (cumVol > 0) ? cumTPV / cumVol : tp;
      BuffVWAP[i] = vwap;

      //--- Standard deviation
      double variance = 0;
      if(cumVol > 0)
         variance = (cumTPV2 / cumVol) - (vwap * vwap);
      if(variance < 0) variance = 0;
      double stddev = MathSqrt(variance);

      //--- Bands
      BuffUp1[i] = InpShowBand1 ? vwap + stddev * InpBandMult1 : EMPTY_VALUE;
      BuffUp2[i] = InpShowBand2 ? vwap + stddev * InpBandMult2 : EMPTY_VALUE;
      BuffUp3[i] = InpShowBand3 ? vwap + stddev * InpBandMult3 : EMPTY_VALUE;
      BuffDn1[i] = InpShowBand1 ? vwap - stddev * InpBandMult1 : EMPTY_VALUE;
      BuffDn2[i] = InpShowBand2 ? vwap - stddev * InpBandMult2 : EMPTY_VALUE;
      BuffDn3[i] = InpShowBand3 ? vwap - stddev * InpBandMult3 : EMPTY_VALUE;
     }

//--- Touch alert
   if(InpAlertTouch && rates_total > 1)
     {
      double tolerance = _Point * 5;
      int lastBar = rates_total - 2;
      if(time[lastBar] > g_lastAlertTime)
        {
         if(MathAbs(close[lastBar] - BuffVWAP[lastBar]) <= tolerance ||
            (low[lastBar] <= BuffVWAP[lastBar] && high[lastBar] >= BuffVWAP[lastBar]))
           {
            string msg = "ExMachina VWAP | " + _Symbol + " | Price touching VWAP @ " +
                         DoubleToString(BuffVWAP[lastBar], _Digits);
            if(InpAlertPopup) Alert(msg);
            if(InpAlertSound) PlaySound("alert.wav");
            if(InpAlertPush)  SendNotification(msg);
            Print(msg);
            g_lastAlertTime = time[lastBar];
           }
        }
     }

//--- Update dashboard
   if(InpShowDashboard && rates_total > 1)
     {
      int last = rates_total - 1;
      UpdateDashboard(close[last], BuffVWAP[last],
                      BuffUp1[last], BuffUp2[last],
                      BuffDn1[last], BuffDn2[last]);
     }

   return(rates_total);
  }

//+------------------------------------------------------------------+
//| Check if new anchor period started                                |
//+------------------------------------------------------------------+
bool IsNewAnchor(const datetime &time[], int idx)
  {
   if(idx == 0) return(true);

   MqlDateTime curr, prev;
   TimeToStruct(time[idx],   curr);
   TimeToStruct(time[idx-1], prev);

   switch(InpAnchor)
     {
      case ANCHOR_DAILY:
         return(curr.day != prev.day || curr.mon != prev.mon || curr.year != prev.year);

      case ANCHOR_WEEKLY:
         return(curr.day_of_week < prev.day_of_week ||
                (time[idx] - time[idx-1]) > 3 * 86400);

      case ANCHOR_MONTHLY:
         return(curr.mon != prev.mon || curr.year != prev.year);

      case ANCHOR_SESSION:
         return((curr.hour >= InpSessionHour && prev.hour < InpSessionHour) ||
                (curr.day != prev.day && curr.hour >= InpSessionHour));
     }

   return(false);
  }

//+------------------------------------------------------------------+
//| Find last anchor before index                                     |
//+------------------------------------------------------------------+
int FindAnchorBefore(const datetime &time[], int idx)
  {
   for(int i = idx; i >= 1; i--)
     {
      if(IsNewAnchor(time, i))
         return(i);
     }
   return(0);
  }

//+------------------------------------------------------------------+
//| Get applied price                                                 |
//+------------------------------------------------------------------+
double GetAppliedPrice(ENUM_APPLIED_PRICE type, double open, double high,
                       double low, double close)
  {
   switch(type)
     {
      case PRICE_CLOSE:    return(close);
      case PRICE_OPEN:     return(open);
      case PRICE_HIGH:     return(high);
      case PRICE_LOW:      return(low);
      case PRICE_MEDIAN:   return((high + low) / 2.0);
      case PRICE_TYPICAL:  return((high + low + close) / 3.0);
      case PRICE_WEIGHTED: return((high + low + close + close) / 4.0);
     }
   return((high + low + close) / 3.0);
  }

//+------------------------------------------------------------------+
//| Create dashboard                                                  |
//+------------------------------------------------------------------+
void CreateDashboard()
  {
   int w = 250, h = 165;

   string bg = g_objPrefix + "DASH_BG";
   ObjectCreate(0, bg, OBJ_RECTANGLE_LABEL, 0, 0, 0);
   ObjectSetInteger(0, bg, OBJPROP_XDISTANCE,   InpDashX);
   ObjectSetInteger(0, bg, OBJPROP_YDISTANCE,   InpDashY);
   ObjectSetInteger(0, bg, OBJPROP_XSIZE,        w);
   ObjectSetInteger(0, bg, OBJPROP_YSIZE,        h);
   ObjectSetInteger(0, bg, OBJPROP_BGCOLOR,      InpDashBgColor);
   ObjectSetInteger(0, bg, OBJPROP_BORDER_COLOR, C'30,34,46');
   ObjectSetInteger(0, bg, OBJPROP_BORDER_TYPE,  BORDER_FLAT);
   ObjectSetInteger(0, bg, OBJPROP_CORNER,       CORNER_LEFT_UPPER);
   ObjectSetInteger(0, bg, OBJPROP_BACK,         false);
   ObjectSetInteger(0, bg, OBJPROP_SELECTABLE,   false);

   MakeLabel("Title",  InpDashX+10, InpDashY+8,   "EXMACHINA VWAP SUITE",    C'90,180,220', InpDashFontSize+1);
   MakeLabel("Sep1",   InpDashX+10, InpDashY+26,  "────────────────────────", C'30,34,46', InpDashFontSize-2);
   MakeLabel("VLbl",   InpDashX+10,  InpDashY+40,  "VWAP:",     C'90,95,110', InpDashFontSize);
   MakeLabel("VVal",   InpDashX+120, InpDashY+40,  "---",       InpVWAPColor, InpDashFontSize);
   MakeLabel("PLbl",   InpDashX+10,  InpDashY+58,  "Position:", C'90,95,110', InpDashFontSize);
   MakeLabel("PVal",   InpDashX+120, InpDashY+58,  "---",       InpDashTextColor, InpDashFontSize);
   MakeLabel("DLbl",   InpDashX+10,  InpDashY+76,  "Distance:", C'90,95,110', InpDashFontSize);
   MakeLabel("DVal",   InpDashX+120, InpDashY+76,  "---",       InpDashTextColor, InpDashFontSize);
   MakeLabel("Sep2",   InpDashX+10, InpDashY+94,  "────────────────────────", C'30,34,46', InpDashFontSize-2);
   MakeLabel("BLbl",   InpDashX+10,  InpDashY+108, "Band zone:", C'90,95,110', InpDashFontSize);
   MakeLabel("BVal",   InpDashX+120, InpDashY+108, "---",        InpDashTextColor, InpDashFontSize);
   MakeLabel("Sep3",   InpDashX+10, InpDashY+126, "────────────────────────", C'30,34,46', InpDashFontSize-2);
   MakeLabel("ALbl",   InpDashX+10,  InpDashY+138, "Anchor:",    C'90,95,110', InpDashFontSize);
   string anchorStr = "";
   switch(InpAnchor){ case ANCHOR_DAILY: anchorStr="Daily"; break; case ANCHOR_WEEKLY: anchorStr="Weekly"; break; case ANCHOR_MONTHLY: anchorStr="Monthly"; break; case ANCHOR_SESSION: anchorStr="Session("+IntegerToString(InpSessionHour)+"h)"; break; }
   MakeLabel("AVal",   InpDashX+120, InpDashY+138, anchorStr,    C'200,170,50', InpDashFontSize);
   MakeLabel("Brand",  InpDashX+10,  InpDashY+152, "Precision before profit", C'55,60,75', InpDashFontSize-2);

   ChartRedraw(0);
  }

//+------------------------------------------------------------------+
//| Make label                                                        |
//+------------------------------------------------------------------+
void MakeLabel(string id, int x, int y, string text, color clr, int fontSize)
  {
   string name = g_objPrefix + "DASH_" + id;
   ObjectCreate(0, name, OBJ_LABEL, 0, 0, 0);
   ObjectSetInteger(0, name, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, name, OBJPROP_YDISTANCE, y);
   ObjectSetString(0,  name, OBJPROP_TEXT,       text);
   ObjectSetInteger(0, name, OBJPROP_COLOR,      clr);
   ObjectSetInteger(0, name, OBJPROP_FONTSIZE,   fontSize);
   ObjectSetString(0,  name, OBJPROP_FONT,       "Consolas");
   ObjectSetInteger(0, name, OBJPROP_CORNER,     CORNER_LEFT_UPPER);
   ObjectSetInteger(0, name, OBJPROP_ANCHOR,     ANCHOR_LEFT_UPPER);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_BACK,       false);
  }

//+------------------------------------------------------------------+
//| Update dashboard                                                  |
//+------------------------------------------------------------------+
void UpdateDashboard(double price, double vwap,
                     double up1, double up2, double dn1, double dn2)
  {
//--- VWAP value
   ObjectSetString(0, g_objPrefix + "DASH_VVal", OBJPROP_TEXT,
                   DoubleToString(vwap, _Digits));

//--- Position
   string posStr;
   color  posClr;
   if(price > vwap)
     { posStr = "▲ ABOVE"; posClr = C'0,185,140'; }
   else
     { posStr = "▼ BELOW"; posClr = C'220,50,80'; }
   ObjectSetString(0,  g_objPrefix + "DASH_PVal", OBJPROP_TEXT, posStr);
   ObjectSetInteger(0, g_objPrefix + "DASH_PVal", OBJPROP_COLOR, posClr);

//--- Distance
   double dist = (price - vwap) / _Point;
   string sign = (dist >= 0) ? "+" : "";
   ObjectSetString(0,  g_objPrefix + "DASH_DVal", OBJPROP_TEXT,
                   sign + DoubleToString(dist, 0) + " pts");
   ObjectSetInteger(0, g_objPrefix + "DASH_DVal", OBJPROP_COLOR, posClr);

//--- Band zone
   string zoneStr;
   color  zoneClr;
   if(price > up2 && up2 != EMPTY_VALUE)
     { zoneStr = "Above +2σ"; zoneClr = C'0,185,140'; }
   else if(price > up1 && up1 != EMPTY_VALUE)
     { zoneStr = "+1σ to +2σ"; zoneClr = C'0,185,140'; }
   else if(price > vwap)
     { zoneStr = "VWAP to +1σ"; zoneClr = C'90,180,220'; }
   else if(price > dn1 && dn1 != EMPTY_VALUE)
     { zoneStr = "-1σ to VWAP"; zoneClr = C'90,180,220'; }
   else if(price > dn2 && dn2 != EMPTY_VALUE)
     { zoneStr = "-2σ to -1σ"; zoneClr = C'220,50,80'; }
   else
     { zoneStr = "Below -2σ"; zoneClr = C'220,50,80'; }

   ObjectSetString(0,  g_objPrefix + "DASH_BVal", OBJPROP_TEXT, zoneStr);
   ObjectSetInteger(0, g_objPrefix + "DASH_BVal", OBJPROP_COLOR, zoneClr);

   ChartRedraw(0);
  }
//+------------------------------------------------------------------+
