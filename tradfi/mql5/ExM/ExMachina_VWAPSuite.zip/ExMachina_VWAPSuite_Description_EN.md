# ExMachina VWAP Suite — MQL5 Code Base Description (English)

---

## Title
ExMachina VWAP Suite

## Short Description
VWAP with daily/weekly/monthly/session anchoring, ±1/2/3 standard deviation bands, band zone tracking, position indicator, dashboard, and touch alerts. Free.

---

## Full Description

**ExMachina VWAP Suite** calculates the Volume Weighted Average Price with proper anchoring and standard deviation bands. VWAP is the benchmark used by institutional traders to gauge fair value — price above VWAP suggests bullish intraday bias, below suggests bearish.

**Core Features:**

• VWAP calculated using tick volume (or real volume when available)
• Four anchor modes: Daily, Weekly, Monthly, Session (custom hour)
• Standard deviation bands: ±1σ, ±2σ, ±3σ (each toggleable)
• Customizable band multipliers
• Dashboard showing VWAP level, position (above/below), distance, and band zone
• Touch alerts when price reaches VWAP
• Multiple price types: Typical (HLC/3), Close, OHLC/4, etc.

**Anchor Modes:**
— Daily: VWAP resets at midnight (server time) each day
— Weekly: VWAP resets at the start of each week
— Monthly: VWAP resets at the start of each month
— Session: VWAP resets at a custom hour you define

**Standard Deviation Bands:**
The bands expand as price deviates from VWAP, creating natural support and resistance levels:
— ±1σ: ~68% of price action contained — normal trading range
— ±2σ: ~95% contained — extended/overextended zone
— ±3σ: ~99% contained — extreme deviation, mean reversion likely

**Dashboard Panel:**
Shows the current VWAP value, whether price is above or below (color-coded), distance in points, which band zone price is currently in, and the active anchor period.

**How Traders Use VWAP:**
— Price above VWAP = bullish bias, look for long entries
— Price below VWAP = bearish bias, look for short entries
— VWAP acts as dynamic support/resistance throughout the day
— Touch of ±2σ band often signals mean reversion opportunity
— Institutional traders use VWAP to benchmark execution quality

Works on all symbols and timeframes. Best on M1–H1 for intraday VWAP analysis.

Developed by ExMachina Trading Systems — Precision before profit.

For professional trading tools, visit: https://www.mql5.com/en/users/williammukam

---

## Tags (comma-separated)
VWAP, volume weighted average price, anchored VWAP, standard deviation, bands, intraday, institutional, daily VWAP, weekly VWAP, free, forex, gold, dashboard, mean reversion

---

## Category
Technical Indicators

## Subcategory
Volumes
