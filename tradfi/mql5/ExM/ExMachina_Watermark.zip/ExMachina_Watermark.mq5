//+------------------------------------------------------------------+
//|                                    ExMachina_Watermark.mq5       |
//|                          Copyright 2026, ExMachina Trading Systems|
//|                   https://www.mql5.com/en/users/williammukam      |
//+------------------------------------------------------------------+
#property copyright "ExMachina Trading Systems"
#property link "https://www.mql5.com/en/users/williammukam"
#property version "1.00"
#property description "ExMachina Watermark"
#property description "Elegant chart watermark with symbol, timeframe,"
#property description "and description. Customizable font/size/color."
#property description "Precision before profit."
#property indicator_chart_window
#property indicator_buffers 0
#property indicator_plots 0
#property strict

input string InpCustomText="";  // Custom Text (empty=auto)
input int InpFontSize=48;       // Font Size
input color InpColor=C'25,28,38'; // Color
input string InpFont="Consolas"; // Font
input ENUM_ANCHOR_POINT InpAnchor=ANCHOR_CENTER; // Position

string g_objPrefix="EXSS_WM_";

int OnInit(){IndicatorSetString(INDICATOR_SHORTNAME,"ExMachina Watermark");CreateWatermark();return(INIT_SUCCEEDED);}
void OnDeinit(const int reason){ObjectsDeleteAll(0,g_objPrefix);ChartRedraw(0);}

int OnCalculate(const int rates_total,const int prev_calculated,const datetime &time[],const double &open[],const double &high[],const double &low[],const double &close[],const long &tick_volume[],const long &volume[],const int &spread[]){
   return(rates_total);
}

void CreateWatermark(){
   string text=InpCustomText;
   if(text==""){
      string tfStr="";
      switch(_Period){case PERIOD_M1:tfStr="M1";break;case PERIOD_M5:tfStr="M5";break;case PERIOD_M15:tfStr="M15";break;case PERIOD_M30:tfStr="M30";break;case PERIOD_H1:tfStr="H1";break;case PERIOD_H4:tfStr="H4";break;case PERIOD_D1:tfStr="D1";break;case PERIOD_W1:tfStr="W1";break;case PERIOD_MN1:tfStr="MN";break;default:tfStr=IntegerToString(_Period);break;}
      text=_Symbol+"  "+tfStr;
   }

   int chartW=(int)ChartGetInteger(0,CHART_WIDTH_IN_PIXELS);
   int chartH=(int)ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS);

   string name=g_objPrefix+"MAIN";
   ObjectCreate(0,name,OBJ_LABEL,0,0,0);
   ObjectSetInteger(0,name,OBJPROP_XDISTANCE,chartW/2);
   ObjectSetInteger(0,name,OBJPROP_YDISTANCE,chartH/2);
   ObjectSetString(0,name,OBJPROP_TEXT,text);
   ObjectSetInteger(0,name,OBJPROP_COLOR,InpColor);
   ObjectSetInteger(0,name,OBJPROP_FONTSIZE,InpFontSize);
   ObjectSetString(0,name,OBJPROP_FONT,InpFont);
   ObjectSetInteger(0,name,OBJPROP_CORNER,CORNER_LEFT_UPPER);
   ObjectSetInteger(0,name,OBJPROP_ANCHOR,InpAnchor);
   ObjectSetInteger(0,name,OBJPROP_BACK,true);
   ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);

   // Branding sub-text
   string sub=g_objPrefix+"SUB";
   ObjectCreate(0,sub,OBJ_LABEL,0,0,0);
   ObjectSetInteger(0,sub,OBJPROP_XDISTANCE,chartW/2);
   ObjectSetInteger(0,sub,OBJPROP_YDISTANCE,chartH/2+InpFontSize+10);
   ObjectSetString(0,sub,OBJPROP_TEXT,"ExMachina Trading Systems");
   ObjectSetInteger(0,sub,OBJPROP_COLOR,C'18,20,28');
   ObjectSetInteger(0,sub,OBJPROP_FONTSIZE,InpFontSize/4);
   ObjectSetString(0,sub,OBJPROP_FONT,InpFont);
   ObjectSetInteger(0,sub,OBJPROP_CORNER,CORNER_LEFT_UPPER);
   ObjectSetInteger(0,sub,OBJPROP_ANCHOR,ANCHOR_CENTER);
   ObjectSetInteger(0,sub,OBJPROP_BACK,true);
   ObjectSetInteger(0,sub,OBJPROP_SELECTABLE,false);

   ChartRedraw(0);
}
