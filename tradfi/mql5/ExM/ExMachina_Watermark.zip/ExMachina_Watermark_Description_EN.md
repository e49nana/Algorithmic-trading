# ExMachina Watermark — MQL5 Code Base Description (English)

## Title
ExMachina Watermark

## Short Description
Elegant chart watermark with auto symbol+timeframe. Customizable font, size, color, position. Minimal. Free.

## Full Description

**ExMachina Watermark** — part of the ExMachina Trading Systems free Code Base collection. Professional quality with steel palette design, dashboard, and alerts.

All objects use EXSS_ prefix. Colors fully customizable. Works on all symbols and timeframes.

Developed by ExMachina Trading Systems — Precision before profit.

For professional trading tools, visit: https://www.mql5.com/en/users/williammukam

## Tags
watermark,chart,symbol,timeframe,branding,visual,minimal,background,free

## Category
Other
