#region Using declarations
using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using System.Threading;
using NinjaTrader.NinjaScript;
#endregion

// ═══════════════════════════════════════════════════════════════════════════════
// SOPHON GOVERNANCE MODULE v3.0 - UNIFIED MOUNA/EMMANUEL EDITION
// ═══════════════════════════════════════════════════════════════════════════════
//
// MODULE CENTRAL NON CONTOURNABLE - POINT DE PASSAGE OBLIGATOIRE
// Aucun module ne peut trader sans autorisation formelle (TradeAuthorization)
//
// ═══════════════════════════════════════════════════════════════════════════════
// INTÉGRATIONS:
// ═══════════════════════════════════════════════════════════════════════════════
//
// MOUNA BOULHAL (ICT/SMC):
//   - Sessions: Asian (6PM-2AM), London (3AM-12PM), NY (9:30AM-4PM)
//   - AMD Cycle: Accumulation → Manipulation → Distribution
//   - News critiques: NFP, CPI, FOMC, Powell = NO TRADING
//   - Judas Swing avoidance (9:25-9:35 AM)
//   - Confluence minimum: 6 points
//   - Entry Model: 8 étapes de validation
//
// EMMANUEL (Scalping):
//   - EMA 19 confirmée
//   - 8 patterns validés avec 85% win rate
//   - NY session optimal (9:30-11:30 AM)
//   - Confluence scoring (max 10 points)
//
// ═══════════════════════════════════════════════════════════════════════════════
// HIÉRARCHIE D'ÉVALUATION:
// ═══════════════════════════════════════════════════════════════════════════════
//
//   0. Kill Switch (absolu)
//   1. Règles Prop Firm (daily/max/trailing DD, position size)
//   2. News critiques (NFP, CPI, FOMC, Powell)
//   3. Session/Temps (Mouna sessions, Judas Swing, lunch time)
//   4. Cooldown (après pertes, séries)
//   5. Environnement (chop, follow-through, volatilité)
//   6. Limites intraday (trades, drawdown restant)
//   7. Confluence minimum (Mouna: 6pts, Emmanuel: 5pts)
//   8. Entry validation (Mouna 8-step model)
//
// Copyright (c) 2026 Algosphere Quant - Emmanuel/Mouna
// ═══════════════════════════════════════════════════════════════════════════════

namespace NinjaTrader.NinjaScript.AddOns.Sophon
{
    public sealed class SophonGovernance : ISophonModule
    {
        #region Singleton & Properties
        
        private static readonly Lazy<SophonGovernance> _instance = 
            new Lazy<SophonGovernance>(() => new SophonGovernance());
        public static SophonGovernance Instance => _instance.Value;
        
        public string ModuleName => "SophonGovernance_v3";
        public bool IsInitialized { get; private set; }
        public bool IsEnabled { get; set; } = true;
        
        // Configuration
        private PropFirmRules _propFirmRules;
        private GovernanceSettings _settings;
        private MounaSessionSettings _mounaSettings;
        private EmmanuelSettings _emmanuelSettings;
        
        // State tracking
        private AccountState _accountState;
        private DailyState _dailyState;
        private CooldownState _cooldownState;
        private EnvironmentState _environmentState;
        private SessionState _sessionState;
        private NewsState _newsState;
        
        // Authorizations
        private ConcurrentDictionary<string, TradeAuthorization> _activeAuthorizations;
        private List<BlockedRequest> _blockedRequests;
        private List<GovernanceAuditEntry> _auditLog;
        
        // Kill switch
        private volatile bool _globalKillSwitch;
        private string _killSwitchReason;
        private KillSwitchType _killSwitchType;
        private DateTime _killSwitchActivatedAt;
        
        // Current state
        private volatile TradingState _currentState;
        private volatile MounaTradingSession _currentSession;
        private volatile MarketPhase _currentPhase;
        
        // Thread safety
        private readonly ReaderWriterLockSlim _lock = new ReaderWriterLockSlim();
        
        // Module coordination
        private ModuleCoordinator _coordinator;
        
        #endregion

        #region Events
        
        public event EventHandler<TradingStateChangedEvent> OnStateChanged;
        public event EventHandler<AuthorizationEvent> OnAuthorizationIssued;
        public event EventHandler<AuthorizationEvent> OnAuthorizationRevoked;
        public event EventHandler<KillSwitchEvent> OnKillSwitchActivated;
        public event EventHandler<KillSwitchEvent> OnKillSwitchDeactivated;
        public event EventHandler<CooldownEvent> OnCooldownStarted;
        public event EventHandler<CooldownEvent> OnCooldownEnded;
        public event EventHandler<SessionChangeEvent> OnSessionChanged;
        public event EventHandler<NewsBlockEvent> OnNewsBlock;
        
        #endregion

        #region Constructor
        
        private SophonGovernance()
        {
            _propFirmRules = new PropFirmRules();
            _settings = new GovernanceSettings();
            _mounaSettings = new MounaSessionSettings();
            _emmanuelSettings = new EmmanuelSettings();
            
            _accountState = new AccountState();
            _dailyState = new DailyState();
            _cooldownState = new CooldownState();
            _environmentState = new EnvironmentState();
            _sessionState = new SessionState();
            _newsState = new NewsState();
            
            _activeAuthorizations = new ConcurrentDictionary<string, TradeAuthorization>();
            _blockedRequests = new List<BlockedRequest>();
            _auditLog = new List<GovernanceAuditEntry>();
            
            _coordinator = new ModuleCoordinator();
        }
        
        #endregion

        #region Initialization
        
        public void Initialize()
        {
            if (IsInitialized) return;
            
            ResetDailyState();
            _globalKillSwitch = false;
            _currentState = TradingState.Evaluating;
            _currentSession = MounaTradingSession.Closed;
            _currentPhase = MarketPhase.Unknown;
            _activeAuthorizations.Clear();
            _blockedRequests.Clear();
            
            IsInitialized = true;
            
            LogAudit("INIT", "Governance initialized", GovernanceAuditLevel.Info);
        }

        public void Shutdown()
        {
            RevokeAllAuthorizations("System shutdown");
            LogAudit("SHUTDOWN", "Governance shutdown", GovernanceAuditLevel.Info);
            IsInitialized = false;
        }

        public void Reset()
        {
            Shutdown();
            Initialize();
        }

        public void OnBarUpdate(int barsInProgress)
        {
            UpdateSession(DateTime.Now);
            EvaluateTradingState();
            CleanExpiredAuthorizations();
        }

        #endregion

        #region Configuration
        
        public void ConfigurePropFirm(PropFirmRules rules)
        {
            _propFirmRules = rules ?? new PropFirmRules();
            LogAudit("CONFIG", $"PropFirm configured: Daily DD {_propFirmRules.DailyDrawdownLimit}%, Max DD {_propFirmRules.MaxDrawdownLimit}%", GovernanceAuditLevel.Info);
        }

        public void ConfigureSettings(GovernanceSettings settings)
        {
            _settings = settings ?? new GovernanceSettings();
        }

        public void ConfigureMounaSettings(MounaSessionSettings settings)
        {
            _mounaSettings = settings ?? new MounaSessionSettings();
        }

        public void ConfigureEmmanuelSettings(EmmanuelSettings settings)
        {
            _emmanuelSettings = settings ?? new EmmanuelSettings();
        }

        public void InitializeAccount(double startingBalance, double currentBalance)
        {
            _lock.EnterWriteLock();
            try
            {
                _accountState.StartingBalance = startingBalance;
                _accountState.CurrentBalance = currentBalance;
                _accountState.PeakBalance = Math.Max(startingBalance, currentBalance);
                _accountState.DayStartBalance = currentBalance;
                
                LogAudit("ACCOUNT", $"Account initialized: Start=${startingBalance:F2}, Current=${currentBalance:F2}", GovernanceAuditLevel.Info);
            }
            finally { _lock.ExitWriteLock(); }
        }

        private void ResetDailyState()
        {
            _dailyState = new DailyState
            {
                Date = DateTime.Today,
                MaxTradesAllowed = _settings.DefaultMaxTradesPerDay
            };
            _accountState.DayStartBalance = _accountState.CurrentBalance;
        }

        #endregion

        #region Session Management (Mouna)
        
        /// <summary>
        /// Update current trading session based on Mouna's methodology
        /// </summary>
        private void UpdateSession(DateTime time)
        {
            var previousSession = _currentSession;
            var previousPhase = _currentPhase;
            
            // Convert to Eastern Time
            TimeZoneInfo easternZone;
            try { easternZone = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time"); }
            catch { easternZone = TimeZoneInfo.FindSystemTimeZoneById("America/New_York"); }
            
            DateTime etTime = TimeZoneInfo.ConvertTime(time, easternZone);
            int hour = etTime.Hour;
            int minute = etTime.Minute;
            double timeDecimal = hour + minute / 60.0;
            
            // Determine session (Mouna's times)
            if (timeDecimal >= 18.0 || timeDecimal < 2.0)
            {
                _currentSession = MounaTradingSession.Asian;
                _currentPhase = MarketPhase.Accumulation;
            }
            else if (timeDecimal >= 3.0 && timeDecimal < 12.0)
            {
                _currentSession = MounaTradingSession.London;
                _currentPhase = MarketPhase.Manipulation;
            }
            else if (timeDecimal >= 9.5 && timeDecimal < 16.0)
            {
                _currentSession = MounaTradingSession.NewYork;
                _currentPhase = MarketPhase.Distribution;
            }
            else if (timeDecimal >= 2.0 && timeDecimal < 3.0)
            {
                _currentSession = MounaTradingSession.PreMarket;
                _currentPhase = MarketPhase.Unknown;
            }
            else
            {
                _currentSession = MounaTradingSession.Closed;
                _currentPhase = MarketPhase.Unknown;
            }
            
            // Store session state
            _sessionState.CurrentSession = _currentSession;
            _sessionState.CurrentPhase = _currentPhase;
            _sessionState.CurrentETTime = etTime;
            _sessionState.IsNYOpen = timeDecimal >= 9.5 && timeDecimal <= 9.58; // 9:30-9:35
            _sessionState.IsOptimalNY = timeDecimal >= 9.5 && timeDecimal <= 11.5; // 9:30-11:30
            _sessionState.IsLunchTime = timeDecimal >= 12.0 && timeDecimal <= 14.0;
            _sessionState.IsFridayClose = etTime.DayOfWeek == DayOfWeek.Friday && timeDecimal >= 15.5;
            
            // Fire event on session change
            if (_currentSession != previousSession)
            {
                OnSessionChanged?.Invoke(this, new SessionChangeEvent
                {
                    PreviousSession = previousSession,
                    NewSession = _currentSession,
                    Phase = _currentPhase,
                    Time = time
                });
                
                LogAudit("SESSION", $"Session changed: {previousSession} → {_currentSession} ({_currentPhase})", GovernanceAuditLevel.Info);
            }
        }

        /// <summary>
        /// Check if we're in the Judas Swing danger zone (9:25-9:35 AM ET)
        /// Mouna: "Ne jamais trader juste à l'ouverture NY"
        /// </summary>
        public bool IsJudasSwingZone()
        {
            return _sessionState.IsNYOpen;
        }

        /// <summary>
        /// Check if we're in the optimal NY window (9:30-11:30 AM ET)
        /// Both Mouna and Emmanuel agree this is the best time
        /// </summary>
        public bool IsOptimalNYWindow()
        {
            return _sessionState.IsOptimalNY && !_sessionState.IsNYOpen;
        }

        /// <summary>
        /// Check if we're in lunch time (12:00-2:00 PM ET)
        /// Mouna: Avoid trading during lunch
        /// </summary>
        public bool IsLunchTime()
        {
            return _sessionState.IsLunchTime;
        }

        #endregion

        #region News Management (Mouna)
        
        /// <summary>
        /// Update news state - call from strategy with ForexFactory data
        /// </summary>
        public void UpdateNewsState(NewsImpact impact, string eventName, int minutesToEvent, bool isCriticalDay)
        {
            _lock.EnterWriteLock();
            try
            {
                _newsState.CurrentImpact = impact;
                _newsState.NextEventName = eventName;
                _newsState.MinutesToEvent = minutesToEvent;
                _newsState.IsCriticalNewsDay = isCriticalDay;
                
                // Mouna's critical news list
                _newsState.IsNFP = eventName?.Contains("NFP") == true || eventName?.Contains("Non-Farm") == true;
                _newsState.IsCPI = eventName?.Contains("CPI") == true || eventName?.Contains("Consumer Price") == true;
                _newsState.IsFOMC = eventName?.Contains("FOMC") == true || eventName?.Contains("Federal Reserve") == true;
                _newsState.IsPowell = eventName?.Contains("Powell") == true || eventName?.Contains("Fed Chair") == true;
                
                // Any critical news = NO TRADING
                if (_newsState.IsNFP || _newsState.IsCPI || _newsState.IsFOMC || _newsState.IsPowell)
                {
                    _newsState.IsCriticalNewsDay = true;
                }
            }
            finally { _lock.ExitWriteLock(); }
        }

        /// <summary>
        /// Check if today is a critical news day (NFP, CPI, FOMC, Powell)
        /// Mouna: "Ces jours-là, je ne trade PAS du tout"
        /// </summary>
        public bool IsCriticalNewsDay()
        {
            return _newsState.IsCriticalNewsDay;
        }

        /// <summary>
        /// Check if high impact news is imminent
        /// </summary>
        public bool IsNewsImminent(int minutesThreshold = 30)
        {
            return _newsState.CurrentImpact >= NewsImpact.High && 
                   _newsState.MinutesToEvent <= minutesThreshold &&
                   _newsState.MinutesToEvent > 0;
        }

        #endregion

        #region Trading State Evaluation
        
        /// <summary>
        /// Main evaluation method - determines if trading is allowed
        /// </summary>
        public TradingStateResult EvaluateTradingState()
        {
            _lock.EnterUpgradeableReadLock();
            try
            {
                var result = new TradingStateResult { Timestamp = DateTime.Now };
                var previousState = _currentState;

                // ═══════════════════════════════════════════════════════════════
                // NIVEAU 0: KILL SWITCH (ABSOLU)
                // ═══════════════════════════════════════════════════════════════
                if (_globalKillSwitch)
                {
                    return CreateBlockResult(result, TradingState.KillSwitchActive, 
                        BlockLevel.KillSwitch, $"KILL SWITCH: {_killSwitchReason}", previousState);
                }

                // ═══════════════════════════════════════════════════════════════
                // NIVEAU 1: RÈGLES PROP FIRM
                // ═══════════════════════════════════════════════════════════════
                var propFirmEval = EvaluatePropFirmRules();
                if (!propFirmEval.IsCompliant)
                {
                    if (propFirmEval.IsCritical)
                    {
                        ActivateKillSwitch(propFirmEval.Message, KillSwitchType.PropFirmBreach);
                    }
                    return CreateBlockResult(result, TradingState.PropFirmBlocked, 
                        BlockLevel.PropFirmRule, propFirmEval.Message, previousState);
                }

                // ═══════════════════════════════════════════════════════════════
                // NIVEAU 2: NEWS CRITIQUES (MOUNA)
                // NFP, CPI, FOMC, Powell = NO TRADING
                // ═══════════════════════════════════════════════════════════════
                if (_newsState.IsCriticalNewsDay && _mounaSettings.FilterCriticalNews)
                {
                    string newsReason = GetCriticalNewsReason();
                    OnNewsBlock?.Invoke(this, new NewsBlockEvent { Reason = newsReason, IsCritical = true });
                    return CreateBlockResult(result, TradingState.NewsBlocked, 
                        BlockLevel.CriticalNews, $"CRITICAL NEWS DAY: {newsReason}", previousState);
                }

                // High impact news imminent
                if (IsNewsImminent(_mounaSettings.NewsBufferMinutes))
                {
                    return CreateBlockResult(result, TradingState.NewsBlocked, 
                        BlockLevel.News, $"News in {_newsState.MinutesToEvent}min: {_newsState.NextEventName}", previousState);
                }

                // ═══════════════════════════════════════════════════════════════
                // NIVEAU 3: SESSION & TIMING (MOUNA)
                // ═══════════════════════════════════════════════════════════════
                var sessionEval = EvaluateSession();
                if (!sessionEval.IsValid)
                {
                    return CreateBlockResult(result, TradingState.OutsideSession, 
                        BlockLevel.SessionTime, sessionEval.Reason, previousState);
                }

                // Judas Swing zone (9:25-9:35 AM ET)
                if (IsJudasSwingZone() && _mounaSettings.AvoidJudasSwing)
                {
                    return CreateBlockResult(result, TradingState.JudasSwingZone, 
                        BlockLevel.JudasSwing, "JUDAS SWING ZONE (9:25-9:35 AM ET) - Attendre", previousState);
                }

                // Lunch time (12:00-2:00 PM ET)
                if (IsLunchTime() && _mounaSettings.AvoidLunchTime)
                {
                    return CreateBlockResult(result, TradingState.LunchTime, 
                        BlockLevel.LunchTime, "LUNCH TIME (12:00-2:00 PM ET) - Marché lent", previousState);
                }

                // ═══════════════════════════════════════════════════════════════
                // NIVEAU 4: COOLDOWN
                // ═══════════════════════════════════════════════════════════════
                if (_cooldownState.IsActive && DateTime.Now < _cooldownState.EndsAt)
                {
                    var remaining = _cooldownState.EndsAt - DateTime.Now;
                    return CreateBlockResult(result, TradingState.Cooldown, 
                        BlockLevel.Cooldown, $"COOLDOWN: {_cooldownState.Reason} ({remaining.TotalMinutes:F0}min restantes)", previousState);
                }
                
                // End cooldown if expired
                if (_cooldownState.IsActive && DateTime.Now >= _cooldownState.EndsAt)
                {
                    _cooldownState.IsActive = false;
                    OnCooldownEnded?.Invoke(this, new CooldownEvent 
                    { 
                        Type = _cooldownState.Type, 
                        Reason = "Cooldown expired" 
                    });
                }

                // ═══════════════════════════════════════════════════════════════
                // NIVEAU 5: ENVIRONNEMENT
                // ═══════════════════════════════════════════════════════════════
                var envEval = EvaluateEnvironment();
                if (!envEval.IsFavorable)
                {
                    return CreateBlockResult(result, TradingState.UnfavorableEnvironment, 
                        BlockLevel.Environment, envEval.Reason, previousState);
                }

                // ═══════════════════════════════════════════════════════════════
                // NIVEAU 6: LIMITES JOURNALIÈRES
                // ═══════════════════════════════════════════════════════════════
                if (_dailyState.TradeCount >= _dailyState.MaxTradesAllowed)
                {
                    return CreateBlockResult(result, TradingState.DailyLimitReached, 
                        BlockLevel.DailyLimit, $"DAILY LIMIT: {_dailyState.TradeCount}/{_dailyState.MaxTradesAllowed} trades", previousState);
                }

                // ═══════════════════════════════════════════════════════════════
                // AUTORISÉ - CALCULER AGRESSIVITÉ
                // ═══════════════════════════════════════════════════════════════
                result.State = TradingState.Active;
                result.CanTrade = true;
                result.AggressivenessLevel = CalculateAggressiveness();
                result.MaxRiskMultiplier = GetRiskMultiplier(result.AggressivenessLevel);
                result.MaxTradesRemaining = _dailyState.MaxTradesAllowed - _dailyState.TradeCount;
                result.DrawdownRemaining = GetRemainingDrawdown();
                result.EnvironmentScore = envEval.Score;
                result.CurrentSession = _currentSession;
                result.CurrentPhase = _currentPhase;
                result.IsOptimalWindow = IsOptimalNYWindow();
                
                UpdateState(result.State, previousState);
                return result;
            }
            finally { _lock.ExitUpgradeableReadLock(); }
        }

        private string GetCriticalNewsReason()
        {
            var reasons = new List<string>();
            if (_newsState.IsNFP) reasons.Add("NFP");
            if (_newsState.IsCPI) reasons.Add("CPI");
            if (_newsState.IsFOMC) reasons.Add("FOMC");
            if (_newsState.IsPowell) reasons.Add("Powell Speech");
            return reasons.Count > 0 ? string.Join(", ", reasons) : "Critical News";
        }

        private TradingStateResult CreateBlockResult(TradingStateResult result, TradingState state, 
            BlockLevel level, string reason, TradingState previousState)
        {
            result.State = state;
            result.CanTrade = false;
            result.Reason = reason;
            result.BlockLevel = level;
            result.CurrentSession = _currentSession;
            result.CurrentPhase = _currentPhase;
            
            UpdateState(state, previousState);
            return result;
        }

        private void UpdateState(TradingState newState, TradingState previousState)
        {
            if (newState != previousState)
            {
                _lock.EnterWriteLock();
                try { _currentState = newState; }
                finally { _lock.ExitWriteLock(); }
                
                OnStateChanged?.Invoke(this, new TradingStateChangedEvent 
                { 
                    PreviousState = previousState, 
                    NewState = newState 
                });
                
                LogAudit("STATE", $"State changed: {previousState} → {newState}", GovernanceAuditLevel.Info);
            }
        }

        #endregion

        #region Rule Evaluations
        
        private PropFirmEvaluation EvaluatePropFirmRules()
        {
            var result = new PropFirmEvaluation { IsCompliant = true };
            
            // Daily Drawdown
            double dailyPnL = _accountState.CurrentBalance - _accountState.DayStartBalance;
            double dailyDD = dailyPnL < 0 ? Math.Abs(dailyPnL) / _accountState.DayStartBalance * 100 : 0;
            
            if (dailyDD >= _propFirmRules.DailyDrawdownLimit)
            {
                return new PropFirmEvaluation 
                { 
                    IsCompliant = false, 
                    IsCritical = true, 
                    ViolationType = PropFirmViolation.DailyDrawdown, 
                    Message = $"DAILY DD BREACH: {dailyDD:F2}% >= {_propFirmRules.DailyDrawdownLimit}%" 
                };
            }

            // Max/Trailing Drawdown
            double refBalance = _propFirmRules.TrailingDrawdownEnabled 
                ? _accountState.PeakBalance 
                : _accountState.StartingBalance;
            double maxDD = (refBalance - _accountState.CurrentBalance) / refBalance * 100;
            
            if (maxDD >= _propFirmRules.MaxDrawdownLimit)
            {
                return new PropFirmEvaluation 
                { 
                    IsCompliant = false, 
                    IsCritical = true,
                    ViolationType = _propFirmRules.TrailingDrawdownEnabled 
                        ? PropFirmViolation.TrailingDrawdown 
                        : PropFirmViolation.MaxDrawdown,
                    Message = $"MAX DD BREACH: {maxDD:F2}% >= {_propFirmRules.MaxDrawdownLimit}%" 
                };
            }

            // Position Size
            if (_propFirmRules.MaxPositionSize > 0 && 
                _accountState.CurrentPositionSize > _propFirmRules.MaxPositionSize)
            {
                return new PropFirmEvaluation 
                { 
                    IsCompliant = false, 
                    ViolationType = PropFirmViolation.PositionSize,
                    Message = $"POSITION SIZE: {_accountState.CurrentPositionSize} > {_propFirmRules.MaxPositionSize}" 
                };
            }
            
            // Calculate remaining drawdown for info
            result.RemainingDailyDD = _propFirmRules.DailyDrawdownLimit - dailyDD;
            result.RemainingMaxDD = _propFirmRules.MaxDrawdownLimit - maxDD;
            
            return result;
        }

        private SessionEvaluation EvaluateSession()
        {
            var now = DateTime.Now;
            var time = now.TimeOfDay;

            // Check restricted periods
            foreach (var period in _propFirmRules.RestrictedPeriods)
            {
                if (time >= period.Start && time <= period.End)
                {
                    return new SessionEvaluation 
                    { 
                        IsValid = false, 
                        Reason = $"Restricted period: {period.Reason}" 
                    };
                }
            }

            // Check no-trading days
            if (_propFirmRules.NoTradingDays.Contains(now.DayOfWeek))
            {
                return new SessionEvaluation 
                { 
                    IsValid = false, 
                    Reason = $"{now.DayOfWeek} is a no-trading day" 
                };
            }

            // Session end
            if (_settings.ForceSessionEnd && time >= _settings.SessionEndTime)
            {
                return new SessionEvaluation 
                { 
                    IsValid = false, 
                    Reason = "Trading session ended" 
                };
            }

            // Friday close (no weekend holding)
            if (!_propFirmRules.AllowWeekendHolding && 
                now.DayOfWeek == DayOfWeek.Friday && 
                time >= _settings.FridayCloseTime)
            {
                return new SessionEvaluation 
                { 
                    IsValid = false, 
                    Reason = "Friday close - No weekend positions" 
                };
            }

            return new SessionEvaluation { IsValid = true };
        }

        private EnvironmentEvaluation EvaluateEnvironment()
        {
            var result = new EnvironmentEvaluation { IsFavorable = true, Score = 100 };
            var reasons = new List<string>();

            // Choppy market
            if (_environmentState.IsChoppy)
            {
                result.Score -= 40;
                reasons.Add("Choppy market");
            }

            // No follow-through
            if (_environmentState.NoFollowThrough)
            {
                result.Score -= 30;
                reasons.Add("No follow-through");
            }

            // ATR ratio
            if (_environmentState.ATRRatio < _settings.MinATRRatio)
            {
                result.Score -= 20;
                reasons.Add($"Low volatility (ATR: {_environmentState.ATRRatio:F2})");
            }
            else if (_environmentState.ATRRatio > _settings.MaxATRRatio)
            {
                result.Score -= 20;
                reasons.Add($"High volatility (ATR: {_environmentState.ATRRatio:F2})");
            }

            // Spread
            if (_environmentState.CurrentSpread > _settings.MaxSpreadTicks)
            {
                result.Score -= 15;
                reasons.Add($"Wide spread ({_environmentState.CurrentSpread:F1} ticks)");
            }

            // Volume
            if (_environmentState.VolumeRatio < _settings.MinVolumeRatio)
            {
                result.Score -= 15;
                reasons.Add($"Low volume ({_environmentState.VolumeRatio:F2}x)");
            }

            // Determine favorability
            if (result.Score < _settings.MinEnvironmentScore)
            {
                result.IsFavorable = false;
                result.Reason = "Environment unfavorable: " + string.Join("; ", reasons);
            }
            else
            {
                result.Reason = reasons.Count > 0 ? string.Join("; ", reasons) : "Environment OK";
            }

            return result;
        }

        #endregion

        #region Authorization Management
        
        /// <summary>
        /// Request authorization to trade - MANDATORY before any trade
        /// </summary>
        public TradeAuthorization RequestAuthorization(TradeAuthorizationRequest request)
        {
            if (!IsEnabled || !IsInitialized)
            {
                return CreateDeniedAuthorization(request, "Governance not initialized", BlockLevel.None);
            }

            // First, evaluate current state
            var stateResult = EvaluateTradingState();
            if (!stateResult.CanTrade)
            {
                var denied = CreateDeniedAuthorization(request, stateResult.Reason, stateResult.BlockLevel);
                LogAudit("AUTH_DENIED", $"{request.Instrument} {request.Direction}: {stateResult.Reason}", GovernanceAuditLevel.Warning);
                return denied;
            }

            // Check confluence minimum (Mouna: 6, Emmanuel: 5)
            int minConfluence = request.SignalSource == SignalSource.SMC 
                ? _mounaSettings.MinConfluenceScore 
                : _emmanuelSettings.MinConfluenceScore;
            
            if (request.ConfluenceScore < minConfluence)
            {
                var denied = CreateDeniedAuthorization(request, 
                    $"Confluence too low: {request.ConfluenceScore} < {minConfluence}", 
                    BlockLevel.SetupQuality);
                LogAudit("AUTH_DENIED", $"{request.Instrument}: Confluence {request.ConfluenceScore} < {minConfluence}", GovernanceAuditLevel.Warning);
                return denied;
            }

            // Check setup quality threshold
            double minQuality = GetMinSetupQuality(stateResult.AggressivenessLevel);
            if (request.SetupQuality < minQuality)
            {
                var denied = CreateDeniedAuthorization(request, 
                    $"Setup quality too low: {request.SetupQuality:F1} < {minQuality:F1}", 
                    BlockLevel.SetupQuality);
                return denied;
            }

            // Calculate risk constraints
            var constraints = CalculateRiskConstraints(stateResult);
            
            // Create authorization
            var auth = new TradeAuthorization
            {
                AuthorizationId = Guid.NewGuid().ToString("N").Substring(0, 8).ToUpper(),
                RequestId = request.RequestId,
                Instrument = request.Instrument,
                Direction = request.Direction,
                RequestedSetup = request.SetupType,
                SignalSource = request.SignalSource,
                ConfluenceScore = request.ConfluenceScore,
                
                RequestTime = DateTime.Now,
                GrantedTime = DateTime.Now,
                ExpiresAt = DateTime.Now.AddSeconds(_settings.AuthorizationValiditySeconds),
                
                IsGranted = true,
                AggressivenessLevel = stateResult.AggressivenessLevel,
                RiskMultiplier = stateResult.MaxRiskMultiplier,
                GrantedRiskAmount = Math.Min(request.RequestedRiskAmount, constraints.MaxRisk),
                MaxPositionSize = constraints.MaxSize,
                MaxHoldingMinutes = constraints.MaxHoldingMinutes
            };

            // Must close by end of session
            if (_settings.ForceSessionEnd)
            {
                var today = DateTime.Today;
                auth.MustCloseBy = today.Add(_settings.SessionEndTime);
            }

            // Store authorization
            _activeAuthorizations[auth.AuthorizationId] = auth;
            _dailyState.AuthorizationsGranted++;

            // Fire event
            OnAuthorizationIssued?.Invoke(this, new AuthorizationEvent { Authorization = auth });
            
            LogAudit("AUTH_GRANTED", 
                $"{auth.AuthorizationId}: {request.Instrument} {request.Direction} | Risk=${auth.GrantedRiskAmount:F2} | Confluence={auth.ConfluenceScore}", 
                GovernanceAuditLevel.Info);

            return auth;
        }

        /// <summary>
        /// Validate that an authorization is still valid before execution
        /// </summary>
        public AuthorizationValidation ValidateAuthorization(string authorizationId)
        {
            if (!_activeAuthorizations.TryGetValue(authorizationId, out var auth))
            {
                return new AuthorizationValidation 
                { 
                    IsValid = false, 
                    Reason = "Authorization not found" 
                };
            }

            if (!auth.IsStillValid)
            {
                string reason = auth.WasRevoked ? $"Revoked: {auth.RevocationReason}" :
                               auth.WasExecuted ? "Already executed" :
                               DateTime.Now > auth.ExpiresAt ? "Expired" : "Invalid";
                
                return new AuthorizationValidation 
                { 
                    IsValid = false, 
                    Reason = reason,
                    Authorization = auth 
                };
            }

            // Re-check current state
            var stateResult = EvaluateTradingState();
            if (!stateResult.CanTrade)
            {
                RevokeAuthorization(authorizationId, $"State changed: {stateResult.Reason}");
                return new AuthorizationValidation 
                { 
                    IsValid = false, 
                    Reason = $"State changed: {stateResult.Reason}",
                    Authorization = auth 
                };
            }

            return new AuthorizationValidation 
            { 
                IsValid = true, 
                Authorization = auth 
            };
        }

        /// <summary>
        /// Confirm execution of an authorized trade
        /// </summary>
        public void ConfirmExecution(string authorizationId, ExecutionConfirmation confirmation)
        {
            if (!_activeAuthorizations.TryGetValue(authorizationId, out var auth))
            {
                LogAudit("EXEC_ERROR", $"Authorization {authorizationId} not found", GovernanceAuditLevel.Error);
                return;
            }

            auth.WasExecuted = true;
            auth.ExecutionTime = confirmation.ExecutionTime;
            auth.ActualEntryPrice = confirmation.EntryPrice;
            auth.ActualPositionSize = confirmation.PositionSize;

            _dailyState.TradeCount++;
            _accountState.CurrentPositionSize += confirmation.PositionSize;

            LogAudit("EXEC_CONFIRMED", 
                $"{authorizationId}: {auth.Instrument} @ {confirmation.EntryPrice:F2} x{confirmation.PositionSize}", 
                GovernanceAuditLevel.Info);
        }

        /// <summary>
        /// Report trade result for statistics and cooldown management
        /// </summary>
        public void ReportTradeResult(TradeResultUpdate result)
        {
            _lock.EnterWriteLock();
            try
            {
                _dailyState.DailyPnL += result.NetPnL;
                _accountState.CurrentBalance += result.NetPnL;
                _accountState.CurrentPositionSize -= result.PositionSize;

                if (_accountState.CurrentBalance > _accountState.PeakBalance)
                {
                    _accountState.PeakBalance = _accountState.CurrentBalance;
                }

                if (result.IsWinner)
                {
                    _dailyState.WinCount++;
                    _dailyState.ConsecutiveWins++;
                    _dailyState.ConsecutiveLosses = 0;
                }
                else
                {
                    _dailyState.LossCount++;
                    _dailyState.ConsecutiveLosses++;
                    _dailyState.ConsecutiveWins = 0;

                    // Check for cooldown trigger
                    if (_dailyState.ConsecutiveLosses >= _settings.CooldownAfterConsecutiveLosses)
                    {
                        StartCooldown(CooldownType.ConsecutiveLosses, 
                            $"{_dailyState.ConsecutiveLosses} consecutive losses", 
                            TimeSpan.FromMinutes(_settings.CooldownMinutes));
                    }
                }

                LogAudit("TRADE_RESULT", 
                    $"PnL=${result.NetPnL:F2} | Day=${_dailyState.DailyPnL:F2} | W/L={_dailyState.WinCount}/{_dailyState.LossCount}", 
                    result.IsWinner ? GovernanceAuditLevel.Info : GovernanceAuditLevel.Warning);
            }
            finally { _lock.ExitWriteLock(); }
        }

        /// <summary>
        /// Revoke a specific authorization
        /// </summary>
        public void RevokeAuthorization(string authorizationId, string reason)
        {
            if (_activeAuthorizations.TryGetValue(authorizationId, out var auth))
            {
                auth.WasRevoked = true;
                auth.RevocationReason = reason;
                
                OnAuthorizationRevoked?.Invoke(this, new AuthorizationEvent { Authorization = auth });
                LogAudit("AUTH_REVOKED", $"{authorizationId}: {reason}", GovernanceAuditLevel.Warning);
            }
        }

        /// <summary>
        /// Revoke all active authorizations
        /// </summary>
        public void RevokeAllAuthorizations(string reason)
        {
            foreach (var kvp in _activeAuthorizations)
            {
                if (kvp.Value.IsStillValid)
                {
                    RevokeAuthorization(kvp.Key, reason);
                }
            }
        }

        private void CleanExpiredAuthorizations()
        {
            var expired = _activeAuthorizations
                .Where(kvp => !kvp.Value.IsStillValid && 
                              (DateTime.Now - kvp.Value.ExpiresAt).TotalMinutes > 5)
                .Select(kvp => kvp.Key)
                .ToList();

            foreach (var key in expired)
            {
                _activeAuthorizations.TryRemove(key, out _);
            }
        }

        private TradeAuthorization CreateDeniedAuthorization(TradeAuthorizationRequest request, 
            string reason, BlockLevel level)
        {
            var auth = new TradeAuthorization
            {
                AuthorizationId = "DENIED",
                RequestId = request.RequestId,
                Instrument = request.Instrument,
                Direction = request.Direction,
                RequestedSetup = request.SetupType,
                RequestTime = DateTime.Now,
                IsGranted = false,
                DenialReason = reason,
                DenialLevel = level
            };

            _blockedRequests.Add(new BlockedRequest
            {
                RequestId = request.RequestId,
                Reason = reason,
                Level = level,
                Timestamp = DateTime.Now
            });

            return auth;
        }

        #endregion

        #region Kill Switch
        
        /// <summary>
        /// Activate kill switch - STOPS ALL TRADING IMMEDIATELY
        /// </summary>
        public void ActivateKillSwitch(string reason, KillSwitchType type)
        {
            _lock.EnterWriteLock();
            try
            {
                _globalKillSwitch = true;
                _killSwitchReason = reason;
                _killSwitchType = type;
                _killSwitchActivatedAt = DateTime.Now;
            }
            finally { _lock.ExitWriteLock(); }

            RevokeAllAuthorizations($"Kill switch: {reason}");
            
            OnKillSwitchActivated?.Invoke(this, new KillSwitchEvent 
            { 
                Type = type, 
                Reason = reason 
            });
            
            LogAudit("KILL_SWITCH", $"ACTIVATED: {type} - {reason}", GovernanceAuditLevel.Critical);
        }

        /// <summary>
        /// Deactivate kill switch with confirmation code
        /// </summary>
        public bool DeactivateKillSwitch(string confirmationCode)
        {
            if (confirmationCode != _settings.KillSwitchDeactivationCode)
            {
                LogAudit("KILL_SWITCH", "Deactivation failed - wrong code", GovernanceAuditLevel.Warning);
                return false;
            }

            _lock.EnterWriteLock();
            try
            {
                _globalKillSwitch = false;
                _killSwitchReason = null;
            }
            finally { _lock.ExitWriteLock(); }

            OnKillSwitchDeactivated?.Invoke(this, new KillSwitchEvent 
            { 
                Type = _killSwitchType, 
                Reason = "Manually deactivated" 
            });
            
            LogAudit("KILL_SWITCH", "DEACTIVATED", GovernanceAuditLevel.Info);
            return true;
        }

        #endregion

        #region Cooldown
        
        /// <summary>
        /// Start a trading cooldown period
        /// </summary>
        public void StartCooldown(CooldownType type, string reason, TimeSpan duration)
        {
            _lock.EnterWriteLock();
            try
            {
                _cooldownState.IsActive = true;
                _cooldownState.Type = type;
                _cooldownState.Reason = reason;
                _cooldownState.StartedAt = DateTime.Now;
                _cooldownState.EndsAt = DateTime.Now.Add(duration);
            }
            finally { _lock.ExitWriteLock(); }

            OnCooldownStarted?.Invoke(this, new CooldownEvent 
            { 
                Type = type, 
                Reason = reason, 
                Duration = duration 
            });
            
            LogAudit("COOLDOWN", $"Started: {reason} ({duration.TotalMinutes:F0} min)", GovernanceAuditLevel.Warning);
        }

        /// <summary>
        /// Manually end cooldown
        /// </summary>
        public void EndCooldown()
        {
            if (_cooldownState.IsActive)
            {
                _cooldownState.IsActive = false;
                OnCooldownEnded?.Invoke(this, new CooldownEvent 
                { 
                    Type = _cooldownState.Type, 
                    Reason = "Manually ended" 
                });
                LogAudit("COOLDOWN", "Manually ended", GovernanceAuditLevel.Info);
            }
        }

        #endregion

        #region Risk & Aggressiveness Calculations
        
        private AggressivenessLevel CalculateAggressiveness()
        {
            double dailyPnL = _accountState.CurrentBalance - _accountState.DayStartBalance;
            double dailyPnLPercent = dailyPnL / _accountState.DayStartBalance * 100;

            // Defensive: Losing day, high consecutive losses
            if (dailyPnLPercent <= -_settings.DefensiveThreshold || _dailyState.ConsecutiveLosses >= 2)
            {
                return AggressivenessLevel.Defensive;
            }

            // Cautious: Slightly losing or breakeven
            if (dailyPnLPercent <= _settings.CautiousThreshold)
            {
                return AggressivenessLevel.Cautious;
            }

            // Confident: Good winning day
            if (dailyPnLPercent >= _settings.ConfidentThreshold && _dailyState.ConsecutiveWins >= 2)
            {
                return AggressivenessLevel.Confident;
            }

            return AggressivenessLevel.Normal;
        }

        private double GetRiskMultiplier(AggressivenessLevel level)
        {
            switch (level)
            {
                case AggressivenessLevel.Defensive: return 0.5;
                case AggressivenessLevel.Cautious: return 0.75;
                case AggressivenessLevel.Confident: return 1.25;
                default: return 1.0;
            }
        }

        private double GetMinSetupQuality(AggressivenessLevel level)
        {
            switch (level)
            {
                case AggressivenessLevel.Defensive: return 8.0;
                case AggressivenessLevel.Cautious: return 7.0;
                case AggressivenessLevel.Confident: return 5.0;
                default: return 6.0;
            }
        }

        private RiskConstraints CalculateRiskConstraints(TradingStateResult state)
        {
            double remainingDD = GetRemainingDrawdown();
            double maxRisk = remainingDD * _settings.MaxRiskPercentOfRemaining / 100;
            
            return new RiskConstraints
            {
                MaxRisk = maxRisk * state.MaxRiskMultiplier,
                MaxSize = _propFirmRules.MaxPositionSize - _accountState.CurrentPositionSize,
                MaxHoldingMinutes = state.AggressivenessLevel == AggressivenessLevel.Defensive ? 30 : 
                                    state.AggressivenessLevel == AggressivenessLevel.Cautious ? 60 : 120
            };
        }

        private double GetRemainingDrawdown()
        {
            double dailyUsed = Math.Max(0, _accountState.DayStartBalance - _accountState.CurrentBalance);
            double dailyRemaining = (_accountState.DayStartBalance * _propFirmRules.DailyDrawdownLimit / 100) - dailyUsed;
            
            double refBal = _propFirmRules.TrailingDrawdownEnabled 
                ? _accountState.PeakBalance 
                : _accountState.StartingBalance;
            double maxUsed = Math.Max(0, refBal - _accountState.CurrentBalance);
            double maxRemaining = (refBal * _propFirmRules.MaxDrawdownLimit / 100) - maxUsed;
            
            return Math.Min(dailyRemaining, maxRemaining);
        }

        #endregion

        #region Environment Updates
        
        /// <summary>
        /// Update environment conditions from market data
        /// </summary>
        public void UpdateEnvironment(EnvironmentUpdate update)
        {
            _lock.EnterWriteLock();
            try
            {
                _environmentState.IsChoppy = update.IsChoppy;
                _environmentState.NoFollowThrough = update.NoFollowThrough;
                _environmentState.ATRRatio = update.ATRRatio;
                _environmentState.VolumeRatio = update.VolumeRatio;
                _environmentState.CurrentSpread = update.CurrentSpread;
            }
            finally { _lock.ExitWriteLock(); }
        }

        #endregion

        #region Module Coordination
        
        /// <summary>
        /// Register a signal module (SMC or Scalping)
        /// </summary>
        public void RegisterModule(string moduleName, SignalSource source)
        {
            _coordinator.RegisterModule(moduleName, source);
        }

        /// <summary>
        /// Get the priority module for conflicting signals
        /// </summary>
        public SignalSource GetPriorityModule()
        {
            // During optimal NY window, Emmanuel scalping might be preferred
            if (IsOptimalNYWindow() && _emmanuelSettings.PriorityDuringOptimalNY)
            {
                return SignalSource.Scalping;
            }
            
            // Otherwise, SMC for higher timeframe setups
            return SignalSource.SMC;
        }

        /// <summary>
        /// Check if a module should be active based on current conditions
        /// </summary>
        public bool ShouldModuleBeActive(SignalSource source)
        {
            switch (source)
            {
                case SignalSource.SMC:
                    // SMC always active unless critical news
                    return !_newsState.IsCriticalNewsDay;
                    
                case SignalSource.Scalping:
                    // Scalping best during NY session
                    return _currentSession == MounaTradingSession.NewYork && 
                           !IsLunchTime() && 
                           !_newsState.IsCriticalNewsDay;
                    
                default:
                    return true;
            }
        }

        #endregion

        #region Public Getters
        
        public GovernanceStatus GetStatus()
        {
            return new GovernanceStatus
            {
                CurrentState = _currentState,
                CanTradeNow = _currentState == TradingState.Active,
                IsKillSwitchActive = _globalKillSwitch,
                KillSwitchReason = _killSwitchReason,
                IsCooldownActive = _cooldownState.IsActive,
                CooldownEndsAt = _cooldownState.EndsAt,
                CurrentSession = _currentSession,
                CurrentPhase = _currentPhase,
                AggressivenessLevel = CalculateAggressiveness(),
                RiskMultiplier = GetRiskMultiplier(CalculateAggressiveness()),
                DailyPnL = _dailyState.DailyPnL,
                TradesExecuted = _dailyState.TradeCount,
                TradesRemaining = _dailyState.MaxTradesAllowed - _dailyState.TradeCount,
                ConsecutiveLosses = _dailyState.ConsecutiveLosses,
                DrawdownRemaining = GetRemainingDrawdown(),
                ActiveAuthorizations = _activeAuthorizations.Count(kvp => kvp.Value.IsStillValid),
                IsCriticalNewsDay = _newsState.IsCriticalNewsDay,
                IsOptimalWindow = IsOptimalNYWindow()
            };
        }

        public MounaTradingSession GetCurrentSession() => _currentSession;
        public MarketPhase GetCurrentPhase() => _currentPhase;
        public bool IsKillSwitchActive() => _globalKillSwitch;
        public bool IsCooldownActive() => _cooldownState.IsActive;

        #endregion

        #region Audit Logging
        
        private void LogAudit(string category, string message, GovernanceAuditLevel level)
        {
            var entry = new GovernanceAuditEntry
            {
                Timestamp = DateTime.Now,
                Category = category,
                Message = message,
                Level = level
            };
            
            lock (_auditLog)
            {
                _auditLog.Add(entry);
                if (_auditLog.Count > 1000)
                {
                    _auditLog.RemoveAt(0);
                }
            }
        }

        public List<GovernanceAuditEntry> GetAuditLog(int count = 50)
        {
            lock (_auditLog)
            {
                return _auditLog.TakeLast(count).ToList();
            }
        }

        #endregion
    }

    #region Supporting Classes
    
    // ═══════════════════════════════════════════════════════════════════════════
    // CONFIGURATION CLASSES
    // ═══════════════════════════════════════════════════════════════════════════
    
    public class PropFirmRules
    {
        public double DailyDrawdownLimit { get; set; } = 5.0;
        public double MaxDrawdownLimit { get; set; } = 10.0;
        public bool TrailingDrawdownEnabled { get; set; } = false;
        public int MaxPositionSize { get; set; } = 5;
        public List<TimeRestriction> RestrictedPeriods { get; set; } = new List<TimeRestriction>();
        public List<DayOfWeek> NoTradingDays { get; set; } = new List<DayOfWeek> { DayOfWeek.Sunday };
        public bool AllowWeekendHolding { get; set; } = false;
    }

    public class GovernanceSettings
    {
        public int DefaultMaxTradesPerDay { get; set; } = 6;
        public bool ForceSessionEnd { get; set; } = true;
        public TimeSpan SessionEndTime { get; set; } = new TimeSpan(16, 0, 0);
        public TimeSpan FridayCloseTime { get; set; } = new TimeSpan(15, 30, 0);
        
        // Aggressiveness thresholds
        public double DefensiveThreshold { get; set; } = 1.5;
        public double CautiousThreshold { get; set; } = 0.5;
        public double ConfidentThreshold { get; set; } = 1.0;
        
        // Environment thresholds
        public double MinATRRatio { get; set; } = 0.5;
        public double MaxATRRatio { get; set; } = 2.5;
        public double MinVolumeRatio { get; set; } = 0.5;
        public double MaxSpreadTicks { get; set; } = 4;
        public double MinEnvironmentScore { get; set; } = 60;
        
        // Authorization
        public int AuthorizationValiditySeconds { get; set; } = 30;
        
        // Risk
        public double MaxRiskPercentOfRemaining { get; set; } = 20;
        
        // Cooldown
        public int CooldownAfterConsecutiveLosses { get; set; } = 2;
        public int CooldownMinutes { get; set; } = 30;
        
        // Kill switch
        public string KillSwitchDeactivationCode { get; set; } = "CONFIRM_RESUME";
    }

    public class MounaSessionSettings
    {
        // News filter
        public bool FilterCriticalNews { get; set; } = true;
        public int NewsBufferMinutes { get; set; } = 30;
        
        // Session filter
        public bool AvoidJudasSwing { get; set; } = true;
        public bool AvoidLunchTime { get; set; } = true;
        
        // Confluence
        public int MinConfluenceScore { get; set; } = 6;
    }

    public class EmmanuelSettings
    {
        // Confluence
        public int MinConfluenceScore { get; set; } = 5;
        
        // Priority
        public bool PriorityDuringOptimalNY { get; set; } = true;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // STATE CLASSES
    // ═══════════════════════════════════════════════════════════════════════════
    
    public class AccountState
    {
        public double StartingBalance { get; set; }
        public double CurrentBalance { get; set; }
        public double PeakBalance { get; set; }
        public double DayStartBalance { get; set; }
        public int CurrentPositionSize { get; set; }
    }

    public class DailyState
    {
        public DateTime Date { get; set; }
        public double DailyPnL { get; set; }
        public int TradeCount { get; set; }
        public int WinCount { get; set; }
        public int LossCount { get; set; }
        public int ConsecutiveWins { get; set; }
        public int ConsecutiveLosses { get; set; }
        public int MaxTradesAllowed { get; set; }
        public int AuthorizationsGranted { get; set; }
    }

    public class CooldownState
    {
        public bool IsActive { get; set; }
        public CooldownType Type { get; set; }
        public string Reason { get; set; }
        public DateTime StartedAt { get; set; }
        public DateTime EndsAt { get; set; }
    }

    public class EnvironmentState
    {
        public bool IsChoppy { get; set; }
        public bool NoFollowThrough { get; set; }
        public double ATRRatio { get; set; } = 1.0;
        public double VolumeRatio { get; set; } = 1.0;
        public double CurrentSpread { get; set; }
    }

    public class SessionState
    {
        public MounaTradingSession CurrentSession { get; set; }
        public MarketPhase CurrentPhase { get; set; }
        public DateTime CurrentETTime { get; set; }
        public bool IsNYOpen { get; set; }
        public bool IsOptimalNY { get; set; }
        public bool IsLunchTime { get; set; }
        public bool IsFridayClose { get; set; }
    }

    public class NewsState
    {
        public NewsImpact CurrentImpact { get; set; }
        public string NextEventName { get; set; }
        public int MinutesToEvent { get; set; }
        public bool IsCriticalNewsDay { get; set; }
        public bool IsNFP { get; set; }
        public bool IsCPI { get; set; }
        public bool IsFOMC { get; set; }
        public bool IsPowell { get; set; }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // AUTHORIZATION CLASSES
    // ═══════════════════════════════════════════════════════════════════════════
    
    public class TradeAuthorization
    {
        public string AuthorizationId { get; set; }
        public string RequestId { get; set; }
        public string Instrument { get; set; }
        public TradeDirection Direction { get; set; }
        public string RequestedSetup { get; set; }
        public SignalSource SignalSource { get; set; }
        public int ConfluenceScore { get; set; }
        
        public DateTime RequestTime { get; set; }
        public DateTime? GrantedTime { get; set; }
        public DateTime ExpiresAt { get; set; }
        public DateTime? MustCloseBy { get; set; }
        
        public bool IsGranted { get; set; }
        public string DenialReason { get; set; }
        public BlockLevel DenialLevel { get; set; }
        
        public AggressivenessLevel AggressivenessLevel { get; set; }
        public double RiskMultiplier { get; set; }
        public double GrantedRiskAmount { get; set; }
        public int MaxPositionSize { get; set; }
        public int MaxHoldingMinutes { get; set; }
        
        public bool WasExecuted { get; set; }
        public DateTime? ExecutionTime { get; set; }
        public double ActualEntryPrice { get; set; }
        public int ActualPositionSize { get; set; }
        
        public bool WasRevoked { get; set; }
        public string RevocationReason { get; set; }
        
        public bool IsStillValid => IsGranted && !WasRevoked && !WasExecuted && DateTime.Now <= ExpiresAt;
    }

    public class TradeAuthorizationRequest
    {
        public string RequestId { get; set; }
        public string Instrument { get; set; }
        public TradeDirection Direction { get; set; }
        public string SetupType { get; set; }
        public double SetupQuality { get; set; }
        public double RequestedRiskAmount { get; set; }
        public SignalSource SignalSource { get; set; }
        public int ConfluenceScore { get; set; }
    }

    public class AuthorizationValidation
    {
        public bool IsValid { get; set; }
        public string Reason { get; set; }
        public TradeAuthorization Authorization { get; set; }
    }

    public class ExecutionConfirmation
    {
        public DateTime ExecutionTime { get; set; }
        public double EntryPrice { get; set; }
        public int PositionSize { get; set; }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // EVALUATION RESULT CLASSES
    // ═══════════════════════════════════════════════════════════════════════════
    
    public class TradingStateResult
    {
        public TradingState State { get; set; }
        public bool CanTrade { get; set; }
        public string Reason { get; set; }
        public BlockLevel BlockLevel { get; set; }
        public AggressivenessLevel AggressivenessLevel { get; set; }
        public double MaxRiskMultiplier { get; set; }
        public int MaxTradesRemaining { get; set; }
        public double DrawdownRemaining { get; set; }
        public double EnvironmentScore { get; set; }
        public MounaTradingSession CurrentSession { get; set; }
        public MarketPhase CurrentPhase { get; set; }
        public bool IsOptimalWindow { get; set; }
        public DateTime Timestamp { get; set; }
    }

    public class PropFirmEvaluation
    {
        public bool IsCompliant { get; set; }
        public bool IsCritical { get; set; }
        public PropFirmViolation ViolationType { get; set; }
        public string Message { get; set; }
        public double RemainingDailyDD { get; set; }
        public double RemainingMaxDD { get; set; }
    }

    public class SessionEvaluation
    {
        public bool IsValid { get; set; }
        public string Reason { get; set; }
    }

    public class EnvironmentEvaluation
    {
        public bool IsFavorable { get; set; }
        public double Score { get; set; }
        public string Reason { get; set; }
    }

    public class RiskConstraints
    {
        public double MaxRisk { get; set; }
        public int MaxSize { get; set; }
        public int MaxHoldingMinutes { get; set; }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // UPDATE CLASSES
    // ═══════════════════════════════════════════════════════════════════════════
    
    public class TradeResultUpdate
    {
        public string AuthorizationId { get; set; }
        public double NetPnL { get; set; }
        public bool IsWinner { get; set; }
        public int PositionSize { get; set; }
    }

    public class EnvironmentUpdate
    {
        public bool IsChoppy { get; set; }
        public bool NoFollowThrough { get; set; }
        public double ATRRatio { get; set; }
        public double VolumeRatio { get; set; }
        public double CurrentSpread { get; set; }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // STATUS & AUDIT CLASSES
    // ═══════════════════════════════════════════════════════════════════════════
    
    public class GovernanceStatus
    {
        public TradingState CurrentState { get; set; }
        public bool CanTradeNow { get; set; }
        public bool IsKillSwitchActive { get; set; }
        public string KillSwitchReason { get; set; }
        public bool IsCooldownActive { get; set; }
        public DateTime CooldownEndsAt { get; set; }
        public MounaTradingSession CurrentSession { get; set; }
        public MarketPhase CurrentPhase { get; set; }
        public AggressivenessLevel AggressivenessLevel { get; set; }
        public double RiskMultiplier { get; set; }
        public double DailyPnL { get; set; }
        public int TradesExecuted { get; set; }
        public int TradesRemaining { get; set; }
        public int ConsecutiveLosses { get; set; }
        public double DrawdownRemaining { get; set; }
        public int ActiveAuthorizations { get; set; }
        public bool IsCriticalNewsDay { get; set; }
        public bool IsOptimalWindow { get; set; }
    }

    public class GovernanceAuditEntry
    {
        public DateTime Timestamp { get; set; }
        public string Category { get; set; }
        public string Message { get; set; }
        public GovernanceAuditLevel Level { get; set; }
        
        public override string ToString()
        {
            return $"[{Timestamp:HH:mm:ss}] [{Level}] {Category}: {Message}";
        }
    }

    public class BlockedRequest
    {
        public string RequestId { get; set; }
        public string Reason { get; set; }
        public BlockLevel Level { get; set; }
        public DateTime Timestamp { get; set; }
    }

    public class TimeRestriction
    {
        public TimeSpan Start { get; set; }
        public TimeSpan End { get; set; }
        public string Reason { get; set; }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // MODULE COORDINATION
    // ═══════════════════════════════════════════════════════════════════════════
    
    public class ModuleCoordinator
    {
        private Dictionary<string, SignalSource> _registeredModules = new Dictionary<string, SignalSource>();
        
        public void RegisterModule(string name, SignalSource source)
        {
            _registeredModules[name] = source;
        }
        
        public bool IsModuleRegistered(string name) => _registeredModules.ContainsKey(name);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // EVENT CLASSES
    // ═══════════════════════════════════════════════════════════════════════════
    
    public class TradingStateChangedEvent
    {
        public TradingState PreviousState { get; set; }
        public TradingState NewState { get; set; }
    }

    public class AuthorizationEvent
    {
        public TradeAuthorization Authorization { get; set; }
    }

    public class KillSwitchEvent
    {
        public KillSwitchType Type { get; set; }
        public string Reason { get; set; }
    }

    public class CooldownEvent
    {
        public CooldownType Type { get; set; }
        public string Reason { get; set; }
        public TimeSpan Duration { get; set; }
    }

    public class SessionChangeEvent
    {
        public MounaTradingSession PreviousSession { get; set; }
        public MounaTradingSession NewSession { get; set; }
        public MarketPhase Phase { get; set; }
        public DateTime Time { get; set; }
    }

    public class NewsBlockEvent
    {
        public string Reason { get; set; }
        public bool IsCritical { get; set; }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // ENUMS
    // ═══════════════════════════════════════════════════════════════════════════
    
    public enum TradingState
    {
        Evaluating,
        Active,
        KillSwitchActive,
        PropFirmBlocked,
        Cooldown,
        OutsideSession,
        NewsBlocked,
        JudasSwingZone,
        LunchTime,
        UnfavorableEnvironment,
        DailyLimitReached
    }

    public enum BlockLevel
    {
        None,
        KillSwitch,
        PropFirmRule,
        CriticalNews,
        News,
        JudasSwing,
        LunchTime,
        SessionTime,
        Cooldown,
        Environment,
        DailyLimit,
        SetupQuality
    }

    public enum PropFirmViolation
    {
        None,
        DailyDrawdown,
        MaxDrawdown,
        TrailingDrawdown,
        PositionSize
    }

    public enum AggressivenessLevel
    {
        Defensive,
        Cautious,
        Normal,
        Confident
    }

    public enum KillSwitchType
    {
        Manual,
        PropFirmBreach,
        ConsecutiveLosses,
        SystemError
    }

    public enum CooldownType
    {
        ConsecutiveLosses,
        LargeDrawdown,
        Manual
    }

    public enum SignalSource
    {
        SMC,
        Scalping,
        Combined
    }

    public enum GovernanceAuditLevel
    {
        Info,
        Warning,
        Error,
        Critical
    }

    #endregion
}
