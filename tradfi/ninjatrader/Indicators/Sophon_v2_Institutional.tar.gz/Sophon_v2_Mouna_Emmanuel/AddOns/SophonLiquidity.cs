//===============================================================================
// SOPHON LIQUIDITY MODULE v2.0 - DAFE + BIGBELUGA EDITION
// Volume Profile, Liquidity Heatmap, Delta Analysis, Bayesian AI
//
// Adapté de:
//   - Open Liquidity Heatmap [BigBeluga] - Liquidation zones
//   - Volume Profile - Density of Density [DAFE] - Full implementation
//
// FONCTIONNALITÉS DAFE:
//   ✅ Volume Profile (POC, VAH, VAL, VWAP)
//   ✅ Delta Profile (Microstructure Hybrid method)
//   ✅ HVN/LVN Detection (High/Low Volume Nodes)
//   ✅ Profile Entropy (Shannon entropy for market chaos)
//   ✅ Bayesian AI Confidence (Bull/Bear probability)
//   ✅ Regime Detection (COILING, ABSORPTION, DISTRIBUTION, VOLATILE)
//   ✅ Breakout Probability Score
//   ✅ Composite Risk Score
//   ✅ Volatility Skew Analysis
//   ✅ POC Dynamics (Velocity, Direction, Sharpness)
//
// FONCTIONNALITÉS BIGBELUGA:
//   ✅ Liquidation Heatmap (par leverage configurable)
//   ✅ Resting Liquidity Zones (EQH/EQL avec volume)
//   ✅ POC Liquidation levels
//
// Copyright (c) 2026 Algosphere Quant - Emmanuel & Mouna
//===============================================================================

using System;
using System.Collections.Generic;
using System.Linq;

namespace NinjaTrader.NinjaScript.AddOns.Sophon
{
    #region ═══════════════════════════════════════════════════════════════
    //                     DATA STRUCTURES
    // ═══════════════════════════════════════════════════════════════════
    #endregion

    /// <summary>
    /// Single row in Volume Profile
    /// </summary>
    public class VolumeRow
    {
        public double PriceLow { get; set; }
        public double PriceHigh { get; set; }
        public double MidPrice => (PriceLow + PriceHigh) / 2;
        public double TotalVolume { get; set; }
        public double BuyVolume { get; set; }
        public double SellVolume { get; set; }
        public double Delta => BuyVolume - SellVolume;
        public double DeltaPct => TotalVolume > 0 ? (Delta / TotalVolume) * 100 : 0;
        public bool IsHVN { get; set; }
        public bool IsLVN { get; set; }
        public bool IsPOC { get; set; }
        public bool IsVAH { get; set; }
        public bool IsVAL { get; set; }
    }

    /// <summary>
    /// Complete Volume Profile for a period - DAFE Style
    /// </summary>
    public class SophonVolumeProfile
    {
        public string Instrument { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public int StartBar { get; set; }
        public int EndBar { get; set; }
        public double ProfileHigh { get; set; }
        public double ProfileLow { get; set; }
        public int NumRows { get; set; }
        public double RowHeight { get; set; }
        
        public List<VolumeRow> Rows { get; set; } = new List<VolumeRow>();
        
        // Key Levels
        public double POC { get; set; }           // Point of Control
        public double POCVolume { get; set; }
        public int POCRowIndex { get; set; }
        public double VAH { get; set; }           // Value Area High
        public double VAL { get; set; }           // Value Area Low
        public int VAHRowIndex { get; set; }
        public int VALRowIndex { get; set; }
        public double VAWidth => VAH - VAL;
        public double VWAP { get; set; }          // Volume Weighted Average Price
        public double VWAPStdDev { get; set; }    // VWAP Standard Deviation
        
        // Delta Analysis
        public double DeltaPOC { get; set; }      // Price with highest absolute delta
        public int DeltaPOCRowIndex { get; set; }
        public double TotalDelta { get; set; }
        public double TotalVolume { get; set; }
        public double BuyVolumePct { get; set; }
        public double SellVolumePct { get; set; }
        public double DeltaImbalance => BuyVolumePct - SellVolumePct;
        public bool IsBuyDominant => BuyVolumePct > SellVolumePct;
        
        // Nodes
        public List<double> HVNLevels { get; set; } = new List<double>();
        public List<double> LVNLevels { get; set; } = new List<double>();
        public List<int> HVNRows { get; set; } = new List<int>();
        public List<int> LVNRows { get; set; } = new List<int>();
        
        // DAFE Entropy (market disorder measure)
        public double Entropy { get; set; }
        public double NormalizedEntropy { get; set; }
        
        // Profile Statistics
        public double MeanVolume { get; set; }
        public double StdDevVolume { get; set; }
        
        // POC Dynamics (DAFE)
        public double POCVelocity { get; set; }       // POC movement speed
        public double POCVelocityZScore { get; set; } // Z-score of velocity
        public string POCDirection { get; set; }      // "Bullish", "Bearish", "Neutral"
        public double POCSharpness { get; set; }      // POC volume / mean volume
        
        // VA Dynamics (DAFE)
        public double VAWidthRatio { get; set; }      // Current VA / SMA(VA)
        public bool IsVAContracting { get; set; }     // Coiling setup
        public bool IsVAExpanding { get; set; }       // Breakout in progress
        
        // Bayesian AI Metrics (DAFE)
        public double BullishConfidence { get; set; }
        public double BearishConfidence { get; set; }
        
        // Breakout Analysis (DAFE)
        public double BreakoutProbability { get; set; }
        public string BreakoutDirection { get; set; }  // "Bullish", "Bearish", "Neutral"
        
        // Risk Analysis (DAFE)
        public double CompositeRiskScore { get; set; }
        public double CompositeScore { get; set; }     // Institutional liquidity score
        public string ConvictionLevel { get; set; }    // "EXTREME", "HIGH", "MODERATE", "LOW"
        
        // Volatility Skew (DAFE)
        public double VolatilitySkew { get; set; }
        public double VolatilitySkewZScore { get; set; }
    }

    /// <summary>
    /// Liquidation level for heatmap
    /// </summary>
    public class LiquidationLevel
    {
        public double Price { get; set; }
        public double Volume { get; set; }          // Estimated liquidation volume
        public double NormalizedVolume { get; set; } // 0-1 for heatmap color
        public bool IsAbovePrice { get; set; }      // Above current price = shorts liquidation
        public DateTime DetectedAt { get; set; }
        public int BarIndex { get; set; }
    }

    /// <summary>
    /// Resting liquidity zone (equal highs/lows with volume)
    /// </summary>
    public class RestingLiquidity
    {
        public string Id { get; set; }
        public double Price { get; set; }
        public double EstimatedVolume { get; set; }
        public LiquidityType Type { get; set; }     // BuySide, SellSide, EQH, EQL
        public int TouchCount { get; set; }
        public DateTime FirstTouch { get; set; }
        public DateTime LastTouch { get; set; }
        public int FirstBar { get; set; }
        public int LastBar { get; set; }
        public bool IsTaken { get; set; }
        public double TakenPrice { get; set; }
        
        public RestingLiquidity()
        {
            Id = Guid.NewGuid().ToString("N").Substring(0, 8);
        }
    }

    /// <summary>
    /// Market regime based on volume analysis - DAFE Style
    /// </summary>
    public enum VolumeRegime
    {
        Balanced,       // Normal VA, balanced delta - "Market in equilibrium"
        Coiling,        // Contracting VA, building energy - "Breakout imminent"
        Absorption,     // High volume, buying dominant - "Smart money accumulating"
        Distribution,   // High volume, selling dominant - "Institutions distributing"
        Volatile,       // Expanding VA, high entropy - "Reduce size"
        Trending,       // POC shifting, strong delta - "Trend developing"
        Extreme,        // Extreme delta conditions - "Reversal possible"
        POCShift        // Significant POC movement - "Value migrating"
    }
    
    /// <summary>
    /// Detailed market regime info - DAFE Style
    /// </summary>
    public class MarketRegimeInfo
    {
        public VolumeRegime Regime { get; set; }
        public string Name { get; set; }
        public string Icon { get; set; }
        public string Description { get; set; }
        public string Color { get; set; }  // Hex color
        
        public static MarketRegimeInfo GetRegimeInfo(VolumeRegime regime)
        {
            switch (regime)
            {
                case VolumeRegime.Balanced:
                    return new MarketRegimeInfo
                    {
                        Regime = regime,
                        Name = "● BALANCED",
                        Icon = "●",
                        Description = "Market in equilibrium - wait for catalyst",
                        Color = "#888888"
                    };
                case VolumeRegime.Coiling:
                    return new MarketRegimeInfo
                    {
                        Regime = regime,
                        Name = "🔷 COILING",
                        Icon = "🔷",
                        Description = "Energy building - breakout imminent",
                        Color = "#00d4ff"
                    };
                case VolumeRegime.Absorption:
                    return new MarketRegimeInfo
                    {
                        Regime = regime,
                        Name = "🟢 ABSORPTION",
                        Icon = "🟢",
                        Description = "Smart money accumulating - bullish bias",
                        Color = "#00ff88"
                    };
                case VolumeRegime.Distribution:
                    return new MarketRegimeInfo
                    {
                        Regime = regime,
                        Name = "🔴 DISTRIBUTION",
                        Icon = "🔴",
                        Description = "Institutions distributing - bearish bias",
                        Color = "#ff4466"
                    };
                case VolumeRegime.Volatile:
                    return new MarketRegimeInfo
                    {
                        Regime = regime,
                        Name = "🌊 VOLATILE",
                        Icon = "🌊",
                        Description = "High volatility regime - reduce size",
                        Color = "#ffaa00"
                    };
                case VolumeRegime.Trending:
                    return new MarketRegimeInfo
                    {
                        Regime = regime,
                        Name = "📈 TRENDING",
                        Icon = "📈",
                        Description = "Clear trend - follow the flow",
                        Color = "#00ff88"
                    };
                case VolumeRegime.Extreme:
                    return new MarketRegimeInfo
                    {
                        Regime = regime,
                        Name = "⚠️ EXTREME",
                        Icon = "⚠️",
                        Description = "Extreme conditions - reversal possible",
                        Color = "#ffaa00"
                    };
                case VolumeRegime.POCShift:
                    return new MarketRegimeInfo
                    {
                        Regime = regime,
                        Name = "🚀 POC SHIFT",
                        Icon = "🚀",
                        Description = "Significant POC movement - trend developing",
                        Color = "#00d4ff"
                    };
                default:
                    return new MarketRegimeInfo
                    {
                        Regime = VolumeRegime.Balanced,
                        Name = "● BALANCED",
                        Icon = "●",
                        Description = "Market in equilibrium",
                        Color = "#888888"
                    };
            }
        }
    }

    #region ═══════════════════════════════════════════════════════════════
    //                     MAIN MODULE
    // ═══════════════════════════════════════════════════════════════════
    #endregion

    public class SophonLiquidity
    {
        #region Constants
        private const double EPS = 1e-10;
        private const int DEFAULT_ROWS = 70;
        private const double DEFAULT_VA_PCT = 70.0;
        private const double DEFAULT_HVN_THRESHOLD = 1.3;  // σ above mean
        private const double DEFAULT_LVN_THRESHOLD = 0.4;  // σ below mean
        #endregion

        #region Settings
        public class LiquiditySettings
        {
            public int ProfileLookback { get; set; } = 100;
            public int NumRows { get; set; } = 70;
            public double ValueAreaPct { get; set; } = 70.0;
            public double HVNThreshold { get; set; } = 1.3;
            public double LVNThreshold { get; set; } = 0.4;
            public double DefaultLeverage { get; set; } = 10.0;
            public double PriceBufferPct { get; set; } = 2.0;
            public string DeltaMethod { get; set; } = "Microstructure";
            
            // DAFE Advanced Settings
            public int MetricLookback { get; set; } = 30;          // History lookback for metrics
            public double VAContractionPct { get; set; } = 20.0;   // VA contraction threshold
            public double VAExpansionPct { get; set; } = 30.0;     // VA expansion threshold
            public double POCVelThreshold { get; set; } = 2.0;     // POC velocity z-score threshold
            public double DeltaExtremeThreshold { get; set; } = 2.5; // Delta extreme z-score threshold
        }
        
        public LiquiditySettings Settings { get; set; } = new LiquiditySettings();
        #endregion

        #region State
        private Dictionary<string, SophonVolumeProfile> _profiles = new Dictionary<string, SophonVolumeProfile>();
        private Dictionary<string, List<LiquidationLevel>> _liquidationLevels = new Dictionary<string, List<LiquidationLevel>>();
        private Dictionary<string, List<RestingLiquidity>> _restingLiquidity = new Dictionary<string, List<RestingLiquidity>>();
        private Dictionary<string, List<BarData>> _barHistory = new Dictionary<string, List<BarData>>();
        
        // DAFE History tracking for advanced metrics
        private Dictionary<string, List<double>> _pocHistory = new Dictionary<string, List<double>>();
        private Dictionary<string, List<double>> _vaWidthHistory = new Dictionary<string, List<double>>();
        private Dictionary<string, List<double>> _deltaImbalanceHistory = new Dictionary<string, List<double>>();
        private Dictionary<string, List<double>> _returnHistory = new Dictionary<string, List<double>>();
        
        // DAFE Smoothed Bayesian confidence
        private Dictionary<string, double> _smoothBullConf = new Dictionary<string, double>();
        private Dictionary<string, double> _smoothBearConf = new Dictionary<string, double>();
        
        private bool _initialized = false;
        #endregion

        #region Bar Data Storage
        private class BarData
        {
            public double Open { get; set; }
            public double High { get; set; }
            public double Low { get; set; }
            public double Close { get; set; }
            public double Volume { get; set; }
            public DateTime Time { get; set; }
            public int BarIndex { get; set; }
        }
        #endregion

        #region ═══════════════════════════════════════════════════════════════
        //                     INITIALIZATION
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        public void Initialize()
        {
            _profiles = new Dictionary<string, SophonVolumeProfile>();
            _liquidationLevels = new Dictionary<string, List<LiquidationLevel>>();
            _restingLiquidity = new Dictionary<string, List<RestingLiquidity>>();
            _barHistory = new Dictionary<string, List<BarData>>();
            _initialized = true;
        }

        public void RegisterInstrument(string instrument)
        {
            if (!_profiles.ContainsKey(instrument))
                _profiles[instrument] = new SophonVolumeProfile { Instrument = instrument };
            
            if (!_liquidationLevels.ContainsKey(instrument))
                _liquidationLevels[instrument] = new List<LiquidationLevel>();
            
            if (!_restingLiquidity.ContainsKey(instrument))
                _restingLiquidity[instrument] = new List<RestingLiquidity>();
            
            if (!_barHistory.ContainsKey(instrument))
                _barHistory[instrument] = new List<BarData>();
            
            // DAFE History tracking
            if (!_pocHistory.ContainsKey(instrument))
                _pocHistory[instrument] = new List<double>();
            
            if (!_vaWidthHistory.ContainsKey(instrument))
                _vaWidthHistory[instrument] = new List<double>();
            
            if (!_deltaImbalanceHistory.ContainsKey(instrument))
                _deltaImbalanceHistory[instrument] = new List<double>();
            
            if (!_returnHistory.ContainsKey(instrument))
                _returnHistory[instrument] = new List<double>();
            
            // Bayesian smoothing
            if (!_smoothBullConf.ContainsKey(instrument))
                _smoothBullConf[instrument] = 0.5;
            
            if (!_smoothBearConf.ContainsKey(instrument))
                _smoothBearConf[instrument] = 0.5;
        }

        #region ═══════════════════════════════════════════════════════════════
        //                     UPDATE METHOD
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        public void UpdateBar(string instrument, double open, double high, double low, double close, 
                             double volume, DateTime time, int barIndex)
        {
            if (!_initialized) Initialize();
            if (!_barHistory.ContainsKey(instrument)) RegisterInstrument(instrument);
            
            var history = _barHistory[instrument];
            
            // Track returns for volatility skew
            if (history.Count > 0)
            {
                double lastClose = history[history.Count - 1].Close;
                if (lastClose > EPS)
                {
                    double logReturn = Math.Log(close / lastClose);
                    var returnHist = _returnHistory[instrument];
                    returnHist.Add(logReturn);
                    while (returnHist.Count > 100)
                        returnHist.RemoveAt(0);
                }
            }
            
            // Add new bar
            history.Add(new BarData
            {
                Open = open,
                High = high,
                Low = low,
                Close = close,
                Volume = volume,
                Time = time,
                BarIndex = barIndex
            });
            
            // Limit history size
            while (history.Count > Settings.ProfileLookback + 50)
                history.RemoveAt(0);
            
            // Rebuild profile if we have enough data
            if (history.Count >= Settings.ProfileLookback)
            {
                BuildVolumeProfile(instrument);
                BuildLiquidationHeatmap(instrument, close);
                UpdateRestingLiquidity(instrument, high, low, close, time, barIndex);
                
                // DAFE Advanced calculations
                CalculatePOCDynamics(instrument);
                CalculateVADynamics(instrument);
                CalculateVolatilitySkew(instrument);
                CalculateBayesianConfidence(instrument, close);
                CalculateBreakoutProbability(instrument, close, volume);
                CalculateRiskScores(instrument, close, volume);
                
                // Update history for metrics
                UpdateMetricHistory(instrument);
            }
        }
        
        /// <summary>
        /// Update POC, VA width, and delta imbalance history
        /// </summary>
        private void UpdateMetricHistory(string instrument)
        {
            var profile = _profiles[instrument];
            
            // POC History
            var pocHist = _pocHistory[instrument];
            if (profile.POC > 0)
            {
                pocHist.Add(profile.POC);
                while (pocHist.Count > 500)
                    pocHist.RemoveAt(0);
            }
            
            // VA Width History
            var vaHist = _vaWidthHistory[instrument];
            if (profile.VAWidth > 0)
            {
                vaHist.Add(profile.VAWidth);
                while (vaHist.Count > 500)
                    vaHist.RemoveAt(0);
            }
            
            // Delta Imbalance History
            var deltaHist = _deltaImbalanceHistory[instrument];
            deltaHist.Add(profile.DeltaImbalance);
            while (deltaHist.Count > 500)
                deltaHist.RemoveAt(0);
        }

        #region ═══════════════════════════════════════════════════════════════
        //                     VOLUME PROFILE CONSTRUCTION
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        private void BuildVolumeProfile(string instrument)
        {
            var history = _barHistory[instrument];
            if (history.Count < Settings.ProfileLookback) return;
            
            var recentBars = history.Skip(history.Count - Settings.ProfileLookback).ToList();
            
            // Find price range
            double highest = recentBars.Max(b => b.High);
            double lowest = recentBars.Min(b => b.Low);
            double range = highest - lowest;
            
            // Add buffer
            double buffer = range * (Settings.PriceBufferPct / 100.0);
            double profileHigh = highest + buffer;
            double profileLow = lowest - buffer;
            double rowHeight = (profileHigh - profileLow) / Settings.NumRows;
            
            // Initialize rows
            var rows = new List<VolumeRow>();
            for (int i = 0; i < Settings.NumRows; i++)
            {
                rows.Add(new VolumeRow
                {
                    PriceLow = profileLow + i * rowHeight,
                    PriceHigh = profileLow + (i + 1) * rowHeight,
                    TotalVolume = 0,
                    BuyVolume = 0,
                    SellVolume = 0
                });
            }
            
            // Distribute volume to rows
            double totalVolume = 0;
            double totalDelta = 0;
            double vwapSum = 0;
            double vwapVolSum = 0;
            double vwapSumSq = 0;
            
            foreach (var bar in recentBars)
            {
                if (bar.Volume <= 0) continue;
                
                // Calculate delta for this bar
                double barDelta = CalculateBarDelta(bar);
                double buyVol = Math.Max(0, (bar.Volume + barDelta) / 2);
                double sellVol = Math.Max(0, (bar.Volume - barDelta) / 2);
                
                // Find which rows this bar spans
                int lowRow = (int)Math.Floor((bar.Low - profileLow) / rowHeight);
                int highRow = (int)Math.Floor((bar.High - profileLow) / rowHeight);
                lowRow = Math.Max(0, Math.Min(Settings.NumRows - 1, lowRow));
                highRow = Math.Max(0, Math.Min(Settings.NumRows - 1, highRow));
                
                if (highRow >= lowRow)
                {
                    int rowsSpanned = highRow - lowRow + 1;
                    double volPerRow = bar.Volume / rowsSpanned;
                    double buyPerRow = buyVol / rowsSpanned;
                    double sellPerRow = sellVol / rowsSpanned;
                    
                    for (int r = lowRow; r <= highRow; r++)
                    {
                        rows[r].TotalVolume += volPerRow;
                        rows[r].BuyVolume += buyPerRow;
                        rows[r].SellVolume += sellPerRow;
                    }
                }
                
                totalVolume += bar.Volume;
                totalDelta += barDelta;
                
                // VWAP calculation
                double typicalPrice = (bar.High + bar.Low + bar.Close) / 3;
                vwapSum += typicalPrice * bar.Volume;
                vwapVolSum += bar.Volume;
                vwapSumSq += typicalPrice * typicalPrice * bar.Volume;
            }
            
            // Find POC (row with maximum volume)
            int pocIndex = 0;
            double maxVol = 0;
            for (int i = 0; i < rows.Count; i++)
            {
                if (rows[i].TotalVolume > maxVol)
                {
                    maxVol = rows[i].TotalVolume;
                    pocIndex = i;
                }
            }
            rows[pocIndex].IsPOC = true;
            
            // Find Delta POC (row with highest absolute delta)
            int deltaPocIndex = 0;
            double maxAbsDelta = 0;
            for (int i = 0; i < rows.Count; i++)
            {
                if (Math.Abs(rows[i].Delta) > maxAbsDelta)
                {
                    maxAbsDelta = Math.Abs(rows[i].Delta);
                    deltaPocIndex = i;
                }
            }
            
            // Calculate Value Area
            double targetVol = totalVolume * (Settings.ValueAreaPct / 100.0);
            double accumVol = rows[pocIndex].TotalVolume;
            int vaHighRow = pocIndex;
            int vaLowRow = pocIndex;
            
            while (accumVol < targetVol && (vaHighRow < rows.Count - 1 || vaLowRow > 0))
            {
                double volAbove = vaHighRow < rows.Count - 1 ? rows[vaHighRow + 1].TotalVolume : 0;
                double volBelow = vaLowRow > 0 ? rows[vaLowRow - 1].TotalVolume : 0;
                
                if (volAbove >= volBelow && vaHighRow < rows.Count - 1)
                {
                    vaHighRow++;
                    accumVol += rows[vaHighRow].TotalVolume;
                }
                else if (vaLowRow > 0)
                {
                    vaLowRow--;
                    accumVol += rows[vaLowRow].TotalVolume;
                }
                else if (vaHighRow < rows.Count - 1)
                {
                    vaHighRow++;
                    accumVol += rows[vaHighRow].TotalVolume;
                }
                else
                    break;
            }
            
            rows[vaHighRow].IsVAH = true;
            rows[vaLowRow].IsVAL = true;
            
            // Calculate statistics for HVN/LVN detection
            double meanVol = rows.Average(r => r.TotalVolume);
            double variance = rows.Count > 1 ? rows.Sum(r => Math.Pow(r.TotalVolume - meanVol, 2)) / (rows.Count - 1) : 0;
            double stdDev = Math.Sqrt(variance);
            
            double hvnThreshold = meanVol + Settings.HVNThreshold * stdDev;
            double lvnThreshold = Math.Max(0, meanVol - Settings.LVNThreshold * stdDev);
            
            var hvnLevels = new List<double>();
            var lvnLevels = new List<double>();
            
            foreach (var row in rows)
            {
                if (row.TotalVolume >= hvnThreshold)
                {
                    row.IsHVN = true;
                    hvnLevels.Add(row.MidPrice);
                }
                else if (row.TotalVolume <= lvnThreshold && row.TotalVolume > 0)
                {
                    row.IsLVN = true;
                    lvnLevels.Add(row.MidPrice);
                }
            }
            
            // Calculate entropy
            double entropy = 0;
            if (totalVolume > EPS)
            {
                foreach (var row in rows)
                {
                    double p = row.TotalVolume / totalVolume;
                    if (p > 0.0001)
                        entropy -= p * Math.Log(p) / Math.Log(2);
                }
            }
            double maxEntropy = Math.Log(Settings.NumRows) / Math.Log(2);
            double normalizedEntropy = maxEntropy > 0 ? entropy / maxEntropy : 0;
            
            // Build profile object
            var profile = _profiles[instrument];
            profile.StartTime = recentBars.First().Time;
            profile.EndTime = recentBars.Last().Time;
            profile.StartBar = recentBars.First().BarIndex;
            profile.EndBar = recentBars.Last().BarIndex;
            profile.ProfileHigh = profileHigh;
            profile.ProfileLow = profileLow;
            profile.NumRows = Settings.NumRows;
            profile.RowHeight = rowHeight;
            profile.Rows = rows;
            
            profile.POC = rows[pocIndex].MidPrice;
            profile.POCVolume = rows[pocIndex].TotalVolume;
            profile.POCRowIndex = pocIndex;
            profile.VAH = rows[vaHighRow].PriceHigh;
            profile.VAL = rows[vaLowRow].PriceLow;
            profile.VAHRowIndex = vaHighRow;
            profile.VALRowIndex = vaLowRow;
            profile.VWAP = vwapVolSum > EPS ? vwapSum / vwapVolSum : rows[pocIndex].MidPrice;
            
            // Calculate VWAP standard deviation
            double vwapVariance = vwapVolSum > EPS ? vwapSumSq / vwapVolSum - (profile.VWAP * profile.VWAP) : 0;
            profile.VWAPStdDev = Math.Sqrt(Math.Max(0, vwapVariance));
            
            profile.DeltaPOC = rows[deltaPocIndex].MidPrice;
            profile.DeltaPOCRowIndex = deltaPocIndex;
            profile.TotalDelta = totalDelta;
            profile.TotalVolume = totalVolume;
            
            double totalBuy = rows.Sum(r => r.BuyVolume);
            double totalSell = rows.Sum(r => r.SellVolume);
            profile.BuyVolumePct = totalVolume > 0 ? (totalBuy / totalVolume) * 100 : 50;
            profile.SellVolumePct = 100 - profile.BuyVolumePct;
            
            profile.HVNLevels = hvnLevels;
            profile.LVNLevels = lvnLevels;
            profile.HVNRows = new List<int>();
            profile.LVNRows = new List<int>();
            
            // Store HVN/LVN row indices
            for (int i = 0; i < rows.Count; i++)
            {
                if (rows[i].IsHVN)
                    profile.HVNRows.Add(i);
                if (rows[i].IsLVN)
                    profile.LVNRows.Add(i);
            }
            
            profile.Entropy = entropy;
            profile.NormalizedEntropy = normalizedEntropy;
            profile.MeanVolume = meanVol;
            profile.StdDevVolume = stdDev;
            
            // POC Sharpness (DAFE)
            profile.POCSharpness = meanVol > EPS ? profile.POCVolume / meanVol : 1.0;
        }

        /// <summary>
        /// Calculate bar delta using microstructure analysis (DAFE method)
        /// </summary>
        private double CalculateBarDelta(BarData bar)
        {
            double delta = 0;
            double range = bar.High - bar.Low;
            
            if (range > EPS && bar.Volume > 0)
            {
                switch (Settings.DeltaMethod)
                {
                    case "ClosePosition":
                        // Based on where candle closes relative to range
                        double buyRatio = (bar.Close - bar.Low) / range;
                        delta = bar.Volume * (2 * buyRatio - 1);
                        break;
                        
                    case "Wicks":
                        // Analyze wick rejection
                        double upperWick = bar.High - Math.Max(bar.Open, bar.Close);
                        double lowerWick = Math.Min(bar.Open, bar.Close) - bar.Low;
                        double body = Math.Abs(bar.Close - bar.Open);
                        double buyPressure = lowerWick + (bar.Close > bar.Open ? body : 0);
                        double sellPressure = upperWick + (bar.Close < bar.Open ? body : 0);
                        double total = buyPressure + sellPressure;
                        delta = total > EPS ? ((buyPressure - sellPressure) / total) * bar.Volume : 0;
                        break;
                        
                    case "Microstructure":
                    default:
                        // Hybrid method combining multiple approaches
                        double closePos = (bar.Close - bar.Low) / range;
                        double uWick = bar.High - Math.Max(bar.Open, bar.Close);
                        double lWick = Math.Min(bar.Open, bar.Close) - bar.Low;
                        double bodySize = Math.Abs(bar.Close - bar.Open);
                        double bodyRatio = bodySize / range;
                        
                        // Weights based on body size
                        double wickWeight = bodyRatio > 0.7 ? 0.2 : bodyRatio < 0.3 ? 0.5 : 0.3;
                        double closeWeight = bodyRatio > 0.7 ? 0.6 : bodyRatio < 0.3 ? 0.2 : 0.4;
                        double bodyWeight = 1.0 - wickWeight - closeWeight;
                        
                        double closeComp = 2 * closePos - 1;
                        double buyPress = lWick + (bar.Close > bar.Open ? bodySize : 0);
                        double sellPress = uWick + (bar.Close < bar.Open ? bodySize : 0);
                        double wickTotal = buyPress + sellPress;
                        double wickComp = wickTotal > EPS ? (buyPress - sellPress) / wickTotal : 0;
                        double bodyComp = (bar.Close >= bar.Open ? 1.0 : -1.0) * bodyRatio;
                        
                        delta = bar.Volume * (closeWeight * closeComp + wickWeight * wickComp + bodyWeight * bodyComp);
                        break;
                }
            }
            
            return delta;
        }

        #region ═══════════════════════════════════════════════════════════════
        //                     DAFE ADVANCED CALCULATIONS
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        /// <summary>
        /// Calculate POC Dynamics - DAFE Style
        /// Velocity, Direction, Z-Score
        /// </summary>
        private void CalculatePOCDynamics(string instrument)
        {
            var profile = _profiles[instrument];
            var pocHist = _pocHistory[instrument];
            
            int velocityLookback = 5;
            
            // POC Velocity
            if (pocHist.Count > velocityLookback)
            {
                double oldPoc = pocHist[pocHist.Count - velocityLookback];
                profile.POCVelocity = profile.POC - oldPoc;
            }
            else
            {
                profile.POCVelocity = 0;
            }
            
            // POC Velocity Z-Score
            int metricLookback = Settings.MetricLookback;
            if (pocHist.Count >= metricLookback + velocityLookback)
            {
                var pocVelHistory = new List<double>();
                int samplesToTake = Math.Min(metricLookback, pocHist.Count - velocityLookback - 1);
                
                for (int i = 0; i < samplesToTake; i++)
                {
                    int newerIdx = pocHist.Count - 1 - i;
                    int olderIdx = newerIdx - velocityLookback;
                    if (olderIdx >= 0)
                    {
                        double histVelocity = pocHist[newerIdx] - pocHist[olderIdx];
                        pocVelHistory.Add(histVelocity);
                    }
                }
                
                if (pocVelHistory.Count > 2)
                {
                    double mean = pocVelHistory.Average();
                    double variance = pocVelHistory.Count > 1 
                        ? pocVelHistory.Sum(v => Math.Pow(v - mean, 2)) / (pocVelHistory.Count - 1) 
                        : 0;
                    double stdDev = Math.Max(Math.Sqrt(variance), EPS);
                    profile.POCVelocityZScore = (profile.POCVelocity - mean) / stdDev;
                }
            }
            
            // POC Direction
            double relativeThreshold = profile.POC * 0.0001;
            if (profile.POCVelocity > relativeThreshold)
                profile.POCDirection = "Bullish";
            else if (profile.POCVelocity < -relativeThreshold)
                profile.POCDirection = "Bearish";
            else
                profile.POCDirection = "Neutral";
        }
        
        /// <summary>
        /// Calculate VA Dynamics - DAFE Style
        /// Contraction/Expansion detection
        /// </summary>
        private void CalculateVADynamics(string instrument)
        {
            var profile = _profiles[instrument];
            var vaHist = _vaWidthHistory[instrument];
            
            // VA Width Ratio
            if (vaHist.Count >= 5)
            {
                double vaWidthSma = vaHist.Skip(vaHist.Count - 5).Average();
                profile.VAWidthRatio = vaWidthSma > EPS ? profile.VAWidth / vaWidthSma : 1.0;
            }
            else
            {
                profile.VAWidthRatio = 1.0;
            }
            
            // Contraction/Expansion detection
            profile.IsVAContracting = profile.VAWidthRatio < (1.0 - Settings.VAContractionPct / 100);
            profile.IsVAExpanding = profile.VAWidthRatio > (1.0 + Settings.VAExpansionPct / 100);
        }
        
        /// <summary>
        /// Calculate Volatility Skew - DAFE Style
        /// Measures asymmetry between up and down volatility
        /// </summary>
        private void CalculateVolatilitySkew(string instrument)
        {
            var profile = _profiles[instrument];
            var returnHist = _returnHistory[instrument];
            
            if (returnHist.Count < 14)
            {
                profile.VolatilitySkew = 0;
                profile.VolatilitySkewZScore = 0;
                return;
            }
            
            var upReturns = returnHist.Where(r => r > 0).ToList();
            var downReturns = returnHist.Where(r => r < 0).ToList();
            
            if (upReturns.Count < 3 || downReturns.Count < 3)
            {
                profile.VolatilitySkew = 0;
                profile.VolatilitySkewZScore = 0;
                return;
            }
            
            // Annualization factor (assuming ~252 trading days)
            double annFactor = Math.Sqrt(252);
            
            double upMean = upReturns.Average();
            double downMean = downReturns.Average();
            double upVariance = upReturns.Count > 1 
                ? upReturns.Sum(r => Math.Pow(r - upMean, 2)) / (upReturns.Count - 1) 
                : 0;
            double downVariance = downReturns.Count > 1 
                ? downReturns.Sum(r => Math.Pow(r - downMean, 2)) / (downReturns.Count - 1) 
                : 0;
            
            double upVol = Math.Sqrt(upVariance) * annFactor;
            double downVol = Math.Sqrt(downVariance) * annFactor;
            
            if (upVol > EPS && downVol > EPS)
            {
                profile.VolatilitySkew = ((downVol - upVol) / ((upVol + downVol) / 2)) * 100;
            }
            
            // Z-Score of skew (simplified)
            profile.VolatilitySkewZScore = profile.VolatilitySkew / 10.0; // Normalize
        }
        
        /// <summary>
        /// Calculate Bayesian Confidence - DAFE Style
        /// Combines multiple factors with prior probabilities
        /// </summary>
        private void CalculateBayesianConfidence(string instrument, double close)
        {
            var profile = _profiles[instrument];
            
            double priorBull = 0.5;
            double priorBear = 0.5;
            
            // Delta Likelihood
            double deltaLikelihoodBull = profile.DeltaImbalance > 0
                ? 0.5 + Math.Min(0.4, Math.Abs(profile.DeltaImbalance) / 100)
                : 0.5 - Math.Min(0.4, Math.Abs(profile.DeltaImbalance) / 100);
            double deltaLikelihoodBear = 1 - deltaLikelihoodBull;
            
            // POC Velocity Likelihood
            double pocLikelihoodBull = profile.POCVelocity > 0
                ? 0.5 + Math.Min(0.3, Math.Abs(profile.POCVelocityZScore) / 5)
                : 0.5 - Math.Min(0.3, Math.Abs(profile.POCVelocityZScore) / 5);
            double pocLikelihoodBear = 1 - pocLikelihoodBull;
            
            // Position Likelihood (relative to POC and VA)
            double positionLikelihoodBull;
            if (close > profile.POC)
                positionLikelihoodBull = close > profile.VAH ? 0.75 : 0.6;
            else
                positionLikelihoodBull = close < profile.VAL ? 0.25 : 0.4;
            double positionLikelihoodBear = 1 - positionLikelihoodBull;
            
            // Skew Likelihood
            double skewLikelihoodBull = profile.VolatilitySkewZScore < 0
                ? 0.5 + Math.Min(0.2, Math.Abs(profile.VolatilitySkewZScore) / 5)
                : 0.5 - Math.Min(0.2, Math.Abs(profile.VolatilitySkewZScore) / 5);
            double skewLikelihoodBear = 1 - skewLikelihoodBull;
            
            // Combined Bayesian
            double combinedBull = deltaLikelihoodBull * pocLikelihoodBull * positionLikelihoodBull * skewLikelihoodBull * priorBull;
            double combinedBear = deltaLikelihoodBear * pocLikelihoodBear * positionLikelihoodBear * skewLikelihoodBear * priorBear;
            
            double totalEvidence = combinedBull + combinedBear;
            double bullConf = totalEvidence > EPS ? combinedBull / totalEvidence : 0.5;
            double bearConf = totalEvidence > EPS ? combinedBear / totalEvidence : 0.5;
            
            // Smooth the confidence values
            double smoothingFactor = 0.3;
            _smoothBullConf[instrument] = _smoothBullConf[instrument] * (1 - smoothingFactor) + bullConf * smoothingFactor;
            _smoothBearConf[instrument] = _smoothBearConf[instrument] * (1 - smoothingFactor) + bearConf * smoothingFactor;
            
            profile.BullishConfidence = _smoothBullConf[instrument];
            profile.BearishConfidence = _smoothBearConf[instrument];
        }
        
        /// <summary>
        /// Calculate Breakout Probability - DAFE Style
        /// </summary>
        private void CalculateBreakoutProbability(string instrument, double close, double volume)
        {
            var profile = _profiles[instrument];
            var history = _barHistory[instrument];
            
            double probability = 0;
            
            // VA Contraction adds probability
            if (profile.IsVAContracting)
                probability += 30;
            else if (profile.VAWidthRatio < 0.9)
                probability += 15;
            
            // Delta Imbalance
            double absDelta = Math.Abs(profile.DeltaImbalance);
            if (absDelta > 25)
                probability += 25;
            else if (absDelta > 15)
                probability += 15;
            else if (absDelta > 10)
                probability += 10;
            
            // POC Velocity
            if (Math.Abs(profile.POCVelocityZScore) > 2.0)
                probability += 20;
            else if (Math.Abs(profile.POCVelocityZScore) > 1.0)
                probability += 10;
            
            // Volume surge
            double avgVolume = history.Count > 50 
                ? history.Skip(history.Count - 50).Average(b => b.Volume) 
                : history.Average(b => b.Volume);
            double volRatio = avgVolume > EPS ? volume / avgVolume : 1.0;
            
            if (volRatio > 1.5)
                probability += 15;
            else if (volRatio > 1.2)
                probability += 10;
            
            // Price outside VA
            if (close > profile.VAH || close < profile.VAL)
                probability += 10;
            
            // Volatility skew extreme
            if (Math.Abs(profile.VolatilitySkewZScore) > 1.5)
                probability += 10;
            
            // Low entropy adds probability
            if (profile.NormalizedEntropy < 0.5)
                probability += 10;
            
            profile.BreakoutProbability = Math.Min(probability, 100);
            
            // Breakout Direction
            double bullScore = 0, bearScore = 0;
            
            if (profile.DeltaImbalance > 10) bullScore += 30;
            else if (profile.DeltaImbalance < -10) bearScore += 30;
            
            if (profile.POCVelocity > 0) bullScore += 20;
            else if (profile.POCVelocity < 0) bearScore += 20;
            
            if (close > profile.POC) bullScore += 15;
            else if (close < profile.POC) bearScore += 15;
            
            if (close > profile.VAH) bullScore += 20;
            else if (close < profile.VAL) bearScore += 20;
            
            if (profile.VolatilitySkewZScore > 1.0) bearScore += 15;
            else if (profile.VolatilitySkewZScore < -1.0) bullScore += 15;
            
            profile.BreakoutDirection = bullScore > bearScore + 15 ? "Bullish" 
                : bearScore > bullScore + 15 ? "Bearish" : "Neutral";
        }
        
        /// <summary>
        /// Calculate Risk Scores - DAFE Style
        /// Composite Risk and Institutional Score
        /// </summary>
        private void CalculateRiskScores(string instrument, double close, double volume)
        {
            var profile = _profiles[instrument];
            var history = _barHistory[instrument];
            var deltaHist = _deltaImbalanceHistory[instrument];
            
            // Calculate average volume
            double avgVolume = history.Count > 50 
                ? history.Skip(history.Count - 50).Average(b => b.Volume) 
                : history.Average(b => b.Volume);
            double volRatio = avgVolume > EPS ? volume / avgVolume : 1.0;
            
            // COMPOSITE INSTITUTIONAL SCORE (DAFE)
            // VA Score
            double vaScore = profile.VAWidthRatio < 0.7 ? 25 
                : profile.VAWidthRatio < 0.85 ? 20 
                : profile.VAWidthRatio < 1.0 ? 15 
                : profile.VAWidthRatio < 1.15 ? 10 : 5;
            
            // POC Score
            double pocScore = profile.POCSharpness > 2.5 ? 25 
                : profile.POCSharpness > 2.0 ? 20 
                : profile.POCSharpness > 1.5 ? 15 
                : profile.POCSharpness > 1.0 ? 10 : 5;
            
            // Delta Score
            double absDelta = Math.Abs(profile.DeltaImbalance);
            double deltaScore = absDelta > 30 ? 25 : absDelta > 20 ? 20 : absDelta > 10 ? 15 : absDelta > 5 ? 10 : 5;
            
            // Volume Score
            double volumeScore = volRatio > 2.0 ? 25 : volRatio > 1.5 ? 20 : volRatio > 1.2 ? 15 : volRatio > 1.0 ? 10 : 5;
            
            // Entropy Score
            double entropyScore = profile.NormalizedEntropy < 0.5 ? 20 
                : profile.NormalizedEntropy < 0.7 ? 15 
                : profile.NormalizedEntropy < 0.85 ? 10 : 5;
            
            // Skew Score
            double skewScore = Math.Abs(profile.VolatilitySkewZScore) > 2.0 ? 20 
                : Math.Abs(profile.VolatilitySkewZScore) > 1.5 ? 15 
                : Math.Abs(profile.VolatilitySkewZScore) > 1.0 ? 10 : 5;
            
            profile.CompositeScore = vaScore + pocScore + deltaScore + volumeScore + entropyScore * 0.5 + skewScore * 0.5;
            
            // Conviction Level
            profile.ConvictionLevel = profile.CompositeScore >= 90 ? "EXTREME" 
                : profile.CompositeScore >= 75 ? "HIGH" 
                : profile.CompositeScore >= 55 ? "MODERATE" : "LOW";
            
            // COMPOSITE RISK SCORE
            double crowdingRisk = 0;
            if (deltaHist.Count >= Settings.MetricLookback)
            {
                double deltaImbalMean = deltaHist.Average();
                double deltaImbalVariance = deltaHist.Count > 1 
                    ? deltaHist.Sum(d => Math.Pow(d - deltaImbalMean, 2)) / (deltaHist.Count - 1) 
                    : 0;
                double deltaImbalStd = Math.Max(Math.Sqrt(deltaImbalVariance), EPS);
                double deltaZScore = (profile.DeltaImbalance - deltaImbalMean) / deltaImbalStd;
                crowdingRisk = Math.Abs(deltaZScore) > 1.5 ? Math.Abs(deltaZScore) / 2 : 0;
            }
            
            double accelerationRisk = Math.Abs(profile.POCVelocityZScore) > 1.5 ? Math.Abs(profile.POCVelocityZScore) / 2 : 0;
            double skewExtremeRisk = Math.Abs(profile.VolatilitySkewZScore) > 1.5 ? Math.Abs(profile.VolatilitySkewZScore) / 2 : 0;
            
            profile.CompositeRiskScore = Math.Min(crowdingRisk * 15 + accelerationRisk * 20 + skewExtremeRisk * 15, 100);
        }

        #region ═══════════════════════════════════════════════════════════════
        //                     LIQUIDATION HEATMAP
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        private void BuildLiquidationHeatmap(string instrument, double currentPrice)
        {
            var history = _barHistory[instrument];
            if (history.Count < Settings.ProfileLookback) return;
            
            var recentBars = history.Skip(history.Count - Settings.ProfileLookback).ToList();
            var profile = _profiles[instrument];
            
            double leverage = Settings.DefaultLeverage / 100.0;
            var levels = new List<LiquidationLevel>();
            
            // For each row, calculate liquidation volume
            foreach (var row in profile.Rows)
            {
                double liqVolAbove = 0;
                double liqVolBelow = 0;
                
                foreach (var bar in recentBars)
                {
                    // Calculate liquidation prices for this bar
                    double longLiqPrice = bar.Low * (1 - leverage);   // Longs liquidated below
                    double shortLiqPrice = bar.High * (1 + leverage); // Shorts liquidated above
                    
                    // Check if this row contains liquidation levels
                    if (longLiqPrice >= row.PriceLow && longLiqPrice <= row.PriceHigh)
                        liqVolBelow += bar.Volume;
                    
                    if (shortLiqPrice >= row.PriceLow && shortLiqPrice <= row.PriceHigh)
                        liqVolAbove += bar.Volume;
                }
                
                if (liqVolAbove > 0)
                {
                    levels.Add(new LiquidationLevel
                    {
                        Price = row.MidPrice,
                        Volume = liqVolAbove,
                        IsAbovePrice = row.MidPrice > currentPrice,
                        DetectedAt = DateTime.Now,
                        BarIndex = recentBars.Last().BarIndex
                    });
                }
                
                if (liqVolBelow > 0)
                {
                    levels.Add(new LiquidationLevel
                    {
                        Price = row.MidPrice,
                        Volume = liqVolBelow,
                        IsAbovePrice = row.MidPrice > currentPrice,
                        DetectedAt = DateTime.Now,
                        BarIndex = recentBars.Last().BarIndex
                    });
                }
            }
            
            // Normalize volumes
            if (levels.Count > 0)
            {
                double maxVol = levels.Max(l => l.Volume);
                double minVol = levels.Min(l => l.Volume);
                foreach (var level in levels)
                {
                    level.NormalizedVolume = maxVol > minVol 
                        ? (level.Volume - minVol) / (maxVol - minVol) 
                        : 0.5;
                }
            }
            
            _liquidationLevels[instrument] = levels;
        }

        #region ═══════════════════════════════════════════════════════════════
        //                     RESTING LIQUIDITY
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        private void UpdateRestingLiquidity(string instrument, double high, double low, double close, 
                                           DateTime time, int barIndex)
        {
            var liquidity = _restingLiquidity[instrument];
            var profile = _profiles[instrument];
            double atr = (profile.ProfileHigh - profile.ProfileLow) / 20; // Approximate ATR
            
            // Check for equal highs (potential buy-side liquidity)
            var history = _barHistory[instrument];
            if (history.Count < 5) return;
            
            for (int i = 3; i < Math.Min(history.Count, 20); i++)
            {
                var oldBar = history[history.Count - 1 - i];
                double threshold = atr * 0.1;
                
                // Equal Highs
                if (Math.Abs(high - oldBar.High) < threshold)
                {
                    var existing = liquidity.FirstOrDefault(l => 
                        Math.Abs(l.Price - high) < threshold && l.Type == LiquidityType.EqualHighs);
                    
                    if (existing != null)
                    {
                        existing.TouchCount++;
                        existing.LastTouch = time;
                        existing.LastBar = barIndex;
                        existing.EstimatedVolume += history.Last().Volume;
                    }
                    else
                    {
                        liquidity.Add(new RestingLiquidity
                        {
                            Price = (high + oldBar.High) / 2,
                            Type = LiquidityType.EqualHighs,
                            TouchCount = 2,
                            FirstTouch = oldBar.Time,
                            LastTouch = time,
                            FirstBar = oldBar.BarIndex,
                            LastBar = barIndex,
                            EstimatedVolume = oldBar.Volume + history.Last().Volume
                        });
                    }
                    break;
                }
                
                // Equal Lows
                if (Math.Abs(low - oldBar.Low) < threshold)
                {
                    var existing = liquidity.FirstOrDefault(l => 
                        Math.Abs(l.Price - low) < threshold && l.Type == LiquidityType.EqualLows);
                    
                    if (existing != null)
                    {
                        existing.TouchCount++;
                        existing.LastTouch = time;
                        existing.LastBar = barIndex;
                        existing.EstimatedVolume += history.Last().Volume;
                    }
                    else
                    {
                        liquidity.Add(new RestingLiquidity
                        {
                            Price = (low + oldBar.Low) / 2,
                            Type = LiquidityType.EqualLows,
                            TouchCount = 2,
                            FirstTouch = oldBar.Time,
                            LastTouch = time,
                            FirstBar = oldBar.BarIndex,
                            LastBar = barIndex,
                            EstimatedVolume = oldBar.Volume + history.Last().Volume
                        });
                    }
                    break;
                }
            }
            
            // Check if any liquidity was taken
            foreach (var liq in liquidity.Where(l => !l.IsTaken))
            {
                if (liq.Type == LiquidityType.EqualHighs && high > liq.Price)
                {
                    liq.IsTaken = true;
                    liq.TakenPrice = high;
                }
                else if (liq.Type == LiquidityType.EqualLows && low < liq.Price)
                {
                    liq.IsTaken = true;
                    liq.TakenPrice = low;
                }
            }
            
            // Clean up old liquidity
            liquidity.RemoveAll(l => barIndex - l.LastBar > 500 || l.IsTaken);
            
            // Limit size
            while (liquidity.Count > 50)
                liquidity.RemoveAt(0);
        }

        #region ═══════════════════════════════════════════════════════════════
        //                     PUBLIC GETTERS
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        public SophonVolumeProfile GetProfile(string instrument)
        {
            return _profiles.ContainsKey(instrument) ? _profiles[instrument] : null;
        }

        public List<LiquidationLevel> GetLiquidationLevels(string instrument)
        {
            return _liquidationLevels.ContainsKey(instrument) ? _liquidationLevels[instrument] : new List<LiquidationLevel>();
        }

        public List<RestingLiquidity> GetRestingLiquidity(string instrument)
        {
            return _restingLiquidity.ContainsKey(instrument) ? _restingLiquidity[instrument] : new List<RestingLiquidity>();
        }

        /// <summary>
        /// Get current market regime based on volume analysis - DAFE Style
        /// </summary>
        public VolumeRegime GetVolumeRegime(string instrument)
        {
            var profile = GetProfile(instrument);
            if (profile == null) return VolumeRegime.Balanced;
            
            double vaWidthPct = profile.VAWidth / ((profile.ProfileHigh - profile.ProfileLow) / 2) * 100;
            double deltaPct = Math.Abs(profile.DeltaImbalance);
            bool isPocExtreme = Math.Abs(profile.POCVelocityZScore) > Settings.POCVelThreshold;
            bool isDeltaExtreme = deltaPct > 30; // High delta imbalance
            
            // DAFE Regime Detection Logic
            
            // Coiling: VA contracting, low delta
            if (profile.IsVAContracting && deltaPct < 10 && profile.NormalizedEntropy < 0.6)
                return VolumeRegime.Coiling;
            
            // POC Shift: Significant POC movement
            if (isPocExtreme)
                return VolumeRegime.POCShift;
            
            // Extreme: Extreme delta conditions
            if (isDeltaExtreme && profile.CompositeRiskScore > 70)
                return VolumeRegime.Extreme;
            
            // Absorption: High volume, buying dominant, VA expanding
            if (profile.IsVAExpanding && profile.DeltaImbalance > 20)
                return VolumeRegime.Absorption;
            
            // Distribution: High volume, selling dominant, VA expanding
            if (profile.IsVAExpanding && profile.DeltaImbalance < -20)
                return VolumeRegime.Distribution;
            
            // Volatile: High entropy, wide VA
            if (vaWidthPct > 60 && profile.NormalizedEntropy > 0.8)
                return VolumeRegime.Volatile;
            
            // Trending: Strong delta, organized (low entropy)
            if (deltaPct > 25 && profile.NormalizedEntropy < 0.6)
                return VolumeRegime.Trending;
            
            return VolumeRegime.Balanced;
        }
        
        /// <summary>
        /// Get detailed market regime info - DAFE Style
        /// </summary>
        public MarketRegimeInfo GetMarketRegimeInfo(string instrument)
        {
            var regime = GetVolumeRegime(instrument);
            var info = MarketRegimeInfo.GetRegimeInfo(regime);
            
            var profile = GetProfile(instrument);
            if (profile != null)
            {
                // Adjust description based on current metrics
                if (regime == VolumeRegime.POCShift)
                {
                    info.Description = profile.POCVelocity > 0 
                        ? "POC shifting UP - bullish trend developing" 
                        : "POC shifting DOWN - bearish trend developing";
                    info.Color = profile.POCVelocity > 0 ? "#00ff88" : "#ff4466";
                }
            }
            
            return info;
        }

        /// <summary>
        /// Get key levels for trading
        /// </summary>
        public Dictionary<string, double> GetKeyLevels(string instrument)
        {
            var profile = GetProfile(instrument);
            var levels = new Dictionary<string, double>();
            
            if (profile == null) return levels;
            
            levels["POC"] = profile.POC;
            levels["VAH"] = profile.VAH;
            levels["VAL"] = profile.VAL;
            levels["VWAP"] = profile.VWAP;
            levels["VWAP_Upper"] = profile.VWAP + profile.VWAPStdDev;
            levels["VWAP_Lower"] = profile.VWAP - profile.VWAPStdDev;
            levels["DeltaPOC"] = profile.DeltaPOC;
            
            // Add HVN/LVN levels
            for (int i = 0; i < Math.Min(3, profile.HVNLevels.Count); i++)
                levels[$"HVN{i + 1}"] = profile.HVNLevels[i];
            
            for (int i = 0; i < Math.Min(3, profile.LVNLevels.Count); i++)
                levels[$"LVN{i + 1}"] = profile.LVNLevels[i];
            
            return levels;
        }
        
        /// <summary>
        /// Get DAFE institutional metrics - for dashboard display
        /// </summary>
        public Dictionary<string, object> GetDAFEMetrics(string instrument)
        {
            var profile = GetProfile(instrument);
            var metrics = new Dictionary<string, object>();
            
            if (profile == null) return metrics;
            
            // Profile Levels
            metrics["POC"] = profile.POC;
            metrics["VAH"] = profile.VAH;
            metrics["VAL"] = profile.VAL;
            metrics["VAWidth"] = profile.VAWidth;
            metrics["VWAP"] = profile.VWAP;
            metrics["DeltaPOC"] = profile.DeltaPOC;
            
            // POC Dynamics
            metrics["POCVelocity"] = profile.POCVelocity;
            metrics["POCVelocityZScore"] = profile.POCVelocityZScore;
            metrics["POCDirection"] = profile.POCDirection;
            metrics["POCSharpness"] = profile.POCSharpness;
            
            // Delta Analysis
            metrics["DeltaImbalance"] = profile.DeltaImbalance;
            metrics["BuyVolumePct"] = profile.BuyVolumePct;
            metrics["SellVolumePct"] = profile.SellVolumePct;
            metrics["IsBuyDominant"] = profile.IsBuyDominant;
            
            // Entropy & Regime
            metrics["Entropy"] = profile.Entropy;
            metrics["NormalizedEntropy"] = profile.NormalizedEntropy;
            metrics["VAWidthRatio"] = profile.VAWidthRatio;
            metrics["IsVAContracting"] = profile.IsVAContracting;
            metrics["IsVAExpanding"] = profile.IsVAExpanding;
            
            // Volatility Skew
            metrics["VolatilitySkew"] = profile.VolatilitySkew;
            metrics["VolatilitySkewZScore"] = profile.VolatilitySkewZScore;
            
            // Bayesian AI
            metrics["BullishConfidence"] = profile.BullishConfidence;
            metrics["BearishConfidence"] = profile.BearishConfidence;
            
            // Breakout Analysis
            metrics["BreakoutProbability"] = profile.BreakoutProbability;
            metrics["BreakoutDirection"] = profile.BreakoutDirection;
            
            // Risk Analysis
            metrics["CompositeRiskScore"] = profile.CompositeRiskScore;
            metrics["CompositeScore"] = profile.CompositeScore;
            metrics["ConvictionLevel"] = profile.ConvictionLevel;
            
            // Nodes
            metrics["HVNCount"] = profile.HVNLevels.Count;
            metrics["LVNCount"] = profile.LVNLevels.Count;
            
            return metrics;
        }
        
        /// <summary>
        /// Check if price is near HVN (High Volume Node)
        /// </summary>
        public bool IsNearHVN(string instrument, double price)
        {
            var profile = GetProfile(instrument);
            if (profile == null || profile.HVNLevels.Count == 0) return false;
            
            double threshold = profile.RowHeight * 2;
            return profile.HVNLevels.Any(hvn => Math.Abs(price - hvn) < threshold);
        }
        
        /// <summary>
        /// Check if price is near LVN (Low Volume Node)
        /// </summary>
        public bool IsNearLVN(string instrument, double price)
        {
            var profile = GetProfile(instrument);
            if (profile == null || profile.LVNLevels.Count == 0) return false;
            
            double threshold = profile.RowHeight * 2;
            return profile.LVNLevels.Any(lvn => Math.Abs(price - lvn) < threshold);
        }
        
        /// <summary>
        /// Get price position relative to VA
        /// </summary>
        public string GetPriceVAPosition(string instrument, double price)
        {
            var profile = GetProfile(instrument);
            if (profile == null) return "Unknown";
            
            if (price > profile.VAH) return "Above VA";
            if (price < profile.VAL) return "Below VA";
            if (Math.Abs(price - profile.POC) < profile.RowHeight) return "At POC";
            if (price > profile.POC) return "Upper VA";
            return "Lower VA";
        }
    }
}
