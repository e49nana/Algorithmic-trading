#region Using declarations
using System;
using System.Collections.Generic;
using System.Linq;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
#endregion

// ═══════════════════════════════════════════════════════════════════════════════
// SOPHON SMC MODULE v2.0 - MOUNA BOULHAL ICT/SMC EDITION
// ═══════════════════════════════════════════════════════════════════════════════
//
// STRATEGY SOURCE: 53 pages transcripts, 50+ videos - Mouna Boulhal
// IMPLEMENTATION: Full ICT/SMC methodology for NinjaTrader 8
//
// ═══════════════════════════════════════════════════════════════════════════════
// CONCEPTS INTEGRATED:
// ═══════════════════════════════════════════════════════════════════════════════
//
// LIQUIDITY:
//   - Buy-Side Liquidity (BSL): Above equal highs, swing highs, bearish trendlines
//   - Sell-Side Liquidity (SSL): Below equal lows, swing lows, bullish trendlines
//   - Liquidity Sweep Detection
//
// ORDER BLOCKS:
//   - Bullish OB: Last red candle before BOS up
//   - Bearish OB: Last green candle before BOS down
//   - Breaker Blocks (mitigated OBs)
//
// FAIR VALUE GAPS (FVG):
//   - Bullish FVG: Gap between C1 high and C3 low
//   - Bearish FVG: Gap between C1 low and C3 high
//   - Fill tracking (partial/complete)
//
// MARKET STRUCTURE:
//   - BOS (Break of Structure): Continuation signal
//   - ChoCH (Change of Character): Reversal signal
//   - Requires: Liquidity taken + BOS + Min 5M timeframe
//
// PREMIUM/DISCOUNT (FIBONACCI):
//   - Premium Zone: Above 50% (sell zone)
//   - Equilibrium: At 50% (avoid)
//   - Discount Zone: Below 50% (buy zone)
//   - OTE Levels: 61.8%, 70.6%, 78.6%
//
// SESSIONS (Eastern Time):
//   - Asian: 6:00 PM - 2:00 AM (Accumulation)
//   - London: 3:00 AM - 12:00 PM (Manipulation)
//   - New York: 9:30 AM - 4:00 PM (Distribution)
//   - Judas Swing detection
//
// REFERENCE LEVELS:
//   - Midnight Opening Price (12:00 AM ET)
//   - 8:30 AM Opening Price
//   - PDH/PDL (Previous Day High/Low)
//   - PWH/PWL (Previous Week High/Low)
//
// INDEX DIVERGENCE:
//   - ES, NQ, YM correlation analysis
//   - Bullish divergence: Leading index higher low
//   - Bearish divergence: Leading index lower high
//
// CONFLUENCE SCORING (Mouna System):
//   - HTF FVG: +2
//   - HTF OB: +2
//   - Premium/Discount optimal (70%+): +2
//   - ChoCH confirmed: +2
//   - Index divergence: +1
//   - Session alignment: +1
//   - Reference level: +1
//   - LTF FVG entry: +1
//   - MINIMUM: 6 points for entry
//
// NEWS FILTER:
//   - Critical: NFP, CPI, FOMC, Powell Speech = NO TRADING
//   - High impact: Caution
//   - Medium: Avoid 30min before/after
//
// Copyright (c) 2026 Algosphere Quant - Emmanuel/Mouna
// ═══════════════════════════════════════════════════════════════════════════════

namespace NinjaTrader.NinjaScript.AddOns.Sophon
{
    #region Mouna-Specific Enums
    
    /// <summary>
    /// Trading session (Eastern Time)
    /// </summary>
    public enum MounaTradingSession
    {
        Asian,      // 6:00 PM - 2:00 AM ET
        London,     // 3:00 AM - 12:00 PM ET
        NewYork,    // 9:30 AM - 4:00 PM ET
        Closed,     // Market closed
        PreMarket   // Before regular hours
    }
    
    /// <summary>
    /// Market phase in AMD cycle
    /// </summary>
    public enum MarketPhase
    {
        Unknown,
        Accumulation,   // Consolidation (typically Asian)
        Manipulation,   // Fake moves (typically London open)
        Distribution    // Real move (typically NY)
    }
    
    // NewsImpact enum defined in SophonNews.cs
    
    /// <summary>
    /// Index divergence type
    /// </summary>
    public enum DivergenceType
    {
        None,
        Bullish,        // Leading index higher low at swing lows
        Bearish,        // Leading index lower high at swing highs
        HiddenBullish,  // Equal lows vs higher low
        HiddenBearish   // Equal highs vs lower high
    }
    
    /// <summary>
    /// OTE (Optimal Trade Entry) Fibonacci levels
    /// </summary>
    public enum OTELevel
    {
        None,
        Level618,   // 61.8% - Golden ratio
        Level706,   // 70.6% - OTE (optimal)
        Level786    // 78.6% - Deep discount/premium
    }
    
    /// <summary>
    /// Inducement pattern type
    /// </summary>
    public enum InducementType
    {
        None,
        FakeSupportResistance,  // Equal highs/lows trap
        PerfectTrendline,       // Trendline with 4+ touches
        PartialFVGFill,         // FOMO trap at partial fill
        SwingTrap,              // Stop beyond swing (liquidity)
        EquilibriumTrap         // POI at 50% Fib
    }
    
    /// <summary>
    /// Mouna's 8-step entry model stages
    /// </summary>
    public enum MounaEntryStage
    {
        Stage0_Waiting,         // Waiting for setup
        Stage1_HTF_POI_Reached, // Prix atteint POI en HTF
        Stage2_Switch_LTF,      // Switch vers 5m/15m
        Stage3_Liquidity_Taken, // Liquidité prise (SSL/BSL)
        Stage4_BOS_ChoCH,       // BOS → ChoCH confirmé
        Stage5_Retracement,     // Retracement vers FVG/OB LTF
        Stage6_Entry,           // Entrée au fill du FVG
        Stage7_StopSet,         // Stop sous/dessus OB
        Stage8_TargetSet        // Target: Liquidité opposée
    }
    
    /// <summary>
    /// Timeframe hierarchy for multi-timeframe analysis
    /// </summary>
    public enum TimeframeLevel
    {
        Daily,      // Bias principal, POI majeurs
        H4,         // Confirmation bias, divergences
        H1,         // Structure intermédiaire
        M15,        // Entry zone, ChoCH
        M5,         // Entry confirmation, FVG entry
        M1          // Fine-tuning (risqué)
    }
    
    /// <summary>
    /// Session momentum direction
    /// </summary>
    public enum SessionMomentum
    {
        Unknown,
        StrongBullish,      // Big green candles
        WeakBullish,        // Slight up
        Neutral,            // Consolidation
        WeakBearish,        // Slight down
        StrongBearish       // Big red candles
    }
    
    /// <summary>
    /// Mouna entry validation errors
    /// </summary>
    [Flags]
    public enum MounaEntryError
    {
        None = 0,
        EntryJustAfterBOS = 1,          // Erreur: Entrer juste après BOS
        TradingBeforeNYOpen = 2,        // Erreur: Trader avant 9:30 AM
        CriticalNewsDay = 4,            // Erreur: Jour de news critique
        ChoCHIn1Minute = 8,             // Erreur: ChoCH en 1 minute
        StopBeyondSwing = 16,           // Erreur: Stop sous swing (liquidité)
        StopBeyondFVG = 32,             // Erreur: Stop sous FVG
        AgainstHTFBias = 64,            // Erreur: Contre le bias HTF
        AtEquilibrium = 128,            // Erreur: Entry à 50% Fib
        PartialFVGFill = 256,           // Erreur: FOMO sur partial fill
        InsufficientConfluence = 512,   // Erreur: Pas assez de confluence (<6)
        StopTooLarge = 1024,            // Erreur: Stop trop grand
        LowRiskReward = 2048,           // Erreur: R:R < 1.5
        TradingPerfectTrendline = 4096  // Erreur: Trader trendline parfaite
    }
    
    #endregion

    /// <summary>
    /// SOPHON SMC MODULE v2.0 - MOUNA BOULHAL ICT/SMC EDITION
    /// Complete implementation of Mouna's ICT/SMC methodology
    /// </summary>
    public class SophonSMC : ISophonModule, ISignalProvider
    {
        #region Properties
        
        public string ModuleName => "SophonSMC_Mouna_v2";
        public bool IsInitialized { get; private set; }
        public bool IsEnabled { get; set; }
        public SMCSettings Settings { get; set; }
        
        private Dictionary<string, InstrumentSMCData> _instrumentData;
        private List<SMCSignal> _activeSignals;
        private readonly object _signalLock = new object();
        private CalculationCache<string, MarketContext> _contextCache;
        
        // Session tracking
        private MounaTradingSession _currentSession;
        private MarketPhase _currentPhase;
        private DateTime _sessionStartTime;
        
        // Reference levels
        private double _midnightOpeningPrice;
        private double _price830Opening;
        private double _asianHigh;
        private double _asianLow;
        private bool _asianRangeSet;
        
        // Index divergence (for multi-instrument tracking)
        private Dictionary<string, double> _lastSwingLows;
        private Dictionary<string, double> _lastSwingHighs;
        
        // News filter
        private NewsImpact _todayNewsImpact;
        private bool _isCriticalNewsDay;
        
        // Mouna Entry Model tracking
        private MounaEntryStage _currentEntryStage;
        private MounaEntryError _lastEntryErrors;
        private DateTime _stageStartTime;
        
        // Session momentum tracking
        private SessionMomentum _asianMomentum;
        private SessionMomentum _londonMomentum;
        private double _londonHighPrice;
        private double _londonLowPrice;
        private bool _londonMomentumSet;
        
        // Judas Swing detection
        private bool _judasSwingDetected;
        private double _judasSwingPrice;
        private TradeDirection _judasSwingDirection;
        
        // Multi-timeframe POI tracking
        private Dictionary<TimeframeLevel, List<OrderBlock>> _htfOrderBlocks;
        private Dictionary<TimeframeLevel, List<FairValueGap>> _htfFVGs;
        private MarketStructure _dailyBias;
        private MarketStructure _h4Bias;

        // Events
        public event EventHandler<SMCSignal> OnNewSignal;
        public event EventHandler<SMCSignal> OnSignalInvalidated;
        public event EventHandler<StructureShiftEvent> OnStructureShift;
        public event EventHandler<OrderBlock> OnOrderBlockCreated;
        public event EventHandler<FairValueGap> OnFVGCreated;
        public event EventHandler<LiquidityZone> OnLiquidityTaken;
        public event EventHandler<LiquiditySweepEvent> OnLiquiditySweep;
        public event EventHandler<ChoCHEvent> OnChoCHConfirmed;
        public event EventHandler<SessionChangeEvent> OnSessionChange;
        public event EventHandler<DivergenceEvent> OnDivergenceDetected;
        
        #endregion

        #region Initialization
        
        public SophonSMC()
        {
            Settings = new SMCSettings();
            _instrumentData = new Dictionary<string, InstrumentSMCData>();
            _activeSignals = new List<SMCSignal>();
            _contextCache = new CalculationCache<string, MarketContext>(TimeSpan.FromSeconds(5));
            _lastSwingLows = new Dictionary<string, double>();
            _lastSwingHighs = new Dictionary<string, double>();
            IsEnabled = true;
        }

        public void Initialize()
        {
            if (IsInitialized) return;
            
            _instrumentData.Clear();
            _activeSignals.Clear();
            _contextCache.Clear();
            _lastSwingLows.Clear();
            _lastSwingHighs.Clear();
            
            _currentSession = MounaTradingSession.Closed;
            _currentPhase = MarketPhase.Unknown;
            _asianRangeSet = false;
            _isCriticalNewsDay = false;
            
            // Mouna Entry Model initialization
            _currentEntryStage = MounaEntryStage.Stage0_Waiting;
            _lastEntryErrors = MounaEntryError.None;
            
            // Session momentum initialization
            _asianMomentum = SessionMomentum.Unknown;
            _londonMomentum = SessionMomentum.Unknown;
            _londonMomentumSet = false;
            _judasSwingDetected = false;
            
            // Multi-timeframe tracking
            _htfOrderBlocks = new Dictionary<TimeframeLevel, List<OrderBlock>>();
            _htfFVGs = new Dictionary<TimeframeLevel, List<FairValueGap>>();
            _dailyBias = MarketStructure.Unknown;
            _h4Bias = MarketStructure.Unknown;
            
            IsInitialized = true;
        }

        public void Shutdown()
        {
            _instrumentData.Clear();
            _activeSignals.Clear();
            _contextCache.Clear();
            IsInitialized = false;
        }

        public void Reset() { Shutdown(); Initialize(); }

        public void RegisterInstrument(string instrument)
        {
            if (!_instrumentData.ContainsKey(instrument))
                _instrumentData[instrument] = new InstrumentSMCData(instrument, Settings);
        }

        public void UnregisterInstrument(string instrument) => _instrumentData.Remove(instrument);
        
        public void OnBarUpdate(int barsInProgress) { }
        
        /// <summary>
        /// Set news impact for today (call from strategy OnStateChange)
        /// </summary>
        public void SetNewsImpact(NewsImpact impact, bool isCriticalDay = false)
        {
            _todayNewsImpact = impact;
            _isCriticalNewsDay = isCriticalDay;
        }
        
        #endregion

        #region Main Update
        
        /// <summary>
        /// Main update method - call on each bar
        /// </summary>
        public void UpdateInstrument(string instrument, double open, double high, double low, double close, 
                                     double volume, DateTime time, int barIndex, double atr)
        {
            if (!IsEnabled || !IsInitialized || !_instrumentData.ContainsKey(instrument)) return;
            
            // Critical news day - no trading
            if (_isCriticalNewsDay && Settings.FilterCriticalNews) return;

            var data = _instrumentData[instrument];
            data.AddBar(open, high, low, close, volume, time, barIndex);
            data.CurrentATR = atr;
            
            // Session and reference level updates
            UpdateSession(time);
            UpdateReferenceLevels(data, time);
            UpdateAsianRange(data, time);
            
            // Core SMC analysis
            UpdatePivots(data);
            UpdateMarketStructure(data);
            UpdateOrderBlocks(data);
            UpdateFairValueGaps(data);
            UpdateLiquidityZones(data);
            UpdatePremiumDiscount(data);
            
            // Mouna-specific analysis
            UpdateChoCHValidation(data);
            UpdateInducementDetection(data);
            UpdateVolumeImbalance(data);
            UpdateJudasSwingDetection(data);
            UpdateLondonMomentum(data);
            
            // Cleanup and signal generation
            CleanExpiredZones(data, barIndex);
            _contextCache.Invalidate(instrument);
            CheckForSignals(data);
        }
        
        /// <summary>
        /// Extended update with HTF data for multi-timeframe analysis
        /// </summary>
        public void UpdateInstrumentHTF(string instrument, 
                                        double htfEMA, MarketStructure htfStructure, 
                                        PricePosition htfPosition, bool htfBullishBias)
        {
            if (!_instrumentData.ContainsKey(instrument)) return;
            
            var data = _instrumentData[instrument];
            data.HTFEMAValue = htfEMA;
            data.HTFStructure = htfStructure;
            data.HTFPosition = htfPosition;
            data.HTFBullishBias = htfBullishBias;
        }
        
        /// <summary>
        /// Update with index data for divergence detection (ES, NQ, YM)
        /// </summary>
        public void UpdateIndexData(string indexSymbol, double swingLow, double swingHigh)
        {
            _lastSwingLows[indexSymbol] = swingLow;
            _lastSwingHighs[indexSymbol] = swingHigh;
        }
        
        #endregion

        #region Session Management
        
        private void UpdateSession(DateTime time)
        {
            // Convert to Eastern Time
            TimeZoneInfo easternZone;
            try
            {
                easternZone = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
            }
            catch
            {
                easternZone = TimeZoneInfo.FindSystemTimeZoneById("America/New_York");
            }
            
            var timeET = TimeZoneInfo.ConvertTime(time, easternZone);
            
            var hour = timeET.Hour;
            var minute = timeET.Minute;
            var totalMinutes = hour * 60 + minute;
            
            MounaTradingSession newSession;
            MarketPhase newPhase;
            
            // Session determination (Eastern Time)
            // Asian: 6:00 PM - 2:00 AM (18:00 - 02:00)
            // London: 3:00 AM - 12:00 PM (03:00 - 12:00)
            // New York: 9:30 AM - 4:00 PM (09:30 - 16:00)
            
            if (totalMinutes >= 18 * 60 || totalMinutes < 2 * 60) // 6PM - 2AM
            {
                newSession = MounaTradingSession.Asian;
                newPhase = MarketPhase.Accumulation;
            }
            else if (totalMinutes >= 3 * 60 && totalMinutes < 9 * 60 + 30) // 3AM - 9:30AM
            {
                newSession = MounaTradingSession.London;
                // Early London = Manipulation, Late London = may continue
                newPhase = totalMinutes < 6 * 60 ? MarketPhase.Manipulation : MarketPhase.Distribution;
            }
            else if (totalMinutes >= 9 * 60 + 30 && totalMinutes < 16 * 60) // 9:30AM - 4PM
            {
                newSession = MounaTradingSession.NewYork;
                newPhase = MarketPhase.Distribution;
            }
            else if (totalMinutes >= 2 * 60 && totalMinutes < 3 * 60) // 2AM - 3AM
            {
                newSession = MounaTradingSession.PreMarket;
                newPhase = MarketPhase.Unknown;
            }
            else
            {
                newSession = MounaTradingSession.Closed;
                newPhase = MarketPhase.Unknown;
            }
            
            // Fire event on session change
            if (newSession != _currentSession)
            {
                var oldSession = _currentSession;
                _currentSession = newSession;
                _currentPhase = newPhase;
                _sessionStartTime = time;
                
                OnSessionChange?.Invoke(this, new SessionChangeEvent
                {
                    PreviousSession = oldSession,
                    NewSession = newSession,
                    Phase = newPhase,
                    Time = time
                });
                
                // Reset Asian range on new Asian session
                if (newSession == MounaTradingSession.Asian)
                {
                    _asianRangeSet = false;
                    _asianHigh = double.MinValue;
                    _asianLow = double.MaxValue;
                }
            }
            
            _currentPhase = newPhase;
        }
        
        private void UpdateReferenceLevels(InstrumentSMCData data, DateTime time)
        {
            TimeZoneInfo easternZone;
            try
            {
                easternZone = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
            }
            catch
            {
                easternZone = TimeZoneInfo.FindSystemTimeZoneById("America/New_York");
            }
            
            var timeET = TimeZoneInfo.ConvertTime(time, easternZone);
            var currentBar = data.CurrentBar;
            
            // Midnight Opening Price (12:00 AM ET)
            if (timeET.Hour == 0 && timeET.Minute == 0)
            {
                _midnightOpeningPrice = currentBar.Open;
                data.MidnightOpeningPrice = _midnightOpeningPrice;
            }
            
            // 8:30 AM Opening Price
            if (timeET.Hour == 8 && timeET.Minute == 30)
            {
                _price830Opening = currentBar.Open;
                data.Price830Opening = _price830Opening;
            }
        }
        
        private void UpdateAsianRange(InstrumentSMCData data, DateTime time)
        {
            if (_currentSession != MounaTradingSession.Asian) return;
            
            var currentBar = data.CurrentBar;
            
            if (currentBar.High > _asianHigh || _asianHigh == double.MinValue)
            {
                _asianHigh = currentBar.High;
                data.AsianHigh = _asianHigh;
            }
            
            if (currentBar.Low < _asianLow || _asianLow == double.MaxValue)
            {
                _asianLow = currentBar.Low;
                data.AsianLow = _asianLow;
            }
            
            _asianRangeSet = true;
        }
        
        /// <summary>
        /// Check if near NY open (avoid trading 9:25-9:35 - Judas Swing)
        /// </summary>
        public bool IsNearNYOpen(DateTime time)
        {
            TimeZoneInfo easternZone;
            try
            {
                easternZone = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
            }
            catch
            {
                easternZone = TimeZoneInfo.FindSystemTimeZoneById("America/New_York");
            }
            
            var timeET = TimeZoneInfo.ConvertTime(time, easternZone);
            return timeET.Hour == 9 && timeET.Minute >= 25 && timeET.Minute <= 35;
        }
        
        /// <summary>
        /// Check if in optimal NY trading window (9:30-11:30)
        /// </summary>
        public bool IsOptimalNYWindow(DateTime time)
        {
            TimeZoneInfo easternZone;
            try
            {
                easternZone = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
            }
            catch
            {
                easternZone = TimeZoneInfo.FindSystemTimeZoneById("America/New_York");
            }
            
            var timeET = TimeZoneInfo.ConvertTime(time, easternZone);
            var totalMinutes = timeET.Hour * 60 + timeET.Minute;
            return totalMinutes >= 9 * 60 + 30 && totalMinutes <= 11 * 60 + 30;
        }
        
        /// <summary>
        /// Check if in lunch time (12:00-14:00 - avoid)
        /// </summary>
        public bool IsLunchTime(DateTime time)
        {
            TimeZoneInfo easternZone;
            try
            {
                easternZone = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
            }
            catch
            {
                easternZone = TimeZoneInfo.FindSystemTimeZoneById("America/New_York");
            }
            
            var timeET = TimeZoneInfo.ConvertTime(time, easternZone);
            return timeET.Hour >= 12 && timeET.Hour < 14;
        }
        
        #endregion

        #region Pivot Detection
        
        private void UpdatePivots(InstrumentSMCData data)
        {
            int lookback = Settings.PivotLookback;
            if (data.Bars.Count < lookback * 2 + 1) return;

            int currentBar = data.Bars.Count - 1 - lookback;
            if (currentBar < 0) return;

            var bar = data.Bars[currentBar];
            bool isSwingHigh = true, isSwingLow = true;

            // Mouna rule: Swing point is ALWAYS middle candle of 3 consecutive candles
            for (int i = 1; i <= lookback; i++)
            {
                if (currentBar - i >= 0 && data.Bars[currentBar - i].High >= bar.High) isSwingHigh = false;
                if (currentBar + i < data.Bars.Count && data.Bars[currentBar + i].High >= bar.High) isSwingHigh = false;
                if (currentBar - i >= 0 && data.Bars[currentBar - i].Low <= bar.Low) isSwingLow = false;
                if (currentBar + i < data.Bars.Count && data.Bars[currentBar + i].Low <= bar.Low) isSwingLow = false;
            }

            if (isSwingHigh)
            {
                var lastPivotHigh = data.PivotHighs.LastOrDefault();
                PivotType type = lastPivotHigh.Price > 0 
                    ? (bar.High > lastPivotHigh.Price ? PivotType.HH 
                       : Math.Abs(bar.High - lastPivotHigh.Price) <= data.CurrentATR * Settings.EqualLevelTolerance ? PivotType.EQH 
                       : PivotType.LH)
                    : PivotType.HH;

                var pivot = new PivotPoint(bar.High, bar.Time, bar.Index, type, true, lookback);
                data.PivotHighs.Add(pivot);
                data.AllPivots.Add(pivot);
                
                // Update index tracking for divergence
                _lastSwingHighs[data.Instrument] = bar.High;
                
                while (data.PivotHighs.Count > SophonConstants.MAX_PIVOTS) data.PivotHighs.RemoveAt(0);
            }

            if (isSwingLow)
            {
                var lastPivotLow = data.PivotLows.LastOrDefault();
                PivotType type = lastPivotLow.Price > 0 
                    ? (bar.Low < lastPivotLow.Price ? PivotType.LL 
                       : Math.Abs(bar.Low - lastPivotLow.Price) <= data.CurrentATR * Settings.EqualLevelTolerance ? PivotType.EQL 
                       : PivotType.HL)
                    : PivotType.LL;

                var pivot = new PivotPoint(bar.Low, bar.Time, bar.Index, type, true, lookback);
                data.PivotLows.Add(pivot);
                data.AllPivots.Add(pivot);
                
                // Update index tracking for divergence
                _lastSwingLows[data.Instrument] = bar.Low;
                
                while (data.PivotLows.Count > SophonConstants.MAX_PIVOTS) data.PivotLows.RemoveAt(0);
            }

            while (data.AllPivots.Count > SophonConstants.MAX_PIVOTS * 2) data.AllPivots.RemoveAt(0);
        }
        
        #endregion

        #region Market Structure (BOS & ChoCH)
        
        private void UpdateMarketStructure(InstrumentSMCData data)
        {
            if (data.PivotHighs.Count < 2 || data.PivotLows.Count < 2) return;

            var currentBar = data.CurrentBar;
            var lastHigh = data.PivotHighs.Last();
            var lastLow = data.PivotLows.Last();
            var prevHigh = data.PivotHighs.Count >= 2 ? data.PivotHighs[data.PivotHighs.Count - 2] : default;
            var prevLow = data.PivotLows.Count >= 2 ? data.PivotLows[data.PivotLows.Count - 2] : default;

            MarketStructure previousStructure = data.CurrentStructure;
            MarketStructureShift shift = MarketStructureShift.None;

            bool hasHH = lastHigh.Type == PivotType.HH;
            bool hasHL = lastLow.Type == PivotType.HL;
            bool hasLH = lastHigh.Type == PivotType.LH;
            bool hasLL = lastLow.Type == PivotType.LL;

            if (hasHH && hasHL) data.CurrentStructure = MarketStructure.Bullish;
            else if (hasLH && hasLL) data.CurrentStructure = MarketStructure.Bearish;
            else data.CurrentStructure = MarketStructure.Ranging;

            double currentClose = currentBar.Close;

            // BOS Detection (Mouna: Close beyond level, not just wick)
            if (previousStructure == MarketStructure.Bullish && prevHigh.Price > 0 && currentClose > prevHigh.Price)
            {
                shift = MarketStructureShift.BOS;
                data.LastBOS = new StructureShiftEvent
                {
                    Type = shift, Price = prevHigh.Price, Time = currentBar.Time,
                    BarIndex = currentBar.Index, Direction = TradeDirection.Long,
                    PreviousStructure = previousStructure
                };
            }
            
            if (previousStructure == MarketStructure.Bearish && prevLow.Price > 0 && currentClose < prevLow.Price)
            {
                shift = MarketStructureShift.BOS;
                data.LastBOS = new StructureShiftEvent
                {
                    Type = shift, Price = prevLow.Price, Time = currentBar.Time,
                    BarIndex = currentBar.Index, Direction = TradeDirection.Short,
                    PreviousStructure = previousStructure
                };
            }

            // ChoCH Detection (Mouna: Requires liquidity taken + BOS)
            if (previousStructure == MarketStructure.Bearish && prevHigh.Price > 0 && currentClose > prevHigh.Price)
            {
                shift = MarketStructureShift.ChoCH;
                data.CurrentStructure = MarketStructure.Bullish;
                data.LastChoCH = new StructureShiftEvent
                {
                    Type = shift, Price = prevHigh.Price, Time = currentBar.Time,
                    BarIndex = currentBar.Index, Direction = TradeDirection.Long,
                    PreviousStructure = previousStructure
                };
                data.PendingChoCHValidation = true;
            }
            
            if (previousStructure == MarketStructure.Bullish && prevLow.Price > 0 && currentClose < prevLow.Price)
            {
                shift = MarketStructureShift.ChoCH;
                data.CurrentStructure = MarketStructure.Bearish;
                data.LastChoCH = new StructureShiftEvent
                {
                    Type = shift, Price = prevLow.Price, Time = currentBar.Time,
                    BarIndex = currentBar.Index, Direction = TradeDirection.Short,
                    PreviousStructure = previousStructure
                };
                data.PendingChoCHValidation = true;
            }

            if (shift != MarketStructureShift.None)
            {
                var shiftEvent = data.LastChoCH ?? new StructureShiftEvent
                {
                    Type = shift,
                    Price = shift == MarketStructureShift.BOS_Bullish ? prevHigh.Price : prevLow.Price,
                    Time = currentBar.Time,
                    BarIndex = currentBar.Index,
                    Direction = shift == MarketStructureShift.BOS_Bullish ? TradeDirection.Long : TradeDirection.Short,
                    PreviousStructure = previousStructure
                };
                OnStructureShift?.Invoke(this, shiftEvent);
            }
        }
        
        /// <summary>
        /// Validate ChoCH according to Mouna's rules:
        /// 1. Liquidity must be taken (SSL for bullish, BSL for bearish)
        /// 2. BOS must be confirmed
        /// 3. Minimum 5M timeframe
        /// </summary>
        private void UpdateChoCHValidation(InstrumentSMCData data)
        {
            if (!data.PendingChoCHValidation || data.LastChoCH == null) return;
            
            bool liquidityTaken = false;
            
            if (data.LastChoCH.Direction == TradeDirection.Long)
            {
                // For bullish ChoCH, SSL must have been taken before
                liquidityTaken = data.LastLiquiditySweep != null && 
                                 data.LastLiquiditySweep.Zone.IsSellSide &&
                                 data.LastLiquiditySweep.BarIndex < data.LastChoCH.BarIndex;
            }
            else
            {
                // For bearish ChoCH, BSL must have been taken before
                liquidityTaken = data.LastLiquiditySweep != null && 
                                 data.LastLiquiditySweep.Zone.IsBuySide &&
                                 data.LastLiquiditySweep.BarIndex < data.LastChoCH.BarIndex;
            }
            
            // Check for FVG presence (indicates momentum)
            bool hasFVG = data.FairValueGaps.Any(f => 
                f.IsActive && 
                f.CreatedBar >= data.LastChoCH.BarIndex - 3 &&
                ((data.LastChoCH.Direction == TradeDirection.Long && f.IsBullish) ||
                 (data.LastChoCH.Direction == TradeDirection.Short && f.IsBearish)));
            
            data.ChoCHValidated = liquidityTaken;
            data.ChoCHHasFVG = hasFVG;
            
            if (data.ChoCHValidated)
            {
                OnChoCHConfirmed?.Invoke(this, new ChoCHEvent
                {
                    Direction = data.LastChoCH.Direction,
                    Price = data.LastChoCH.Price,
                    Time = data.LastChoCH.Time,
                    LiquidityTaken = liquidityTaken,
                    HasFVG = hasFVG,
                    IsValid = true
                });
            }
            
            data.PendingChoCHValidation = false;
        }
        
        #endregion

        #region Order Blocks
        
        private void UpdateOrderBlocks(InstrumentSMCData data)
        {
            if (data.Bars.Count < Settings.OBLookback + 3) return;

            int currentIdx = data.Bars.Count - 1;
            var currentBar = data.Bars[currentIdx];
            
            double impulsiveMove = CalculateImpulsiveMove(data, currentIdx, Settings.OBLookback);
            double impulsiveThreshold = data.CurrentATR * Settings.OBImpulseMultiplier;

            if (Math.Abs(impulsiveMove) < impulsiveThreshold) return;

            bool isBullishImpulse = impulsiveMove > 0;
            
            // Mouna: OB is the last opposite candle BEFORE the impulsive move
            for (int i = currentIdx - 1; i >= Math.Max(0, currentIdx - Settings.OBLookback); i--)
            {
                var bar = data.Bars[i];
                bool isBearishCandle = bar.Close < bar.Open;
                bool isBullishCandle = bar.Close > bar.Open;

                // Bullish OB: Last RED candle before up move
                if (isBullishImpulse && isBearishCandle)
                {
                    if (!data.OrderBlocks.Any(ob => ob.CreatedBar == bar.Index && ob.Type == OrderBlockType.Bullish))
                    {
                        var ob = new OrderBlock
                        {
                            HighPrice = bar.High, LowPrice = bar.Low, OpenPrice = bar.Open, ClosePrice = bar.Close,
                            CreatedAt = bar.Time, CreatedBar = bar.Index, Type = OrderBlockType.Bullish,
                            Volume = bar.Volume, ImpulseStrength = Math.Abs(impulsiveMove) / data.CurrentATR,
                            Instrument = data.Instrument, ExpirationBars = Settings.OBExpirationBars
                        };
                        
                        // Calculate Fibonacci level for the OB
                        if (data.CurrentSwingRange.IsValid)
                        {
                            ob.FibLevel = data.CurrentSwingRange.GetFibLevel(ob.MidPrice);
                            ob.IsInDiscount = ob.FibLevel >= 0.5;
                            ob.IsAtOTE = ob.FibLevel >= 0.618 && ob.FibLevel <= 0.786;
                        }
                        
                        // Check if OB has BOS confirmation
                        ob.HasBOSConfirmation = data.LastBOS != null && 
                                                data.LastBOS.BarIndex > ob.CreatedBar &&
                                                data.LastBOS.Direction == TradeDirection.Long;
                        
                        data.OrderBlocks.Add(ob);
                        OnOrderBlockCreated?.Invoke(this, ob);
                        while (data.OrderBlocks.Count > SophonConstants.MAX_ORDER_BLOCKS) data.OrderBlocks.RemoveAt(0);
                    }
                    break;
                }

                // Bearish OB: Last GREEN candle before down move
                if (!isBullishImpulse && isBullishCandle)
                {
                    if (!data.OrderBlocks.Any(ob => ob.CreatedBar == bar.Index && ob.Type == OrderBlockType.Bearish))
                    {
                        var ob = new OrderBlock
                        {
                            HighPrice = bar.High, LowPrice = bar.Low, OpenPrice = bar.Open, ClosePrice = bar.Close,
                            CreatedAt = bar.Time, CreatedBar = bar.Index, Type = OrderBlockType.Bearish,
                            Volume = bar.Volume, ImpulseStrength = Math.Abs(impulsiveMove) / data.CurrentATR,
                            Instrument = data.Instrument, ExpirationBars = Settings.OBExpirationBars
                        };
                        
                        // Calculate Fibonacci level for the OB
                        if (data.CurrentSwingRange.IsValid)
                        {
                            ob.FibLevel = data.CurrentSwingRange.GetFibLevel(ob.MidPrice);
                            ob.IsInPremium = ob.FibLevel <= 0.5;
                            ob.IsAtOTE = ob.FibLevel >= 0.214 && ob.FibLevel <= 0.382; // Premium OTE
                        }
                        
                        // Check if OB has BOS confirmation
                        ob.HasBOSConfirmation = data.LastBOS != null && 
                                                data.LastBOS.BarIndex > ob.CreatedBar &&
                                                data.LastBOS.Direction == TradeDirection.Short;
                        
                        data.OrderBlocks.Add(ob);
                        OnOrderBlockCreated?.Invoke(this, ob);
                        while (data.OrderBlocks.Count > SophonConstants.MAX_ORDER_BLOCKS) data.OrderBlocks.RemoveAt(0);
                    }
                    break;
                }
            }

            UpdateOrderBlockStates(data, currentBar);
        }

        private void UpdateOrderBlockStates(InstrumentSMCData data, BarData currentBar)
        {
            foreach (var ob in data.OrderBlocks.Where(o => o.IsActive))
            {
                if (ob.Contains(currentBar.Low) || ob.Contains(currentBar.High)) 
                    ob.RecordTouch();
                
                // Mouna: OB broken = becomes Breaker
                if (ob.IsBullish && currentBar.Close < ob.LowPrice - data.CurrentATR * 0.1) 
                    ob.State = ZoneState.Broken;
                if (ob.IsBearish && currentBar.Close > ob.HighPrice + data.CurrentATR * 0.1) 
                    ob.State = ZoneState.Broken;
                
                if (ob.State == ZoneState.Broken)
                    ob.Type = ob.IsBullish ? OrderBlockType.BearishBreaker : OrderBlockType.BullishBreaker;
            }
        }

        private double CalculateImpulsiveMove(InstrumentSMCData data, int endIndex, int lookback)
        {
            int startIndex = Math.Max(0, endIndex - lookback);
            if (startIndex >= endIndex) return 0;
            return data.Bars[endIndex].Close - data.Bars[startIndex].Close;
        }
        
        #endregion

        #region Fair Value Gaps
        
        private void UpdateFairValueGaps(InstrumentSMCData data)
        {
            if (data.Bars.Count < 3) return;

            int idx = data.Bars.Count - 2;
            var bar1 = data.Bars[idx - 1];
            var bar2 = data.Bars[idx];
            var bar3 = data.Bars[idx + 1];

            // Bullish FVG: Gap between C1 high and C3 low
            if (bar3.Low > bar1.High)
            {
                double gapSize = bar3.Low - bar1.High;
                if (gapSize >= data.CurrentATR * Settings.FVGMinATRRatio)
                {
                    if (!data.FairValueGaps.Any(f => f.CreatedBar == bar2.Index && f.Type == FVGType.Bullish))
                    {
                        var fvg = new FairValueGap
                        {
                            HighPrice = bar3.Low, LowPrice = bar1.High, CreatedAt = bar2.Time,
                            CreatedBar = bar2.Index, Type = FVGType.Bullish, Instrument = data.Instrument,
                            ExpirationBars = Settings.FVGExpirationBars,
                            GapSize = gapSize,
                            GapSizeATR = gapSize / data.CurrentATR
                        };
                        data.FairValueGaps.Add(fvg);
                        OnFVGCreated?.Invoke(this, fvg);
                        while (data.FairValueGaps.Count > SophonConstants.MAX_FVGS) data.FairValueGaps.RemoveAt(0);
                    }
                }
            }

            // Bearish FVG: Gap between C1 low and C3 high
            if (bar3.High < bar1.Low)
            {
                double gapSize = bar1.Low - bar3.High;
                if (gapSize >= data.CurrentATR * Settings.FVGMinATRRatio)
                {
                    if (!data.FairValueGaps.Any(f => f.CreatedBar == bar2.Index && f.Type == FVGType.Bearish))
                    {
                        var fvg = new FairValueGap
                        {
                            HighPrice = bar1.Low, LowPrice = bar3.High, CreatedAt = bar2.Time,
                            CreatedBar = bar2.Index, Type = FVGType.Bearish, Instrument = data.Instrument,
                            ExpirationBars = Settings.FVGExpirationBars,
                            GapSize = gapSize,
                            GapSizeATR = gapSize / data.CurrentATR
                        };
                        data.FairValueGaps.Add(fvg);
                        OnFVGCreated?.Invoke(this, fvg);
                        while (data.FairValueGaps.Count > SophonConstants.MAX_FVGS) data.FairValueGaps.RemoveAt(0);
                    }
                }
            }

            UpdateFVGStates(data, data.CurrentBar);
        }

        private void UpdateFVGStates(InstrumentSMCData data, BarData currentBar)
        {
            foreach (var fvg in data.FairValueGaps.Where(f => f.IsActive))
            {
                // Track fill percentage (Mouna: wait for COMPLETE fill, not partial)
                if (fvg.IsBullish && currentBar.Low <= fvg.HighPrice && currentBar.Low >= fvg.LowPrice)
                {
                    fvg.UpdateFill(currentBar.Low);
                }
                else if (fvg.IsBearish && currentBar.High >= fvg.LowPrice && currentBar.High <= fvg.HighPrice)
                {
                    fvg.UpdateFill(currentBar.High);
                }
            }
        }
        
        #endregion

        #region Liquidity Zones
        
        private void UpdateLiquidityZones(InstrumentSMCData data)
        {
            if (data.CurrentBar.Index == 0) return;
            
            DetectEqualLevels(data, true);  // Equal Highs (BSL)
            DetectEqualLevels(data, false); // Equal Lows (SSL)
            UpdateDailyLevels(data);
            UpdateWeeklyLevels(data);
            CheckLiquidityTaken(data, data.CurrentBar);
        }

        private void DetectEqualLevels(InstrumentSMCData data, bool isHigh)
        {
            var pivots = isHigh ? data.PivotHighs : data.PivotLows;
            if (pivots.Count < 2) return;

            double tolerance = data.CurrentATR * Settings.EqualLevelTolerance;
            var recentPivots = pivots.TakeLast(5).ToList();
            
            for (int i = 0; i < recentPivots.Count - 1; i++)
            {
                for (int j = i + 1; j < recentPivots.Count; j++)
                {
                    if (Math.Abs(recentPivots[i].Price - recentPivots[j].Price) <= tolerance)
                    {
                        double avgPrice = (recentPivots[i].Price + recentPivots[j].Price) / 2;
                        var liqType = isHigh ? LiquidityType.EqualHighs : LiquidityType.EqualLows;
                        
                        if (!data.LiquidityZones.Any(l => Math.Abs(l.Price - avgPrice) <= tolerance && l.Type == liqType))
                        {
                            data.LiquidityZones.Add(new LiquidityZone
                            {
                                Price = avgPrice, CreatedAt = recentPivots[j].Timestamp,
                                CreatedBar = recentPivots[j].BarIndex, Type = liqType,
                                TouchCount = 2, EstimatedVolume = 1.0, Instrument = data.Instrument
                            });
                            while (data.LiquidityZones.Count > SophonConstants.MAX_LIQUIDITY_ZONES) 
                                data.LiquidityZones.RemoveAt(0);
                        }
                    }
                }
            }
        }

        private void UpdateDailyLevels(InstrumentSMCData data)
        {
            if (data.Bars.Count < 2) return;
            var currentBar = data.CurrentBar;
            var prevBar = data.Bars[data.Bars.Count - 2];
            
            // New day detection
            if (currentBar.Time.Date != prevBar.Time.Date)
            {
                var previousDayBars = data.Bars.Where(b => b.Time.Date == prevBar.Time.Date).ToList();
                if (previousDayBars.Count > 0)
                {
                    data.PreviousDayHigh = previousDayBars.Max(b => b.High);
                    data.PreviousDayLow = previousDayBars.Min(b => b.Low);
                    
                    // PDH - Buy-side liquidity
                    data.LiquidityZones.Add(new LiquidityZone
                    {
                        Price = data.PreviousDayHigh, CreatedAt = currentBar.Time,
                        CreatedBar = currentBar.Index, Type = LiquidityType.PDH, Instrument = data.Instrument
                    });
                    
                    // PDL - Sell-side liquidity
                    data.LiquidityZones.Add(new LiquidityZone
                    {
                        Price = data.PreviousDayLow, CreatedAt = currentBar.Time,
                        CreatedBar = currentBar.Index, Type = LiquidityType.PDL, Instrument = data.Instrument
                    });
                }
            }
        }
        
        private void UpdateWeeklyLevels(InstrumentSMCData data)
        {
            if (data.Bars.Count < 2) return;
            var currentBar = data.CurrentBar;
            var prevBar = data.Bars[data.Bars.Count - 2];
            
            // New week detection (Monday)
            var currentDayOfWeek = currentBar.Time.DayOfWeek;
            var prevDayOfWeek = prevBar.Time.DayOfWeek;
            
            if (currentDayOfWeek == DayOfWeek.Monday && prevDayOfWeek != DayOfWeek.Monday)
            {
                // Calculate previous week's high/low
                var oneWeekAgo = currentBar.Time.AddDays(-7);
                var previousWeekBars = data.Bars.Where(b => b.Time >= oneWeekAgo && b.Time < currentBar.Time.Date).ToList();
                
                if (previousWeekBars.Count > 0)
                {
                    data.PreviousWeekHigh = previousWeekBars.Max(b => b.High);
                    data.PreviousWeekLow = previousWeekBars.Min(b => b.Low);
                    
                    // PWH - Buy-side liquidity
                    data.LiquidityZones.Add(new LiquidityZone
                    {
                        Price = data.PreviousWeekHigh, CreatedAt = currentBar.Time,
                        CreatedBar = currentBar.Index, Type = LiquidityType.PWH, Instrument = data.Instrument
                    });
                    
                    // PWL - Sell-side liquidity
                    data.LiquidityZones.Add(new LiquidityZone
                    {
                        Price = data.PreviousWeekLow, CreatedAt = currentBar.Time,
                        CreatedBar = currentBar.Index, Type = LiquidityType.PWL, Instrument = data.Instrument
                    });
                }
            }
        }

        private void CheckLiquidityTaken(InstrumentSMCData data, BarData currentBar)
        {
            foreach (var liq in data.LiquidityZones.Where(l => l.IsActive))
            {
                bool taken = liq.IsBuySide ? currentBar.High > liq.Price : currentBar.Low < liq.Price;
                if (taken)
                {
                    liq.MarkAsTaken(currentBar.Time);
                    data.LastLiquiditySweep = new LiquiditySweepEvent
                    {
                        Zone = liq, Time = currentBar.Time, BarIndex = currentBar.Index,
                        SweepPrice = liq.IsBuySide ? currentBar.High : currentBar.Low
                    };
                    OnLiquidityTaken?.Invoke(this, liq);
                }
            }
        }
        
        #endregion

        #region Premium/Discount (Fibonacci)
        
        private void UpdatePremiumDiscount(InstrumentSMCData data)
        {
            if (data.AllPivots.Count >= 4)
            {
                var recentPivots = data.AllPivots.TakeLast(10).ToList();
                double rangeHigh = recentPivots.Max(p => p.Price);
                double rangeLow = recentPivots.Min(p => p.Price);
                
                data.CurrentSwingRange = new PriceRange(rangeHigh, rangeLow,
                    recentPivots.First().Timestamp, recentPivots.Last().Timestamp,
                    recentPivots.First().BarIndex, recentPivots.Last().BarIndex);
                
                data.CurrentPricePosition = data.CurrentSwingRange.GetPosition(data.CurrentBar.Close);
                data.CurrentFibLevel = data.CurrentSwingRange.GetFibLevel(data.CurrentBar.Close);
                
                // Determine OTE level
                data.CurrentOTELevel = OTELevel.None;
                if (data.CurrentFibLevel >= 0.60 && data.CurrentFibLevel < 0.68)
                    data.CurrentOTELevel = OTELevel.Level618;
                else if (data.CurrentFibLevel >= 0.68 && data.CurrentFibLevel < 0.75)
                    data.CurrentOTELevel = OTELevel.Level706;
                else if (data.CurrentFibLevel >= 0.75)
                    data.CurrentOTELevel = OTELevel.Level786;
            }
        }
        
        /// <summary>
        /// Check if price is at optimal entry level (OTE: 70.6% or better)
        /// </summary>
        public bool IsAtOTELevel(InstrumentSMCData data)
        {
            return data.CurrentOTELevel != OTELevel.None;
        }
        
        /// <summary>
        /// Check if price is at equilibrium (50% - avoid trading)
        /// </summary>
        public bool IsAtEquilibrium(InstrumentSMCData data)
        {
            return data.CurrentFibLevel >= 0.48 && data.CurrentFibLevel <= 0.52;
        }
        
        #endregion

        #region Inducement Detection
        
        private void UpdateInducementDetection(InstrumentSMCData data)
        {
            var currentBar = data.CurrentBar;
            
            // Pattern 1: Fake Support/Resistance (Equal Highs/Lows with many touches)
            foreach (var liq in data.LiquidityZones.Where(l => l.IsActive && l.TouchCount >= 3))
            {
                if (!data.InducementPatterns.Any(p => Math.Abs(p.Price - liq.Price) < data.CurrentATR * 0.2))
                {
                    data.InducementPatterns.Add(new InducementPattern
                    {
                        Type = InducementType.FakeSupportResistance,
                        Price = liq.Price,
                        DetectedBar = currentBar.Index,
                        Confidence = Math.Min(1.0, liq.TouchCount * 0.2)
                    });
                }
            }
            
            // Pattern 2: Partial FVG Fill (FOMO trap)
            foreach (var fvg in data.FairValueGaps.Where(f => f.IsActive && f.FillPercentage > 30 && f.FillPercentage < 90))
            {
                double patternPrice = fvg.IsBullish ? fvg.LowPrice : fvg.HighPrice;
                if (!data.InducementPatterns.Any(p => Math.Abs(p.Price - patternPrice) < data.CurrentATR * 0.2))
                {
                    data.InducementPatterns.Add(new InducementPattern
                    {
                        Type = InducementType.PartialFVGFill,
                        Price = patternPrice,
                        DetectedBar = currentBar.Index,
                        Confidence = 0.6
                    });
                }
            }
            
            // Pattern 3: POI at Equilibrium (50% Fib trap)
            if (IsAtEquilibrium(data))
            {
                var poiAtEquilibrium = data.OrderBlocks.Any(ob => 
                    ob.IsActive && data.CurrentSwingRange.IsValid &&
                    Math.Abs(data.CurrentSwingRange.GetFibLevel(ob.MidPrice) - 0.5) < 0.05);
                
                if (poiAtEquilibrium)
                {
                    if (!data.InducementPatterns.Any(p => p.Type == InducementType.EquilibriumTrap && 
                                                          currentBar.Index - p.DetectedBar < 10))
                    {
                        data.InducementPatterns.Add(new InducementPattern
                        {
                            Type = InducementType.EquilibriumTrap,
                            Price = currentBar.Close,
                            DetectedBar = currentBar.Index,
                            Confidence = 0.7
                        });
                    }
                }
            }
            
            // Cleanup old patterns
            data.InducementPatterns.RemoveAll(p => currentBar.Index - p.DetectedBar > 50);
        }
        
        #endregion

        #region Volume Imbalance (Gaps)
        
        private void UpdateVolumeImbalance(InstrumentSMCData data)
        {
            if (data.Bars.Count < 2) return;
            
            var currentBar = data.CurrentBar;
            var prevBar = data.Bars[data.Bars.Count - 2];
            
            // Gap detection: Open different from previous close
            double gap = currentBar.Open - prevBar.Close;
            double gapThreshold = data.CurrentATR * Settings.VolumeImbalanceMinATR;
            
            if (Math.Abs(gap) >= gapThreshold)
            {
                var vi = new VolumeImbalance
                {
                    GapHigh = Math.Max(currentBar.Open, prevBar.Close),
                    GapLow = Math.Min(currentBar.Open, prevBar.Close),
                    GapSize = Math.Abs(gap),
                    IsBullish = gap > 0,
                    CreatedBar = currentBar.Index,
                    CreatedAt = currentBar.Time,
                    IsSundayGap = currentBar.Time.DayOfWeek == DayOfWeek.Monday && 
                                  prevBar.Time.DayOfWeek == DayOfWeek.Friday
                };
                
                data.VolumeImbalances.Add(vi);
                while (data.VolumeImbalances.Count > 20) data.VolumeImbalances.RemoveAt(0);
            }
            
            // Update gap fill status
            foreach (var vi in data.VolumeImbalances.Where(v => !v.IsFilled))
            {
                if (vi.IsBullish && currentBar.Low <= vi.GapLow)
                    vi.IsFilled = true;
                else if (!vi.IsBullish && currentBar.High >= vi.GapHigh)
                    vi.IsFilled = true;
            }
        }
        
        #endregion

        #region Judas Swing Detection
        
        /// <summary>
        /// Detect Judas Swing at session opens (London 3AM, NY 9:30AM)
        /// Mouna: "Le Judas Swing est une manipulation à l'ouverture des sessions"
        /// </summary>
        private void UpdateJudasSwingDetection(InstrumentSMCData data)
        {
            var currentBar = data.CurrentBar;
            
            // Reset Judas detection on new session
            if (_currentSession != _previousSessionForJudas)
            {
                _judasSwingDetected = false;
                _previousSessionForJudas = _currentSession;
            }
            
            // Judas Swing at London Open (3:00 AM ET)
            if (_currentSession == MounaTradingSession.London && !_judasSwingDetected)
            {
                // Check if price broke Asian high/low and reversed
                if (_asianRangeSet)
                {
                    // Bullish Judas: Break Asian low then reverse up
                    if (currentBar.Low < _asianLow && currentBar.Close > _asianLow)
                    {
                        _judasSwingDetected = true;
                        _judasSwingPrice = _asianLow;
                        _judasSwingDirection = TradeDirection.Long;
                        data.JudasSwingDetected = true;
                        data.JudasDirection = TradeDirection.Long;
                    }
                    // Bearish Judas: Break Asian high then reverse down
                    else if (currentBar.High > _asianHigh && currentBar.Close < _asianHigh)
                    {
                        _judasSwingDetected = true;
                        _judasSwingPrice = _asianHigh;
                        _judasSwingDirection = TradeDirection.Short;
                        data.JudasSwingDetected = true;
                        data.JudasDirection = TradeDirection.Short;
                    }
                }
            }
            
            // Judas Swing at NY Open (9:30 AM ET)
            if (_currentSession == MounaTradingSession.NewYork && IsNearNYOpen(currentBar.Time))
            {
                // Big candle in opposite direction = potential Judas
                if (currentBar.Range > data.CurrentATR * 1.5)
                {
                    if (currentBar.IsBearish && _londonMomentum == SessionMomentum.StrongBullish)
                    {
                        _judasSwingDetected = true;
                        _judasSwingDirection = TradeDirection.Short;
                    }
                    else if (currentBar.IsBullish && _londonMomentum == SessionMomentum.StrongBearish)
                    {
                        _judasSwingDetected = true;
                        _judasSwingDirection = TradeDirection.Long;
                    }
                }
            }
        }
        
        private MounaTradingSession _previousSessionForJudas;
        
        #endregion

        #region London Session Momentum Tracking
        
        /// <summary>
        /// Track London session momentum for NY session analysis
        /// Mouna: "Si London était très bullish et on est à premium en NY → expect bearish reversal"
        /// </summary>
        private void UpdateLondonMomentum(InstrumentSMCData data)
        {
            var currentBar = data.CurrentBar;
            
            if (_currentSession == MounaTradingSession.London)
            {
                // Track London high/low
                if (currentBar.High > _londonHighPrice || _londonHighPrice == 0)
                    _londonHighPrice = currentBar.High;
                if (currentBar.Low < _londonLowPrice || _londonLowPrice == double.MaxValue)
                    _londonLowPrice = currentBar.Low;
                
                _londonMomentumSet = true;
            }
            
            // Calculate London momentum at end of London session
            if (_currentSession == MounaTradingSession.NewYork && _londonMomentumSet && !_londonMomentumCalculated)
            {
                double londonRange = _londonHighPrice - _londonLowPrice;
                double londonMove = data.CurrentBar.Close - _londonLowPrice;
                double londonMovePercent = londonRange > 0 ? londonMove / londonRange : 0.5;
                
                if (londonMovePercent >= 0.8)
                    _londonMomentum = SessionMomentum.StrongBullish;
                else if (londonMovePercent >= 0.6)
                    _londonMomentum = SessionMomentum.WeakBullish;
                else if (londonMovePercent <= 0.2)
                    _londonMomentum = SessionMomentum.StrongBearish;
                else if (londonMovePercent <= 0.4)
                    _londonMomentum = SessionMomentum.WeakBearish;
                else
                    _londonMomentum = SessionMomentum.Neutral;
                
                data.LondonMomentum = _londonMomentum;
                _londonMomentumCalculated = true;
            }
            
            // Reset on new day
            if (_currentSession == MounaTradingSession.Asian)
            {
                _londonHighPrice = 0;
                _londonLowPrice = double.MaxValue;
                _londonMomentumSet = false;
                _londonMomentumCalculated = false;
            }
        }
        
        private bool _londonMomentumCalculated;
        
        #endregion

        #region Mouna Entry Model (8-Step Validation)
        
        /// <summary>
        /// Validate entry according to Mouna's 8-step entry model
        /// </summary>
        public MounaEntryValidation ValidateMounaEntry(InstrumentSMCData data, TradeDirection direction)
        {
            var validation = new MounaEntryValidation();
            var currentBar = data.CurrentBar;
            
            // ═══════════════════════════════════════════════════════════════════
            // STEP 1: POI HTF atteint
            // ═══════════════════════════════════════════════════════════════════
            var htfOB = data.OrderBlocks.FirstOrDefault(ob => 
                ob.IsActive && ob.HasBOSConfirmation &&
                ((direction == TradeDirection.Long && ob.IsBullish && ob.IsInDiscount) ||
                 (direction == TradeDirection.Short && ob.IsBearish && ob.IsInPremium)));
            
            var htfFVG = data.FairValueGaps.FirstOrDefault(f => 
                f.IsActive &&
                ((direction == TradeDirection.Long && f.IsBullish) ||
                 (direction == TradeDirection.Short && f.IsBearish)));
            
            validation.Step1_POIReached = (htfOB != null || htfFVG != null);
            if (!validation.Step1_POIReached)
                validation.AddError("Aucun POI HTF (OB/FVG) atteint");
            
            // ═══════════════════════════════════════════════════════════════════
            // STEP 2: Switch vers LTF (déjà en LTF si on utilise ce module)
            // ═══════════════════════════════════════════════════════════════════
            validation.Step2_SwitchedLTF = true; // Assuming we're on execution TF
            
            // ═══════════════════════════════════════════════════════════════════
            // STEP 3: Liquidité prise
            // ═══════════════════════════════════════════════════════════════════
            if (direction == TradeDirection.Long)
            {
                // Pour bullish, SSL doit être prise
                validation.Step3_LiquidityTaken = data.LastLiquiditySweep != null && 
                                                   data.LastLiquiditySweep.Zone.IsSellSide;
            }
            else
            {
                // Pour bearish, BSL doit être prise
                validation.Step3_LiquidityTaken = data.LastLiquiditySweep != null && 
                                                   data.LastLiquiditySweep.Zone.IsBuySide;
            }
            if (!validation.Step3_LiquidityTaken)
                validation.AddError("Liquidité non prise (SSL pour long, BSL pour short)");
            
            // ═══════════════════════════════════════════════════════════════════
            // STEP 4: BOS → ChoCH confirmé
            // ═══════════════════════════════════════════════════════════════════
            validation.Step4_ChoCHConfirmed = data.ChoCHValidated && 
                                               data.LastChoCH != null && 
                                               data.LastChoCH.Direction == direction;
            if (!validation.Step4_ChoCHConfirmed)
                validation.AddError("ChoCH non confirmé (liquidité + BOS requis)");
            
            // ═══════════════════════════════════════════════════════════════════
            // STEP 5: Retracement vers FVG/OB LTF
            // ═══════════════════════════════════════════════════════════════════
            bool priceInOB = htfOB != null && htfOB.Contains(currentBar.Close);
            bool priceInFVG = htfFVG != null && currentBar.Close >= htfFVG.LowPrice && currentBar.Close <= htfFVG.HighPrice;
            validation.Step5_RetracementComplete = priceInOB || priceInFVG;
            if (!validation.Step5_RetracementComplete)
                validation.AddError("Prix pas encore dans zone de retracement (OB/FVG)");
            
            // ═══════════════════════════════════════════════════════════════════
            // STEP 6: Entry au fill du FVG (attendre complete fill)
            // ═══════════════════════════════════════════════════════════════════
            var entryFVG = data.FairValueGaps.FirstOrDefault(f => 
                f.IsActive && f.FillPercentage >= 90 &&
                ((direction == TradeDirection.Long && f.IsBullish) ||
                 (direction == TradeDirection.Short && f.IsBearish)));
            validation.Step6_FVGFilled = entryFVG != null;
            if (!validation.Step6_FVGFilled)
                validation.AddError("FVG non complètement rempli (attendre fill 90%+)");
            
            // ═══════════════════════════════════════════════════════════════════
            // STEP 7: Stop loss sous/dessus OB (PAS swing!)
            // ═══════════════════════════════════════════════════════════════════
            if (htfOB != null)
            {
                double proposedStop = direction == TradeDirection.Long 
                    ? htfOB.LowPrice - data.CurrentATR * 0.2
                    : htfOB.HighPrice + data.CurrentATR * 0.2;
                
                validation.Step7_StopValid = true;
                validation.ProposedStopLoss = proposedStop;
                
                // Check if stop is beyond swing (ERROR!)
                var nearestSwing = direction == TradeDirection.Long
                    ? data.PivotLows.LastOrDefault()
                    : data.PivotHighs.LastOrDefault();
                
                if (nearestSwing.Price > 0)
                {
                    bool stopBeyondSwing = direction == TradeDirection.Long
                        ? proposedStop < nearestSwing.Price
                        : proposedStop > nearestSwing.Price;
                    
                    if (stopBeyondSwing)
                    {
                        validation.Errors |= MounaEntryError.StopBeyondSwing;
                        validation.AddError("ERREUR: Stop au-delà du swing (liquidité!)");
                    }
                }
            }
            else
            {
                validation.Step7_StopValid = false;
                validation.AddError("Pas d'OB pour placer le stop");
            }
            
            // ═══════════════════════════════════════════════════════════════════
            // STEP 8: Target = Liquidité opposée
            // ═══════════════════════════════════════════════════════════════════
            var targetLiq = data.LiquidityZones.FirstOrDefault(l => 
                l.IsActive &&
                ((direction == TradeDirection.Long && l.IsBuySide && l.Price > currentBar.Close) ||
                 (direction == TradeDirection.Short && l.IsSellSide && l.Price < currentBar.Close)));
            
            validation.Step8_TargetSet = targetLiq != null;
            if (targetLiq != null)
                validation.ProposedTarget = targetLiq.Price;
            else
                validation.AddError("Pas de liquidité opposée pour target");
            
            // ═══════════════════════════════════════════════════════════════════
            // ADDITIONAL VALIDATIONS (Erreurs à éviter)
            // ═══════════════════════════════════════════════════════════════════
            
            // Check R:R
            if (validation.ProposedStopLoss > 0 && validation.ProposedTarget > 0)
            {
                double risk = Math.Abs(currentBar.Close - validation.ProposedStopLoss);
                double reward = Math.Abs(validation.ProposedTarget - currentBar.Close);
                validation.RiskRewardRatio = risk > 0 ? reward / risk : 0;
                
                if (validation.RiskRewardRatio < Settings.MinRiskReward)
                {
                    validation.Errors |= MounaEntryError.LowRiskReward;
                    validation.AddError($"R:R trop faible ({validation.RiskRewardRatio:F2} < {Settings.MinRiskReward})");
                }
            }
            
            // Check if at equilibrium
            if (IsAtEquilibrium(data))
            {
                validation.Errors |= MounaEntryError.AtEquilibrium;
                validation.AddError("Prix à l'equilibrium (50% Fib) - zone de manipulation");
            }
            
            // Check against HTF bias
            if ((direction == TradeDirection.Long && data.HTFStructure == MarketStructure.Bearish) ||
                (direction == TradeDirection.Short && data.HTFStructure == MarketStructure.Bullish))
            {
                validation.Errors |= MounaEntryError.AgainstHTFBias;
                validation.AddError("Trade contre le bias HTF");
            }
            
            // Check critical news
            if (_isCriticalNewsDay)
            {
                validation.Errors |= MounaEntryError.CriticalNewsDay;
                validation.AddError("Jour de news critique (NFP/CPI/FOMC/Powell)");
            }
            
            // Check NY open timing
            if (IsNearNYOpen(currentBar.Time))
            {
                validation.Errors |= MounaEntryError.TradingBeforeNYOpen;
                validation.AddError("Trop proche de NY open (9:25-9:35) - Judas Swing");
            }
            
            // Calculate confluence score
            validation.ConfluenceScore = CalculateMounaConfluenceScore(data, direction);
            if (validation.ConfluenceScore < Settings.MinConfluenceScore)
            {
                validation.Errors |= MounaEntryError.InsufficientConfluence;
                validation.AddError($"Confluence insuffisante ({validation.ConfluenceScore} < {Settings.MinConfluenceScore})");
            }
            
            // Final validation
            validation.IsValid = validation.Step1_POIReached &&
                                 validation.Step3_LiquidityTaken &&
                                 validation.Step4_ChoCHConfirmed &&
                                 validation.Step5_RetracementComplete &&
                                 validation.Step7_StopValid &&
                                 validation.Step8_TargetSet &&
                                 validation.ConfluenceScore >= Settings.MinConfluenceScore &&
                                 validation.Errors == MounaEntryError.None;
            
            return validation;
        }
        
        /// <summary>
        /// Get session-based expected move direction
        /// Mouna: Session reversal/continuation logic
        /// </summary>
        public TradeDirection GetSessionExpectedDirection(InstrumentSMCData data)
        {
            if (_currentSession != MounaTradingSession.NewYork)
                return TradeDirection.Flat;
            
            // CAS 1: Reversal à NY
            // Si London très bullish + prix à premium → expect bearish
            if (_londonMomentum == SessionMomentum.StrongBullish && 
                data.CurrentPricePosition == PricePosition.Premium)
                return TradeDirection.Short;
            
            // Si London très bearish + prix à discount → expect bullish
            if (_londonMomentum == SessionMomentum.StrongBearish && 
                data.CurrentPricePosition == PricePosition.Discount)
                return TradeDirection.Long;
            
            // CAS 2: Continuation
            // Si Judas swing au début de London et liquidité pas encore prise
            if (_judasSwingDetected)
            {
                // Continue dans direction opposée au Judas
                return _judasSwingDirection;
            }
            
            return TradeDirection.Flat;
        }
        
        #endregion

        #region Confluence Scoring (Mouna System)
        
        /// <summary>
        /// Calculate confluence score according to Mouna's system
        /// MINIMUM 6 points required for entry
        /// </summary>
        public int CalculateMounaConfluenceScore(InstrumentSMCData data, TradeDirection direction)
        {
            int score = 0;
            var breakdown = new MounaScoreBreakdown();
            var currentBar = data.CurrentBar;
            
            // 1. HTF FVG (+2) - FVG reached
            var htfFVG = data.FairValueGaps.FirstOrDefault(f => 
                f.IsActive && 
                ((direction == TradeDirection.Long && f.IsBullish) || 
                 (direction == TradeDirection.Short && f.IsBearish)));
            if (htfFVG != null)
            {
                breakdown.HTFFVGScore = 2;
                score += 2;
            }
            
            // 2. HTF Order Block (+2)
            var htfOB = data.OrderBlocks.FirstOrDefault(ob => 
                ob.IsActive && 
                ob.HasBOSConfirmation &&
                ((direction == TradeDirection.Long && ob.IsBullish) || 
                 (direction == TradeDirection.Short && ob.IsBearish)));
            if (htfOB != null)
            {
                breakdown.HTFOBScore = 2;
                score += 2;
            }
            
            // 3. Premium/Discount at optimal level - 70%+ (+2)
            bool atOptimalLevel = false;
            if (direction == TradeDirection.Long && data.CurrentFibLevel >= 0.70)
                atOptimalLevel = true;
            if (direction == TradeDirection.Short && data.CurrentFibLevel <= 0.30)
                atOptimalLevel = true;
            if (atOptimalLevel)
            {
                breakdown.PremiumDiscountScore = 2;
                score += 2;
            }
            
            // 4. ChoCH Confirmed (+2)
            if (data.ChoCHValidated && data.LastChoCH != null && data.LastChoCH.Direction == direction)
            {
                breakdown.ChoCHScore = 2;
                score += 2;
            }
            
            // 5. Index Divergence (+1)
            var divergence = DetectIndexDivergence(direction);
            if (divergence != DivergenceType.None)
            {
                breakdown.DivergenceScore = 1;
                score += 1;
            }
            
            // 6. Session Alignment (+1)
            bool sessionAligned = ValidateSessionAlignment(direction);
            if (sessionAligned)
            {
                breakdown.SessionScore = 1;
                score += 1;
            }
            
            // 7. Reference Level - Midnight or 8:30 (+1)
            double tolerance = data.CurrentATR * 0.5;
            bool atReferenceLevel = Math.Abs(currentBar.Close - data.MidnightOpeningPrice) <= tolerance ||
                                    Math.Abs(currentBar.Close - data.Price830Opening) <= tolerance;
            if (atReferenceLevel && data.MidnightOpeningPrice > 0)
            {
                breakdown.ReferenceLevelScore = 1;
                score += 1;
            }
            
            // 8. LTF FVG for entry (+1)
            var ltfFVG = data.FairValueGaps.FirstOrDefault(f => 
                f.IsActive && 
                f.FillPercentage >= 90 && // Mouna: wait for complete fill
                ((direction == TradeDirection.Long && f.IsBullish) || 
                 (direction == TradeDirection.Short && f.IsBearish)));
            if (ltfFVG != null)
            {
                breakdown.LTFFVGScore = 1;
                score += 1;
            }
            
            data.LastScoreBreakdown = breakdown;
            return score;
        }
        
        private DivergenceType DetectIndexDivergence(TradeDirection direction)
        {
            // Need at least ES, NQ, YM data
            if (!_lastSwingLows.ContainsKey("ES") || !_lastSwingLows.ContainsKey("NQ") || !_lastSwingLows.ContainsKey("YM"))
                return DivergenceType.None;
            
            // Simplified divergence detection
            // Full implementation would compare historical swing sequences
            return DivergenceType.None;
        }
        
        private bool ValidateSessionAlignment(TradeDirection direction)
        {
            // Mouna's session logic:
            // Best trading in NY session (9:30-11:30)
            // Avoid lunch time (12:00-14:00)
            
            if (_currentSession != MounaTradingSession.NewYork)
                return false;
            
            return IsOptimalNYWindow(DateTime.Now) && !IsLunchTime(DateTime.Now);
        }
        
        #endregion

        #region Signal Generation
        
        private void CheckForSignals(InstrumentSMCData data)
        {
            if (!IsEnabled) return;
            
            // Don't generate signals during critical news or near NY open
            if (_isCriticalNewsDay) return;
            if (IsNearNYOpen(data.CurrentBar.Time)) return;
            if (IsLunchTime(data.CurrentBar.Time) && Settings.AvoidLunchTime) return;
            
            List<SMCSignal> newSignals = new List<SMCSignal>();

            // Check all Mouna setups
            var mounaOBFVGSignal = CheckMounaOBFVGSetup(data);
            if (mounaOBFVGSignal != null) newSignals.Add(mounaOBFVGSignal);

            var liqSweepSignal = CheckLiquiditySweepSetup(data);
            if (liqSweepSignal != null) newSignals.Add(liqSweepSignal);

            var chochReversalSignal = CheckChoCHReversalSetup(data);
            if (chochReversalSignal != null) newSignals.Add(chochReversalSignal);

            lock (_signalLock)
            {
                foreach (var signal in newSignals)
                {
                    _activeSignals.Add(signal);
                    OnNewSignal?.Invoke(this, signal);
                }

                var expired = _activeSignals.Where(s => s.IsExpired).ToList();
                foreach (var signal in expired)
                {
                    signal.IsValid = false;
                    OnSignalInvalidated?.Invoke(this, signal);
                    _activeSignals.Remove(signal);
                }

                while (_activeSignals.Count > SophonConstants.MAX_SIGNALS)
                    _activeSignals.RemoveAt(0);
            }
        }

        /// <summary>
        /// Mouna's primary setup: OB + FVG confluence with full validation
        /// </summary>
        private SMCSignal CheckMounaOBFVGSetup(InstrumentSMCData data)
        {
            var currentBar = data.CurrentBar;
            
            foreach (var ob in data.OrderBlocks.Where(o => o.IsActive && o.HasBOSConfirmation))
            {
                foreach (var fvg in data.FairValueGaps.Where(f => f.IsActive))
                {
                    bool sameDirection = (ob.IsBullish && fvg.IsBullish) || (ob.IsBearish && fvg.IsBearish);
                    if (!sameDirection) continue;

                    bool overlaps = ob.LowPrice <= fvg.HighPrice && ob.HighPrice >= fvg.LowPrice;
                    if (!overlaps) continue;

                    double confluenceHigh = Math.Min(ob.HighPrice, fvg.HighPrice);
                    double confluenceLow = Math.Max(ob.LowPrice, fvg.LowPrice);
                    
                    bool priceInZone = currentBar.Low <= confluenceHigh && currentBar.High >= confluenceLow;
                    if (!priceInZone) continue;

                    // Mouna: Must be in discount for long, premium for short
                    bool correctZone = (ob.IsBullish && data.CurrentPricePosition == PricePosition.Discount) ||
                                       (ob.IsBearish && data.CurrentPricePosition == PricePosition.Premium);
                    if (!correctZone && Settings.RequirePremiumDiscount) continue;
                    
                    // Mouna: Don't trade if OB is at equal highs/lows (inducement)
                    bool atInducement = data.InducementPatterns.Any(i => 
                        Math.Abs(i.Price - ob.MidPrice) < data.CurrentATR * 0.5);
                    if (atInducement) continue;

                    TradeDirection direction = ob.IsBullish ? TradeDirection.Long : TradeDirection.Short;
                    
                    // Calculate Mouna confluence score
                    int confluenceScore = CalculateMounaConfluenceScore(data, direction);
                    
                    // Mouna: MINIMUM 6 points required
                    if (confluenceScore < Settings.MinConfluenceScore) continue;

                    var signal = CreateSignal(data, SetupType.E_OB_FVG, ob.IsBullish);
                    signal.RelatedOB = ob;
                    signal.RelatedFVG = fvg;
                    signal.ConfluenceScore = confluenceScore;
                    signal.ScoreBreakdown = data.LastScoreBreakdown?.ToString() ?? "";
                    
                    // Mouna: Stop loss ALWAYS beyond Order Block, NEVER beyond swing
                    if (ob.IsBullish)
                    {
                        signal.EntryPrice = confluenceLow;
                        signal.StopLoss = ob.LowPrice - data.CurrentATR * 0.2; // Tight below OB
                    }
                    else
                    {
                        signal.EntryPrice = confluenceHigh;
                        signal.StopLoss = ob.HighPrice + data.CurrentATR * 0.2; // Tight above OB
                    }
                    
                    // Mouna: Target is opposite liquidity
                    double risk = Math.Abs(signal.EntryPrice - signal.StopLoss);
                    
                    // Find target liquidity
                    var targetLiq = data.LiquidityZones.FirstOrDefault(l => 
                        l.IsActive &&
                        ((ob.IsBullish && l.IsBuySide && l.Price > signal.EntryPrice) ||
                         (ob.IsBearish && l.IsSellSide && l.Price < signal.EntryPrice)));
                    
                    if (targetLiq != null)
                    {
                        signal.TakeProfit1 = targetLiq.Price;
                        signal.RiskRewardRatio = Math.Abs(signal.TakeProfit1 - signal.EntryPrice) / risk;
                    }
                    else
                    {
                        signal.TakeProfit1 = ob.IsBullish ? signal.EntryPrice + risk * Settings.TP1RRRatio 
                                                          : signal.EntryPrice - risk * Settings.TP1RRRatio;
                        signal.RiskRewardRatio = Settings.TP1RRRatio;
                    }
                    
                    signal.TakeProfit2 = ob.IsBullish ? signal.EntryPrice + risk * Settings.TP2RRRatio 
                                                      : signal.EntryPrice - risk * Settings.TP2RRRatio;

                    // Mouna: Minimum R:R of 1.5
                    if (signal.RiskRewardRatio < Settings.MinRiskReward) continue;

                    signal.AddConfluence("OrderBlock");
                    signal.AddConfluence("FVG");
                    signal.AddConfluence("BOSConfirmed");
                    if (correctZone) signal.AddConfluence(ob.IsBullish ? "Discount" : "Premium");
                    if (ob.IsAtOTE) signal.AddConfluence("OTE");
                    if (data.ChoCHValidated) signal.AddConfluence("ChoCH");

                    return signal;
                }
            }
            return null;
        }

        private SMCSignal CheckLiquiditySweepSetup(InstrumentSMCData data)
        {
            if (data.LastLiquiditySweep == null || data.LastChoCH == null) return null;

            var currentBar = data.CurrentBar;
            var sweep = data.LastLiquiditySweep;
            var choch = data.LastChoCH;

            if (currentBar.Index - sweep.BarIndex > 10 || currentBar.Index - choch.BarIndex > 10) return null;
            if (sweep.BarIndex >= choch.BarIndex) return null;

            bool isLong = sweep.Zone.IsSellSide;
            if (isLong && choch.Direction != TradeDirection.Long) return null;
            if (!isLong && choch.Direction != TradeDirection.Short) return null;

            // Calculate confluence score
            TradeDirection direction = isLong ? TradeDirection.Long : TradeDirection.Short;
            int confluenceScore = CalculateMounaConfluenceScore(data, direction);
            if (confluenceScore < Settings.MinConfluenceScore) return null;

            var signal = CreateSignal(data, SetupType.F_LiquiditySweep, isLong);
            signal.RelatedLiquidity = sweep.Zone;
            signal.ConfluenceScore = confluenceScore;
            signal.EntryPrice = currentBar.Close;
            signal.StopLoss = isLong ? sweep.Zone.Price - data.CurrentATR * Settings.SLATRMultiplier
                                     : sweep.Zone.Price + data.CurrentATR * Settings.SLATRMultiplier;
            
            double risk = Math.Abs(signal.EntryPrice - signal.StopLoss);
            signal.TakeProfit1 = isLong ? signal.EntryPrice + risk * Settings.TP1RRRatio 
                                        : signal.EntryPrice - risk * Settings.TP1RRRatio;
            signal.TakeProfit2 = isLong ? signal.EntryPrice + risk * Settings.TP2RRRatio 
                                        : signal.EntryPrice - risk * Settings.TP2RRRatio;

            signal.AddConfluence("LiquiditySweep");
            signal.AddConfluence("ChoCH");
            signal.RiskRewardRatio = Settings.TP1RRRatio;

            data.LastLiquiditySweep = null;
            data.LastChoCH = null;
            return signal;
        }

        private SMCSignal CheckChoCHReversalSetup(InstrumentSMCData data)
        {
            if (data.LastChoCH == null || !data.ChoCHValidated) return null;
            
            var currentBar = data.CurrentBar;
            if (currentBar.Index - data.LastChoCH.BarIndex > 5) return null;

            bool isLong = data.LastChoCH.Direction == TradeDirection.Long;
            
            // Mouna: Must be in discount for long, premium for short
            if (isLong && data.CurrentPricePosition != PricePosition.Discount) return null;
            if (!isLong && data.CurrentPricePosition != PricePosition.Premium) return null;

            // Calculate confluence score
            TradeDirection direction = isLong ? TradeDirection.Long : TradeDirection.Short;
            int confluenceScore = CalculateMounaConfluenceScore(data, direction);
            if (confluenceScore < Settings.MinConfluenceScore) return null;

            var signal = CreateSignal(data, SetupType.H_ChoCH_Reversal, isLong);
            signal.ConfluenceScore = confluenceScore;
            signal.EntryPrice = currentBar.Close;
            
            // Find nearest OB for stop placement
            var nearestOB = data.OrderBlocks
                .Where(ob => ob.IsActive && ob.IsBullish == isLong)
                .OrderBy(ob => Math.Abs(ob.MidPrice - currentBar.Close))
                .FirstOrDefault();
            
            if (nearestOB != null)
            {
                signal.StopLoss = isLong ? nearestOB.LowPrice - data.CurrentATR * 0.2
                                         : nearestOB.HighPrice + data.CurrentATR * 0.2;
                signal.RelatedOB = nearestOB;
            }
            else
            {
                signal.StopLoss = isLong ? currentBar.Low - data.CurrentATR * Settings.SLATRMultiplier
                                         : currentBar.High + data.CurrentATR * Settings.SLATRMultiplier;
            }
            
            double risk = Math.Abs(signal.EntryPrice - signal.StopLoss);
            signal.TakeProfit1 = isLong ? signal.EntryPrice + risk * Settings.TP1RRRatio 
                                        : signal.EntryPrice - risk * Settings.TP1RRRatio;
            signal.TakeProfit2 = isLong ? signal.EntryPrice + risk * Settings.TP2RRRatio 
                                        : signal.EntryPrice - risk * Settings.TP2RRRatio;

            signal.AddConfluence("ChoCH");
            signal.AddConfluence("Reversal");
            signal.AddConfluence(isLong ? "Discount" : "Premium");
            if (data.ChoCHHasFVG) signal.AddConfluence("FVG");
            signal.RiskRewardRatio = Settings.TP1RRRatio;

            return signal;
        }

        private SMCSignal CreateSignal(InstrumentSMCData data, SetupType setup, bool isLong)
        {
            var currentBar = data.CurrentBar;
            return new SMCSignal
            {
                Instrument = data.Instrument,
                Timestamp = currentBar.Time,
                BarIndex = currentBar.Index,
                Setup = setup,
                Direction = isLong ? TradeDirection.Long : TradeDirection.Short,
                Structure = data.CurrentStructure,
                PricePosition = data.CurrentPricePosition,
                Session = ConvertToTradingSession(_currentSession),
                Phase = _currentPhase.ToString(),
                ExpiresAt = DateTime.Now.AddMinutes(Settings.SignalExpiryMinutes)
            };
        }
        
        private TradingSession ConvertToTradingSession(MounaTradingSession session)
        {
            return session switch
            {
                MounaTradingSession.Asian => TradingSession.Asian,
                MounaTradingSession.London => TradingSession.London,
                MounaTradingSession.NewYork => TradingSession.NewYork,
                MounaTradingSession.Closed => TradingSession.Closed,
                MounaTradingSession.PreMarket => TradingSession.Closed,
                _ => TradingSession.Closed
            };
        }
        
        #endregion

        #region Cleanup
        
        private void CleanExpiredZones(InstrumentSMCData data, int currentBar)
        {
            data.OrderBlocks.RemoveAll(ob => currentBar - ob.CreatedBar > ob.ExpirationBars || ob.State == ZoneState.Mitigated);
            data.FairValueGaps.RemoveAll(fvg => currentBar - fvg.CreatedBar > fvg.ExpirationBars || fvg.State == ZoneState.Mitigated);
            data.LiquidityZones.RemoveAll(liq => liq.WasTaken);
        }
        
        #endregion

        #region Public Interface
        
        public List<SMCSignal> GetActiveSignals()
        {
            lock (_signalLock) { return _activeSignals.Where(s => s.IsValid && !s.IsExpired).ToList(); }
        }

        public SMCSignal GetSignal(string instrument)
        {
            lock (_signalLock) { return _activeSignals.FirstOrDefault(s => s.Instrument == instrument && s.IsValid && !s.IsExpired); }
        }

        public void InvalidateSignal(string signalId)
        {
            lock (_signalLock)
            {
                var signal = _activeSignals.FirstOrDefault(s => s.Id == signalId);
                if (signal != null) { signal.IsValid = false; OnSignalInvalidated?.Invoke(this, signal); }
            }
        }

        public MarketContext GetMarketContext(string instrument)
        {
            return _contextCache.GetOrCompute(instrument, () =>
            {
                if (!_instrumentData.ContainsKey(instrument)) return new MarketContext { Instrument = instrument };
                var data = _instrumentData[instrument];
                
                return new MarketContext
                {
                    Instrument = instrument, Timestamp = DateTime.Now,
                    Structure = data.CurrentStructure, CurrentPosition = data.CurrentPricePosition,
                    CurrentSession = ConvertToTradingSession(_currentSession), CurrentPhase = _currentPhase.ToString(),
                    ATR = data.CurrentATR, CurrentSwingRange = data.CurrentSwingRange,
                    RecentPivots = data.AllPivots.TakeLast(10).ToList(),
                    ActiveOrderBlocks = data.OrderBlocks.Where(o => o.IsActive).ToList(),
                    ActiveFVGs = data.FairValueGaps.Where(f => f.IsActive).ToList(),
                    ActiveLiquidity = data.LiquidityZones.Where(l => l.IsActive).ToList(),
                    HasBullishBias = data.CurrentStructure == MarketStructure.Bullish,
                    HasBearishBias = data.CurrentStructure == MarketStructure.Bearish,
                    MidnightOpeningPrice = data.MidnightOpeningPrice,
                    Price830Opening = data.Price830Opening,
                    AsianHigh = data.AsianHigh,
                    AsianLow = data.AsianLow,
                    PDH = data.PreviousDayHigh,
                    PDL = data.PreviousDayLow,
                    PWH = data.PreviousWeekHigh,
                    PWL = data.PreviousWeekLow,
                    CurrentFibLevel = data.CurrentFibLevel,
                    CurrentOTELevel = data.CurrentOTELevel,
                    ChoCHValidated = data.ChoCHValidated
                };
            });
        }

        public List<OrderBlock> GetActiveOrderBlocks(string instrument) =>
            _instrumentData.ContainsKey(instrument) ? _instrumentData[instrument].OrderBlocks.Where(o => o.IsActive).ToList() : new List<OrderBlock>();

        public List<FairValueGap> GetActiveFVGs(string instrument) =>
            _instrumentData.ContainsKey(instrument) ? _instrumentData[instrument].FairValueGaps.Where(f => f.IsActive).ToList() : new List<FairValueGap>();

        public List<LiquidityZone> GetActiveLiquidity(string instrument) =>
            _instrumentData.ContainsKey(instrument) ? _instrumentData[instrument].LiquidityZones.Where(l => l.IsActive).ToList() : new List<LiquidityZone>();
        
        public MounaTradingSession GetCurrentSession() => _currentSession;
        public MarketPhase GetCurrentPhase() => _currentPhase;
        public bool IsCriticalNewsDay() => _isCriticalNewsDay;
        
        /// <summary>
        /// Get reference levels for current session
        /// </summary>
        public ReferenceLevels GetReferenceLevels(string instrument)
        {
            if (!_instrumentData.ContainsKey(instrument)) return new ReferenceLevels();
            var data = _instrumentData[instrument];
            
            return new ReferenceLevels
            {
                MidnightOpening = data.MidnightOpeningPrice,
                Opening830 = data.Price830Opening,
                AsianHigh = data.AsianHigh,
                AsianLow = data.AsianLow,
                PDH = data.PreviousDayHigh,
                PDL = data.PreviousDayLow,
                PWH = data.PreviousWeekHigh,
                PWL = data.PreviousWeekLow
            };
        }
        
        #endregion
    }

    #region Supporting Classes
    
    public class SMCSettings
    {
        // Pivot settings
        public int PivotLookback { get; set; } = 3; // Mouna: 3 candles for swing
        public double EqualLevelTolerance { get; set; } = 0.15; // ATR ratio for equal levels
        
        // Order Block settings
        public int OBLookback { get; set; } = 10;
        public double OBImpulseMultiplier { get; set; } = 2.0;
        public int OBExpirationBars { get; set; } = 100;
        
        // FVG settings
        public double FVGMinATRRatio { get; set; } = 0.3;
        public int FVGExpirationBars { get; set; } = 50;
        
        // Volume Imbalance
        public double VolumeImbalanceMinATR { get; set; } = 0.2;
        
        // Signal settings
        public int SignalExpiryMinutes { get; set; } = 30;
        public bool RequireStructureAlignment { get; set; } = true;
        public bool RequirePremiumDiscount { get; set; } = true;
        
        // Risk management (Mouna)
        public double SLATRMultiplier { get; set; } = 0.5; // Mouna: tight stop beyond OB
        public double TP1RRRatio { get; set; } = 1.5;
        public double TP2RRRatio { get; set; } = 3.0;
        public double TP3RRRatio { get; set; } = 5.0;
        public double MinRiskReward { get; set; } = 1.5; // Mouna: minimum R:R
        
        // Confluence (Mouna)
        public int MinConfluenceScore { get; set; } = 6; // Mouna: minimum 6 points
        
        // Session filter
        public bool FilterCriticalNews { get; set; } = true;
        public bool AvoidLunchTime { get; set; } = true;
        public int NYOpenBuffer { get; set; } = 5; // Minutes to avoid around 9:30
    }

    public class InstrumentSMCData
    {
        public string Instrument { get; }
        public SMCSettings Settings { get; }
        public List<BarData> Bars { get; }
        public BarData CurrentBar => Bars.Count > 0 ? Bars.Last() : default;
        
        // Pivots
        public List<PivotPoint> PivotHighs { get; }
        public List<PivotPoint> PivotLows { get; }
        public List<PivotPoint> AllPivots { get; }
        
        // Market structure
        public MarketStructure CurrentStructure { get; set; }
        public PricePosition CurrentPricePosition { get; set; }
        public PriceRange CurrentSwingRange { get; set; }
        public double CurrentFibLevel { get; set; }
        public OTELevel CurrentOTELevel { get; set; }
        
        // HTF data (from multi-timeframe analysis)
        public double HTFEMAValue { get; set; }
        public MarketStructure HTFStructure { get; set; }
        public PricePosition HTFPosition { get; set; }
        public bool HTFBullishBias { get; set; }
        
        // Zones
        public List<OrderBlock> OrderBlocks { get; }
        public List<FairValueGap> FairValueGaps { get; }
        public List<LiquidityZone> LiquidityZones { get; }
        public List<VolumeImbalance> VolumeImbalances { get; }
        public List<InducementPattern> InducementPatterns { get; }
        
        // Events
        public StructureShiftEvent LastBOS { get; set; }
        public StructureShiftEvent LastChoCH { get; set; }
        public LiquiditySweepEvent LastLiquiditySweep { get; set; }
        
        // ChoCH validation (Mouna)
        public bool PendingChoCHValidation { get; set; }
        public bool ChoCHValidated { get; set; }
        public bool ChoCHHasFVG { get; set; }
        
        // Reference levels (Mouna)
        public double MidnightOpeningPrice { get; set; }
        public double Price830Opening { get; set; }
        public double AsianHigh { get; set; }
        public double AsianLow { get; set; }
        public double PreviousDayHigh { get; set; }
        public double PreviousDayLow { get; set; }
        public double PreviousWeekHigh { get; set; }
        public double PreviousWeekLow { get; set; }
        
        // ATR
        public double CurrentATR { get; set; }
        
        // Score tracking
        public MounaScoreBreakdown LastScoreBreakdown { get; set; }
        
        // Judas Swing tracking (Mouna)
        public bool JudasSwingDetected { get; set; }
        public TradeDirection JudasDirection { get; set; }
        
        // Session momentum tracking (Mouna)
        public SessionMomentum LondonMomentum { get; set; }
        public SessionMomentum AsianMomentum { get; set; }
        
        // Entry model tracking (Mouna)
        public MounaEntryStage CurrentEntryStage { get; set; }
        public MounaEntryValidation LastEntryValidation { get; set; }

        public InstrumentSMCData(string instrument, SMCSettings settings)
        {
            Instrument = instrument;
            Settings = settings;
            Bars = new List<BarData>();
            PivotHighs = new List<PivotPoint>();
            PivotLows = new List<PivotPoint>();
            AllPivots = new List<PivotPoint>();
            OrderBlocks = new List<OrderBlock>();
            FairValueGaps = new List<FairValueGap>();
            LiquidityZones = new List<LiquidityZone>();
            VolumeImbalances = new List<VolumeImbalance>();
            InducementPatterns = new List<InducementPattern>();
            CurrentStructure = MarketStructure.Unknown;
            CurrentPricePosition = PricePosition.Equilibrium;
        }

        public void AddBar(double open, double high, double low, double close, double volume, DateTime time, int index)
        {
            Bars.Add(new BarData { Open = open, High = high, Low = low, Close = close, Volume = volume, Time = time, Index = index });
            while (Bars.Count > 500) Bars.RemoveAt(0);
        }
    }

    public struct BarData
    {
        public double Open, High, Low, Close, Volume;
        public DateTime Time;
        public int Index;
        public double Body => Math.Abs(Close - Open);
        public double Range => High - Low;
        public bool IsBullish => Close > Open;
        public bool IsBearish => Close < Open;
        public double MidPoint => (High + Low) / 2;
    }

    public class StructureShiftEvent
    {
        public MarketStructureShift Type { get; set; }
        public double Price { get; set; }
        public DateTime Time { get; set; }
        public int BarIndex { get; set; }
        public TradeDirection Direction { get; set; }
        public MarketStructure PreviousStructure { get; set; }
    }

    public class LiquiditySweepEvent
    {
        public LiquidityZone Zone { get; set; }
        public DateTime Time { get; set; }
        public int BarIndex { get; set; }
        public double SweepPrice { get; set; }
    }
    
    public class ChoCHEvent
    {
        public TradeDirection Direction { get; set; }
        public double Price { get; set; }
        public DateTime Time { get; set; }
        public bool LiquidityTaken { get; set; }
        public bool HasFVG { get; set; }
        public bool IsValid { get; set; }
    }
    
    // SessionChangeEvent defined in SophonGovernance.cs
    
    public class DivergenceEvent
    {
        public DivergenceType Type { get; set; }
        public string LeadingIndex { get; set; }
        public string DelayedIndex { get; set; }
        public DateTime Time { get; set; }
    }
    
    public class VolumeImbalance
    {
        public double GapHigh { get; set; }
        public double GapLow { get; set; }
        public double GapSize { get; set; }
        public bool IsBullish { get; set; }
        public int CreatedBar { get; set; }
        public DateTime CreatedAt { get; set; }
        public bool IsSundayGap { get; set; }
        public bool IsFilled { get; set; }
    }
    
    public class InducementPattern
    {
        public InducementType Type { get; set; }
        public double Price { get; set; }
        public int DetectedBar { get; set; }
        public double Confidence { get; set; }
    }
    
    public class ReferenceLevels
    {
        public double MidnightOpening { get; set; }
        public double Opening830 { get; set; }
        public double AsianHigh { get; set; }
        public double AsianLow { get; set; }
        public double PDH { get; set; }
        public double PDL { get; set; }
        public double PWH { get; set; }
        public double PWL { get; set; }
    }
    
    /// <summary>
    /// Mouna confluence score breakdown
    /// </summary>
    public class MounaScoreBreakdown
    {
        public int HTFFVGScore { get; set; }           // +2
        public int HTFOBScore { get; set; }            // +2
        public int PremiumDiscountScore { get; set; }  // +2
        public int ChoCHScore { get; set; }            // +2
        public int DivergenceScore { get; set; }       // +1
        public int SessionScore { get; set; }          // +1
        public int ReferenceLevelScore { get; set; }   // +1
        public int LTFFVGScore { get; set; }           // +1
        
        public int Total => HTFFVGScore + HTFOBScore + PremiumDiscountScore + 
                           ChoCHScore + DivergenceScore + SessionScore + 
                           ReferenceLevelScore + LTFFVGScore;
        
        public override string ToString()
        {
            return $"HTF_FVG:{HTFFVGScore} HTF_OB:{HTFOBScore} P/D:{PremiumDiscountScore} " +
                   $"ChoCH:{ChoCHScore} Div:{DivergenceScore} Session:{SessionScore} " +
                   $"Ref:{ReferenceLevelScore} LTF_FVG:{LTFFVGScore} = {Total}";
        }
    }
    
    /// <summary>
    /// Mouna's 8-step entry validation result
    /// </summary>
    public class MounaEntryValidation
    {
        // 8 Steps validation
        public bool Step1_POIReached { get; set; }
        public bool Step2_SwitchedLTF { get; set; }
        public bool Step3_LiquidityTaken { get; set; }
        public bool Step4_ChoCHConfirmed { get; set; }
        public bool Step5_RetracementComplete { get; set; }
        public bool Step6_FVGFilled { get; set; }
        public bool Step7_StopValid { get; set; }
        public bool Step8_TargetSet { get; set; }
        
        // Trade parameters
        public double ProposedEntry { get; set; }
        public double ProposedStopLoss { get; set; }
        public double ProposedTarget { get; set; }
        public double RiskRewardRatio { get; set; }
        public int ConfluenceScore { get; set; }
        
        // Error tracking
        public MounaEntryError Errors { get; set; }
        public List<string> ErrorMessages { get; private set; }
        
        // Final result
        public bool IsValid { get; set; }
        
        public MounaEntryValidation()
        {
            ErrorMessages = new List<string>();
            Errors = MounaEntryError.None;
        }
        
        public void AddError(string message)
        {
            ErrorMessages.Add(message);
        }
        
        public int StepsCompleted
        {
            get
            {
                int count = 0;
                if (Step1_POIReached) count++;
                if (Step2_SwitchedLTF) count++;
                if (Step3_LiquidityTaken) count++;
                if (Step4_ChoCHConfirmed) count++;
                if (Step5_RetracementComplete) count++;
                if (Step6_FVGFilled) count++;
                if (Step7_StopValid) count++;
                if (Step8_TargetSet) count++;
                return count;
            }
        }
        
        public override string ToString()
        {
            return $"Mouna Entry: {StepsCompleted}/8 steps, Score:{ConfluenceScore}, R:R:{RiskRewardRatio:F2}, Valid:{IsValid}";
        }
    }
    
    #endregion
}
