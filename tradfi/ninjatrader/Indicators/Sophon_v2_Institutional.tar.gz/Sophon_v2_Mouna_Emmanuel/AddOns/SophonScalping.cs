#region Using declarations
using System;
using System.Collections.Generic;
using System.Linq;
using NinjaTrader.NinjaScript;
#endregion

// ═══════════════════════════════════════════════════════════════════════════════
// SOPHON SCALPING MODULE v2.0 - UNIFIED EMMANUEL EDITION
// ═══════════════════════════════════════════════════════════════════════════════
//
// MERGED FROM:
//   - SophonScalping.cs v1.2 (Module architecture, events, data structures)
//   - SophonScalping_Emmanuel_v1_5_FINAL.cs (8 validated patterns, ICT concepts)
//
// SOURCE: 7 Conversations, 90+ Images, +$32,953.70 P&L Documented
//
// ═══════════════════════════════════════════════════════════════════════════════
// CONFIGURATION EMMANUEL (CONFIRMED):
// ═══════════════════════════════════════════════════════════════════════════════
//
// EMA:              19 (6x+ confirmé)
// Timeframes:       2m, 3m, 5m, 15m, 30m, 60m, Daily
// Position Sizing:  GC=1ct, MGC=5ct, MES=5-10ct, ES=1-3ct
// Win Rate:         ~85%
// Avg Win:          ~$550
// Avg Loss:         ~$322
// Biggest Win:      $1,520
//
// ═══════════════════════════════════════════════════════════════════════════════
// EMMANUEL PATTERNS (8 Total - Validated with 90+ trades):
// ═══════════════════════════════════════════════════════════════════════════════
//
// 1. Emmanuel_EMABounce         (~20%) - Win Rate: 80%
// 2. Emmanuel_RangeBreakout     (~20%) - Win Rate: 80%
// 3. Emmanuel_TrendlineTrading  (~15%) - Win Rate: 75%
// 4. Emmanuel_ZoneTrading       (~15%) - Win Rate: 80%
// 5. Emmanuel_ICTLevelBounce    (~10%) - Win Rate: 75%
// 6. Emmanuel_BOSEntry          (~10%) - Win Rate: 80%
// 7. Emmanuel_LiquiditySweep    (~5%)  - Win Rate: 75%
// 8. Emmanuel_TrendContinuation (~5%)  - Win Rate: 70%
//
// ═══════════════════════════════════════════════════════════════════════════════
// ICT/SMC CONCEPTS INTEGRATED:
// ═══════════════════════════════════════════════════════════════════════════════
//
// PDH/PDL:          Previous Day High/Low
// PWH/PWL:          Previous Week High/Low
// BOS:              Break of Structure
// Strong/Weak:      High/Low levels with volume confirmation
//
// ═══════════════════════════════════════════════════════════════════════════════
// CONFLUENCE SCORING (Max 10 points):
// ═══════════════════════════════════════════════════════════════════════════════
//
// EMA position:  +2 (price on correct side of EMA)
// EMA slope:     +2 (EMA sloping in trade direction)
// Momentum:      +1 (body > 0.5 ATR in direction)
// Volume spike:  +1 (volume > 1.3x average)
// ICT level:     +1 (near PDH/PDL/PWH/PWL)
// BOS confirmed: +1 (structure break in direction)
// NY session:    +1 (9:30-11:30 ET)
// HTF aligned:   +1 (60min EMA aligned)
//
// Copyright (c) 2026 Algosphere Quant - Emmanuel
// ═══════════════════════════════════════════════════════════════════════════════

namespace NinjaTrader.NinjaScript.AddOns.Sophon
{
    #region Enums
    
    /// <summary>
    /// Emmanuel Pattern Types (8 validated patterns)
    /// </summary>
    public enum EmmanuelPatternType
    {
        None,
        EMABounce,              // ~20%, 80% WR
        EMA19_Support,          // EMA 19 support bounce
        EMA19_Resistance,       // EMA 19 resistance rejection
        RangeBreakout,          // ~20%, 80% WR
        TrendlineTrading,       // ~15%, 75% WR
        ZoneTrading,            // ~15%, 80% WR
        ICTLevelBounce,         // ~10%, 75% WR
        BOSEntry,               // ~10%, 80% WR
        BOS_Continuation,       // BOS continuation pattern
        LiquiditySweep,         // ~5%, 75% WR
        TrendContinuation       // ~5%, 70% WR
    }
    
    /// <summary>
    /// ICT Level Types
    /// </summary>
    public enum ICTLevelType
    {
        None,
        PDH,    // Previous Day High
        PDL,    // Previous Day Low
        PWH,    // Previous Week High
        PWL,    // Previous Week Low
        HOD,    // High of Day
        LOD     // Low of Day
    }
    
    // MarketStructure defined in SophonCore.cs
    
    /// <summary>
    /// Candle pattern detection
    /// </summary>
    public enum CandlePattern
    {
        None,
        Doji,
        Hammer,
        InvertedHammer,
        ShootingStar,
        HangingMan,
        BullishEngulfing,
        BearishEngulfing,
        BullishPinBar,
        BearishPinBar,
        BullishMarubozu,
        BearishMarubozu,
        MorningStar,
        EveningStar,
        ThreeWhiteSoldiers,
        ThreeBlackCrows
    }
    
    // PivotType defined in SophonCore.cs
    public enum SRZoneType { Support, Resistance }
    public enum TrendlineDirection { Up, Down }
    
    #endregion

    /// <summary>
    /// SOPHON SCALPING MODULE v2.0 - UNIFIED EMMANUEL EDITION
    /// Implements ISophonModule for integration with SophonStrategy
    /// </summary>
    public class SophonScalping : ISophonModule
    {
        #region Properties
        
        public string ModuleName => "SophonScalping_Emmanuel_v2";
        public bool IsInitialized { get; private set; }
        public bool IsEnabled { get; set; }
        
        public ScalpingSettings Settings { get; set; }
        
        // Data by instrument
        private Dictionary<string, ScalpingData> _dataByInstrument;
        
        // Active signals
        private List<ScalpingSignal> _activeSignals;
        
        // Events
        public event EventHandler<ScalpingSignal> OnSetupDetected;
        public event EventHandler<ScalpingSignal> OnSetupInvalidated;
        public event EventHandler<ScalpingSignal> OnNewSignal;  // Alias for OnSetupDetected for compatibility
        public event EventHandler<BOSEvent> OnBOSDetected;
        public event EventHandler<ICTLevelEvent> OnICTLevelTouched;
        
        private readonly object _lock = new object();
        
        #endregion

        #region Initialization
        
        public SophonScalping()
        {
            Settings = new ScalpingSettings();
            _dataByInstrument = new Dictionary<string, ScalpingData>();
            _activeSignals = new List<ScalpingSignal>();
            IsEnabled = true;
        }

        public void Initialize()
        {
            if (IsInitialized) return;
            
            _dataByInstrument.Clear();
            _activeSignals.Clear();
            
            IsInitialized = true;
        }

        public void Shutdown()
        {
            _dataByInstrument.Clear();
            _activeSignals.Clear();
            IsInitialized = false;
        }

        public void Reset()
        {
            Shutdown();
            Initialize();
        }

        public void OnBarUpdate(int barsInProgress) { }
        
        /// <summary>
        /// Update instrument data with new bar information
        /// </summary>
        public void UpdateInstrument(string instrument, double open, double high, double low, double close,
                                     double volume, DateTime time, int barIndex, double atr, double ema19 = 0)
        {
            if (!IsEnabled || !IsInitialized) return;
            if (!_dataByInstrument.ContainsKey(instrument))
            {
                RegisterInstrument(instrument);
            }
            
            var data = _dataByInstrument[instrument];
            data.AddBar(open, high, low, close, volume, time, barIndex);
            data.ATR = atr;
            if (ema19 > 0) data.EMA19 = ema19;
            
            // Update analysis
            UpdateMarketStructure(data);
            UpdateICTLevels(data);
            DetectPatterns(data);
        }

        /// <summary>
        /// Register an instrument for scalping
        /// </summary>
        public void RegisterInstrument(string instrument)
        {
            lock (_lock)
            {
                if (!_dataByInstrument.ContainsKey(instrument))
                {
                    _dataByInstrument[instrument] = new ScalpingData(instrument, Settings);
                }
            }
        }
        
        #endregion

        #region Main Update
        
        /// <summary>
        /// Main update method - call this on every bar
        /// </summary>
        public void Update(string instrument, double open, double high, double low, double close,
                          double volume, DateTime time, int barIndex, double atr,
                          double ema19, double ema19_5m, double ema19_15m, double ema19_60m,
                          double volumeSMA, bool isFirstBarOfSession = false,
                          double dailyHigh = 0, double dailyLow = 0,
                          double prevDayHigh = 0, double prevDayLow = 0,
                          double prevWeekHigh = 0, double prevWeekLow = 0)
        {
            lock (_lock)
            {
                if (!_dataByInstrument.ContainsKey(instrument))
                    RegisterInstrument(instrument);
                
                var data = _dataByInstrument[instrument];
                
                // Update candle
                var candle = new CandleData
                {
                    Open = open,
                    High = high,
                    Low = low,
                    Close = close,
                    Volume = volume,
                    Time = time,
                    BarIndex = barIndex
                };
                
                data.Candles.Add(candle);
                data.ATR = atr;
                data.EMA19 = ema19;
                data.EMA19_5m = ema19_5m;
                data.EMA19_15m = ema19_15m;
                data.EMA19_60m = ema19_60m;
                data.VolumeSMA = volumeSMA;
                data.LastUpdate = time;
                
                // Update ICT levels
                data.PDH = prevDayHigh;
                data.PDL = prevDayLow;
                data.PWH = prevWeekHigh;
                data.PWL = prevWeekLow;
                
                // Update today's high/low
                if (isFirstBarOfSession)
                {
                    data.TodayHigh = high;
                    data.TodayLow = low;
                }
                else
                {
                    if (high > data.TodayHigh) data.TodayHigh = high;
                    if (low < data.TodayLow) data.TodayLow = low;
                }
                
                // Limit history
                while (data.Candles.Count > Settings.MaxCandleHistory)
                    data.Candles.RemoveAt(0);
                
                // Update structure analysis
                UpdateSwingStructure(data);
                UpdateBOS(data);
                UpdateRangeDetection(data);
                UpdateTrendlines(data);
                UpdateMarketStructure(data);
                DetectCandlePattern(data, candle);
                
                // Check all Emmanuel patterns
                CheckEmmanuelPatterns(data);
                
                // Cleanup expired signals
                CleanupExpiredSignals(time);
            }
        }
        
        /// <summary>
        /// Simplified update (backward compatible)
        /// </summary>
        public void Update(string instrument, double open, double high, double low, double close,
                          double volume, DateTime time, int barIndex, double atr,
                          double ema19, double rsi, double volumeSMA)
        {
            Update(instrument, open, high, low, close, volume, time, barIndex, atr,
                   ema19, 0, 0, 0, volumeSMA);
        }
        
        #endregion

        #region Swing Structure & BOS Detection
        
        /// <summary>
        /// Update swing high/low structure for BOS detection
        /// </summary>
        private void UpdateSwingStructure(ScalpingData data)
        {
            if (data.Candles.Count < Settings.SwingStrength * 2 + 1)
                return;
            
            int pivotBar = Settings.SwingStrength;
            var candles = data.Candles;
            int currentIndex = candles.Count - 1 - pivotBar;
            
            if (currentIndex < pivotBar) return;
            
            // Check for swing high
            bool isSwingHigh = true;
            double pivotHigh = candles[currentIndex].High;
            
            for (int i = -Settings.SwingStrength; i <= Settings.SwingStrength; i++)
            {
                if (i == 0) continue;
                int checkIndex = currentIndex + i;
                if (checkIndex < 0 || checkIndex >= candles.Count) continue;
                
                if (candles[checkIndex].High >= pivotHigh)
                {
                    isSwingHigh = false;
                    break;
                }
            }
            
            if (isSwingHigh)
            {
                var pivot = new PivotPoint
                {
                    Price = pivotHigh,
                    BarIndex = candles[currentIndex].BarIndex,
                    Time = candles[currentIndex].Time,
                    Type = PivotType.High
                };
                
                data.SwingHighs.Add(pivot);
                
                // Update last swing high for BOS
                if (pivotHigh > data.LastSwingHigh || data.LastSwingHigh == 0)
                {
                    data.LastSwingHigh = pivotHigh;
                    data.LastSwingHighBar = candles[currentIndex].BarIndex;
                }
                
                // Limit history
                while (data.SwingHighs.Count > Settings.MaxSwings)
                    data.SwingHighs.RemoveAt(0);
            }
            
            // Check for swing low
            bool isSwingLow = true;
            double pivotLow = candles[currentIndex].Low;
            
            for (int i = -Settings.SwingStrength; i <= Settings.SwingStrength; i++)
            {
                if (i == 0) continue;
                int checkIndex = currentIndex + i;
                if (checkIndex < 0 || checkIndex >= candles.Count) continue;
                
                if (candles[checkIndex].Low <= pivotLow)
                {
                    isSwingLow = false;
                    break;
                }
            }
            
            if (isSwingLow)
            {
                var pivot = new PivotPoint
                {
                    Price = pivotLow,
                    BarIndex = candles[currentIndex].BarIndex,
                    Time = candles[currentIndex].Time,
                    Type = PivotType.Low
                };
                
                data.SwingLows.Add(pivot);
                
                // Update last swing low for BOS
                if (pivotLow < data.LastSwingLow || data.LastSwingLow == double.MaxValue)
                {
                    data.LastSwingLow = pivotLow;
                    data.LastSwingLowBar = candles[currentIndex].BarIndex;
                }
                
                while (data.SwingLows.Count > Settings.MaxSwings)
                    data.SwingLows.RemoveAt(0);
            }
        }
        
        /// <summary>
        /// Detect Break of Structure (BOS)
        /// BOS Long: Price breaks above recent swing high
        /// BOS Short: Price breaks below recent swing low
        /// </summary>
        private void UpdateBOS(ScalpingData data)
        {
            if (data.Candles.Count < 2) return;
            
            var current = data.Candles.Last();
            var previous = data.Candles[data.Candles.Count - 2];
            
            // Reset BOS flags
            data.BOSLongTriggered = false;
            data.BOSShortTriggered = false;
            
            // BOS Long: Break above swing high
            if (data.LastSwingHigh > 0 && 
                current.Close > data.LastSwingHigh && 
                previous.Close <= data.LastSwingHigh)
            {
                data.BOSLongTriggered = true;
                data.BOSLevel = data.LastSwingHigh;
                data.BOSTime = current.Time;
                
                OnBOSDetected?.Invoke(this, new BOSEvent
                {
                    Instrument = data.Instrument,
                    Direction = TradeDirection.Long,
                    Level = data.LastSwingHigh,
                    Time = current.Time
                });
                
                // Reset for next BOS
                data.LastSwingHigh = 0;
            }
            
            // BOS Short: Break below swing low
            if (data.LastSwingLow < double.MaxValue && data.LastSwingLow > 0 &&
                current.Close < data.LastSwingLow && 
                previous.Close >= data.LastSwingLow)
            {
                data.BOSShortTriggered = true;
                data.BOSLevel = data.LastSwingLow;
                data.BOSTime = current.Time;
                
                OnBOSDetected?.Invoke(this, new BOSEvent
                {
                    Instrument = data.Instrument,
                    Direction = TradeDirection.Short,
                    Level = data.LastSwingLow,
                    Time = current.Time
                });
                
                data.LastSwingLow = double.MaxValue;
            }
        }
        
        #endregion

        #region Range & Trendline Detection
        
        /// <summary>
        /// Detect consolidation ranges for breakout trading
        /// </summary>
        private void UpdateRangeDetection(ScalpingData data)
        {
            if (data.Candles.Count < Settings.RangeLookback)
                return;
            
            var recentCandles = data.Candles.TakeLast(Settings.RangeLookback).ToList();
            
            data.RangeHigh = recentCandles.Max(c => c.High);
            data.RangeLow = recentCandles.Min(c => c.Low);
            
            double rangeSize = data.RangeHigh - data.RangeLow;
            double avgRange = data.ATR * 2;
            
            // Valid range: Not too big, not too small
            data.InRange = rangeSize < avgRange && rangeSize > data.ATR * 0.5;
        }
        
        /// <summary>
        /// Update trendlines from swing points
        /// </summary>
        private void UpdateTrendlines(ScalpingData data)
        {
            // Ascending trendline from swing lows
            if (data.SwingLows.Count >= 2)
            {
                var lows = data.SwingLows.TakeLast(5).OrderBy(p => p.BarIndex).ToList();
                
                for (int i = 0; i < lows.Count - 1; i++)
                {
                    for (int j = i + 1; j < lows.Count; j++)
                    {
                        var p1 = lows[i];
                        var p2 = lows[j];
                        
                        if (p2.BarIndex == p1.BarIndex) continue;
                        
                        // Ascending = positive slope
                        if (p2.Price > p1.Price)
                        {
                            double slope = (p2.Price - p1.Price) / (p2.BarIndex - p1.BarIndex);
                            
                            data.TrendlineUp = new Trendline
                            {
                                Id = Guid.NewGuid().ToString("N").Substring(0, 8),
                                StartPrice = p1.Price,
                                StartBar = p1.BarIndex,
                                Slope = slope,
                                Direction = TrendlineDirection.Up,
                                TouchCount = 2,
                                IsValid = true
                            };
                            break;
                        }
                    }
                    if (data.TrendlineUp != null && data.TrendlineUp.IsValid) break;
                }
            }
            
            // Descending trendline from swing highs
            if (data.SwingHighs.Count >= 2)
            {
                var highs = data.SwingHighs.TakeLast(5).OrderBy(p => p.BarIndex).ToList();
                
                for (int i = 0; i < highs.Count - 1; i++)
                {
                    for (int j = i + 1; j < highs.Count; j++)
                    {
                        var p1 = highs[i];
                        var p2 = highs[j];
                        
                        if (p2.BarIndex == p1.BarIndex) continue;
                        
                        // Descending = negative slope
                        if (p2.Price < p1.Price)
                        {
                            double slope = (p2.Price - p1.Price) / (p2.BarIndex - p1.BarIndex);
                            
                            data.TrendlineDown = new Trendline
                            {
                                Id = Guid.NewGuid().ToString("N").Substring(0, 8),
                                StartPrice = p1.Price,
                                StartBar = p1.BarIndex,
                                Slope = slope,
                                Direction = TrendlineDirection.Down,
                                TouchCount = 2,
                                IsValid = true
                            };
                            break;
                        }
                    }
                    if (data.TrendlineDown != null && data.TrendlineDown.IsValid) break;
                }
            }
        }
        
        /// <summary>
        /// Update overall market structure
        /// </summary>
        private void UpdateMarketStructure(ScalpingData data)
        {
            if (data.Candles.Count < 10) return;
            
            var current = data.Candles.Last();
            double emaSlope = data.EMA19 - GetEMAAt(data, 10);
            
            if (emaSlope > data.ATR * 0.1 && current.Close > data.EMA19)
            {
                data.Structure = MarketStructure.Bullish;
            }
            else if (emaSlope < -data.ATR * 0.1 && current.Close < data.EMA19)
            {
                data.Structure = MarketStructure.Bearish;
            }
            else if (data.InRange)
            {
                data.Structure = MarketStructure.Ranging;
            }
            else
            {
                data.Structure = MarketStructure.Unknown;
            }
        }
        
        /// <summary>
        /// Update ICT levels (PDH, PDL, PWH, PWL)
        /// </summary>
        private void UpdateICTLevels(ScalpingData data)
        {
            if (data.Candles.Count < 2) return;
            
            var current = data.Candles.Last();
            var previousCandles = data.Candles.Where(c => c.Time.Date < current.Time.Date).ToList();
            
            // Previous Day High/Low
            var previousDayCandles = previousCandles.Where(c => c.Time.Date == current.Time.Date.AddDays(-1)).ToList();
            if (previousDayCandles.Any())
            {
                data.PDH = previousDayCandles.Max(c => c.High);
                data.PDL = previousDayCandles.Min(c => c.Low);
            }
            
            // Previous Week High/Low (simplified - last 5 trading days)
            var lastWeekCandles = previousCandles.Where(c => c.Time.Date >= current.Time.Date.AddDays(-7)).ToList();
            if (lastWeekCandles.Any())
            {
                data.PWH = lastWeekCandles.Max(c => c.High);
                data.PWL = lastWeekCandles.Min(c => c.Low);
            }
        }
        
        /// <summary>
        /// Detect Emmanuel's 8 scalping patterns
        /// </summary>
        private void DetectPatterns(ScalpingData data)
        {
            if (data.Candles.Count < 20) return;
            
            var current = data.Candles.Last();
            var prev = data.Candles.Count > 1 ? data.Candles[data.Candles.Count - 2] : current;
            
            // Check each pattern type
            foreach (EmmanuelPatternType patternType in Enum.GetValues(typeof(EmmanuelPatternType)))
            {
                if (patternType == EmmanuelPatternType.None) continue;
                
                var signal = CheckPattern(data, patternType, current, prev);
                if (signal != null)
                {
                    lock (_lock)
                    {
                        _activeSignals.Add(signal);
                    }
                    OnSetupDetected?.Invoke(this, signal);
                    OnNewSignal?.Invoke(this, signal);
                }
            }
        }
        
        /// <summary>
        /// Check specific pattern
        /// </summary>
        private ScalpingSignal CheckPattern(ScalpingData data, EmmanuelPatternType patternType, CandleData current, CandleData prev)
        {
            // Check if pattern already detected recently (within 5 bars)
            if (_activeSignals.Any(s => s.Pattern == patternType && s.Instrument == data.Instrument && 
                                        current.BarIndex - s.BarIndex < 5))
                return null;
            
            bool isValid = false;
            bool isLong = false;
            double entry = 0, sl = 0, tp1 = 0, tp2 = 0, tp3 = 0;
            
            switch (patternType)
            {
                case EmmanuelPatternType.EMA19_Support:
                    isValid = CheckEMA19Support(data, current, out isLong, out entry, out sl, out tp1, out tp2, out tp3);
                    break;
                case EmmanuelPatternType.EMA19_Resistance:
                    isValid = CheckEMA19Resistance(data, current, out isLong, out entry, out sl, out tp1, out tp2, out tp3);
                    break;
                case EmmanuelPatternType.BOS_Continuation:
                    isValid = CheckBOSContinuation(data, current, out isLong, out entry, out sl, out tp1, out tp2, out tp3);
                    break;
                // Add other pattern checks as needed
            }
            
            if (!isValid) return null;
            
            return new ScalpingSignal
            {
                Instrument = data.Instrument,
                Pattern = patternType,
                IsLong = isLong,
                EntryPrice = entry,
                StopLoss = sl,
                TakeProfit1 = tp1,
                TakeProfit2 = tp2,
                TakeProfit3 = tp3,
                Time = current.Time,
                BarIndex = current.BarIndex,
                ATR = data.ATR,
                EMA19 = data.EMA19,
                Volume = current.Volume,
                VolumeSMA = data.VolumeSMA,
                Structure = data.Structure,
                ConfluenceScore = CalculateConfluenceScore(data, isLong ? 1 : -1)
            };
        }
        
        private bool CheckEMA19Support(ScalpingData data, CandleData current, out bool isLong, 
            out double entry, out double sl, out double tp1, out double tp2, out double tp3)
        {
            isLong = true; entry = sl = tp1 = tp2 = tp3 = 0;
            
            // Price touching EMA from above in uptrend
            if (data.Structure != MarketStructure.Bullish) return false;
            if (current.Low > data.EMA19 * 1.002) return false; // Not touching
            if (current.Close < data.EMA19) return false; // Closed below
            
            entry = current.Close;
            sl = data.EMA19 - data.ATR * 1.0;
            double risk = entry - sl;
            tp1 = entry + risk * 1.5;
            tp2 = entry + risk * 2.5;
            tp3 = entry + risk * 4.0;
            
            return true;
        }
        
        private bool CheckEMA19Resistance(ScalpingData data, CandleData current, out bool isLong,
            out double entry, out double sl, out double tp1, out double tp2, out double tp3)
        {
            isLong = false; entry = sl = tp1 = tp2 = tp3 = 0;
            
            // Price touching EMA from below in downtrend
            if (data.Structure != MarketStructure.Bearish) return false;
            if (current.High < data.EMA19 * 0.998) return false; // Not touching
            if (current.Close > data.EMA19) return false; // Closed above
            
            entry = current.Close;
            sl = data.EMA19 + data.ATR * 1.0;
            double risk = sl - entry;
            tp1 = entry - risk * 1.5;
            tp2 = entry - risk * 2.5;
            tp3 = entry - risk * 4.0;
            
            return true;
        }
        
        private bool CheckBOSContinuation(ScalpingData data, CandleData current, out bool isLong,
            out double entry, out double sl, out double tp1, out double tp2, out double tp3)
        {
            isLong = false; entry = sl = tp1 = tp2 = tp3 = 0;
            
            if (!data.BOSLongTriggered && !data.BOSShortTriggered) return false;
            
            isLong = data.BOSLongTriggered;
            entry = current.Close;
            
            if (isLong)
            {
                sl = data.LastSwingLow - data.ATR * 0.5;
                double risk = entry - sl;
                tp1 = entry + risk * 2.0;
                tp2 = entry + risk * 3.0;
                tp3 = data.PDH > 0 ? data.PDH : entry + risk * 5.0;
            }
            else
            {
                sl = data.LastSwingHigh + data.ATR * 0.5;
                double risk = sl - entry;
                tp1 = entry - risk * 2.0;
                tp2 = entry - risk * 3.0;
                tp3 = data.PDL > 0 ? data.PDL : entry - risk * 5.0;
            }
            
            return true;
        }
        
        private double GetEMAAt(ScalpingData data, int barsAgo)
        {
            // Approximate EMA calculation for historical bars
            // In real implementation, this would come from NinjaTrader indicator
            if (data.Candles.Count <= barsAgo) return data.EMA19;
            
            // Simple approximation
            return data.EMA19 - (data.Candles.Last().Close - data.Candles[data.Candles.Count - 1 - barsAgo].Close) * 0.1;
        }
        
        #endregion

        #region ICT Level Detection
        
        /// <summary>
        /// Check if price is near an ICT level
        /// </summary>
        public bool IsNearICTLevel(ScalpingData data, double price, out ICTLevelType levelType, out int expectedDirection)
        {
            levelType = ICTLevelType.None;
            expectedDirection = 0;
            double tolerance = data.ATR * Settings.ICTLevelTolerance;
            
            // PDH (resistance - expect short)
            if (data.PDH > 0 && Math.Abs(price - data.PDH) < tolerance)
            {
                levelType = ICTLevelType.PDH;
                expectedDirection = -1;
                return true;
            }
            
            // PDL (support - expect long)
            if (data.PDL > 0 && Math.Abs(price - data.PDL) < tolerance)
            {
                levelType = ICTLevelType.PDL;
                expectedDirection = 1;
                return true;
            }
            
            // PWH (resistance - expect short)
            if (data.PWH > 0 && Math.Abs(price - data.PWH) < tolerance)
            {
                levelType = ICTLevelType.PWH;
                expectedDirection = -1;
                return true;
            }
            
            // PWL (support - expect long)
            if (data.PWL > 0 && Math.Abs(price - data.PWL) < tolerance)
            {
                levelType = ICTLevelType.PWL;
                expectedDirection = 1;
                return true;
            }
            
            return false;
        }
        
        #endregion

        #region Confluence Scoring
        
        /// <summary>
        /// Calculate confluence score (max 10 points)
        /// Based on documented factors from Emmanuel's trading
        /// </summary>
        public int CalculateConfluenceScore(ScalpingData data, int direction)
        {
            if (data.Candles.Count < 10) return 0;
            
            int score = 0;
            var current = data.Candles.Last();
            
            // ═══════════════════════════════════════════════════════════════════════
            // REQUIRED FACTORS (Max 5 points)
            // ═══════════════════════════════════════════════════════════════════════
            
            // 1. EMA 19 Position (+2 points)
            bool emaPositionOk = (direction == 1 && current.Close > data.EMA19) ||
                                 (direction == -1 && current.Close < data.EMA19);
            if (emaPositionOk)
                score += 2;
            
            // 2. EMA 19 Slope (+2 points)
            double emaSlope = data.EMA19 - GetEMAAt(data, 5);
            bool emaSlopeOk = (direction == 1 && emaSlope > 0) ||
                             (direction == -1 && emaSlope < 0);
            if (emaSlopeOk)
                score += 2;
            
            // 3. Momentum Candle (+1 point)
            double bodySize = Math.Abs(current.Close - current.Open);
            bool hasMomentum = bodySize > data.ATR * 0.5;
            bool correctDirection = (direction == 1 && current.Close > current.Open) ||
                                   (direction == -1 && current.Close < current.Open);
            if (hasMomentum && correctDirection)
                score += 1;
            
            // ═══════════════════════════════════════════════════════════════════════
            // IMPORTANT FACTORS (Max 3 points)
            // ═══════════════════════════════════════════════════════════════════════
            
            // 4. Volume Spike (+1 point)
            if (current.Volume > data.VolumeSMA * Settings.VolumeSpikeMultiplier)
                score += 1;
            
            // 5. Near ICT Level (+1 point)
            ICTLevelType levelType;
            int levelDir;
            if (IsNearICTLevel(data, current.Close, out levelType, out levelDir))
            {
                if (levelDir == direction)
                    score += 1;
            }
            
            // 6. BOS Confirmed (+1 point)
            if ((direction == 1 && data.BOSLongTriggered) ||
                (direction == -1 && data.BOSShortTriggered))
                score += 1;
            
            // ═══════════════════════════════════════════════════════════════════════
            // BONUS FACTORS (Max 2 points)
            // ═══════════════════════════════════════════════════════════════════════
            
            // 7. Trading Session (+1 point)
            if (IsGoodTradingSession(current.Time))
                score += 1;
            
            // 8. HTF Aligned - 60min (+1 point)
            if (data.EMA19_60m > 0)
            {
                // Approximate HTF slope
                bool htfAligned = (direction == 1 && current.Close > data.EMA19_60m) ||
                                 (direction == -1 && current.Close < data.EMA19_60m);
                if (htfAligned)
                    score += 1;
            }
            
            return score; // Max: 10
        }
        
        /// <summary>
        /// Check if in good trading session
        /// Best: 9:30-11:30 ET (NY Open)
        /// Good: 14:00-16:00 ET (NY Afternoon)
        /// </summary>
        private bool IsGoodTradingSession(DateTime time)
        {
            int hour = time.Hour;
            int minute = time.Minute;
            int timeInt = hour * 100 + minute;
            
            // NY Open: 9:30 - 11:30 ET
            bool nyOpen = timeInt >= 930 && timeInt <= 1130;
            
            // NY Afternoon: 14:00 - 16:00 ET
            bool nyAfternoon = timeInt >= 1400 && timeInt <= 1600;
            
            return nyOpen || nyAfternoon;
        }
        
        #endregion

        #region Emmanuel Pattern Detection
        
        /// <summary>
        /// Check all 8 Emmanuel patterns and generate signals
        /// </summary>
        private void CheckEmmanuelPatterns(ScalpingData data)
        {
            if (data.Candles.Count < Settings.MinBarsRequired) return;
            
            var current = data.Candles.Last();
            
            // Calculate confluence for both directions
            int longConf = CalculateConfluenceScore(data, 1);
            int shortConf = CalculateConfluenceScore(data, -1);
            
            // Pattern priority order based on frequency and win rate
            
            // 1. EMA Bounce (~20%, 80% WR)
            if (Settings.EnableEMABounce)
            {
                if (longConf >= Settings.MinConfluenceScore && CheckEMABounce(data, 1))
                    GenerateSignal(data, EmmanuelPatternType.EMABounce, true, current, longConf, "EMA bounce support");
                if (shortConf >= Settings.MinConfluenceScore && CheckEMABounce(data, -1))
                    GenerateSignal(data, EmmanuelPatternType.EMABounce, false, current, shortConf, "EMA bounce resistance");
            }
            
            // 2. Range Breakout (~20%, 80% WR)
            if (Settings.EnableRangeBreakout)
            {
                if (longConf >= Settings.MinConfluenceScore && CheckRangeBreakout(data, 1))
                    GenerateSignal(data, EmmanuelPatternType.RangeBreakout, true, current, longConf, "Bullish range breakout");
                if (shortConf >= Settings.MinConfluenceScore && CheckRangeBreakout(data, -1))
                    GenerateSignal(data, EmmanuelPatternType.RangeBreakout, false, current, shortConf, "Bearish range breakout");
            }
            
            // 3. Trendline Trading (~15%, 75% WR)
            if (Settings.EnableTrendlineTrading)
            {
                if (longConf >= Settings.MinConfluenceScore && CheckTrendlineTrading(data, 1))
                    GenerateSignal(data, EmmanuelPatternType.TrendlineTrading, true, current, longConf, "Ascending trendline bounce");
                if (shortConf >= Settings.MinConfluenceScore && CheckTrendlineTrading(data, -1))
                    GenerateSignal(data, EmmanuelPatternType.TrendlineTrading, false, current, shortConf, "Descending trendline rejection");
            }
            
            // 4. Zone Trading (~15%, 80% WR)
            if (Settings.EnableZoneTrading)
            {
                if (longConf >= Settings.MinConfluenceScore && CheckZoneTrading(data, 1))
                    GenerateSignal(data, EmmanuelPatternType.ZoneTrading, true, current, longConf, "Support zone bounce");
                if (shortConf >= Settings.MinConfluenceScore && CheckZoneTrading(data, -1))
                    GenerateSignal(data, EmmanuelPatternType.ZoneTrading, false, current, shortConf, "Resistance zone rejection");
            }
            
            // 5. ICT Level Bounce (~10%, 75% WR)
            if (Settings.EnableICTLevelBounce)
            {
                if (longConf >= Settings.MinConfluenceScore && CheckICTLevelBounce(data, 1))
                    GenerateSignal(data, EmmanuelPatternType.ICTLevelBounce, true, current, longConf, "ICT level support");
                if (shortConf >= Settings.MinConfluenceScore && CheckICTLevelBounce(data, -1))
                    GenerateSignal(data, EmmanuelPatternType.ICTLevelBounce, false, current, shortConf, "ICT level resistance");
            }
            
            // 6. BOS Entry (~10%, 80% WR)
            if (Settings.EnableBOSEntry)
            {
                if (longConf >= Settings.MinConfluenceScore && CheckBOSEntry(data, 1))
                    GenerateSignal(data, EmmanuelPatternType.BOSEntry, true, current, longConf, "BOS long entry");
                if (shortConf >= Settings.MinConfluenceScore && CheckBOSEntry(data, -1))
                    GenerateSignal(data, EmmanuelPatternType.BOSEntry, false, current, shortConf, "BOS short entry");
            }
            
            // 7. Liquidity Sweep (~5%, 75% WR)
            if (Settings.EnableLiquiditySweep)
            {
                if (longConf >= Settings.MinConfluenceScore && CheckLiquiditySweep(data, 1))
                    GenerateSignal(data, EmmanuelPatternType.LiquiditySweep, true, current, longConf, "Bullish liquidity sweep");
                if (shortConf >= Settings.MinConfluenceScore && CheckLiquiditySweep(data, -1))
                    GenerateSignal(data, EmmanuelPatternType.LiquiditySweep, false, current, shortConf, "Bearish liquidity sweep");
            }
            
            // 8. Trend Continuation (~5%, 70% WR)
            if (Settings.EnableTrendContinuation)
            {
                if (longConf >= Settings.MinConfluenceScore && CheckTrendContinuation(data, 1))
                    GenerateSignal(data, EmmanuelPatternType.TrendContinuation, true, current, longConf, "Uptrend continuation");
                if (shortConf >= Settings.MinConfluenceScore && CheckTrendContinuation(data, -1))
                    GenerateSignal(data, EmmanuelPatternType.TrendContinuation, false, current, shortConf, "Downtrend continuation");
            }
        }
        
        // ═══════════════════════════════════════════════════════════════════════════
        // PATTERN 1: EMA BOUNCE
        // Price touches EMA 19 and bounces in trend direction
        // ═══════════════════════════════════════════════════════════════════════════
        private bool CheckEMABounce(ScalpingData data, int direction)
        {
            if (data.Candles.Count < 5) return false;
            
            var current = data.Candles.Last();
            
            // Price should be close to EMA
            double distToEMA = Math.Abs(current.Close - data.EMA19);
            if (distToEMA > data.ATR * 0.5)
                return false;
            
            // EMA slope should match direction
            double emaSlope = data.EMA19 - GetEMAAt(data, 3);
            bool correctSlope = (direction == 1 && emaSlope > 0) || 
                               (direction == -1 && emaSlope < 0);
            if (!correctSlope)
                return false;
            
            // Look for touch in recent bars
            bool touchedEMA = false;
            for (int i = 1; i <= 3 && i < data.Candles.Count; i++)
            {
                var candle = data.Candles[data.Candles.Count - 1 - i];
                double emaAtBar = GetEMAAt(data, i);
                
                if (direction == 1)
                {
                    // For long: Low touched EMA but closed above
                    if (candle.Low <= emaAtBar * 1.001 && candle.Close > emaAtBar)
                    {
                        touchedEMA = true;
                        break;
                    }
                }
                else
                {
                    // For short: High touched EMA but closed below
                    if (candle.High >= emaAtBar * 0.999 && candle.Close < emaAtBar)
                    {
                        touchedEMA = true;
                        break;
                    }
                }
            }
            
            if (!touchedEMA)
                return false;
            
            // Current candle should show momentum in direction
            bool momentum = (direction == 1 && current.Close > current.Open && current.Close > data.EMA19) ||
                           (direction == -1 && current.Close < current.Open && current.Close < data.EMA19);
            
            return momentum;
        }
        
        // ═══════════════════════════════════════════════════════════════════════════
        // PATTERN 2: RANGE BREAKOUT
        // Price breaks out of consolidation range with momentum
        // ═══════════════════════════════════════════════════════════════════════════
        private bool CheckRangeBreakout(ScalpingData data, int direction)
        {
            if (!data.InRange)
                return false;
            
            var current = data.Candles.Last();
            
            // Check for breakout with momentum
            double bodySize = Math.Abs(current.Close - current.Open);
            bool hasMomentum = bodySize > data.ATR * 0.5;
            bool hasVolume = current.Volume > data.VolumeSMA * Settings.VolumeSpikeMultiplier;
            
            if (direction == 1)
            {
                // Bullish breakout
                bool breakout = current.Close > data.RangeHigh && current.Close > current.Open;
                return breakout && hasMomentum && hasVolume;
            }
            else
            {
                // Bearish breakout
                bool breakout = current.Close < data.RangeLow && current.Close < current.Open;
                return breakout && hasMomentum && hasVolume;
            }
        }
        
        // ═══════════════════════════════════════════════════════════════════════════
        // PATTERN 3: TRENDLINE TRADING
        // Touch or bounce of diagonal trendline
        // ═══════════════════════════════════════════════════════════════════════════
        private bool CheckTrendlineTrading(ScalpingData data, int direction)
        {
            var current = data.Candles.Last();
            
            if (direction == 1)
            {
                // Looking for bounce from ascending trendline (support)
                if (data.TrendlineUp == null || !data.TrendlineUp.IsValid)
                    return false;
                
                double trendlineNow = data.TrendlineUp.GetPriceAtBar(current.BarIndex);
                
                // Price should be near trendline
                bool nearTrendline = Math.Abs(current.Low - trendlineNow) < data.ATR * 0.3;
                
                // Bullish candle for bounce
                bool bullishCandle = current.Close > current.Open && current.Close > trendlineNow;
                
                return nearTrendline && bullishCandle && data.TrendlineUp.Slope > 0;
            }
            else
            {
                // Looking for rejection from descending trendline (resistance)
                if (data.TrendlineDown == null || !data.TrendlineDown.IsValid)
                    return false;
                
                double trendlineNow = data.TrendlineDown.GetPriceAtBar(current.BarIndex);
                
                bool nearTrendline = Math.Abs(current.High - trendlineNow) < data.ATR * 0.3;
                bool bearishCandle = current.Close < current.Open && current.Close < trendlineNow;
                
                return nearTrendline && bearishCandle && data.TrendlineDown.Slope < 0;
            }
        }
        
        // ═══════════════════════════════════════════════════════════════════════════
        // PATTERN 4: ZONE TRADING
        // Reaction from support/resistance zone (ICT levels)
        // ═══════════════════════════════════════════════════════════════════════════
        private bool CheckZoneTrading(ScalpingData data, int direction)
        {
            var current = data.Candles.Last();
            
            ICTLevelType levelType;
            int expectedDir;
            
            if (!IsNearICTLevel(data, current.Close, out levelType, out expectedDir))
                return false;
            
            if (expectedDir != direction)
                return false;
            
            // Look for rejection candle
            bool rejection = false;
            
            if (direction == 1)
            {
                // Bullish rejection (long lower wick)
                double lowerWick = Math.Min(current.Open, current.Close) - current.Low;
                double body = Math.Abs(current.Close - current.Open);
                rejection = body > 0 && lowerWick > body * 1.5 && current.Close > current.Open;
            }
            else
            {
                // Bearish rejection (long upper wick)
                double upperWick = current.High - Math.Max(current.Open, current.Close);
                double body = Math.Abs(current.Close - current.Open);
                rejection = body > 0 && upperWick > body * 1.5 && current.Close < current.Open;
            }
            
            // Volume confirmation
            bool hasVolume = current.Volume > data.VolumeSMA * 1.2;
            
            return rejection && hasVolume;
        }
        
        // ═══════════════════════════════════════════════════════════════════════════
        // PATTERN 5: ICT LEVEL BOUNCE
        // Bounce from PDH/PDL/PWH/PWL
        // ═══════════════════════════════════════════════════════════════════════════
        private bool CheckICTLevelBounce(ScalpingData data, int direction)
        {
            var current = data.Candles.Last();
            
            ICTLevelType levelType;
            int expectedDir;
            
            if (!IsNearICTLevel(data, current.Close, out levelType, out expectedDir))
                return false;
            
            if (expectedDir != direction)
                return false;
            
            // Fire event
            OnICTLevelTouched?.Invoke(this, new ICTLevelEvent
            {
                Instrument = data.Instrument,
                Level = levelType,
                Price = current.Close,
                Time = current.Time
            });
            
            // Momentum candle in direction
            bool momentum = (direction == 1 && current.Close > current.Open) ||
                           (direction == -1 && current.Close < current.Open);
            
            // Volume confirmation
            bool hasVolume = current.Volume > data.VolumeSMA * 1.2;
            
            return momentum && hasVolume;
        }
        
        // ═══════════════════════════════════════════════════════════════════════════
        // PATTERN 6: BOS ENTRY
        // Entry after Break of Structure confirmation
        // ═══════════════════════════════════════════════════════════════════════════
        private bool CheckBOSEntry(ScalpingData data, int direction)
        {
            var current = data.Candles.Last();
            
            if (direction == 1)
            {
                // BOS Long was triggered, look for pullback entry
                if (!data.BOSLongTriggered && data.BOSLevel == 0)
                    return false;
                
                // Wait for pullback to EMA
                bool hadPullback = current.Low <= data.EMA19 * 1.002;
                bool bouncing = current.Close > current.Open && current.Close > data.EMA19;
                
                return hadPullback && bouncing;
            }
            else
            {
                // BOS Short was triggered
                if (!data.BOSShortTriggered && data.BOSLevel == 0)
                    return false;
                
                bool hadPullback = current.High >= data.EMA19 * 0.998;
                bool rejecting = current.Close < current.Open && current.Close < data.EMA19;
                
                return hadPullback && rejecting;
            }
        }
        
        // ═══════════════════════════════════════════════════════════════════════════
        // PATTERN 7: LIQUIDITY SWEEP
        // Price sweeps highs/lows then reverses
        // ═══════════════════════════════════════════════════════════════════════════
        private bool CheckLiquiditySweep(ScalpingData data, int direction)
        {
            if (data.Candles.Count < Settings.LiquiditySweepLookback + 2)
                return false;
            
            var current = data.Candles.Last();
            var previous = data.Candles[data.Candles.Count - 2];
            
            // Find recent high/low
            double recentHigh = double.MinValue;
            double recentLow = double.MaxValue;
            
            for (int i = 2; i <= Settings.LiquiditySweepLookback && i < data.Candles.Count; i++)
            {
                var candle = data.Candles[data.Candles.Count - 1 - i];
                if (candle.High > recentHigh) recentHigh = candle.High;
                if (candle.Low < recentLow) recentLow = candle.Low;
            }
            
            if (direction == 1)
            {
                // Bullish sweep: Swept lows then reversed
                bool sweptLow = previous.Low < recentLow;
                bool reversedUp = previous.Close > recentLow && current.Close > previous.Close;
                
                // Long lower wick on sweep bar
                double range = previous.High - previous.Low;
                double lowerWick = Math.Min(previous.Open, previous.Close) - previous.Low;
                bool wickyCandle = range > 0 && lowerWick > range * 0.6;
                
                return sweptLow && reversedUp && wickyCandle;
            }
            else
            {
                // Bearish sweep: Swept highs then reversed
                bool sweptHigh = previous.High > recentHigh;
                bool reversedDown = previous.Close < recentHigh && current.Close < previous.Close;
                
                double range = previous.High - previous.Low;
                double upperWick = previous.High - Math.Max(previous.Open, previous.Close);
                bool wickyCandle = range > 0 && upperWick > range * 0.6;
                
                return sweptHigh && reversedDown && wickyCandle;
            }
        }
        
        // ═══════════════════════════════════════════════════════════════════════════
        // PATTERN 8: TREND CONTINUATION
        // Pullback in established trend
        // ═══════════════════════════════════════════════════════════════════════════
        private bool CheckTrendContinuation(ScalpingData data, int direction)
        {
            if (data.Candles.Count < 12) return false;
            
            var current = data.Candles.Last();
            
            // Check for established trend
            double emaSlope = data.EMA19 - GetEMAAt(data, 10);
            bool strongTrend = Math.Abs(emaSlope) > data.ATR * 0.3;
            
            if (!strongTrend)
                return false;
            
            if (direction == 1)
            {
                // Uptrend continuation
                if (emaSlope <= 0)
                    return false;
                
                // Pullback to EMA in recent bars
                bool pulledBack = false;
                for (int i = 1; i <= 3 && i < data.Candles.Count; i++)
                {
                    var candle = data.Candles[data.Candles.Count - 1 - i];
                    double emaAtBar = GetEMAAt(data, i);
                    if (candle.Low <= emaAtBar * 1.005)
                    {
                        pulledBack = true;
                        break;
                    }
                }
                
                bool resuming = current.Close > current.Open && current.Close > data.EMA19;
                
                return pulledBack && resuming;
            }
            else
            {
                // Downtrend continuation
                if (emaSlope >= 0)
                    return false;
                
                bool pulledBack = false;
                for (int i = 1; i <= 3 && i < data.Candles.Count; i++)
                {
                    var candle = data.Candles[data.Candles.Count - 1 - i];
                    double emaAtBar = GetEMAAt(data, i);
                    if (candle.High >= emaAtBar * 0.995)
                    {
                        pulledBack = true;
                        break;
                    }
                }
                
                bool resuming = current.Close < current.Open && current.Close < data.EMA19;
                
                return pulledBack && resuming;
            }
        }
        
        #endregion

        #region Candle Pattern Detection
        
        /// <summary>
        /// Detect candle pattern
        /// </summary>
        private void DetectCandlePattern(ScalpingData data, CandleData candle)
        {
            double body = Math.Abs(candle.Close - candle.Open);
            double range = candle.High - candle.Low;
            double upperWick = candle.High - Math.Max(candle.Open, candle.Close);
            double lowerWick = Math.Min(candle.Open, candle.Close) - candle.Low;
            bool isBullish = candle.Close > candle.Open;
            
            candle.Pattern = CandlePattern.None;
            
            if (range < 0.0001) return;
            
            double bodyRatio = body / range;
            double upperWickRatio = upperWick / range;
            double lowerWickRatio = lowerWick / range;
            
            // Doji
            if (bodyRatio < 0.1)
            {
                candle.Pattern = CandlePattern.Doji;
                return;
            }
            
            // Hammer (bullish, long lower wick)
            if (isBullish && lowerWickRatio > 0.6 && upperWickRatio < 0.1)
            {
                candle.Pattern = CandlePattern.Hammer;
                return;
            }
            
            // Inverted Hammer
            if (isBullish && upperWickRatio > 0.6 && lowerWickRatio < 0.1)
            {
                candle.Pattern = CandlePattern.InvertedHammer;
                return;
            }
            
            // Shooting Star (bearish, long upper wick)
            if (!isBullish && upperWickRatio > 0.6 && lowerWickRatio < 0.1)
            {
                candle.Pattern = CandlePattern.ShootingStar;
                return;
            }
            
            // Hanging Man
            if (!isBullish && lowerWickRatio > 0.6 && upperWickRatio < 0.1)
            {
                candle.Pattern = CandlePattern.HangingMan;
                return;
            }
            
            // Pin Bar
            if (lowerWickRatio > 0.7 && bodyRatio < 0.2)
            {
                candle.Pattern = CandlePattern.BullishPinBar;
                return;
            }
            if (upperWickRatio > 0.7 && bodyRatio < 0.2)
            {
                candle.Pattern = CandlePattern.BearishPinBar;
                return;
            }
            
            // Marubozu (no wicks)
            if (bodyRatio > 0.9)
            {
                candle.Pattern = isBullish ? CandlePattern.BullishMarubozu : CandlePattern.BearishMarubozu;
                return;
            }
            
            // Engulfing (requires previous candle)
            if (data.Candles.Count >= 2)
            {
                var prev = data.Candles[data.Candles.Count - 2];
                bool prevBullish = prev.Close > prev.Open;
                
                if (isBullish && !prevBullish && 
                    candle.Open <= prev.Close && candle.Close >= prev.Open)
                {
                    candle.Pattern = CandlePattern.BullishEngulfing;
                    return;
                }
                
                if (!isBullish && prevBullish && 
                    candle.Open >= prev.Close && candle.Close <= prev.Open)
                {
                    candle.Pattern = CandlePattern.BearishEngulfing;
                    return;
                }
            }
        }
        
        #endregion

        #region Signal Generation
        
        /// <summary>
        /// Generate a scalping signal
        /// </summary>
        private void GenerateSignal(ScalpingData data, EmmanuelPatternType pattern, bool isLong, 
                                    CandleData candle, int confluenceScore, string description)
        {
            // Avoid duplicates
            if (_activeSignals.Any(s => s.Instrument == data.Instrument && 
                                        s.Pattern == pattern && 
                                        s.BarIndex == candle.BarIndex))
                return;
            
            var signal = new ScalpingSignal
            {
                Id = Guid.NewGuid().ToString("N").Substring(0, 8),
                Instrument = data.Instrument,
                Pattern = pattern,
                IsLong = isLong,
                EntryPrice = candle.Close,
                Time = candle.Time,
                BarIndex = candle.BarIndex,
                Description = description,
                ATR = data.ATR,
                EMA19 = data.EMA19,
                Volume = candle.Volume,
                VolumeSMA = data.VolumeSMA,
                CandlePattern = candle.Pattern,
                Structure = data.Structure,
                ConfluenceScore = confluenceScore
            };
            
            // Calculate SL and TP based on pattern
            double slMultiplier = GetStopMultiplier(pattern);
            double slDistance = data.ATR * slMultiplier;
            
            signal.StopLoss = isLong ? candle.Close - slDistance : candle.Close + slDistance;
            signal.TakeProfit1 = isLong ? candle.Close + slDistance * Settings.TP1RMultiple : candle.Close - slDistance * Settings.TP1RMultiple;
            signal.TakeProfit2 = isLong ? candle.Close + slDistance * Settings.TP2RMultiple : candle.Close - slDistance * Settings.TP2RMultiple;
            signal.TakeProfit3 = isLong ? candle.Close + slDistance * Settings.RunnerRMultiple : candle.Close - slDistance * Settings.RunnerRMultiple;
            
            // Calculate expected win rate based on pattern
            signal.ExpectedWinRate = GetPatternWinRate(pattern);
            
            _activeSignals.Add(signal);
            
            OnSetupDetected?.Invoke(this, signal);
        }
        
        /// <summary>
        /// Get stop loss multiplier by pattern
        /// </summary>
        private double GetStopMultiplier(EmmanuelPatternType pattern)
        {
            switch (pattern)
            {
                case EmmanuelPatternType.EMABounce: return 1.2;
                case EmmanuelPatternType.RangeBreakout: return 1.5;
                case EmmanuelPatternType.TrendlineTrading: return 1.5;
                case EmmanuelPatternType.ZoneTrading: return 1.3;
                case EmmanuelPatternType.ICTLevelBounce: return 1.3;
                case EmmanuelPatternType.BOSEntry: return 1.5;
                case EmmanuelPatternType.LiquiditySweep: return 1.8;
                case EmmanuelPatternType.TrendContinuation: return 1.5;
                default: return 1.5;
            }
        }
        
        /// <summary>
        /// Get expected win rate by pattern (from documented data)
        /// </summary>
        private double GetPatternWinRate(EmmanuelPatternType pattern)
        {
            switch (pattern)
            {
                case EmmanuelPatternType.EMABounce: return 0.80;
                case EmmanuelPatternType.RangeBreakout: return 0.80;
                case EmmanuelPatternType.TrendlineTrading: return 0.75;
                case EmmanuelPatternType.ZoneTrading: return 0.80;
                case EmmanuelPatternType.ICTLevelBounce: return 0.75;
                case EmmanuelPatternType.BOSEntry: return 0.80;
                case EmmanuelPatternType.LiquiditySweep: return 0.75;
                case EmmanuelPatternType.TrendContinuation: return 0.70;
                default: return 0.70;
            }
        }
        
        private void CleanupExpiredSignals(DateTime currentTime)
        {
            _activeSignals.RemoveAll(s => (currentTime - s.Time).TotalMinutes > Settings.SignalExpiryMinutes);
        }
        
        #endregion

        #region Public Interface
        
        /// <summary>
        /// Get active signals
        /// </summary>
        public List<ScalpingSignal> GetActiveSignals(string instrument = null)
        {
            lock (_lock)
            {
                if (string.IsNullOrEmpty(instrument))
                    return _activeSignals.ToList();
                
                return _activeSignals.Where(s => s.Instrument == instrument).ToList();
            }
        }
        
        /// <summary>
        /// Get signals filtered by minimum confluence
        /// </summary>
        public List<ScalpingSignal> GetHighConfluenceSignals(string instrument, int minConfluence = 6)
        {
            lock (_lock)
            {
                return _activeSignals
                    .Where(s => s.Instrument == instrument && s.ConfluenceScore >= minConfluence)
                    .OrderByDescending(s => s.ConfluenceScore)
                    .ToList();
            }
        }
        
        /// <summary>
        /// Get scalping data for an instrument
        /// </summary>
        public ScalpingData GetScalpingData(string instrument)
        {
            lock (_lock)
            {
                return _dataByInstrument.TryGetValue(instrument, out var data) ? data : null;
            }
        }
        
        /// <summary>
        /// Get ICT levels
        /// </summary>
        public (double PDH, double PDL, double PWH, double PWL) GetICTLevels(string instrument)
        {
            var data = GetScalpingData(instrument);
            if (data == null) return (0, 0, 0, 0);
            return (data.PDH, data.PDL, data.PWH, data.PWL);
        }
        
        /// <summary>
        /// Get trendlines
        /// </summary>
        public (Trendline Up, Trendline Down) GetTrendlines(string instrument)
        {
            var data = GetScalpingData(instrument);
            return (data?.TrendlineUp, data?.TrendlineDown);
        }
        
        /// <summary>
        /// Get market structure
        /// </summary>
        public MarketStructure GetMarketStructure(string instrument)
        {
            var data = GetScalpingData(instrument);
            return data?.Structure ?? MarketStructure.Unknown;
        }
        
        /// <summary>
        /// Check if BOS is active
        /// </summary>
        public (bool Long, bool Short, double Level) GetBOSStatus(string instrument)
        {
            var data = GetScalpingData(instrument);
            if (data == null) return (false, false, 0);
            return (data.BOSLongTriggered, data.BOSShortTriggered, data.BOSLevel);
        }
        
        /// <summary>
        /// Invalidate a signal
        /// </summary>
        public void InvalidateSignal(string signalId, string reason)
        {
            lock (_lock)
            {
                var signal = _activeSignals.FirstOrDefault(s => s.Id == signalId);
                if (signal != null)
                {
                    _activeSignals.Remove(signal);
                    OnSetupInvalidated?.Invoke(this, signal);
                }
            }
        }
        
        #endregion
    }

    #region Supporting Classes
    
    /// <summary>
    /// Scalping settings - Emmanuel configuration
    /// </summary>
    public class ScalpingSettings
    {
        // ═══════════════════════════════════════════════════════════════════════
        // EMA SETTINGS - CONFIRMED: 19
        // ═══════════════════════════════════════════════════════════════════════
        public int EMAPeriod { get; set; } = 19;  // Confirmed 6x+
        public int ATRPeriod { get; set; } = 14;
        public int VolumeMAPeriod { get; set; } = 20;
        
        // ═══════════════════════════════════════════════════════════════════════
        // CONFLUENCE SCORING
        // ═══════════════════════════════════════════════════════════════════════
        public int MinConfluenceScore { get; set; } = 4;  // Minimum 4 recommended
        public double VolumeSpikeMultiplier { get; set; } = 1.3;
        
        // ═══════════════════════════════════════════════════════════════════════
        // PATTERN ENABLES
        // ═══════════════════════════════════════════════════════════════════════
        public bool EnableEMABounce { get; set; } = true;
        public bool EnableRangeBreakout { get; set; } = true;
        public bool EnableTrendlineTrading { get; set; } = true;
        public bool EnableZoneTrading { get; set; } = true;
        public bool EnableICTLevelBounce { get; set; } = true;
        public bool EnableBOSEntry { get; set; } = true;
        public bool EnableLiquiditySweep { get; set; } = true;
        public bool EnableTrendContinuation { get; set; } = true;
        
        // ═══════════════════════════════════════════════════════════════════════
        // TAKE PROFIT SCALING - FROM DOCUMENTED DATA
        // ═══════════════════════════════════════════════════════════════════════
        public double TP1RMultiple { get; set; } = 1.5;   // 50% at 1.5R
        public double TP2RMultiple { get; set; } = 2.5;   // 30% at 2.5R
        public double RunnerRMultiple { get; set; } = 3.0; // 20% runner
        public double TP1Percentage { get; set; } = 0.5;
        public double TP2Percentage { get; set; } = 0.3;
        
        // ═══════════════════════════════════════════════════════════════════════
        // STRUCTURE DETECTION
        // ═══════════════════════════════════════════════════════════════════════
        public int SwingStrength { get; set; } = 5;
        public int MaxSwings { get; set; } = 10;
        public int RangeLookback { get; set; } = 15;
        public int LiquiditySweepLookback { get; set; } = 20;
        
        // ═══════════════════════════════════════════════════════════════════════
        // ICT LEVELS
        // ═══════════════════════════════════════════════════════════════════════
        public double ICTLevelTolerance { get; set; } = 0.5;  // × ATR
        
        // ═══════════════════════════════════════════════════════════════════════
        // GENERAL
        // ═══════════════════════════════════════════════════════════════════════
        public int MaxCandleHistory { get; set; } = 200;
        public int SignalExpiryMinutes { get; set; } = 60;
        public int MinBarsRequired { get; set; } = 50;
    }

    /// <summary>
    /// Scalping data per instrument
    /// </summary>
    public class ScalpingData
    {
        public string Instrument { get; set; }
        public List<CandleData> Candles { get; set; }
        public double ATR { get; set; }
        public double EMA19 { get; set; }
        public double EMA19_5m { get; set; }
        public double EMA19_15m { get; set; }
        public double EMA19_60m { get; set; }
        public double VolumeSMA { get; set; }
        public DateTime LastUpdate { get; set; }
        
        // ICT Levels
        public double PDH { get; set; }  // Previous Day High
        public double PDL { get; set; }  // Previous Day Low
        public double PWH { get; set; }  // Previous Week High
        public double PWL { get; set; }  // Previous Week Low
        public double TodayHigh { get; set; }
        public double TodayLow { get; set; }
        
        // BOS Tracking
        public double LastSwingHigh { get; set; }
        public double LastSwingLow { get; set; } = double.MaxValue;
        public int LastSwingHighBar { get; set; }
        public int LastSwingLowBar { get; set; }
        public bool BOSLongTriggered { get; set; }
        public bool BOSShortTriggered { get; set; }
        public double BOSLevel { get; set; }
        public DateTime BOSTime { get; set; }
        
        // Structure
        public List<PivotPoint> SwingHighs { get; set; }
        public List<PivotPoint> SwingLows { get; set; }
        public MarketStructure Structure { get; set; }
        
        // Range
        public double RangeHigh { get; set; }
        public double RangeLow { get; set; }
        public bool InRange { get; set; }
        
        // Trendlines
        public Trendline TrendlineUp { get; set; }
        public Trendline TrendlineDown { get; set; }
        
        public ScalpingData(string instrument, ScalpingSettings settings)
        {
            Instrument = instrument;
            Candles = new List<CandleData>();
            SwingHighs = new List<PivotPoint>();
            SwingLows = new List<PivotPoint>();
            Structure = MarketStructure.Unknown;
            TodayLow = double.MaxValue;
        }
        
        public void AddBar(double open, double high, double low, double close, double volume, DateTime time, int barIndex)
        {
            var candle = new CandleData
            {
                Open = open,
                High = high,
                Low = low,
                Close = close,
                Volume = volume,
                Time = time,
                BarIndex = barIndex
            };
            
            Candles.Add(candle);
            LastUpdate = time;
            
            // Keep only last 500 candles
            if (Candles.Count > 500)
                Candles.RemoveAt(0);
            
            // Update today's high/low
            if (time.Date == DateTime.Today)
            {
                if (high > TodayHigh) TodayHigh = high;
                if (low < TodayLow) TodayLow = low;
            }
        }
    }

    /// <summary>
    /// Candle data
    /// </summary>
    public class CandleData
    {
        public double Open { get; set; }
        public double High { get; set; }
        public double Low { get; set; }
        public double Close { get; set; }
        public double Volume { get; set; }
        public DateTime Time { get; set; }
        public int BarIndex { get; set; }
        public CandlePattern Pattern { get; set; }
    }

    /// <summary>
    /// Pivot point
    /// </summary>
    // PivotPoint defined in SophonCore.cs

    /// <summary>
    /// Trendline
    /// </summary>
    public class Trendline
    {
        public string Id { get; set; }
        public double StartPrice { get; set; }
        public int StartBar { get; set; }
        public double Slope { get; set; }
        public TrendlineDirection Direction { get; set; }
        public int TouchCount { get; set; }
        public bool IsValid { get; set; }
        
        public double GetPriceAtBar(int barIndex)
        {
            return StartPrice + Slope * (barIndex - StartBar);
        }
    }

    /// <summary>
    /// Scalping signal - Emmanuel patterns
    /// </summary>
    public class ScalpingSignal
    {
        public string Id { get; set; }
        public string Instrument { get; set; }
        public EmmanuelPatternType Pattern { get; set; }
        public bool IsLong { get; set; }
        public double EntryPrice { get; set; }
        public double StopLoss { get; set; }
        public double TakeProfit1 { get; set; }
        public double TakeProfit2 { get; set; }
        public double TakeProfit3 { get; set; }
        public DateTime Time { get; set; }
        public int BarIndex { get; set; }
        public int ConfluenceScore { get; set; }
        public double ExpectedWinRate { get; set; }
        public string Description { get; set; }
        
        // Additional properties for integration
        public DateTime CreatedAt { get; set; }
        public TradeDirection Direction => IsLong ? TradeDirection.Long : TradeDirection.Short;
        
        // Context
        public double ATR { get; set; }
        public double EMA19 { get; set; }
        public double Volume { get; set; }
        public double VolumeSMA { get; set; }
        public CandlePattern CandlePattern { get; set; }
        public MarketStructure Structure { get; set; }
        
        public ScalpingSignal()
        {
            Id = Guid.NewGuid().ToString("N").Substring(0, 8);
            CreatedAt = DateTime.Now;
            Time = DateTime.Now;
        }
        
        public string PatternLabel => $"{Pattern}{(IsLong ? "↑" : "↓")}";
        public double RiskReward1 => Math.Abs(TakeProfit1 - EntryPrice) / Math.Abs(EntryPrice - StopLoss);
    }

    /// <summary>
    /// BOS Event
    /// </summary>
    public class BOSEvent
    {
        public string Instrument { get; set; }
        public TradeDirection Direction { get; set; }
        public double Level { get; set; }
        public DateTime Time { get; set; }
    }

    /// <summary>
    /// ICT Level Event
    /// </summary>
    public class ICTLevelEvent
    {
        public string Instrument { get; set; }
        public ICTLevelType Level { get; set; }
        public double Price { get; set; }
        public DateTime Time { get; set; }
    }
    
    #endregion
}
