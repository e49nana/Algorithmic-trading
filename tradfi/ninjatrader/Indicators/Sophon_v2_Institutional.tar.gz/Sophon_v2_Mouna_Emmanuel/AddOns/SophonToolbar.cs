#region Using declarations
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

// ═══════════════════════════════════════════════════════════════════════════════
// SOPHON TOOLBAR v1.0 - Interactive Chart Controls
// ═══════════════════════════════════════════════════════════════════════════════
//
// FEATURES:
//   - Global hotkey support (Ctrl+1, Ctrl+2, Ctrl+3)
//   - Mode switching via keyboard
//   - Feature toggles
//
// Copyright (c) 2026 Algosphere Quant - Emmanuel
// ═══════════════════════════════════════════════════════════════════════════════

namespace NinjaTrader.NinjaScript.AddOns
{
    public class SophonToolbar : AddOnBase
    {
        // Current state (shared across charts)
        private static SophonDisplayMode _currentMode = SophonDisplayMode.Both;
        private static bool _vpEnabled = true;
        private static bool _heatmapEnabled = false;
        
        // Events for indicator communication
        public static event EventHandler<SophonModeChangedEventArgs> ModeChanged;
        public static event EventHandler<SophonToggleEventArgs> FeatureToggled;
        
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "Sophon Toolbar - Interactive chart controls for SMC/Scalping modes";
                Name = "SophonToolbar";
            }
        }

        protected override void OnWindowCreated(Window window)
        {
            // Add hotkeys to Chart window
            Gui.Chart.Chart chartWindow = window as Gui.Chart.Chart;
            if (chartWindow != null)
            {
                AttachHotkeys(chartWindow);
            }
        }

        protected override void OnWindowDestroyed(Window window)
        {
            // Cleanup
            Gui.Chart.Chart chartWindow = window as Gui.Chart.Chart;
            if (chartWindow != null)
            {
                DetachHotkeys(chartWindow);
            }
        }

        #region Hotkeys
        
        private void AttachHotkeys(Gui.Chart.Chart chartWindow)
        {
            try
            {
                chartWindow.PreviewKeyDown += ChartWindow_PreviewKeyDown;
            }
            catch { }
        }
        
        private void DetachHotkeys(Gui.Chart.Chart chartWindow)
        {
            try
            {
                chartWindow.PreviewKeyDown -= ChartWindow_PreviewKeyDown;
            }
            catch { }
        }
        
        private void ChartWindow_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            // Check for Ctrl modifier
            if ((Keyboard.Modifiers & ModifierKeys.Control) != ModifierKeys.Control)
                return;
            
            bool handled = false;
            
            switch (e.Key)
            {
                case Key.D1:  // Ctrl+1 = SMC Mode
                case Key.NumPad1:
                    SetMode(SophonDisplayMode.SMC);
                    handled = true;
                    break;
                    
                case Key.D2:  // Ctrl+2 = Scalping Mode
                case Key.NumPad2:
                    SetMode(SophonDisplayMode.Scalping);
                    handled = true;
                    break;
                    
                case Key.D3:  // Ctrl+3 = Both Mode
                case Key.NumPad3:
                    SetMode(SophonDisplayMode.Both);
                    handled = true;
                    break;
                    
                case Key.M:  // Ctrl+M = Cycle Mode
                    CycleMode();
                    handled = true;
                    break;
                    
                case Key.V:  // Ctrl+V = Toggle Volume Profile (skip if Ctrl+Shift for paste)
                    if ((Keyboard.Modifiers & ModifierKeys.Shift) != ModifierKeys.Shift)
                    {
                        ToggleFeature("VolumeProfile");
                        handled = true;
                    }
                    break;
                    
                case Key.H:  // Ctrl+H = Toggle Heatmap
                    ToggleFeature("LiquidationHeatmap");
                    handled = true;
                    break;
                    
                case Key.O:  // Ctrl+O = Toggle Order Blocks
                    ToggleFeature("OrderBlocks");
                    handled = true;
                    break;
                    
                case Key.F:  // Ctrl+F = Toggle FVG
                    ToggleFeature("FVG");
                    handled = true;
                    break;
                    
                case Key.S:  // Ctrl+Shift+S = Toggle Scalping Signals
                    if ((Keyboard.Modifiers & ModifierKeys.Shift) == ModifierKeys.Shift)
                    {
                        ToggleFeature("ScalpingSignals");
                        handled = true;
                    }
                    break;
            }
            
            if (handled)
            {
                e.Handled = true;
            }
        }
        
        #endregion

        #region Mode & Feature Management
        
        public static SophonDisplayMode CurrentMode => _currentMode;
        public static bool IsVolumeProfileEnabled => _vpEnabled;
        public static bool IsHeatmapEnabled => _heatmapEnabled;
        
        private void SetMode(SophonDisplayMode mode)
        {
            if (_currentMode == mode) return;
            
            var oldMode = _currentMode;
            _currentMode = mode;
            
            // Fire event
            ModeChanged?.Invoke(this, new SophonModeChangedEventArgs(oldMode, mode));
            
            Log($"Sophon Mode: {mode}", LogLevel.Information);
        }
        
        private void CycleMode()
        {
            switch (_currentMode)
            {
                case SophonDisplayMode.Both:
                    SetMode(SophonDisplayMode.SMC);
                    break;
                case SophonDisplayMode.SMC:
                    SetMode(SophonDisplayMode.Scalping);
                    break;
                case SophonDisplayMode.Scalping:
                    SetMode(SophonDisplayMode.Both);
                    break;
            }
        }
        
        private void ToggleFeature(string feature)
        {
            bool newState = false;
            
            switch (feature)
            {
                case "VolumeProfile":
                    _vpEnabled = !_vpEnabled;
                    newState = _vpEnabled;
                    break;
                    
                case "LiquidationHeatmap":
                    _heatmapEnabled = !_heatmapEnabled;
                    newState = _heatmapEnabled;
                    break;
                    
                default:
                    newState = true; // Will be determined by indicator
                    break;
            }
            
            // Fire event
            FeatureToggled?.Invoke(this, new SophonToggleEventArgs(feature, newState));
            
            Log($"Sophon {feature}: {(newState ? "ON" : "OFF")}", LogLevel.Information);
        }
        
        #endregion
    }
    
    #region Event Args & Enums
    
    public enum SophonDisplayMode
    {
        SMC,
        Scalping,
        Both,
        Clean
    }
    
    public class SophonModeChangedEventArgs : EventArgs
    {
        public SophonDisplayMode OldMode { get; }
        public SophonDisplayMode NewMode { get; }
        
        public SophonModeChangedEventArgs(SophonDisplayMode oldMode, SophonDisplayMode newMode)
        {
            OldMode = oldMode;
            NewMode = newMode;
        }
    }
    
    public class SophonToggleEventArgs : EventArgs
    {
        public string Feature { get; }
        public bool IsEnabled { get; }
        
        public SophonToggleEventArgs(string feature, bool isEnabled)
        {
            Feature = feature;
            IsEnabled = isEnabled;
        }
    }
    
    #endregion
}
