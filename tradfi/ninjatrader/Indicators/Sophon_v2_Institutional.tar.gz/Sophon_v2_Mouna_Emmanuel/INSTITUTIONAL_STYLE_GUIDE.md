# Sophon v9.0 - Institutional Style Guide

## 🎨 Color Palette

### Primary Colors (3 max visible simultaneously)
| Element | Color | Hex | Opacity |
|---------|-------|-----|---------|
| BOS Haussier | Cool Green | #3FA9A5 | 100% |
| BOS Baissier | Soft Red | #D16C6C | 100% |
| CHoCH | Pale Amber | #E6C36A | 80% |

### Secondary Colors (Desaturated)
| Element | Color | Hex | Opacity |
|---------|-------|-----|---------|
| Zones (OB/FVG) | Blue-gray | #607D8B | 8-18% |
| Premium Zone | Soft Red | #D16C6C | 10% |
| Discount Zone | Cool Green | #3FA9A5 | 10% |
| POC Line | Blue-gray | #78909C | 30% |
| Secondary Text | Gray | #9E9E9E | 60% |

### Chart Theme
| Element | Color | Hex |
|---------|-------|-----|
| Background | Dark Blue-gray | #0E1116 |
| Grid Lines | Blue-gray | #607D8B at 12% |
| Up Candle | Muted Teal | #3FA9A5 |
| Down Candle | Muted Red | #D16C6C |
| Wick | Lighter than body | +20% brightness |

---

## 📐 Visual Hierarchy Rules

### Rule 1: If everything is important, nothing is
- Max 3 dominant colors visible at once
- All zones semi-transparent (8-18%)
- Old labels fade automatically

### Rule 2: Text Sizes (3 levels max)
1. **Major Structure** (BOS HTF) - 100% opacity
2. **Local Structure** (BOS/CHoCH) - 100% → 40% fade
3. **Secondary Info** - Gray 60%

### Rule 3: Alignment
- BOS text: Always ABOVE bullish / BELOW bearish
- CHoCH text: Always LEFT of price level
- Constant spacing: 0.15 × ATR between text and level

---

## 🔧 Settings

### Visual Settings (`5b. Visual` group)
- **Max Bars for Labels**: Hide labels older than N bars (default: 100)
- **Focus Trading Mode**: Simplified view for execution
- **Apply Chart Theme**: Auto-apply institutional dark theme

### Focus Trading Mode
When enabled:
- 70% of labels hidden
- Only 2 BOS + 1 CHoCH visible
- Only 1 Order Block
- 2 FVG maximum
- VP hidden
- Minimal dashboard

---

## ✅ Design Checklist

Before trading session:
- [ ] Readable in 1 second
- [ ] No eye fatigue after 2h
- [ ] Signal stands out immediately
- [ ] Past doesn't overwhelm present
- [ ] Background is dark gray (not pure black)
- [ ] Candles are desaturated

---

## 🎯 Hotkeys

| Hotkey | Action |
|--------|--------|
| Ctrl+1 | SMC Mode |
| Ctrl+2 | Scalping Mode |
| Ctrl+3 | Both Modes |
| Ctrl+M | Cycle Modes |
| Ctrl+V | Toggle Volume Profile |
| Ctrl+H | Toggle Heatmap |
| Ctrl+O | Toggle Order Blocks |
| Ctrl+F | Toggle FVG |
| Ctrl+Shift+S | Toggle Scalping |

---

## 📊 Element Opacity Guide

```
BOS/CHoCH Labels:    100% → 40% (fades with age)
Order Blocks:        12% (internal) / 18% (swing)
FVG:                 8%
Premium/Discount:    10%
Volume Profile:      15-25%
POC Line:            30%
VAH/VAL:             15%
Reference Lines:     20%
```

---

## 🔄 Fade Animation

Labels automatically fade based on age:
```
Age Factor = 1.0 - (barsAgo / MaxBars) × 0.6
Minimum opacity = 40%

Example (MaxBars = 100):
- Bar 0:   100% opacity
- Bar 50:  70% opacity
- Bar 100: 40% opacity
```
