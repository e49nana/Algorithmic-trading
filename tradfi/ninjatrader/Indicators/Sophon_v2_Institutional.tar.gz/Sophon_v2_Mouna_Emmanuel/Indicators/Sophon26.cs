#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.DrawingTools;
using NinjaTrader.NinjaScript.AddOns.Sophon;
using SophonMarketRegime = NinjaTrader.NinjaScript.AddOns.Sophon.SophonMarketRegime;
#endregion

//===============================================================================
// SOPHON26 DASHBOARD v8.0 - LUXALGO SMC STYLE
// Adaptation du code LuxAlgo Smart Money Concepts pour NinjaTrader 8
//
// FONCTIONNALITÉS LUXALGO ADAPTÉES:
//   ✅ Internal & Swing Structure (BOS/CHoCH)
//   ✅ Order Blocks avec filtrage ATR et mitigation
//   ✅ Fair Value Gaps avec threshold automatique
//   ✅ Equal Highs/Lows (EQH/EQL)
//   ✅ Strong/Weak High/Low (Trailing Extremes)
//   ✅ Premium/Discount/Equilibrium Zones
//   ✅ Pivots HH/HL/LH/LL
//
// Basé sur: Smart Money Concepts [LuxAlgo] - PineScript v5
// Copyright (c) 2026 Algosphere Quant - Emmanuel & Mouna
//===============================================================================

namespace NinjaTrader.NinjaScript.Indicators
{
    public class Sophon26 : Indicator
    {
        #region ═══════════════════════════════════════════════════════════════
        //                     CONSTANTS (LUXALGO STYLE)
        // ═══════════════════════════════════════════════════════════════════
        #endregion
        
        private const int BULLISH = 1;
        private const int BEARISH = -1;
        private const int BULLISH_LEG = 1;
        private const int BEARISH_LEG = 0;

        #region ═══════════════════════════════════════════════════════════════
        //                     DATA STRUCTURES (LUXALGO STYLE)
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        // Pivot structure (comme LuxAlgo)
        private class Pivot
        {
            public double CurrentLevel { get; set; }
            public double LastLevel { get; set; }
            public bool Crossed { get; set; }
            public DateTime BarTime { get; set; }
            public int BarIndex { get; set; }
        }

        // Order Block structure (comme LuxAlgo)
        private class OB
        {
            public double BarHigh { get; set; }
            public double BarLow { get; set; }
            public DateTime BarTime { get; set; }
            public int BarIndex { get; set; }
            public int Bias { get; set; } // BULLISH or BEARISH
            public bool Mitigated { get; set; }
        }

        // Fair Value Gap structure
        private class FVG
        {
            public double Top { get; set; }
            public double Bottom { get; set; }
            public int Bias { get; set; }
            public DateTime BarTime { get; set; }
            public int BarIndex { get; set; }
            public bool Filled { get; set; }
        }

        // Trailing Extremes (pour Strong/Weak High/Low)
        private class TrailingExtremes
        {
            public double Top { get; set; }
            public double Bottom { get; set; }
            public DateTime LastTopTime { get; set; }
            public DateTime LastBottomTime { get; set; }
            public int LastTopBar { get; set; }
            public int LastBottomBar { get; set; }
        }

        #region ═══════════════════════════════════════════════════════════════
        //                     STATE VARIABLES
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        // Modules
        private SophonSMC _smcModule;
        private SophonAI _aiModule;
        private SophonLiquidity _liquidityModule;
        private SophonScalping _scalpingModule;
        
        // Technical indicators
        private ATR _atr;
        private SMA _sma20, _sma50, _sma200;
        private EMA _ema9, _ema21, _ema19;
        
        // Volume Profile State
        private SophonVolumeProfile _currentProfile;
        private VolumeRegime _volumeRegime = VolumeRegime.Balanced;
        
        // Scalping State
        private List<ScalpingSignal> _activeScalpingSignals = new List<ScalpingSignal>();
        private ScalpingSignal _lastScalpingSignal;
        
        // Display Mode
        private DisplayMode _currentMode = DisplayMode.Both;
        
        // State
        private string _currentInstrument;
        private DateTime _lastPanelUpdate = DateTime.MinValue;
        private Dictionary<string, string> _drawnObjects = new Dictionary<string, string>();

        // LUXALGO-STYLE PIVOTS
        private Pivot _swingHigh = new Pivot();
        private Pivot _swingLow = new Pivot();
        private Pivot _internalHigh = new Pivot();
        private Pivot _internalLow = new Pivot();
        
        // TREND BIAS
        private int _swingTrend = 0;
        private int _internalTrend = 0;
        
        // TRAILING EXTREMES (Strong/Weak High/Low)
        private TrailingExtremes _trailing = new TrailingExtremes();
        
        // ORDER BLOCKS
        private List<OB> _swingOrderBlocks = new List<OB>();
        private List<OB> _internalOrderBlocks = new List<OB>();
        
        // FAIR VALUE GAPS
        private List<FVG> _fairValueGaps = new List<FVG>();
        
        // EQUAL HIGHS/LOWS
        private List<Pivot> _equalHighs = new List<Pivot>();
        private List<Pivot> _equalLows = new List<Pivot>();
        
        // STRUCTURE LABELS
        private List<StructureLabel> _structureLabels = new List<StructureLabel>();
        
        // LEG TRACKING
        private int _currentLeg = 0;
        private int _lastLeg = 0;
        private int _internalLeg = 0;
        private int _lastInternalLeg = 0;
        
        // REFERENCE LEVELS
        private double _midnightOpen, _open830, _asianHigh, _asianLow, _pdh, _pdl;
        private DateTime _lastSessionUpdate, _lastDayProcessed;
        
        // HTF BIAS
        private string _htfBias = "NEUTRAL";
        private string _dailyBias = "◆", _h4Bias = "◆", _h1Bias = "◆", _m15Bias = "◆";
        private string _localStructure = "Unknown";

        private class StructureLabel
        {
            public string Type { get; set; } // BOS, CHoCH, HH, HL, LH, LL
            public double Price { get; set; }
            public int BarIndex { get; set; }
            public int Bias { get; set; }
            public bool IsSwing { get; set; } // True for swing structure, false for internal
        }

        #region ═══════════════════════════════════════════════════════════════
        //                     USER PARAMETERS
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        #region 1. Structure Settings
        [NinjaScriptProperty]
        [Display(Name = "Show Internal Structure", Order = 1, GroupName = "1. Structure")]
        public bool ShowInternals { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Swing Structure", Order = 2, GroupName = "1. Structure")]
        public bool ShowSwingStructure { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Swing Points (HH/HL/LH/LL)", Order = 3, GroupName = "1. Structure")]
        public bool ShowSwingPoints { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Strong/Weak High/Low", Order = 4, GroupName = "1. Structure")]
        public bool ShowStrongWeakHL { get; set; }

        [NinjaScriptProperty]
        [Range(10, 100)]
        [Display(Name = "Swing Length", Order = 5, GroupName = "1. Structure")]
        public int SwingLength { get; set; }

        [NinjaScriptProperty]
        [Range(3, 20)]
        [Display(Name = "Internal Length", Order = 6, GroupName = "1. Structure")]
        public int InternalLength { get; set; }
        #endregion

        #region 2. Order Blocks
        [NinjaScriptProperty]
        [Display(Name = "Show Internal Order Blocks", Order = 1, GroupName = "2. Order Blocks")]
        public bool ShowInternalOB { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Swing Order Blocks", Order = 2, GroupName = "2. Order Blocks")]
        public bool ShowSwingOB { get; set; }

        [NinjaScriptProperty]
        [Range(1, 20)]
        [Display(Name = "Max Internal OB", Order = 3, GroupName = "2. Order Blocks")]
        public int MaxInternalOB { get; set; }

        [NinjaScriptProperty]
        [Range(1, 20)]
        [Display(Name = "Max Swing OB", Order = 4, GroupName = "2. Order Blocks")]
        public int MaxSwingOB { get; set; }
        #endregion

        #region 3. FVG & EQH/EQL
        [NinjaScriptProperty]
        [Display(Name = "Show Fair Value Gaps", Order = 1, GroupName = "3. FVG & EQH")]
        public bool ShowFVG { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Equal Highs/Lows", Order = 2, GroupName = "3. FVG & EQH")]
        public bool ShowEqualHL { get; set; }

        [NinjaScriptProperty]
        [Range(0.05, 0.5)]
        [Display(Name = "EQH/EQL Threshold", Order = 3, GroupName = "3. FVG & EQH")]
        public double EqualThreshold { get; set; }

        [NinjaScriptProperty]
        [Range(1, 10)]
        [Display(Name = "EQH/EQL Confirmation Bars", Order = 4, GroupName = "3. FVG & EQH")]
        public int EqualConfirmBars { get; set; }
        #endregion

        #region 4. Zones & Levels
        [NinjaScriptProperty]
        [Display(Name = "Show Premium/Discount Zones", Order = 1, GroupName = "4. Zones")]
        public bool ShowPremiumDiscount { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Reference Levels", Order = 2, GroupName = "4. Zones")]
        public bool ShowReferenceLevels { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show Info Panel", Order = 3, GroupName = "4. Zones")]
        public bool ShowInfoPanel { get; set; }
        
        [NinjaScriptProperty]
        [Display(Name = "Show Volume Profile", Order = 4, GroupName = "4. Zones")]
        public bool ShowVolumeProfile { get; set; }
        
        [NinjaScriptProperty]
        [Display(Name = "Show Liquidation Heatmap", Order = 5, GroupName = "4. Zones")]
        public bool ShowLiquidationHeatmap { get; set; }
        
        [NinjaScriptProperty]
        [Range(30, 150)]
        [Display(Name = "VP Rows", Order = 6, GroupName = "4. Zones")]
        public int VPRows { get; set; }
        
        [NinjaScriptProperty]
        [Range(50, 90)]
        [Display(Name = "Value Area %", Order = 7, GroupName = "4. Zones")]
        public double ValueAreaPct { get; set; }
        
        [NinjaScriptProperty]
        [Range(1, 50)]
        [Display(Name = "Default Leverage", Order = 8, GroupName = "4. Zones")]
        public double DefaultLeverage { get; set; }
        #endregion
        
        #region 5. Scalping (Emmanuel Patterns)
        [NinjaScriptProperty]
        [Display(Name = "Enable Scalping Signals", Order = 1, GroupName = "5. Scalping")]
        public bool EnableScalping { get; set; }
        
        [NinjaScriptProperty]
        [Display(Name = "Show Scalping Arrows", Order = 2, GroupName = "5. Scalping")]
        public bool ShowScalpingArrows { get; set; }
        
        [NinjaScriptProperty]
        [Display(Name = "Enable EMA Bounce", Order = 3, GroupName = "5. Scalping")]
        public bool EnableEMABounce { get; set; }
        
        [NinjaScriptProperty]
        [Display(Name = "Enable Range Breakout", Order = 4, GroupName = "5. Scalping")]
        public bool EnableRangeBreakout { get; set; }
        
        [NinjaScriptProperty]
        [Display(Name = "Enable BOS Entry", Order = 5, GroupName = "5. Scalping")]
        public bool EnableBOSEntry { get; set; }
        
        [NinjaScriptProperty]
        [Display(Name = "Enable Liquidity Sweep", Order = 6, GroupName = "5. Scalping")]
        public bool EnableLiquiditySweep { get; set; }
        
        [NinjaScriptProperty]
        [Range(3, 10)]
        [Display(Name = "Min Confluence Score", Order = 7, GroupName = "5. Scalping")]
        public int MinConfluenceScore { get; set; }
        
        [NinjaScriptProperty]
        [Range(10, 30)]
        [Display(Name = "EMA Period", Order = 8, GroupName = "5. Scalping")]
        public int ScalpingEMAPeriod { get; set; }
        
        [NinjaScriptProperty]
        [Display(Name = "Show Mode Toolbar", Order = 9, GroupName = "5. Scalping")]
        public bool ShowModeToolbar { get; set; }
        
        [NinjaScriptProperty]
        [Display(Name = "Play Mode Change Sound", Order = 10, GroupName = "5. Scalping")]
        public bool PlayModeChangeSound { get; set; }
        #endregion
        
        #region 5b. Visual Settings (NEW)
        [NinjaScriptProperty]
        [Range(20, 300)]
        [Display(Name = "Max Bars for Labels", Description = "Hide labels older than this many bars", Order = 1, GroupName = "5b. Visual")]
        public int MaxBarsVisibleForLabels { get; set; }
        
        [NinjaScriptProperty]
        [Display(Name = "Focus Trading Mode", Description = "Hide 70% of labels, show only active signal", Order = 2, GroupName = "5b. Visual")]
        public bool FocusTradingMode { get; set; }
        
        [NinjaScriptProperty]
        [Display(Name = "Apply Chart Theme", Description = "Apply dark institutional theme to chart", Order = 3, GroupName = "5b. Visual")]
        public bool ApplyChartTheme { get; set; }
        #endregion

        #region 5. Colors
        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Bullish Color", Order = 1, GroupName = "6. Colors")]
        public Brush BullishColor { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Bearish Color", Order = 2, GroupName = "6. Colors")]
        public Brush BearishColor { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Internal Bullish OB", Order = 3, GroupName = "6. Colors")]
        public Brush InternalBullOBColor { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Internal Bearish OB", Order = 4, GroupName = "6. Colors")]
        public Brush InternalBearOBColor { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Swing Bullish OB", Order = 5, GroupName = "6. Colors")]
        public Brush SwingBullOBColor { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Swing Bearish OB", Order = 6, GroupName = "6. Colors")]
        public Brush SwingBearOBColor { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Bullish FVG", Order = 7, GroupName = "6. Colors")]
        public Brush BullishFVGColor { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Bearish FVG", Order = 8, GroupName = "6. Colors")]
        public Brush BearishFVGColor { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Premium Zone", Order = 9, GroupName = "6. Colors")]
        public Brush PremiumColor { get; set; }

        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Discount Zone", Order = 10, GroupName = "6. Colors")]
        public Brush DiscountColor { get; set; }
        
        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "POC Color", Order = 11, GroupName = "6. Colors")]
        public Brush POCColor { get; set; }
        
        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "VAH/VAL Color", Order = 12, GroupName = "6. Colors")]
        public Brush VAColor { get; set; }
        
        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "HVN Color", Order = 13, GroupName = "6. Colors")]
        public Brush HVNColor { get; set; }
        
        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "LVN Color", Order = 14, GroupName = "6. Colors")]
        public Brush LVNColor { get; set; }
        
        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "VP Buy Color", Order = 15, GroupName = "6. Colors")]
        public Brush VPBuyColor { get; set; }
        
        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "VP Sell Color", Order = 16, GroupName = "6. Colors")]
        public Brush VPSellColor { get; set; }
        
        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Scalping Buy Signal", Order = 17, GroupName = "6. Colors")]
        public Brush ScalpingBuyColor { get; set; }
        
        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Scalping Sell Signal", Order = 18, GroupName = "6. Colors")]
        public Brush ScalpingSellColor { get; set; }
        
        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "CHoCH Color", Order = 19, GroupName = "6. Colors")]
        public Brush ChochColor { get; set; }
        
        [NinjaScriptProperty]
        [XmlIgnore]
        [Display(Name = "Secondary Text", Order = 20, GroupName = "6. Colors")]
        public Brush SecondaryTextColor { get; set; }
        #endregion

        #region 6. Panel Settings
        [NinjaScriptProperty]
        [Display(Name = "Panel Position", Order = 1, GroupName = "6. Panel")]
        public PanelPosition InfoPanelPosition { get; set; }

        [NinjaScriptProperty]
        [Range(8, 12)]
        [Display(Name = "Font Size", Order = 2, GroupName = "6. Panel")]
        public int FontSize { get; set; }
        #endregion

        #region ═══════════════════════════════════════════════════════════════
        //                     INITIALIZATION
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        protected override void OnStateChange()
        {
            switch (State)
            {
                case State.SetDefaults:
                    SetDefaults();
                    break;
                case State.Configure:
                    _drawnObjects = new Dictionary<string, string>();
                    _swingOrderBlocks = new List<OB>();
                    _internalOrderBlocks = new List<OB>();
                    _fairValueGaps = new List<FVG>();
                    _structureLabels = new List<StructureLabel>();
                    
                    // Freeze all brushes for thread safety
                    FreezeBrushes();
                    break;
                case State.DataLoaded:
                    InitializeIndicators();
                    break;
                case State.Terminated:
                    CleanupDrawings();
                    // Unsubscribe from toolbar events
                    try
                    {
                        NinjaTrader.NinjaScript.AddOns.SophonToolbar.ModeChanged -= OnToolbarModeChanged;
                        NinjaTrader.NinjaScript.AddOns.SophonToolbar.FeatureToggled -= OnToolbarFeatureToggled;
                    }
                    catch { }
                    break;
            }
        }
        
        /// <summary>
        /// Freeze all custom brushes for thread safety
        /// NinjaTrader requires frozen brushes when accessing from different threads
        /// </summary>
        private void FreezeBrushes()
        {
            try
            {
                // Helper function to freeze a brush and return a frozen copy
                Func<Brush, Brush> freezeBrush = (brush) =>
                {
                    if (brush == null) return Brushes.Gray;
                    if (brush.IsFrozen) return brush;
                    
                    // If it's a SolidColorBrush, create a frozen copy
                    if (brush is SolidColorBrush scb)
                    {
                        var newBrush = new SolidColorBrush(scb.Color);
                        newBrush.Freeze();
                        return newBrush;
                    }
                    
                    // Try to freeze the original
                    if (brush.CanFreeze)
                    {
                        brush.Freeze();
                        return brush;
                    }
                    
                    return brush;
                };
                
                // Freeze all brush properties
                InternalBullOBColor = freezeBrush(InternalBullOBColor);
                InternalBearOBColor = freezeBrush(InternalBearOBColor);
                SwingBullOBColor = freezeBrush(SwingBullOBColor);
                SwingBearOBColor = freezeBrush(SwingBearOBColor);
                BullishFVGColor = freezeBrush(BullishFVGColor);
                BearishFVGColor = freezeBrush(BearishFVGColor);
                HVNColor = freezeBrush(HVNColor);
                LVNColor = freezeBrush(LVNColor);
                VPBuyColor = freezeBrush(VPBuyColor);
                VPSellColor = freezeBrush(VPSellColor);
                
                // Standard brushes are already frozen, but ensure they're set
                if (BullishColor == null) BullishColor = Brushes.LimeGreen;
                if (BearishColor == null) BearishColor = Brushes.Red;
                if (PremiumColor == null) PremiumColor = Brushes.Crimson;
                if (DiscountColor == null) DiscountColor = Brushes.ForestGreen;
                if (POCColor == null) POCColor = Brushes.Gold;
                if (VAColor == null) VAColor = Brushes.DodgerBlue;
            }
            catch (Exception ex)
            {
                Print($"FreezeBrushes error: {ex.Message}");
            }
        }

        private void SetDefaults()
        {
            Description = "Sophon26 v9.0 - Institutional Style";
            Name = "Sophon26";
            Calculate = Calculate.OnBarClose;
            IsOverlay = true;
            DisplayInDataBox = false;
            DrawOnPricePanel = true;
            PaintPriceMarkers = false;
            ScaleJustification = ScaleJustification.Right;
            IsSuspendedWhileInactive = true;

            // ═══════════════════════════════════════════════════════════════
            // VISUAL HIERARCHY SETTINGS
            // ═══════════════════════════════════════════════════════════════
            
            // Structure - minimal by default
            ShowInternals = true;
            ShowSwingStructure = true;
            ShowSwingPoints = false;
            ShowStrongWeakHL = false;
            SwingLength = 50;
            InternalLength = 5;

            // Order Blocks - very few
            ShowInternalOB = false;  // Hidden by default - less clutter
            ShowSwingOB = true;      // Only swing OB visible
            MaxInternalOB = 2;
            MaxSwingOB = 2;

            // FVG & EQH - minimal
            ShowFVG = true;
            ShowEqualHL = false;     // Hidden by default
            EqualThreshold = 0.1;
            EqualConfirmBars = 3;

            // Zones - subtle
            ShowPremiumDiscount = false;  // Hidden by default
            ShowReferenceLevels = true;
            ShowInfoPanel = true;
            ShowVolumeProfile = true;
            ShowLiquidationHeatmap = false;
            VPRows = 40;              // Reduced further
            ValueAreaPct = 70.0;
            DefaultLeverage = 10.0;
            
            // Label visibility control
            MaxBarsVisibleForLabels = 100;  // Hide labels older than this
            FocusTradingMode = false;       // Full analysis by default
            ApplyChartTheme = true;         // Apply dark theme to chart

            // ═══════════════════════════════════════════════════════════════
            // INSTITUTIONAL COLOR PALETTE
            // ═══════════════════════════════════════════════════════════════
            // Rule: 3 dominant colors max, everything else desaturated
            
            // PRIMARY: BOS Bullish - Cool Green (#3FA9A5)
            var bullishBrush = new SolidColorBrush(Color.FromArgb(255, 63, 169, 165));
            bullishBrush.Freeze();
            BullishColor = bullishBrush;
            
            // PRIMARY: BOS Bearish - Soft Red (#D16C6C)
            var bearishBrush = new SolidColorBrush(Color.FromArgb(255, 209, 108, 108));
            bearishBrush.Freeze();
            BearishColor = bearishBrush;
            
            // SECONDARY: CHoCH - Pale Amber (#E6C36A) at 80%
            var chochBrush = new SolidColorBrush(Color.FromArgb(204, 230, 195, 106));
            chochBrush.Freeze();
            ChochColor = chochBrush;
            
            // ZONES: Blue-gray at 12-18% opacity
            var internalBullOB = new SolidColorBrush(Color.FromArgb(30, 63, 169, 165)); // 12%
            internalBullOB.Freeze();
            InternalBullOBColor = internalBullOB;
            
            var internalBearOB = new SolidColorBrush(Color.FromArgb(30, 209, 108, 108)); // 12%
            internalBearOB.Freeze();
            InternalBearOBColor = internalBearOB;
            
            var swingBullOB = new SolidColorBrush(Color.FromArgb(45, 63, 169, 165)); // 18%
            swingBullOB.Freeze();
            SwingBullOBColor = swingBullOB;
            
            var swingBearOB = new SolidColorBrush(Color.FromArgb(45, 209, 108, 108)); // 18%
            swingBearOB.Freeze();
            SwingBearOBColor = swingBearOB;
            
            // FVG - extremely subtle (8% opacity)
            var bullishFVG = new SolidColorBrush(Color.FromArgb(20, 63, 169, 165)); // 8%
            bullishFVG.Freeze();
            BullishFVGColor = bullishFVG;
            
            var bearishFVG = new SolidColorBrush(Color.FromArgb(20, 209, 108, 108)); // 8%
            bearishFVG.Freeze();
            BearishFVGColor = bearishFVG;
            
            // Premium/Discount - barely visible (10% opacity)
            var premiumBrush = new SolidColorBrush(Color.FromArgb(25, 209, 108, 108)); // 10%
            premiumBrush.Freeze();
            PremiumColor = premiumBrush;
            
            var discountBrush = new SolidColorBrush(Color.FromArgb(25, 63, 169, 165)); // 10%
            discountBrush.Freeze();
            DiscountColor = discountBrush;
            
            // VOLUME PROFILE - Monochrome blue-gray
            var pocBrush = new SolidColorBrush(Color.FromArgb(255, 120, 144, 156)); // Blue-gray POC
            pocBrush.Freeze();
            POCColor = pocBrush;
            
            var vaBrush = new SolidColorBrush(Color.FromArgb(100, 96, 125, 139)); // Muted blue-gray
            vaBrush.Freeze();
            VAColor = vaBrush;
            
            // HVN/LVN - same color family, different opacity
            var hvnColor = new SolidColorBrush(Color.FromArgb(60, 96, 125, 139)); // 24%
            hvnColor.Freeze();
            HVNColor = hvnColor;
            
            var lvnColor = new SolidColorBrush(Color.FromArgb(30, 96, 125, 139)); // 12%
            lvnColor.Freeze();
            LVNColor = lvnColor;
            
            // VP bars - monochrome
            var vpBuyColor = new SolidColorBrush(Color.FromArgb(50, 96, 125, 139));
            vpBuyColor.Freeze();
            VPBuyColor = vpBuyColor;
            
            var vpSellColor = new SolidColorBrush(Color.FromArgb(50, 96, 125, 139));
            vpSellColor.Freeze();
            VPSellColor = vpSellColor;
            
            // TEXT: Secondary labels - Gray at 60%
            var secondaryTextBrush = new SolidColorBrush(Color.FromArgb(153, 158, 158, 158)); // 60%
            secondaryTextBrush.Freeze();
            SecondaryTextColor = secondaryTextBrush;
            
            // Scalping Colors
            ScalpingBuyColor = Brushes.Cyan;
            ScalpingSellColor = Brushes.Magenta;
            
            // Scalping Settings (Emmanuel)
            EnableScalping = true;
            ShowScalpingArrows = true;
            EnableEMABounce = true;
            EnableRangeBreakout = true;
            EnableBOSEntry = true;
            EnableLiquiditySweep = true;
            MinConfluenceScore = 5;
            ScalpingEMAPeriod = 19;
            ShowModeToolbar = true;
            PlayModeChangeSound = true;

            // Panel
            InfoPanelPosition = PanelPosition.TopRight;
            FontSize = 9;
        }

        private void InitializeIndicators()
        {
            _currentInstrument = Instrument.MasterInstrument.Name;
            _atr = ATR(14);
            _sma20 = SMA(20);
            _sma50 = SMA(50);
            _sma200 = SMA(200);
            _ema9 = EMA(9);
            _ema21 = EMA(21);
            _ema19 = EMA(ScalpingEMAPeriod);

            // Initialize pivots
            _swingHigh = new Pivot { CurrentLevel = 0, LastLevel = 0, Crossed = false };
            _swingLow = new Pivot { CurrentLevel = double.MaxValue, LastLevel = double.MaxValue, Crossed = false };
            _internalHigh = new Pivot { CurrentLevel = 0, LastLevel = 0, Crossed = false };
            _internalLow = new Pivot { CurrentLevel = double.MaxValue, LastLevel = double.MaxValue, Crossed = false };
            
            // Initialize trailing
            _trailing = new TrailingExtremes { Top = 0, Bottom = double.MaxValue };

            // Initialize SMC module
            try
            {
                _smcModule = new SophonSMC();
                _smcModule.Initialize();
                _smcModule.RegisterInstrument(_currentInstrument);
            }
            catch { }
            
            // Initialize Liquidity module
            try
            {
                _liquidityModule = new SophonLiquidity();
                _liquidityModule.Settings.ProfileLookback = SwingLength * 2;
                _liquidityModule.Settings.NumRows = VPRows;
                _liquidityModule.Settings.ValueAreaPct = ValueAreaPct;
                _liquidityModule.Settings.DefaultLeverage = DefaultLeverage;
                _liquidityModule.Initialize();
                _liquidityModule.RegisterInstrument(_currentInstrument);
            }
            catch { }
            
            // Initialize Scalping module (Emmanuel Patterns)
            try
            {
                _scalpingModule = new SophonScalping();
                _scalpingModule.Settings.EMAPeriod = ScalpingEMAPeriod;
                _scalpingModule.Settings.MinConfluenceScore = MinConfluenceScore;
                _scalpingModule.Settings.EnableEMABounce = EnableEMABounce;
                _scalpingModule.Settings.EnableRangeBreakout = EnableRangeBreakout;
                _scalpingModule.Settings.EnableBOSEntry = EnableBOSEntry;
                _scalpingModule.Settings.EnableLiquiditySweep = EnableLiquiditySweep;
                _scalpingModule.Initialize();
                _scalpingModule.RegisterInstrument(_currentInstrument);
                
                // Subscribe to scalping signal events
                _scalpingModule.OnSetupDetected += OnScalpingSignalDetected;
            }
            catch { }
            
            // Subscribe to toolbar events
            try
            {
                NinjaTrader.NinjaScript.AddOns.SophonToolbar.ModeChanged += OnToolbarModeChanged;
                NinjaTrader.NinjaScript.AddOns.SophonToolbar.FeatureToggled += OnToolbarFeatureToggled;
            }
            catch { }
            
            // ═══════════════════════════════════════════════════════════════
            // APPLY INSTITUTIONAL CHART THEME (Rule 9)
            // Background: Dark gray (#0E1116)
            // Candles: Desaturated bodies
            // ═══════════════════════════════════════════════════════════════
            if (ApplyChartTheme)
            {
                ApplyInstitutionalChartTheme();
            }
        }
        
        /// <summary>
        /// Apply institutional dark theme to chart
        /// </summary>
        private void ApplyInstitutionalChartTheme()
        {
            try
            {
                if (ChartControl == null) return;
                
                // Apply on UI thread
                ChartControl.Dispatcher.InvokeAsync(() =>
                {
                    try
                    {
                        // Background: Dark gray-blue (#0E1116) instead of pure black
                        var bgBrush = new SolidColorBrush(Color.FromRgb(14, 17, 22));
                        bgBrush.Freeze();
                        ChartControl.Properties.ChartBackground = bgBrush;
                        
                        // Grid lines: Very subtle
                        var gridBrush = new SolidColorBrush(Color.FromArgb(30, 96, 125, 139)); // 12%
                        gridBrush.Freeze();
                        ChartControl.Properties.ChartGridlines = gridBrush;
                        
                        // Axis text: Gray 60%
                        var axisBrush = new SolidColorBrush(Color.FromArgb(153, 158, 158, 158));
                        axisBrush.Freeze();
                        ChartControl.Properties.AxisPen.Brush = axisBrush;
                        
                        // Candle colors - desaturated institutional style
                        // Up candle: Muted teal (#3FA9A5)
                        var upBrush = new SolidColorBrush(Color.FromRgb(63, 169, 165));
                        upBrush.Freeze();
                        ChartControl.Properties.ChartBars.Bars.UpBrush = upBrush;
                        
                        // Down candle: Muted red (#D16C6C)
                        var downBrush = new SolidColorBrush(Color.FromRgb(209, 108, 108));
                        downBrush.Freeze();
                        ChartControl.Properties.ChartBars.Bars.DownBrush = downBrush;
                        
                        // Wick colors - slightly lighter than body
                        var upWick = new SolidColorBrush(Color.FromArgb(200, 80, 190, 180));
                        upWick.Freeze();
                        ChartControl.Properties.ChartBars.Bars.UpWickBrush = upWick;
                        
                        var downWick = new SolidColorBrush(Color.FromArgb(200, 220, 130, 130));
                        downWick.Freeze();
                        ChartControl.Properties.ChartBars.Bars.DownWickBrush = downWick;
                        
                        ChartControl.InvalidateVisual();
                    }
                    catch { }
                });
            }
            catch { }
        }
        
        /// <summary>
        /// Handle toolbar mode change event
        /// </summary>
        private void OnToolbarModeChanged(object sender, NinjaTrader.NinjaScript.AddOns.SophonModeChangedEventArgs e)
        {
            // Map toolbar mode to internal mode
            switch (e.NewMode)
            {
                case NinjaTrader.NinjaScript.AddOns.SophonDisplayMode.SMC:
                    _currentMode = DisplayMode.SMC;
                    break;
                case NinjaTrader.NinjaScript.AddOns.SophonDisplayMode.Scalping:
                    _currentMode = DisplayMode.Scalping;
                    break;
                case NinjaTrader.NinjaScript.AddOns.SophonDisplayMode.Both:
                    _currentMode = DisplayMode.Both;
                    break;
                case NinjaTrader.NinjaScript.AddOns.SophonDisplayMode.Clean:
                    _currentMode = DisplayMode.Clean;
                    break;
            }
            
            // Play sound notification
            if (PlayModeChangeSound)
            {
                try { Alert("ModeChange", Priority.Low, $"Sophon Mode: {_currentMode}", NinjaTrader.Core.Globals.InstallDir + @"\sounds\Alert1.wav", 3, Brushes.DodgerBlue, Brushes.White); }
                catch { }
            }
            
            ForceRefresh();
        }
        
        /// <summary>
        /// Handle toolbar feature toggle event
        /// </summary>
        private void OnToolbarFeatureToggled(object sender, NinjaTrader.NinjaScript.AddOns.SophonToggleEventArgs e)
        {
            switch (e.Feature)
            {
                case "VolumeProfile":
                    ShowVolumeProfile = e.IsEnabled;
                    break;
                case "LiquidationHeatmap":
                    ShowLiquidationHeatmap = e.IsEnabled;
                    break;
                case "OrderBlocks":
                    ShowSwingOB = e.IsEnabled;
                    ShowInternalOB = e.IsEnabled;
                    break;
                case "FVG":
                    ShowFVG = e.IsEnabled;
                    break;
                case "ScalpingSignals":
                    EnableScalping = e.IsEnabled;
                    ShowScalpingArrows = e.IsEnabled;
                    break;
            }
            
            ForceRefresh();
        }
        
        /// <summary>
        /// Handle scalping signal detection
        /// </summary>
        private void OnScalpingSignalDetected(object sender, ScalpingSignal signal)
        {
            if (signal == null || signal.ConfluenceScore < MinConfluenceScore)
                return;
            
            _lastScalpingSignal = signal;
            _activeScalpingSignals.Add(signal);
            
            // Keep only last 10 signals
            while (_activeScalpingSignals.Count > 10)
                _activeScalpingSignals.RemoveAt(0);
            
            // Play alert sound for high-quality signals
            if (PlayModeChangeSound && signal.ConfluenceScore >= 7)
            {
                try
                {
                    string soundFile = signal.IsLong 
                        ? NinjaTrader.Core.Globals.InstallDir + @"\sounds\Alert2.wav"
                        : NinjaTrader.Core.Globals.InstallDir + @"\sounds\Alert3.wav";
                    
                    Brush alertColor = signal.IsLong ? Brushes.LimeGreen : Brushes.Coral;
                    string dir = signal.IsLong ? "LONG" : "SHORT";
                    string pattern = GetPatternShortName(signal.Pattern);
                    
                    Alert($"Scalp_{signal.Id}", Priority.High, 
                        $"Sophon {dir}: {pattern} [{signal.ConfluenceScore}/10] @ {signal.EntryPrice:F2}",
                        soundFile, 5, alertColor, Brushes.Black);
                }
                catch { }
            }
        }

        #region ═══════════════════════════════════════════════════════════════
        //                     MAIN UPDATE LOOP
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        protected override void OnBarUpdate()
        {
            try
            {
                if (CurrentBar < SwingLength + 10) return;
                if (_atr == null) return;

                double atr = _atr[0] > 0 ? _atr[0] : 1.0;

                // 1. UPDATE REFERENCE LEVELS
                UpdateReferenceLevels();

                // 2. LUXALGO-STYLE STRUCTURE DETECTION
                // Swing structure
                GetCurrentStructure(SwingLength, false);
                
                // Internal structure
                GetCurrentStructure(InternalLength, true);

                // 3. DETECT BOS/CHOCH AND STORE ORDER BLOCKS
                if (ShowSwingStructure || ShowSwingOB || ShowStrongWeakHL)
                    DisplayStructure(false);

                if (ShowInternals || ShowInternalOB)
                    DisplayStructure(true);

                // 4. UPDATE TRAILING EXTREMES
                if (ShowStrongWeakHL || ShowPremiumDiscount)
                    UpdateTrailingExtremes();

                // 5. DETECT EQUAL HIGHS/LOWS
                if (ShowEqualHL)
                    DetectEqualHighsLows();

                // 6. DETECT FAIR VALUE GAPS
                if (ShowFVG)
                    DetectFairValueGaps();

                // 7. MITIGATE ORDER BLOCKS
                MitigateOrderBlocks();

                // 8. MITIGATE FVGs
                MitigateFVGs();

                // 9. UPDATE HTF BIAS
                UpdateHTFBias();
                
                // 9.5 UPDATE LIQUIDITY MODULE
                if (_liquidityModule != null)
                {
                    try
                    {
                        _liquidityModule.UpdateBar(_currentInstrument, Open[0], High[0], Low[0], Close[0],
                            Volume[0], Time[0], CurrentBar);
                        _currentProfile = _liquidityModule.GetProfile(_currentInstrument);
                        _volumeRegime = _liquidityModule.GetVolumeRegime(_currentInstrument);
                    }
                    catch { }
                }
                
                // 9.6 UPDATE SCALPING MODULE (Emmanuel Patterns)
                if (EnableScalping && _scalpingModule != null)
                {
                    try
                    {
                        double ema19Value = _ema19 != null && _ema19[0] > 0 ? _ema19[0] : 0;
                        double volumeSMA = Volume[0];  // Default
                        
                        // Calculate volume SMA manually
                        if (CurrentBar >= 20)
                        {
                            double volSum = 0;
                            for (int i = 0; i < 20; i++)
                                volSum += Volume[i];
                            volumeSMA = volSum / 20;
                        }
                        
                        // Use simplified update method: Update(instrument, OHLC, volume, time, barIndex, atr, ema19, rsi, volumeSMA)
                        _scalpingModule.Update(
                            _currentInstrument,
                            Open[0], High[0], Low[0], Close[0],
                            Volume[0], Time[0], CurrentBar,
                            _atr[0],
                            ema19Value,
                            0,           // RSI (not used, pass 0)
                            volumeSMA
                        );
                    }
                    catch { }
                }

                // 10. DRAW EVERYTHING
                DrawAllElements();

                // 11. UPDATE PANEL
                if (ShowInfoPanel && (DateTime.Now - _lastPanelUpdate).TotalMilliseconds > 300)
                {
                    UpdateInfoPanel();
                    _lastPanelUpdate = DateTime.Now;
                }
            }
            catch (Exception ex)
            {
                if (State == State.Realtime)
                    Print($"Sophon26 Error: {ex.Message}");
            }
        }

        #region ═══════════════════════════════════════════════════════════════
        //                     MODE SWITCHING (Keyboard)
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        /// <summary>
        /// Render DAFE-style modern dashboard on chart
        /// </summary>
        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
            base.OnRender(chartControl, chartScale);
            
            // ═══════════════════════════════════════════════════════════════
            // INSTITUTIONAL DASHBOARD
            // Clean, minimal, only essential information
            // Focus Mode: Even simpler - just signal + structure
            // ═══════════════════════════════════════════════════════════════
            
            if (!ShowModeToolbar || chartControl == null) return;
            
            try
            {
                SharpDX.Direct2D1.RenderTarget rt = RenderTarget;
                if (rt == null) return;
                
                // Panel size based on mode
                float panelWidth = FocusTradingMode ? 160 : 180;
                float panelHeight = FocusTradingMode ? 100 : 200;
                float panelX = chartControl.ActualWidth - panelWidth - 10;
                float panelY = 50;
                
                // INSTITUTIONAL COLOR PALETTE
                var bgColor = new SharpDX.Color(14, 17, 22, 230);        // #0E1116
                var borderColor = new SharpDX.Color(50, 60, 70, 200);
                var textWhite = new SharpDX.Color(220, 220, 220, 255);
                var textGray = new SharpDX.Color(120, 130, 140, 255);    // 60% gray
                var bullGreen = new SharpDX.Color(63, 169, 165, 255);    // #3FA9A5
                var bearRed = new SharpDX.Color(209, 108, 108, 255);     // #D16C6C
                var amber = new SharpDX.Color(230, 195, 106, 255);       // #E6C36A
                
                using (var bgBrush = new SharpDX.Direct2D1.SolidColorBrush(rt, bgColor))
                using (var borderBrush = new SharpDX.Direct2D1.SolidColorBrush(rt, borderColor))
                using (var whiteBrush = new SharpDX.Direct2D1.SolidColorBrush(rt, textWhite))
                using (var grayBrush = new SharpDX.Direct2D1.SolidColorBrush(rt, textGray))
                using (var greenBrush = new SharpDX.Direct2D1.SolidColorBrush(rt, bullGreen))
                using (var redBrush = new SharpDX.Direct2D1.SolidColorBrush(rt, bearRed))
                using (var amberBrush = new SharpDX.Direct2D1.SolidColorBrush(rt, amber))
                {
                    // Panel background
                    var mainRect = new SharpDX.RectangleF(panelX, panelY, panelWidth, panelHeight);
                    var rounded = new SharpDX.Direct2D1.RoundedRectangle { Rect = mainRect, RadiusX = 4, RadiusY = 4 };
                    rt.FillRoundedRectangle(rounded, bgBrush);
                    rt.DrawRoundedRectangle(rounded, borderBrush, 1);
                    
                    using (var titleFont = new SharpDX.DirectWrite.TextFormat(Core.Globals.DirectWriteFactory, "Segoe UI", SharpDX.DirectWrite.FontWeight.Bold, SharpDX.DirectWrite.FontStyle.Normal, 10))
                    using (var labelFont = new SharpDX.DirectWrite.TextFormat(Core.Globals.DirectWriteFactory, "Segoe UI", 9))
                    using (var valueFont = new SharpDX.DirectWrite.TextFormat(Core.Globals.DirectWriteFactory, "Consolas", 9))
                    {
                        float y = panelY + 8;
                        float leftCol = panelX + 8;
                        
                        // Title: Mode indicator
                        string modeText = FocusTradingMode ? "FOCUS" : _currentMode.ToString().ToUpper();
                        var titleRect = new SharpDX.RectangleF(leftCol, y, panelWidth - 16, 14);
                        rt.DrawText($"SOPHON [{modeText}]", titleFont, titleRect, whiteBrush);
                        y += 20;
                        
                        // Structure - most important
                        bool isBull = _localStructure == "BULLISH";
                        bool isBear = _localStructure == "BEARISH";
                        var structBrush = isBull ? greenBrush : isBear ? redBrush : grayBrush;
                        
                        var structRect = new SharpDX.RectangleF(leftCol, y, panelWidth - 16, 14);
                        labelFont.TextAlignment = SharpDX.DirectWrite.TextAlignment.Leading;
                        rt.DrawText("Structure:", labelFont, structRect, grayBrush);
                        
                        var structValRect = new SharpDX.RectangleF(leftCol + 60, y, panelWidth - 76, 14);
                        valueFont.TextAlignment = SharpDX.DirectWrite.TextAlignment.Leading;
                        rt.DrawText(_localStructure ?? "—", valueFont, structValRect, structBrush);
                        y += 16;
                        
                        // HTF Bias
                        bool htfBull = _htfBias != null && _htfBias.Contains("BULL");
                        bool htfBear = _htfBias != null && _htfBias.Contains("BEAR");
                        var biasBrush = htfBull ? greenBrush : htfBear ? redBrush : grayBrush;
                        
                        var biasRect = new SharpDX.RectangleF(leftCol, y, panelWidth - 16, 14);
                        rt.DrawText("Bias:", labelFont, biasRect, grayBrush);
                        
                        var biasValRect = new SharpDX.RectangleF(leftCol + 60, y, panelWidth - 76, 14);
                        rt.DrawText(_htfBias ?? "NEUTRAL", valueFont, biasValRect, biasBrush);
                        y += 16;
                        
                        // Active Signal (if any) - MOST PROMINENT
                        if (EnableScalping && _lastScalpingSignal != null)
                        {
                            y += 4;
                            var signalBrush = _lastScalpingSignal.IsLong ? greenBrush : redBrush;
                            string dir = _lastScalpingSignal.IsLong ? "▲ LONG" : "▼ SHORT";
                            
                            var sigRect = new SharpDX.RectangleF(leftCol, y, panelWidth - 16, 14);
                            rt.DrawText($"Signal: {dir}", titleFont, sigRect, signalBrush);
                            y += 16;
                            
                            // Entry/SL in focus mode
                            var entryRect = new SharpDX.RectangleF(leftCol, y, panelWidth - 16, 12);
                            rt.DrawText($"Entry: {_lastScalpingSignal.EntryPrice:F2}  SL: {_lastScalpingSignal.StopLoss:F2}", labelFont, entryRect, grayBrush);
                            y += 14;
                        }
                        
                        // Additional info only in full mode
                        if (!FocusTradingMode)
                        {
                            y += 4;
                            
                            // Counts
                            var countRect = new SharpDX.RectangleF(leftCol, y, panelWidth - 16, 12);
                            rt.DrawText($"OB: {_swingOrderBlocks?.Count ?? 0}  FVG: {_fairValueGaps?.Count ?? 0}", labelFont, countRect, grayBrush);
                            y += 14;
                            
                            // POC if VP enabled
                            if (ShowVolumeProfile && _currentProfile != null && _currentProfile.POC > 0)
                            {
                                var pocRect = new SharpDX.RectangleF(leftCol, y, panelWidth - 16, 12);
                                rt.DrawText($"POC: {_currentProfile.POC:F2}", labelFont, pocRect, grayBrush);
                                y += 14;
                            }
                            
                            // Key levels
                            if (_pdh > 0)
                            {
                                var pdhRect = new SharpDX.RectangleF(leftCol, y, panelWidth - 16, 12);
                                rt.DrawText($"PDH: {_pdh:F2}  PDL: {_pdl:F2}", labelFont, pdhRect, amberBrush);
                            }
                        }
                    }
                }
            }
            catch { }
        }
        
        /// <summary>
        /// Cycle through display modes
        /// </summary>
        public void CycleDisplayMode()
        {
            switch (_currentMode)
            {
                case DisplayMode.Both:
                    _currentMode = DisplayMode.SMC;
                    break;
                case DisplayMode.SMC:
                    _currentMode = DisplayMode.Scalping;
                    break;
                case DisplayMode.Scalping:
                    _currentMode = DisplayMode.Both;
                    break;
                default:
                    _currentMode = DisplayMode.Both;
                    break;
            }
            ForceRefresh();
        }
        
        /// <summary>
        /// Set display mode directly
        /// </summary>
        public void SetDisplayMode(DisplayMode mode)
        {
            _currentMode = mode;
            ForceRefresh();
        }

        #region ═══════════════════════════════════════════════════════════════
        //                     LUXALGO-STYLE STRUCTURE DETECTION
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        /// <summary>
        /// Get current leg (bullish or bearish) - LuxAlgo style
        /// </summary>
        private int GetLeg(int size)
        {
            if (CurrentBar < size * 2) return _currentLeg;

            bool newLegHigh = High[size] > HighestHigh(size, size);
            bool newLegLow = Low[size] < LowestLow(size, size);

            if (newLegHigh)
                return BEARISH_LEG;
            else if (newLegLow)
                return BULLISH_LEG;

            return _currentLeg;
        }

        private double HighestHigh(int startBar, int length)
        {
            double highest = 0;
            for (int i = 0; i < length; i++)
            {
                if (startBar + i < CurrentBar && High[startBar + i] > highest)
                    highest = High[startBar + i];
            }
            return highest;
        }

        private double LowestLow(int startBar, int length)
        {
            double lowest = double.MaxValue;
            for (int i = 0; i < length; i++)
            {
                if (startBar + i < CurrentBar && Low[startBar + i] < lowest)
                    lowest = Low[startBar + i];
            }
            return lowest;
        }

        /// <summary>
        /// Get current structure and store pivots - LuxAlgo style
        /// </summary>
        private void GetCurrentStructure(int size, bool isInternal)
        {
            if (CurrentBar < size * 2) return;

            int currentLeg = GetLeg(size);
            bool startOfNewLeg = (isInternal ? _lastInternalLeg : _lastLeg) != currentLeg;
            bool pivotLow = currentLeg == BULLISH_LEG && startOfNewLeg;
            bool pivotHigh = currentLeg == BEARISH_LEG && startOfNewLeg;

            if (startOfNewLeg)
            {
                Pivot pHigh = isInternal ? _internalHigh : _swingHigh;
                Pivot pLow = isInternal ? _internalLow : _swingLow;

                if (pivotLow)
                {
                    // New swing low detected
                    pLow.LastLevel = pLow.CurrentLevel;
                    pLow.CurrentLevel = Low[size];
                    pLow.Crossed = false;
                    pLow.BarTime = Time[size];
                    pLow.BarIndex = CurrentBar - size;

                    if (!isInternal)
                    {
                        _trailing.Bottom = pLow.CurrentLevel;
                        _trailing.LastBottomTime = pLow.BarTime;
                        _trailing.LastBottomBar = pLow.BarIndex;
                    }

                    // Draw swing label
                    if (ShowSwingPoints && !isInternal)
                    {
                        string label = pLow.CurrentLevel < pLow.LastLevel ? "LL" : "HL";
                        AddStructureLabel(label, pLow.CurrentLevel, CurrentBar - size, BULLISH);
                    }
                }
                else if (pivotHigh)
                {
                    // New swing high detected
                    pHigh.LastLevel = pHigh.CurrentLevel;
                    pHigh.CurrentLevel = High[size];
                    pHigh.Crossed = false;
                    pHigh.BarTime = Time[size];
                    pHigh.BarIndex = CurrentBar - size;

                    if (!isInternal)
                    {
                        _trailing.Top = pHigh.CurrentLevel;
                        _trailing.LastTopTime = pHigh.BarTime;
                        _trailing.LastTopBar = pHigh.BarIndex;
                    }

                    // Draw swing label
                    if (ShowSwingPoints && !isInternal)
                    {
                        string label = pHigh.CurrentLevel > pHigh.LastLevel ? "HH" : "LH";
                        AddStructureLabel(label, pHigh.CurrentLevel, CurrentBar - size, BEARISH);
                    }
                }
            }

            if (isInternal)
            {
                _lastInternalLeg = currentLeg;
                _internalLeg = currentLeg;
            }
            else
            {
                _lastLeg = currentLeg;
                _currentLeg = currentLeg;
            }
        }

        /// <summary>
        /// Display structure (BOS/CHoCH) and store order blocks - LuxAlgo style
        /// </summary>
        private void DisplayStructure(bool isInternal)
        {
            Pivot pHigh = isInternal ? _internalHigh : _swingHigh;
            Pivot pLow = isInternal ? _internalLow : _swingLow;
            int trend = isInternal ? _internalTrend : _swingTrend;

            // Check for bullish BOS/CHoCH (price crosses above high)
            if (Close[0] > pHigh.CurrentLevel && !pHigh.Crossed && pHigh.CurrentLevel > 0)
            {
                string tag = trend == BEARISH ? "CHoCH" : "BOS";
                pHigh.Crossed = true;

                if (isInternal)
                    _internalTrend = BULLISH;
                else
                    _swingTrend = BULLISH;

                // Draw structure label
                if ((isInternal && ShowInternals) || (!isInternal && ShowSwingStructure))
                {
                    AddStructureLabel(tag, pHigh.CurrentLevel, pHigh.BarIndex, BULLISH);
                }

                // Store order block
                if ((isInternal && ShowInternalOB) || (!isInternal && ShowSwingOB))
                {
                    StoreOrderBlock(pHigh, isInternal, BULLISH);
                }
            }

            // Check for bearish BOS/CHoCH (price crosses below low)
            if (Close[0] < pLow.CurrentLevel && !pLow.Crossed && pLow.CurrentLevel < double.MaxValue)
            {
                string tag = trend == BULLISH ? "CHoCH" : "BOS";
                pLow.Crossed = true;

                if (isInternal)
                    _internalTrend = BEARISH;
                else
                    _swingTrend = BEARISH;

                // Draw structure label
                if ((isInternal && ShowInternals) || (!isInternal && ShowSwingStructure))
                {
                    AddStructureLabel(tag, pLow.CurrentLevel, pLow.BarIndex, BEARISH);
                }

                // Store order block
                if ((isInternal && ShowInternalOB) || (!isInternal && ShowSwingOB))
                {
                    StoreOrderBlock(pLow, isInternal, BEARISH);
                }
            }
        }

        private void AddStructureLabel(string type, double price, int barIndex, int bias)
        {
            _structureLabels.Add(new StructureLabel
            {
                Type = type,
                Price = price,
                BarIndex = barIndex,
                Bias = bias
            });

            // Keep only recent labels
            while (_structureLabels.Count > 100)
                _structureLabels.RemoveAt(0);
        }

        #region ═══════════════════════════════════════════════════════════════
        //                     ORDER BLOCK MANAGEMENT
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        /// <summary>
        /// Store order block - LuxAlgo style
        /// </summary>
        private void StoreOrderBlock(Pivot pivot, bool isInternal, int bias)
        {
            if (pivot.BarIndex <= 0 || pivot.BarIndex >= CurrentBar) return;

            // Find the extreme bar within the range
            int startIdx = pivot.BarIndex;
            int endIdx = CurrentBar;
            int barsBack = endIdx - startIdx;
            if (barsBack <= 0 || barsBack > CurrentBar) return;

            double obHigh = 0, obLow = double.MaxValue;
            int obBarIndex = startIdx;

            for (int i = 0; i < Math.Min(barsBack, 50); i++)
            {
                int lookback = CurrentBar - startIdx + i;
                if (lookback < 0 || lookback >= CurrentBar) continue;

                if (bias == BEARISH)
                {
                    // For bearish OB, find the highest high
                    if (High[lookback] > obHigh)
                    {
                        obHigh = High[lookback];
                        obLow = Low[lookback];
                        obBarIndex = CurrentBar - lookback;
                    }
                }
                else
                {
                    // For bullish OB, find the lowest low
                    if (Low[lookback] < obLow)
                    {
                        obLow = Low[lookback];
                        obHigh = High[lookback];
                        obBarIndex = CurrentBar - lookback;
                    }
                }
            }

            if (obHigh == 0 || obLow == double.MaxValue) return;

            var ob = new OB
            {
                BarHigh = obHigh,
                BarLow = obLow,
                BarTime = Time[CurrentBar - obBarIndex],
                BarIndex = obBarIndex,
                Bias = bias,
                Mitigated = false
            };

            var list = isInternal ? _internalOrderBlocks : _swingOrderBlocks;
            list.Insert(0, ob);

            // Limit size
            int maxOB = isInternal ? MaxInternalOB : MaxSwingOB;
            while (list.Count > maxOB * 2)
                list.RemoveAt(list.Count - 1);
        }

        /// <summary>
        /// Mitigate order blocks - LuxAlgo style
        /// </summary>
        private void MitigateOrderBlocks()
        {
            // Mitigate internal OBs
            for (int i = _internalOrderBlocks.Count - 1; i >= 0; i--)
            {
                var ob = _internalOrderBlocks[i];
                if (ob.Bias == BEARISH && High[0] > ob.BarHigh)
                    _internalOrderBlocks.RemoveAt(i);
                else if (ob.Bias == BULLISH && Low[0] < ob.BarLow)
                    _internalOrderBlocks.RemoveAt(i);
            }

            // Mitigate swing OBs
            for (int i = _swingOrderBlocks.Count - 1; i >= 0; i--)
            {
                var ob = _swingOrderBlocks[i];
                if (ob.Bias == BEARISH && High[0] > ob.BarHigh)
                    _swingOrderBlocks.RemoveAt(i);
                else if (ob.Bias == BULLISH && Low[0] < ob.BarLow)
                    _swingOrderBlocks.RemoveAt(i);
            }
        }

        #region ═══════════════════════════════════════════════════════════════
        //                     FVG & EQUAL HIGHS/LOWS
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        /// <summary>
        /// Detect Fair Value Gaps - LuxAlgo style
        /// </summary>
        private void DetectFairValueGaps()
        {
            if (CurrentBar < 3) return;

            double atr = _atr[0] > 0 ? _atr[0] : 1.0;
            double threshold = atr * 0.1; // Auto threshold

            // Bullish FVG: Current low > 2 bars ago high
            if (Low[0] > High[2] && (Low[0] - High[2]) > threshold)
            {
                _fairValueGaps.Add(new FVG
                {
                    Top = Low[0],
                    Bottom = High[2],
                    Bias = BULLISH,
                    BarTime = Time[1],
                    BarIndex = CurrentBar - 1,
                    Filled = false
                });
            }

            // Bearish FVG: Current high < 2 bars ago low
            if (High[0] < Low[2] && (Low[2] - High[0]) > threshold)
            {
                _fairValueGaps.Add(new FVG
                {
                    Top = Low[2],
                    Bottom = High[0],
                    Bias = BEARISH,
                    BarTime = Time[1],
                    BarIndex = CurrentBar - 1,
                    Filled = false
                });
            }

            // Limit size
            while (_fairValueGaps.Count > 20)
                _fairValueGaps.RemoveAt(0);
        }

        /// <summary>
        /// Mitigate FVGs
        /// </summary>
        private void MitigateFVGs()
        {
            for (int i = _fairValueGaps.Count - 1; i >= 0; i--)
            {
                var fvg = _fairValueGaps[i];
                if (fvg.Bias == BULLISH && Low[0] < fvg.Bottom)
                    _fairValueGaps.RemoveAt(i);
                else if (fvg.Bias == BEARISH && High[0] > fvg.Top)
                    _fairValueGaps.RemoveAt(i);
            }
        }

        /// <summary>
        /// Detect Equal Highs/Lows - LuxAlgo style
        /// </summary>
        private void DetectEqualHighsLows()
        {
            if (CurrentBar < EqualConfirmBars * 2) return;

            double atr = _atr[0] > 0 ? _atr[0] : 1.0;
            double threshold = atr * EqualThreshold;

            // Check for equal highs
            for (int i = EqualConfirmBars; i < EqualConfirmBars * 3; i++)
            {
                if (Math.Abs(High[0] - High[i]) < threshold && 
                    High[0] > High[1] && High[i] > High[i + 1])
                {
                    AddStructureLabel("EQH", High[0], CurrentBar, BEARISH);
                    break;
                }
            }

            // Check for equal lows
            for (int i = EqualConfirmBars; i < EqualConfirmBars * 3; i++)
            {
                if (Math.Abs(Low[0] - Low[i]) < threshold &&
                    Low[0] < Low[1] && Low[i] < Low[i + 1])
                {
                    AddStructureLabel("EQL", Low[0], CurrentBar, BULLISH);
                    break;
                }
            }
        }

        #region ═══════════════════════════════════════════════════════════════
        //                     TRAILING EXTREMES & ZONES
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        /// <summary>
        /// Update trailing extremes - LuxAlgo style
        /// </summary>
        private void UpdateTrailingExtremes()
        {
            if (High[0] > _trailing.Top || _trailing.Top == 0)
            {
                _trailing.Top = High[0];
                _trailing.LastTopTime = Time[0];
                _trailing.LastTopBar = CurrentBar;
            }

            if (Low[0] < _trailing.Bottom || _trailing.Bottom == double.MaxValue)
            {
                _trailing.Bottom = Low[0];
                _trailing.LastBottomTime = Time[0];
                _trailing.LastBottomBar = CurrentBar;
            }
        }

        private void UpdateReferenceLevels()
        {
            DateTime barTime = Time[0];

            // PDH/PDL
            if (barTime.Date != _lastDayProcessed.Date && CurrentBar > 100)
            {
                for (int i = 1; i < Math.Min(CurrentBar, 500); i++)
                {
                    if (Time[i].Date == barTime.Date.AddDays(-1))
                    {
                        double dayHigh = High[i], dayLow = Low[i];
                        for (int j = i; j < Math.Min(CurrentBar, i + 500); j++)
                        {
                            if (Time[j].Date != Time[i].Date) break;
                            if (High[j] > dayHigh) dayHigh = High[j];
                            if (Low[j] < dayLow) dayLow = Low[j];
                        }
                        _pdh = dayHigh;
                        _pdl = dayLow;
                        break;
                    }
                }
                _lastDayProcessed = barTime;
            }

            // Reset at midnight
            if (barTime.Date != _lastSessionUpdate.Date)
            {
                _asianHigh = 0;
                _asianLow = double.MaxValue;
                _lastSessionUpdate = barTime;
            }

            // Midnight/8:30 Open
            if (barTime.Hour == 0 && barTime.Minute < 5) _midnightOpen = Open[0];
            if (barTime.Hour == 8 && barTime.Minute >= 30 && barTime.Minute < 35) _open830 = Open[0];

            // Asian session
            int hour = barTime.Hour;
            if (hour >= 18 || hour < 2)
            {
                if (High[0] > _asianHigh) _asianHigh = High[0];
                if (Low[0] < _asianLow) _asianLow = Low[0];
            }
        }

        private void UpdateHTFBias()
        {
            if (_ema9 == null || _ema21 == null || _sma50 == null) return;

            double close = Close[0];
            _m15Bias = close > _ema9[0] && _ema9[0] > _ema21[0] ? "▲" : close < _ema9[0] && _ema9[0] < _ema21[0] ? "▼" : "◆";
            _h1Bias = close > _sma50[0] ? "▲" : close < _sma50[0] ? "▼" : "◆";
            _h4Bias = _swingTrend == BULLISH ? "▲" : _swingTrend == BEARISH ? "▼" : "◆";
            _dailyBias = _sma200 != null && close > _sma200[0] ? "▲" : close < _sma200[0] ? "▼" : "◆";

            int bullCount = new[] { _dailyBias, _h4Bias, _h1Bias, _m15Bias }.Count(b => b == "▲");
            int bearCount = new[] { _dailyBias, _h4Bias, _h1Bias, _m15Bias }.Count(b => b == "▼");

            _htfBias = bullCount >= 3 ? "BULLISH" : bearCount >= 3 ? "BEARISH" : bullCount >= 2 ? "LEAN BULL" : bearCount >= 2 ? "LEAN BEAR" : "NEUTRAL";
            _localStructure = _swingTrend == BULLISH ? "BULLISH" : _swingTrend == BEARISH ? "BEARISH" : "RANGING";
        }

        #region ═══════════════════════════════════════════════════════════════
        //                     DRAWING METHODS
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        private void DrawAllElements()
        {
            if (_drawnObjects == null) _drawnObjects = new Dictionary<string, string>();

            double atr = _atr != null && _atr[0] > 0 ? _atr[0] : 1.0;
            
            // Check display mode for SMC elements
            bool showSMC = _currentMode == DisplayMode.SMC || _currentMode == DisplayMode.Both;
            bool showScalping = _currentMode == DisplayMode.Scalping || _currentMode == DisplayMode.Both;

            // SMC ELEMENTS (only if mode allows)
            if (showSMC)
            {
                // Draw structure labels
                DrawStructureLabels(atr);

                // Draw order blocks
                if (ShowInternalOB) DrawOrderBlocks(_internalOrderBlocks, true);
                if (ShowSwingOB) DrawOrderBlocks(_swingOrderBlocks, false);

                // Draw FVGs
                if (ShowFVG) DrawFairValueGaps();

                // Draw Strong/Weak High/Low
                if (ShowStrongWeakHL) DrawStrongWeakHL(atr);

                // Draw Premium/Discount zones
                if (ShowPremiumDiscount) DrawPremiumDiscountZones(atr);
            }

            // ALWAYS draw reference levels (PDH/PDL, etc.)
            if (ShowReferenceLevels) DrawReferenceLevels(atr);
            
            // VOLUME PROFILE (independent toggle via toolbar)
            if (ShowVolumeProfile && _currentProfile != null) DrawVolumeProfile(atr);
            
            // Draw Liquidation Heatmap
            if (ShowLiquidationHeatmap && _liquidityModule != null) DrawLiquidationHeatmap(atr);
            
            // SCALPING ELEMENTS (only if mode allows)
            if (showScalping)
            {
                // Draw Scalping Signals (Emmanuel Patterns)
                if (EnableScalping && ShowScalpingArrows) DrawScalpingSignals(atr);
            }
        }
        
        /// <summary>
        /// Draw Scalping Signals - Emmanuel Patterns
        /// </summary>
        private void DrawScalpingSignals(double atr)
        {
            if (_scalpingModule == null) return;
            
            try
            {
                var signals = _scalpingModule.GetActiveSignals(_currentInstrument);
                if (signals == null || signals.Count == 0) return;
                
                foreach (var signal in signals)
                {
                    if (signal.ConfluenceScore < MinConfluenceScore)
                        continue;
                    
                    int barsAgo = Math.Max(0, CurrentBar - signal.BarIndex);
                    if (barsAgo > 50) continue; // Don't draw old signals
                    
                    string tag = $"SCALP_{signal.Id}";
                    Brush color = signal.IsLong ? ScalpingBuyColor : ScalpingSellColor;
                    
                    // Draw arrow (isAutoScale = false)
                    if (signal.IsLong)
                    {
                        Draw.ArrowUp(this, tag, false, barsAgo, signal.EntryPrice - atr * 0.5, color);
                    }
                    else
                    {
                        Draw.ArrowDown(this, tag, false, barsAgo, signal.EntryPrice + atr * 0.5, color);
                    }
                    RegisterDrawnObject(tag);
                    
                    // Draw pattern label
                    string labelTag = $"SCALP_LBL_{signal.Id}";
                    string patternName = GetPatternShortName(signal.Pattern);
                    double labelY = signal.IsLong ? signal.EntryPrice - atr * 0.8 : signal.EntryPrice + atr * 0.8;
                    Draw.Text(this, labelTag, $"{patternName} [{signal.ConfluenceScore}]", barsAgo, labelY, color);
                    RegisterDrawnObject(labelTag);
                    
                    // Draw SL and TP lines (optional, for most recent signal)
                    if (signal == _lastScalpingSignal && barsAgo < 5)
                    {
                        // Stop Loss line
                        Draw.Line(this, $"SCALP_SL_{signal.Id}", barsAgo + 3, signal.StopLoss, barsAgo - 3, signal.StopLoss, Brushes.Red);
                        
                        // Take Profit lines
                        Brush tpColor = signal.IsLong ? Brushes.LimeGreen : Brushes.Coral;
                        Draw.Line(this, $"SCALP_TP1_{signal.Id}", barsAgo + 3, signal.TakeProfit1, barsAgo - 3, signal.TakeProfit1, tpColor);
                        if (signal.TakeProfit2 > 0)
                            Draw.Line(this, $"SCALP_TP2_{signal.Id}", barsAgo + 3, signal.TakeProfit2, barsAgo - 3, signal.TakeProfit2, tpColor);
                    }
                }
            }
            catch { }
        }
        
        /// <summary>
        /// Get short pattern name for display
        /// </summary>
        private string GetPatternShortName(EmmanuelPatternType pattern)
        {
            switch (pattern)
            {
                case EmmanuelPatternType.EMABounce: return "EMA↩";
                case EmmanuelPatternType.EMA19_Support: return "EMA▲";
                case EmmanuelPatternType.EMA19_Resistance: return "EMA▼";
                case EmmanuelPatternType.RangeBreakout: return "BRK";
                case EmmanuelPatternType.TrendlineTrading: return "TL";
                case EmmanuelPatternType.ZoneTrading: return "ZONE";
                case EmmanuelPatternType.ICTLevelBounce: return "ICT";
                case EmmanuelPatternType.BOSEntry: return "BOS";
                case EmmanuelPatternType.BOS_Continuation: return "BOS+";
                case EmmanuelPatternType.LiquiditySweep: return "LIQ";
                case EmmanuelPatternType.TrendContinuation: return "TREND";
                default: return "—";
            }
        }
        
        /// <summary>
        /// Draw Volume Profile - DAFE Style with POC triangles, gradient bars
        /// </summary>
        private void DrawVolumeProfile(double atr)
        {
            // ═══════════════════════════════════════════════════════════════
            // INSTITUTIONAL STYLE: Monochrome blue-gray, read in peripheral vision
            // No red/green gradients - just gray scale based on volume
            // ═══════════════════════════════════════════════════════════════
            
            if (_currentProfile == null || _currentProfile.Rows == null || _currentProfile.Rows.Count == 0)
                return;
            
            // Hide VP in extreme Focus mode
            if (FocusTradingMode) return;
            
            try
            {
                int profileWidth = 20; // Bars to extend
                double maxVol = _currentProfile.Rows.Any() ? _currentProfile.Rows.Max(r => r.TotalVolume) : 1;
                if (maxVol <= 0) maxVol = 1;
                
                // Single color for all VP bars: Blue-gray (#607D8B)
                // Only vary opacity based on volume (15-25% range)
                int rowIdx = 0;
                foreach (var row in _currentProfile.Rows)
                {
                    if (row.TotalVolume <= 0) { rowIdx++; continue; }
                    
                    double normalizedVol = row.TotalVolume / maxVol;
                    if (normalizedVol < 0.08) { rowIdx++; continue; }
                    
                    int barWidth = Math.Max(1, (int)(normalizedVol * profileWidth));
                    string tag = $"VP_{rowIdx}";
                    
                    // Blue-gray at 15-25% opacity based on volume
                    byte alpha = (byte)(38 + normalizedVol * 25); // 15% to 25%
                    
                    // POC gets slightly more opacity
                    if (row.IsPOC) alpha = 80; // ~30%
                    
                    var rowColor = new SolidColorBrush(Color.FromArgb(alpha, 96, 125, 139)); // #607D8B
                    rowColor.Freeze();
                    
                    Draw.Rectangle(this, tag, barWidth, row.PriceHigh, 0, row.PriceLow, rowColor);
                    RegisterDrawnObject(tag);
                    rowIdx++;
                }
                
                // POC line - slightly thicker, same blue-gray but more opaque
                if (_currentProfile.POC > 0)
                {
                    var pocBrush = new SolidColorBrush(Color.FromArgb(200, 120, 144, 156)); // #78909C
                    pocBrush.Freeze();
                    Draw.Line(this, "VP_POC", 60, _currentProfile.POC, 0, _currentProfile.POC, pocBrush, DashStyleHelper.Solid, 2);
                    
                    // Small POC label - gray text
                    var textBrush = new SolidColorBrush(Color.FromArgb(153, 158, 158, 158)); // Gray 60%
                    textBrush.Freeze();
                    Draw.Text(this, "VP_POC_Lbl", $"POC", 3, _currentProfile.POC + atr * 0.05, textBrush);
                    RegisterDrawnObject("VP_POC");
                }
                
                // VAH/VAL - same color, dotted style
                if (_currentProfile.VAH > 0)
                {
                    var vaBrush = new SolidColorBrush(Color.FromArgb(100, 96, 125, 139));
                    vaBrush.Freeze();
                    Draw.Line(this, "VP_VAH", 40, _currentProfile.VAH, 0, _currentProfile.VAH, vaBrush, DashStyleHelper.Dot, 1);
                    RegisterDrawnObject("VP_VAH");
                }
                
                if (_currentProfile.VAL > 0)
                {
                    var vaBrush = new SolidColorBrush(Color.FromArgb(100, 96, 125, 139));
                    vaBrush.Freeze();
                    Draw.Line(this, "VP_VAL", 40, _currentProfile.VAL, 0, _currentProfile.VAL, vaBrush, DashStyleHelper.Dot, 1);
                    RegisterDrawnObject("VP_VAL");
                }
            }
            catch { }
        }
        
        /// <summary>
        /// Draw Liquidation Heatmap - BigBeluga Style
        /// </summary>
        private void DrawLiquidationHeatmap(double atr)
        {
            if (_liquidityModule == null) return;
            
            try
            {
                var liqLevels = _liquidityModule.GetLiquidationLevels(_currentInstrument);
                if (liqLevels == null || liqLevels.Count == 0) return;
                
                foreach (var level in liqLevels.OrderByDescending(l => l.NormalizedVolume).Take(20))
                {
                    string tag = $"LIQ_{level.Price:F0}";
                    
                    // Color gradient based on volume - Must freeze for thread safety
                    byte intensity = (byte)(100 + level.NormalizedVolume * 155);
                    SolidColorBrush color;
                    if (level.IsAbovePrice)
                    {
                        color = new SolidColorBrush(Color.FromArgb(80, intensity, 50, 50));
                    }
                    else
                    {
                        color = new SolidColorBrush(Color.FromArgb(80, 50, intensity, 50));
                    }
                    color.Freeze();
                    
                    int barWidth = Math.Max(5, (int)(level.NormalizedVolume * 30));
                    double rowHeight = atr * 0.3;
                    
                    Draw.Rectangle(this, tag, barWidth, level.Price + rowHeight / 2, 0, level.Price - rowHeight / 2, color);
                    RegisterDrawnObject(tag);
                }
            }
            catch { }
        }

        private void DrawStructureLabels(double atr)
        {
            // ═══════════════════════════════════════════════════════════════
            // INSTITUTIONAL STYLE: Clean hierarchy, fade old labels
            // ═══════════════════════════════════════════════════════════════
            
            // Focus Trading Mode: Only show last 2 BOS + active signal
            int maxLabels = FocusTradingMode ? 5 : 15;
            int maxBOS = FocusTradingMode ? 2 : 6;
            int maxCHoCH = FocusTradingMode ? 1 : 4;
            int maxBarsVisible = FocusTradingMode ? 50 : MaxBarsVisibleForLabels;
            
            var recent = _structureLabels
                .Where(s => CurrentBar - s.BarIndex < maxBarsVisible)
                .OrderByDescending(s => s.BarIndex)
                .Take(maxLabels);
            
            int bosCount = 0;
            int chochCount = 0;

            foreach (var label in recent)
            {
                int barsAgo = CurrentBar - label.BarIndex;
                if (barsAgo < 0 || barsAgo >= CurrentBar) continue;
                
                // Enforce limits
                if (label.Type == "BOS" && bosCount >= maxBOS) continue;
                if (label.Type == "CHoCH" && chochCount >= maxCHoCH) continue;
                
                // Skip HH/HL/LH/LL in Focus mode
                if (FocusTradingMode && (label.Type == "HH" || label.Type == "HL" || label.Type == "LH" || label.Type == "LL"))
                    continue;
                
                string tag = $"STR_{label.BarIndex}_{label.Type}";
                bool isBullish = label.Bias == BULLISH;
                
                // ═══════════════════════════════════════════════════════════
                // FADE BASED ON AGE (Rule 7)
                // Recent = 100%, Old = 40%
                // ═══════════════════════════════════════════════════════════
                double ageFactor = 1.0 - (barsAgo / (double)maxBarsVisible) * 0.6;
                ageFactor = Math.Max(0.4, Math.Min(1.0, ageFactor));
                byte alpha = (byte)(255 * ageFactor);
                byte alphaLine = (byte)(150 * ageFactor);
                
                // ═══════════════════════════════════════════════════════════
                // INSTITUTIONAL COLOR PALETTE (Rule 2)
                // ═══════════════════════════════════════════════════════════
                SolidColorBrush textBrush;
                SolidColorBrush lineBrush;
                
                if (label.Type == "CHoCH")
                {
                    // CHoCH = Pale Amber (#E6C36A) - ALWAYS this color
                    textBrush = new SolidColorBrush(Color.FromArgb(alpha, 230, 195, 106));
                    lineBrush = new SolidColorBrush(Color.FromArgb(alphaLine, 230, 195, 106));
                }
                else if (label.Type == "BOS")
                {
                    // BOS = Cool Green (#3FA9A5) or Soft Red (#D16C6C)
                    textBrush = isBullish 
                        ? new SolidColorBrush(Color.FromArgb(alpha, 63, 169, 165))
                        : new SolidColorBrush(Color.FromArgb(alpha, 209, 108, 108));
                    lineBrush = isBullish 
                        ? new SolidColorBrush(Color.FromArgb(alphaLine, 63, 169, 165))
                        : new SolidColorBrush(Color.FromArgb(alphaLine, 209, 108, 108));
                }
                else
                {
                    // Secondary labels (HH/HL/LH/LL) = Gray 60%
                    byte grayAlpha = (byte)(153 * ageFactor); // 60% of faded alpha
                    textBrush = new SolidColorBrush(Color.FromArgb(grayAlpha, 158, 158, 158));
                    lineBrush = textBrush;
                }
                textBrush.Freeze();
                lineBrush.Freeze();
                
                // ═══════════════════════════════════════════════════════════
                // ALIGNMENT: Consistent spacing (Rule 6)
                // BOS above/below swing, CHoCH to the left
                // ═══════════════════════════════════════════════════════════
                double textOffset = atr * 0.15; // Constant spacing
                double yPos = isBullish ? label.Price - textOffset : label.Price + textOffset;

                // Draw based on type
                if (label.Type == "BOS")
                {
                    bosCount++;
                    
                    // Line extending right from structure point
                    Draw.Line(this, $"{tag}_line", barsAgo + 10, label.Price, barsAgo, label.Price, 
                        lineBrush, DashStyleHelper.Dash, 1);
                    RegisterDrawnObject($"{tag}_line");
                    
                    // Text label - positioned consistently
                    Draw.Text(this, tag, "BOS", barsAgo + 5, yPos, textBrush);
                    RegisterDrawnObject(tag);
                }
                else if (label.Type == "CHoCH")
                {
                    chochCount++;
                    
                    // CHoCH line - slightly different style
                    Draw.Line(this, $"{tag}_line", barsAgo + 8, label.Price, barsAgo, label.Price, 
                        lineBrush, DashStyleHelper.Solid, 1);
                    RegisterDrawnObject($"{tag}_line");
                    
                    // CHoCH text - always amber, to the left
                    Draw.Text(this, tag, "CHoCH", barsAgo + 4, yPos, textBrush);
                    RegisterDrawnObject(tag);
                }
                else if (label.Type == "HH" || label.Type == "HL" || label.Type == "LH" || label.Type == "LL")
                {
                    // Only draw if swing point and not in focus mode
                    if (label.IsSwing)
                    {
                        Draw.Text(this, tag, label.Type, barsAgo, yPos, textBrush);
                        RegisterDrawnObject(tag);
                    }
                }
                else if (label.Type == "EQH" || label.Type == "EQL")
                {
                    // Skip EQH/EQL in focus mode
                    if (!FocusTradingMode)
                    {
                        var eqBrush = new SolidColorBrush(Color.FromArgb((byte)(153 * ageFactor), 230, 195, 106));
                        eqBrush.Freeze();
                        Draw.Text(this, tag, label.Type, barsAgo, yPos, eqBrush);
                        Draw.Line(this, $"{tag}_eq", barsAgo + 8, label.Price, barsAgo, label.Price, 
                            eqBrush, DashStyleHelper.Dot, 1);
                        RegisterDrawnObject($"{tag}_eq");
                        RegisterDrawnObject(tag);
                    }
                }
            }
        }

        private void DrawOrderBlocks(List<OB> orderBlocks, bool isInternal)
        {
            // ═══════════════════════════════════════════════════════════════
            // INSTITUTIONAL STYLE: Zones = background, not active info
            // Opacity: 8-18% (Rule 4)
            // ═══════════════════════════════════════════════════════════════
            
            // Hide internal OBs in Focus mode
            if (FocusTradingMode && isInternal) return;
            
            int maxOB = isInternal ? MaxInternalOB : MaxSwingOB;
            if (FocusTradingMode) maxOB = 1; // Only 1 OB in focus mode
            
            var toDraw = orderBlocks.Take(maxOB);

            foreach (var ob in toDraw)
            {
                string tag = $"OB_{(isInternal ? "I" : "S")}_{ob.BarIndex}";
                int barsAgo = CurrentBar - ob.BarIndex;
                if (barsAgo < 0 || barsAgo >= CurrentBar) continue;
                if (barsAgo > MaxBarsVisibleForLabels) continue; // Respect visibility limit

                bool isBull = ob.Bias == BULLISH;
                
                // INSTITUTIONAL OPACITY: 8% internal, 15% swing
                byte alpha = (byte)(isInternal ? 20 : 38); // ~8% / ~15%
                
                // Use institutional palette
                var fillColor = isBull 
                    ? new SolidColorBrush(Color.FromArgb(alpha, 63, 169, 165))   // #3FA9A5
                    : new SolidColorBrush(Color.FromArgb(alpha, 209, 108, 108)); // #D16C6C
                fillColor.Freeze();
                
                // Draw OB rectangle
                Draw.Rectangle(this, tag, barsAgo, ob.BarHigh, 0, ob.BarLow, fillColor);
                
                // Thin border - same color, more opaque
                byte borderAlpha = (byte)(alpha * 2.5);
                var borderColor = isBull 
                    ? new SolidColorBrush(Color.FromArgb(borderAlpha, 63, 169, 165))
                    : new SolidColorBrush(Color.FromArgb(borderAlpha, 209, 108, 108));
                borderColor.Freeze();
                Draw.Line(this, $"{tag}_border", barsAgo, ob.BarHigh, barsAgo, ob.BarLow, borderColor, DashStyleHelper.Solid, 1);
                
                RegisterDrawnObject(tag);
                RegisterDrawnObject($"{tag}_border");
            }
        }

        private void DrawFairValueGaps()
        {
            // ═══════════════════════════════════════════════════════════════
            // INSTITUTIONAL STYLE: FVG very subtle (8% opacity)
            // ═══════════════════════════════════════════════════════════════
            
            // Fewer FVGs in Focus mode
            int maxFVG = FocusTradingMode ? 2 : 5;
            
            foreach (var fvg in _fairValueGaps.Take(maxFVG))
            {
                string tag = $"FVG_{fvg.BarIndex}";
                int barsAgo = CurrentBar - fvg.BarIndex;
                if (barsAgo < 0 || barsAgo >= CurrentBar) continue;
                if (barsAgo > MaxBarsVisibleForLabels) continue;

                bool isBull = fvg.Bias == BULLISH;
                
                // 8% opacity fill
                var fillColor = isBull 
                    ? new SolidColorBrush(Color.FromArgb(20, 63, 169, 165))   // #3FA9A5 at 8%
                    : new SolidColorBrush(Color.FromArgb(20, 209, 108, 108)); // #D16C6C at 8%
                fillColor.Freeze();
                
                Draw.Rectangle(this, tag, barsAgo, fvg.Top, 0, fvg.Bottom, fillColor);

                // CE line - subtle gray (not yellow to reduce colors)
                if (!FocusTradingMode)
                {
                    double ce = (fvg.Top + fvg.Bottom) / 2;
                    var ceColor = new SolidColorBrush(Color.FromArgb(80, 158, 158, 158)); // Gray 30%
                    ceColor.Freeze();
                    Draw.Line(this, $"{tag}_ce", barsAgo, ce, 0, ce, ceColor, DashStyleHelper.Dot, 1);
                    RegisterDrawnObject($"{tag}_ce");
                }

                RegisterDrawnObject(tag);
            }
        }

        private void DrawStrongWeakHL(double atr)
        {
            if (_trailing.Top == 0 || _trailing.Bottom == double.MaxValue) return;

            // LuxAlgo style: Clean labels for strong/weak highs and lows
            bool isHighStrong = _swingTrend == BEARISH;
            bool isLowStrong = _swingTrend == BULLISH;
            
            // Strong High - coral/red
            var highBrush = new SolidColorBrush(isHighStrong ? Color.FromArgb(200, 242, 87, 87) : Color.FromArgb(120, 242, 87, 87));
            highBrush.Freeze();
            string highLabel = isHighStrong ? "Strong High" : "Weak High";
            Draw.Line(this, "TrailingHigh", 200, _trailing.Top, 0, _trailing.Top, highBrush, DashStyleHelper.Dash, 1);
            Draw.Text(this, "TrailingHighLbl", highLabel, 3, _trailing.Top + atr * 0.08, highBrush);

            // Strong Low - teal/cyan
            var lowBrush = new SolidColorBrush(isLowStrong ? Color.FromArgb(200, 34, 211, 198) : Color.FromArgb(120, 34, 211, 198));
            lowBrush.Freeze();
            string lowLabel = isLowStrong ? "Strong Low" : "Weak Low";
            Draw.Line(this, "TrailingLow", 200, _trailing.Bottom, 0, _trailing.Bottom, lowBrush, DashStyleHelper.Dash, 1);
            Draw.Text(this, "TrailingLowLbl", lowLabel, 3, _trailing.Bottom - atr * 0.1, lowBrush);

            RegisterDrawnObject("TrailingHigh");
            RegisterDrawnObject("TrailingLow");
        }

        private void DrawPremiumDiscountZones(double atr)
        {
            if (_trailing.Top == 0 || _trailing.Bottom == double.MaxValue) return;

            double range = _trailing.Top - _trailing.Bottom;
            if (range <= 0) return;

            double equilibrium = _trailing.Bottom + range * 0.5;
            double premiumTop = _trailing.Top;
            double premiumBottom = equilibrium + range * 0.05; // Smaller premium zone starts above equilibrium
            double discountTop = equilibrium - range * 0.05;   // Smaller discount zone starts below equilibrium
            double discountBottom = _trailing.Bottom;

            // LuxAlgo style: Subtle gradient zones extending from equilibrium
            // Premium zone (above equilibrium) - soft red gradient
            var premiumBrush = new SolidColorBrush(Color.FromArgb(25, 255, 82, 82));
            premiumBrush.Freeze();
            Draw.Rectangle(this, "PremiumZone", 200, premiumTop, 0, equilibrium, premiumBrush);
            
            // Small "Premium" label at top right
            var premiumTextBrush = new SolidColorBrush(Color.FromArgb(180, 255, 82, 82));
            premiumTextBrush.Freeze();
            Draw.Text(this, "PremiumLbl", "Premium", 3, premiumTop - atr * 0.08, premiumTextBrush);

            // Equilibrium line - subtle gray dashed
            var eqBrush = new SolidColorBrush(Color.FromArgb(150, 158, 158, 158));
            eqBrush.Freeze();
            Draw.Line(this, "Equilibrium", 200, equilibrium, 0, equilibrium, eqBrush, DashStyleHelper.Dash, 1);
            Draw.Text(this, "EqLbl", "Equilibrium", 3, equilibrium + atr * 0.05, eqBrush);

            // Discount zone (below equilibrium) - soft teal/blue gradient
            var discountBrush = new SolidColorBrush(Color.FromArgb(25, 0, 188, 212));
            discountBrush.Freeze();
            Draw.Rectangle(this, "DiscountZone", 200, equilibrium, 0, discountBottom, discountBrush);
            
            // Small "Discount" label at bottom right
            var discountTextBrush = new SolidColorBrush(Color.FromArgb(180, 0, 188, 212));
            discountTextBrush.Freeze();
            Draw.Text(this, "DiscountLbl", "Discount", 3, discountBottom + atr * 0.08, discountTextBrush);

            RegisterDrawnObject("PremiumZone");
            RegisterDrawnObject("DiscountZone");
            RegisterDrawnObject("Equilibrium");
        }

        private void DrawReferenceLevels(double atr)
        {
            // LuxAlgo style: Subtle reference levels with clean labels
            
            if (_pdh > 0 && _pdl > 0)
            {
                // PDH/PDL - Gold/amber color, dashed lines
                var pdhBrush = new SolidColorBrush(Color.FromArgb(200, 255, 193, 7));
                pdhBrush.Freeze();
                
                Draw.Line(this, "PDH", 200, _pdh, 0, _pdh, pdhBrush, DashStyleHelper.Dash, 1);
                Draw.Line(this, "PDL", 200, _pdl, 0, _pdl, pdhBrush, DashStyleHelper.Dash, 1);
                Draw.Text(this, "PDHLbl", "PDH", 3, _pdh + atr * 0.05, pdhBrush);
                Draw.Text(this, "PDLLbl", "PDL", 3, _pdl - atr * 0.08, pdhBrush);
                RegisterDrawnObject("PDH");
                RegisterDrawnObject("PDL");
            }

            if (_asianHigh > 0 && _asianLow < double.MaxValue)
            {
                // Asian High/Low - Cyan color, subtle
                var ashBrush = new SolidColorBrush(Color.FromArgb(200, 0, 188, 212));
                ashBrush.Freeze();
                
                Draw.Line(this, "ASH", 200, _asianHigh, 0, _asianHigh, ashBrush, DashStyleHelper.Dot, 1);
                Draw.Line(this, "ASL", 200, _asianLow, 0, _asianLow, ashBrush, DashStyleHelper.Dot, 1);
                Draw.Text(this, "ASHLbl", "ASH", 3, _asianHigh + atr * 0.05, ashBrush);
                Draw.Text(this, "ASLLbl", "ASL", 3, _asianLow - atr * 0.08, ashBrush);
                RegisterDrawnObject("ASH");
                RegisterDrawnObject("ASL");
            }
        }

        #region ═══════════════════════════════════════════════════════════════
        //                     INFO PANEL
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        private void UpdateInfoPanel()
        {
            try
            {
                var sb = new System.Text.StringBuilder();
                
                // Mode indicator
                string modeIcon = _currentMode == DisplayMode.SMC ? "🔷" : 
                                 _currentMode == DisplayMode.Scalping ? "🎯" : 
                                 _currentMode == DisplayMode.Both ? "⚡" : "○";
                string modeName = _currentMode.ToString().ToUpper();

                sb.AppendLine("╔═══════════════════════════════════╗");
                sb.AppendLine($"║  {modeIcon} SOPHON26 [{modeName,-6}]        ║");
                sb.AppendLine("╠═══════════════════════════════════╣");
                sb.AppendLine($"║ {_currentInstrument ?? "N/A",-10}│ {Time[0]:HH:mm:ss}          ║");
                sb.AppendLine("╠═══════════════════════════════════╣");

                // HTF BIAS
                string biasIcon = _htfBias.Contains("BULL") ? "🟢" : _htfBias.Contains("BEAR") ? "🔴" : "🟡";
                sb.AppendLine($"║ HTF BIAS: {biasIcon} {_htfBias,-17}  ║");
                sb.AppendLine($"║ D:{_dailyBias} │ 4H:{_h4Bias} │ 1H:{_h1Bias} │ 15M:{_m15Bias}   ║");
                sb.AppendLine("╠═══════════════════════════════════╣");

                // STRUCTURE
                string structIcon = _localStructure == "BULLISH" ? "🟢" : _localStructure == "BEARISH" ? "🔴" : "⚪";
                string intTrend = _internalTrend == BULLISH ? "BULL" : _internalTrend == BEARISH ? "BEAR" : "—";
                sb.AppendLine($"║ Swing:    {structIcon} {_localStructure,-16}  ║");
                sb.AppendLine($"║ Internal: {intTrend,-21}  ║");
                sb.AppendLine("╠═══════════════════════════════════╣");

                // ZONES COUNT
                sb.AppendLine($"║ Int OB: {_internalOrderBlocks.Count,2} │ Swing OB: {_swingOrderBlocks.Count,2}    ║");
                sb.AppendLine($"║ FVG: {_fairValueGaps.Count,2} │ Labels: {_structureLabels.Count,2}           ║");
                
                // VOLUME PROFILE METRICS (DAFE)
                if (_currentProfile != null && ShowVolumeProfile)
                {
                    sb.AppendLine("╠═══════════════════════════════════╣");
                    sb.AppendLine("║ 📊 VOLUME PROFILE (DAFE)          ║");
                    sb.AppendLine($"║  POC:  {_currentProfile.POC,12:F2}           ║");
                    sb.AppendLine($"║  VAH:  {_currentProfile.VAH,12:F2}           ║");
                    sb.AppendLine($"║  VAL:  {_currentProfile.VAL,12:F2}           ║");
                    sb.AppendLine($"║  VWAP: {_currentProfile.VWAP,12:F2}           ║");
                    
                    // Delta Analysis
                    string deltaDir = _currentProfile.IsBuyDominant ? "◆ BUYERS" : "◇ SELLERS";
                    sb.AppendLine($"║  Delta: {_currentProfile.DeltaImbalance,+6:F1}% {deltaDir,-10} ║");
                    
                    // Entropy
                    string entropyLvl = _currentProfile.NormalizedEntropy < 0.5 ? "LOW" : 
                                       _currentProfile.NormalizedEntropy > 0.8 ? "HIGH" : "MED";
                    sb.AppendLine($"║  Entropy: {_currentProfile.NormalizedEntropy * 100,3:F0}% ({entropyLvl})          ║");
                    
                    // POC Dynamics
                    string pocDir = _currentProfile.POCDirection ?? "Neutral";
                    sb.AppendLine($"║  POC Dir: {pocDir,-10} Z:{_currentProfile.POCVelocityZScore,+5:F1}σ ║");
                    
                    // Regime
                    var regimeInfo = _liquidityModule?.GetMarketRegimeInfo(_currentInstrument);
                    if (regimeInfo != null)
                    {
                        sb.AppendLine("╠═══════════════════════════════════╣");
                        sb.AppendLine($"║ {regimeInfo.Name,-33} ║");
                    }
                    
                    // Bayesian AI
                    sb.AppendLine("╠═══════════════════════════════════╣");
                    sb.AppendLine("║ 🤖 BAYESIAN AI                    ║");
                    sb.AppendLine($"║  Bull: {_currentProfile.BullishConfidence * 100,5:F0}% │ Bear: {_currentProfile.BearishConfidence * 100,5:F0}%   ║");
                    sb.AppendLine($"║  Breakout: {_currentProfile.BreakoutProbability,3:F0}% {_currentProfile.BreakoutDirection,-12}  ║");
                    
                    // Institutional Score
                    string conviction = _currentProfile.ConvictionLevel ?? "—";
                    sb.AppendLine($"║  Score: {_currentProfile.CompositeScore,5:F0}/100 [{conviction}]     ║");
                    sb.AppendLine($"║  Risk: {_currentProfile.CompositeRiskScore,5:F0}%                   ║");
                }
                
                sb.AppendLine("╠═══════════════════════════════════╣");

                // REFERENCE LEVELS
                sb.AppendLine("║ 📍 KEY LEVELS                     ║");
                if (_pdh > 0) sb.AppendLine($"║  PDH: {_pdh,12:F2}              ║");
                if (_pdl > 0) sb.AppendLine($"║  PDL: {_pdl,12:F2}              ║");
                if (_trailing.Top > 0) sb.AppendLine($"║  High: {_trailing.Top,11:F2}              ║");
                if (_trailing.Bottom < double.MaxValue) sb.AppendLine($"║  Low: {_trailing.Bottom,12:F2}              ║");
                
                // SCALPING SIGNALS (Emmanuel)
                if (EnableScalping && _lastScalpingSignal != null)
                {
                    sb.AppendLine("╠═══════════════════════════════════╣");
                    sb.AppendLine("║ 🎯 SCALPING (Emmanuel)            ║");
                    
                    string dir = _lastScalpingSignal.IsLong ? "🟢 LONG" : "🔴 SHORT";
                    string patName = GetPatternShortName(_lastScalpingSignal.Pattern);
                    sb.AppendLine($"║  Signal: {dir} {patName,-14}  ║");
                    sb.AppendLine($"║  Entry:  {_lastScalpingSignal.EntryPrice,12:F2}           ║");
                    sb.AppendLine($"║  SL:     {_lastScalpingSignal.StopLoss,12:F2}           ║");
                    sb.AppendLine($"║  TP1:    {_lastScalpingSignal.TakeProfit1,12:F2}           ║");
                    sb.AppendLine($"║  Conf:   {_lastScalpingSignal.ConfluenceScore}/10 | WR:{_lastScalpingSignal.ExpectedWinRate:F0}%      ║");
                    
                    // R:R ratio
                    double rr = _lastScalpingSignal.RiskReward1;
                    sb.AppendLine($"║  R:R 1st TP: {rr:F1}x                  ║");
                }
                else if (EnableScalping)
                {
                    sb.AppendLine("╠═══════════════════════════════════╣");
                    sb.AppendLine("║ 🎯 SCALPING: Scanning...          ║");
                }
                
                sb.AppendLine("╠═══════════════════════════════════╣");

                // SESSION
                string session = GetSessionLabel();
                sb.AppendLine($"║ Session: {session,-23}  ║");
                sb.AppendLine("╚═══════════════════════════════════╝");

                TextPosition pos = InfoPanelPosition == PanelPosition.TopRight ? TextPosition.TopRight :
                    InfoPanelPosition == PanelPosition.TopLeft ? TextPosition.TopLeft :
                    InfoPanelPosition == PanelPosition.BottomRight ? TextPosition.BottomRight :
                    TextPosition.BottomLeft;

                Draw.TextFixed(this, "InfoPanel", sb.ToString(), pos,
                    Brushes.White, new SimpleFont("Consolas", FontSize),
                    Brushes.Transparent, Brushes.DarkSlateGray, 90);
            }
            catch { }
        }

        private string GetSessionLabel()
        {
            int hour = Time[0].Hour;
            if (hour >= 18 || hour < 2) return "ASIAN";
            if (hour >= 2 && hour < 8) return "LONDON";
            if (hour >= 8 && hour < 9) return "LONDON/PRE-NY";
            if (hour >= 9 && hour < 12) return "NY AM (KILLZONE)";
            if (hour >= 12 && hour < 16) return "NY PM";
            return "AFTER HOURS";
        }

        #region ═══════════════════════════════════════════════════════════════
        //                     UTILITIES
        // ═══════════════════════════════════════════════════════════════════
        #endregion

        private void RegisterDrawnObject(string tag)
        {
            if (_drawnObjects == null) _drawnObjects = new Dictionary<string, string>();
            if (!_drawnObjects.ContainsKey(tag))
                _drawnObjects[tag] = DateTime.Now.ToString("HHmmss");

            if (_drawnObjects.Count > 300)
            {
                var old = _drawnObjects.OrderBy(k => k.Value).Take(50).Select(k => k.Key).ToList();
                foreach (var k in old)
                {
                    RemoveDrawObject(k);
                    _drawnObjects.Remove(k);
                }
            }
        }

        private void CleanupDrawings()
        {
            if (_drawnObjects == null) return;
            foreach (var k in _drawnObjects.Keys.ToList())
                RemoveDrawObject(k);
            _drawnObjects.Clear();
        }
    }

    #region ═══════════════════════════════════════════════════════════════
    //                     SUPPORTING TYPES
    // ═══════════════════════════════════════════════════════════════════
    #endregion

    public enum PanelPosition { TopLeft, TopRight, BottomLeft, BottomRight }
    
    /// <summary>
    /// Display mode for Sophon26
    /// </summary>
    public enum DisplayMode
    {
        SMC,        // Only SMC elements (OB, FVG, BOS/CHoCH)
        Scalping,   // Only Scalping signals (Emmanuel patterns)
        Both,       // Both SMC and Scalping
        Clean       // Minimal - only key levels
    }
}
