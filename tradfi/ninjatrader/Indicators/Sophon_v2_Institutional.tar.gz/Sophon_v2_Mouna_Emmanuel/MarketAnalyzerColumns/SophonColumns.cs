#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.NinjaScript;
#endregion

// ═══════════════════════════════════════════════════════════════════════════════
// SOPHON MARKET ANALYZER COLUMNS v1.0 (Simplified)
// ═══════════════════════════════════════════════════════════════════════════════
//
// Basic columns for Market Analyzer
// Note: For full Sophon analysis, use the Sophon26 indicator on charts
//
// Copyright (c) 2026 Algosphere Quant - Emmanuel
// ═══════════════════════════════════════════════════════════════════════════════

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
    /// <summary>
    /// Simple price momentum column
    /// </summary>
    public class SophonMomentum : MarketAnalyzerColumn
    {
        private double _prevClose = 0;
        private double _momentum = 0;
        
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "Sophon Momentum - Price change percentage";
                Name = "Sophon Mom %";
                IsDataSeriesRequired = true;
            }
        }

        protected override void OnMarketData(MarketDataEventArgs marketDataUpdate)
        {
            if (marketDataUpdate.MarketDataType != MarketDataType.Last)
                return;
            
            double price = marketDataUpdate.Price;
            
            if (_prevClose > 0)
            {
                _momentum = ((price - _prevClose) / _prevClose) * 100;
                CurrentValue = Math.Round(_momentum, 2);
                
                // Color based on momentum
                if (_momentum > 0.5)
                    BackColor = Brushes.DarkGreen;
                else if (_momentum < -0.5)
                    BackColor = Brushes.DarkRed;
                else
                    BackColor = Brushes.Transparent;
            }
        }
        
        protected override void OnBarUpdate()
        {
            if (CurrentBar > 0)
                _prevClose = Close[1];
        }
    }
    
    /// <summary>
    /// Volume spike detection column
    /// </summary>
    public class SophonVolSpike : MarketAnalyzerColumn
    {
        private double _avgVolume = 0;
        private int _volCount = 0;
        private double _volRatio = 0;
        
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "Sophon Volume Spike - Volume relative to average";
                Name = "Sophon Vol";
                IsDataSeriesRequired = true;
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < 20) return;
            
            // Calculate 20-bar volume average
            double sumVol = 0;
            for (int i = 1; i <= 20; i++)
                sumVol += Volume[i];
            _avgVolume = sumVol / 20;
            
            if (_avgVolume > 0)
            {
                _volRatio = Volume[0] / _avgVolume;
                CurrentValue = Math.Round(_volRatio, 1);
                
                // Color based on volume spike
                if (_volRatio > 2.0)
                    BackColor = Brushes.Gold;
                else if (_volRatio > 1.5)
                    BackColor = Brushes.DarkOrange;
                else if (_volRatio > 1.2)
                    BackColor = Brushes.DarkCyan;
                else
                    BackColor = Brushes.Transparent;
            }
        }
    }
    
    /// <summary>
    /// Trend direction based on price vs moving averages
    /// </summary>
    public class SophonTrend : MarketAnalyzerColumn
    {
        private double _sma20 = 0;
        private double _sma50 = 0;
        private int _trendScore = 0;
        
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "Sophon Trend - Trend strength (-2 to +2)";
                Name = "Sophon Trend";
                IsDataSeriesRequired = true;
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < 50) return;
            
            // Calculate SMAs manually
            double sum20 = 0, sum50 = 0;
            for (int i = 0; i < 20; i++)
                sum20 += Close[i];
            _sma20 = sum20 / 20;
            
            for (int i = 0; i < 50; i++)
                sum50 += Close[i];
            _sma50 = sum50 / 50;
            
            double price = Close[0];
            _trendScore = 0;
            
            if (price > _sma20) _trendScore++;
            else if (price < _sma20) _trendScore--;
            
            if (price > _sma50) _trendScore++;
            else if (price < _sma50) _trendScore--;
            
            CurrentValue = _trendScore;
            
            // Color based on trend
            if (_trendScore >= 2)
                BackColor = Brushes.DarkGreen;
            else if (_trendScore <= -2)
                BackColor = Brushes.DarkRed;
            else if (_trendScore > 0)
                BackColor = Brushes.ForestGreen;
            else if (_trendScore < 0)
                BackColor = Brushes.IndianRed;
            else
                BackColor = Brushes.DarkGray;
        }
    }
    
    /// <summary>
    /// ATR percentage for volatility
    /// </summary>
    public class SophonATRPct : MarketAnalyzerColumn
    {
        private double _atrPct = 0;
        
        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "Sophon ATR% - Volatility as percentage of price";
                Name = "Sophon ATR%";
                IsDataSeriesRequired = true;
            }
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBar < 14) return;
            
            // Calculate ATR manually
            double sumTR = 0;
            for (int i = 0; i < 14; i++)
            {
                double high = High[i];
                double low = Low[i];
                double prevClose = i < CurrentBar ? Close[i + 1] : Close[i];
                
                double tr = Math.Max(high - low, Math.Max(Math.Abs(high - prevClose), Math.Abs(low - prevClose)));
                sumTR += tr;
            }
            
            double atr = sumTR / 14;
            double price = Close[0];
            
            if (price > 0)
            {
                _atrPct = (atr / price) * 100;
                CurrentValue = Math.Round(_atrPct, 2);
                
                // Color based on volatility
                if (_atrPct > 3.0)
                    BackColor = Brushes.DarkRed;
                else if (_atrPct > 2.0)
                    BackColor = Brushes.DarkOrange;
                else if (_atrPct > 1.0)
                    BackColor = Brushes.DarkCyan;
                else
                    BackColor = Brushes.Transparent;
            }
        }
    }
}
